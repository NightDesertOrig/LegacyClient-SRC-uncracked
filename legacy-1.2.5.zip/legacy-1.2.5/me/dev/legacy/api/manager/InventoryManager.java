package me.dev.legacy.api.manager;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import me.dev.legacy.api.util.Util;

public class InventoryManager implements Util
{
    public int currentPlayerItem;
    private int recoverySlot;
    
    public InventoryManager() {
        this.recoverySlot = -1;
    }
    
    public void update() {
        /*SL:12*/if (this.recoverySlot != -1) {
            InventoryManager.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:13*/(Packet)new CPacketHeldItemChange((this.recoverySlot == 8) ? 7 : (this.recoverySlot + 1)));
            InventoryManager.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:14*/(Packet)new CPacketHeldItemChange(this.recoverySlot));
            InventoryManager.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:15*/this.recoverySlot;
            final int v1 = InventoryManager.mc.field_71439_g.field_71071_by.field_70461_c;
            /*SL:17*/if (v1 != this.currentPlayerItem) {
                /*SL:18*/this.currentPlayerItem = v1;
                InventoryManager.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:19*/(Packet)new CPacketHeldItemChange(this.currentPlayerItem));
            }
            /*SL:21*/this.recoverySlot = -1;
        }
    }
    
    public void recoverSilent(final int a1) {
        /*SL:26*/this.recoverySlot = a1;
    }
}
