package me.dev.legacy.api.manager;

import java.util.ArrayList;
import me.dev.legacy.api.util.NoStackTraceThrowable;
import me.dev.legacy.api.util.DisplayUtil;
import me.dev.legacy.api.util.SystemUtil;
import me.dev.legacy.api.util.URLReader;
import java.util.List;

public class HWIDManager
{
    public static final String pastebinURL = "https://pastebin.com/raw/p5qX2zAQ";
    public static List<String> hwids;
    
    public static void hwidCheck() {
        HWIDManager.hwids = /*EL:23*/URLReader.readURL();
        final boolean v1 = HWIDManager.hwids.contains(/*EL:24*/SystemUtil.getSystemInfo());
        /*SL:25*/if (!v1) {
            /*SL:26*/DisplayUtil.Display();
            /*SL:27*/throw new NoStackTraceThrowable("");
        }
    }
    
    static {
        HWIDManager.hwids = new ArrayList<String>();
    }
}
