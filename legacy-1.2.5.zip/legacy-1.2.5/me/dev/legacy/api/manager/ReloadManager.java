package me.dev.legacy.api.manager;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.Legacy;
import net.minecraft.network.play.client.CPacketChatMessage;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.AbstractModule;

public class ReloadManager extends AbstractModule
{
    public String prefix;
    
    public void init(final String a1) {
        /*SL:17*/this.prefix = a1;
        MinecraftForge.EVENT_BUS.register(/*EL:18*/(Object)this);
        /*SL:19*/if (!AbstractModule.fullNullCheck()) {
            /*SL:20*/Command.sendMessage(ChatFormatting.RED + "Legacy has been unloaded. Type " + a1 + "reload to reload.");
        }
    }
    
    public void unload() {
        MinecraftForge.EVENT_BUS.unregister(/*EL:25*/(Object)this);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v2) {
        final CPacketChatMessage a1;
        /*SL:31*/if (v2.getPacket() instanceof CPacketChatMessage && (a1 = (CPacketChatMessage)v2.getPacket()).func_149439_c().startsWith(this.prefix) && a1.func_149439_c().contains("reload")) {
            /*SL:32*/Legacy.load();
            /*SL:33*/v2.setCanceled(true);
        }
    }
}
