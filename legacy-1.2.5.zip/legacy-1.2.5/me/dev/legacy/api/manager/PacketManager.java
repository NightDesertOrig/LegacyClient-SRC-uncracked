package me.dev.legacy.api.manager;

import java.util.ArrayList;
import net.minecraft.network.Packet;
import java.util.List;
import me.dev.legacy.api.AbstractModule;

public class PacketManager extends AbstractModule
{
    private final List<Packet<?>> noEventPackets;
    
    public PacketManager() {
        this.noEventPackets = new ArrayList<Packet<?>>();
    }
    
    public void sendPacketNoEvent(final Packet<?> a1) {
        /*SL:14*/if (a1 != null && !AbstractModule.nullCheck()) {
            /*SL:15*/this.noEventPackets.add(a1);
            PacketManager.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:16*/(Packet)a1);
        }
    }
    
    public boolean shouldSendPacket(final Packet<?> a1) {
        /*SL:21*/if (this.noEventPackets.contains(a1)) {
            /*SL:22*/this.noEventPackets.remove(a1);
            /*SL:23*/return false;
        }
        /*SL:25*/return true;
    }
}
