package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import me.dev.legacy.api.util.EntityUtil;
import java.awt.Color;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.modules.client.ClickGui;
import org.lwjgl.opengl.GL11;
import me.dev.legacy.api.event.events.render.RenderEntityModelEvent;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import me.dev.legacy.modules.render.CrystalChams;
import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBase;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ RenderEnderCrystal.class })
public class MixinRenderEnderCrystal
{
    @Shadow
    @Final
    private static ResourceLocation field_110787_a;
    private static final ResourceLocation glint;
    
    @Redirect(method = { "doRender" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
    public void renderModelBaseHook(final ModelBase v2, final Entity v3, final float v4, final float v5, final float v6, final float v7, final float v8, final float v9) {
        /*SL:32*/if (CrystalChams.INSTANCE.isEnabled()) {
            /*SL:33*/if (CrystalChams.INSTANCE.animateScale.getValue() && CrystalChams.INSTANCE.scaleMap.containsKey(v3)) {
                /*SL:34*/GlStateManager.func_179152_a((float)CrystalChams.INSTANCE.scaleMap.get(v3), (float)CrystalChams.INSTANCE.scaleMap.get(v3), (float)CrystalChams.INSTANCE.scaleMap.get(v3));
            }
            else {
                /*SL:36*/GlStateManager.func_179152_a((float)CrystalChams.INSTANCE.scale.getValue(), (float)CrystalChams.INSTANCE.scale.getValue(), (float)CrystalChams.INSTANCE.scale.getValue());
            }
        }
        /*SL:39*/if (CrystalChams.INSTANCE.isEnabled() && CrystalChams.INSTANCE.wireframe.getValue()) {
            final RenderEntityModelEvent a1 = /*EL:40*/new RenderEntityModelEvent(0, v2, v3, v4, v5, v6, v7, v8, v9);
            CrystalChams.INSTANCE.onRenderModel(/*EL:41*/a1);
        }
        /*SL:43*/if (CrystalChams.INSTANCE.isEnabled() && CrystalChams.INSTANCE.chams.getValue()) {
            /*SL:44*/GL11.glPushAttrib(1048575);
            /*SL:45*/GL11.glDisable(3008);
            /*SL:46*/GL11.glDisable(3553);
            /*SL:47*/GL11.glDisable(2896);
            /*SL:48*/GL11.glEnable(3042);
            /*SL:49*/GL11.glBlendFunc(770, 771);
            /*SL:50*/GL11.glLineWidth(1.5f);
            /*SL:51*/GL11.glEnable(2960);
            /*SL:52*/if (CrystalChams.INSTANCE.rainbow.getValue()) {
                final Color a2 = CrystalChams.INSTANCE.colorSync.getValue() ? /*EL:53*/ClickGui.getInstance().getCurrentColor() : new Color(RenderUtil.getRainbow(CrystalChams.INSTANCE.speed.getValue() * 100, 0, CrystalChams.INSTANCE.saturation.getValue() / 100.0f, CrystalChams.INSTANCE.brightness.getValue() / 100.0f));
                final Color a3 = /*EL:54*/EntityUtil.getColor(v3, a2.getRed(), a2.getGreen(), a2.getBlue(), CrystalChams.INSTANCE.alpha.getValue(), true);
                /*SL:55*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:56*/GL11.glDisable(2929);
                    /*SL:57*/GL11.glDepthMask(false);
                }
                /*SL:59*/GL11.glEnable(10754);
                /*SL:60*/GL11.glColor4f(a3.getRed() / 255.0f, a3.getGreen() / 255.0f, a3.getBlue() / 255.0f, CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                /*SL:61*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
                /*SL:62*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:63*/GL11.glEnable(2929);
                    /*SL:64*/GL11.glDepthMask(true);
                }
            }
            else/*SL:66*/ if (CrystalChams.INSTANCE.xqz.getValue() && CrystalChams.INSTANCE.throughWalls.getValue()) {
                final Color a4 = CrystalChams.INSTANCE.colorSync.getValue() ? /*EL:68*/EntityUtil.getColor(v3, CrystalChams.INSTANCE.hiddenRed.getValue(), CrystalChams.INSTANCE.hiddenGreen.getValue(), CrystalChams.INSTANCE.hiddenBlue.getValue(), CrystalChams.INSTANCE.hiddenAlpha.getValue(), true) : EntityUtil.getColor(v3, CrystalChams.INSTANCE.hiddenRed.getValue(), CrystalChams.INSTANCE.hiddenGreen.getValue(), CrystalChams.INSTANCE.hiddenBlue.getValue(), CrystalChams.INSTANCE.hiddenAlpha.getValue(), true);
                final Color a6;
                final Color a5 = /*EL:69*/a6 = (CrystalChams.INSTANCE.colorSync.getValue() ? EntityUtil.getColor(v3, CrystalChams.INSTANCE.red.getValue(), CrystalChams.INSTANCE.green.getValue(), CrystalChams.INSTANCE.blue.getValue(), CrystalChams.INSTANCE.alpha.getValue(), true) : EntityUtil.getColor(v3, CrystalChams.INSTANCE.red.getValue(), CrystalChams.INSTANCE.green.getValue(), CrystalChams.INSTANCE.blue.getValue(), CrystalChams.INSTANCE.alpha.getValue(), true));
                /*SL:70*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:71*/GL11.glDisable(2929);
                    /*SL:72*/GL11.glDepthMask(false);
                }
                /*SL:74*/GL11.glEnable(10754);
                /*SL:75*/GL11.glColor4f(a4.getRed() / 255.0f, a4.getGreen() / 255.0f, a4.getBlue() / 255.0f, CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                /*SL:76*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
                /*SL:77*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:78*/GL11.glEnable(2929);
                    /*SL:79*/GL11.glDepthMask(true);
                }
                /*SL:81*/GL11.glColor4f(a5.getRed() / 255.0f, a5.getGreen() / 255.0f, a5.getBlue() / 255.0f, CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                /*SL:82*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
            }
            else {
                final Color a8;
                final Color a7 = /*EL:85*/a8 = (CrystalChams.INSTANCE.colorSync.getValue() ? ClickGui.getInstance().getCurrentColor() : EntityUtil.getColor(v3, CrystalChams.INSTANCE.red.getValue(), CrystalChams.INSTANCE.green.getValue(), CrystalChams.INSTANCE.blue.getValue(), CrystalChams.INSTANCE.alpha.getValue(), true));
                /*SL:86*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:87*/GL11.glDisable(2929);
                    /*SL:88*/GL11.glDepthMask(false);
                }
                /*SL:90*/GL11.glEnable(10754);
                /*SL:91*/GL11.glColor4f(a7.getRed() / 255.0f, a7.getGreen() / 255.0f, a7.getBlue() / 255.0f, CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                /*SL:92*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
                /*SL:93*/if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    /*SL:94*/GL11.glEnable(2929);
                    /*SL:95*/GL11.glDepthMask(true);
                }
            }
            /*SL:98*/GL11.glEnable(3042);
            /*SL:99*/GL11.glEnable(2896);
            /*SL:100*/GL11.glEnable(3553);
            /*SL:101*/GL11.glEnable(3008);
            /*SL:102*/GL11.glPopAttrib();
            /*SL:103*/if (CrystalChams.INSTANCE.glint.getValue()) {
                /*SL:104*/GL11.glDisable(2929);
                /*SL:105*/GL11.glDepthMask(false);
                /*SL:106*/GlStateManager.func_179141_d();
                /*SL:107*/GlStateManager.func_179131_c(1.0f, 0.0f, 0.0f, 0.13f);
                /*SL:108*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
                /*SL:109*/GlStateManager.func_179118_c();
                /*SL:110*/GL11.glEnable(2929);
                /*SL:111*/GL11.glDepthMask(true);
            }
        }
        else {
            /*SL:114*/v2.func_78088_a(v3, v4, v5, v6, v7, v8, v9);
        }
        /*SL:116*/if (CrystalChams.INSTANCE.isEnabled()) {
            /*SL:117*/if (CrystalChams.INSTANCE.animateScale.getValue() && CrystalChams.INSTANCE.scaleMap.containsKey(v3)) {
                /*SL:118*/GlStateManager.func_179152_a(1.0f / CrystalChams.INSTANCE.scaleMap.get(v3), 1.0f / CrystalChams.INSTANCE.scaleMap.get(v3), 1.0f / CrystalChams.INSTANCE.scaleMap.get(v3));
            }
            else {
                /*SL:120*/GlStateManager.func_179152_a(1.0f / CrystalChams.INSTANCE.scale.getValue(), 1.0f / CrystalChams.INSTANCE.scale.getValue(), 1.0f / CrystalChams.INSTANCE.scale.getValue());
            }
        }
    }
    
    static {
        glint = new ResourceLocation("textures/glint.png");
    }
}
