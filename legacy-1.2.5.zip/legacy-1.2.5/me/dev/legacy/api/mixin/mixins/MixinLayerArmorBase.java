package me.dev.legacy.api.mixin.mixins;

import net.minecraft.inventory.EntityEquipmentSlot;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.render.NoRender;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ LayerArmorBase.class })
public class MixinLayerArmorBase
{
    @Inject(method = { "doRenderLayer" }, at = { @At("HEAD") }, cancellable = true)
    public void doRenderLayer(final EntityLivingBase a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8, final CallbackInfo a9) {
        /*SL:17*/if (NoRender.getInstance().isEnabled() && NoRender.getInstance().noArmor.getValue() == NoRender.NoArmor.ALL) {
            /*SL:18*/a9.cancel();
        }
    }
    
    @Inject(method = { "renderArmorLayer" }, at = { @At("HEAD") }, cancellable = true)
    public void renderArmorLayer(final EntityLivingBase a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8, final EntityEquipmentSlot a9, final CallbackInfo a10) {
        /*SL:24*/if (NoRender.getInstance().isEnabled() && NoRender.getInstance().noArmor.getValue() == NoRender.NoArmor.HELMET && a9 == EntityEquipmentSlot.HEAD) {
            /*SL:25*/a10.cancel();
        }
    }
}
