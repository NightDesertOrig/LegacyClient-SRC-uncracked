package me.dev.legacy.api.event;

import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.AbstractModule;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class ClientEvent extends EventStage
{
    private AbstractModule feature;
    private Setting setting;
    
    public ClientEvent(final int a1, final AbstractModule a2) {
        super(a1);
        this.feature = a2;
    }
    
    public ClientEvent(final Setting a1) {
        super(2);
        this.setting = a1;
    }
    
    public AbstractModule getFeature() {
        /*SL:24*/return this.feature;
    }
    
    public Setting getSetting() {
        /*SL:28*/return this.setting;
    }
    
    public Setting getProperty() {
        /*SL:32*/return this.setting;
    }
}
