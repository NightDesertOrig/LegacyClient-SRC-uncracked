package me.dev.legacy.api.event.events.event;

public enum EventPriority
{
    HIGH, 
    NONE, 
    LOW;
}
