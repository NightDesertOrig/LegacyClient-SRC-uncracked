package me.dev.legacy.api.event.events.other;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class Packet extends Event
{
    private Object packet;
    private Type type;
    
    public Packet(final Object a1, final Type a2) {
        this.packet = a1;
        this.type = a2;
    }
    
    public void setPacket(final Object a1) {
        /*SL:18*/this.packet = a1;
    }
    
    public void setType(final Type a1) {
        /*SL:22*/this.type = a1;
    }
    
    public Object getPacket() {
        /*SL:26*/return this.packet;
    }
    
    public Type getType() {
        /*SL:30*/return this.type;
    }
    
    public enum Type
    {
        INCOMING, 
        OUTGOING;
    }
}
