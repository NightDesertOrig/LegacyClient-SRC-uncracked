package me.dev.legacy.api.event.events.render;

import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBase;
import me.dev.legacy.api.event.EventStage;

public class RenderEntityModelEvent extends EventStage
{
    public ModelBase modelBase;
    public Entity entity;
    public float limbSwing;
    public float limbSwingAmount;
    public float age;
    public float headYaw;
    public float headPitch;
    public float scale;
    
    public RenderEntityModelEvent(final int a1, final ModelBase a2, final Entity a3, final float a4, final float a5, final float a6, final float a7, final float a8, final float a9) {
        super(a1);
        this.modelBase = a2;
        this.entity = a3;
        this.limbSwing = a4;
        this.limbSwingAmount = a5;
        this.age = a6;
        this.headYaw = a7;
        this.headPitch = a8;
        this.scale = a9;
    }
}
