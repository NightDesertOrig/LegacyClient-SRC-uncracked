package me.dev.legacy.api.event.events.misc;

import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.event.EventStage;

public class TotemPopEvent extends EventStage
{
    private final EntityPlayer entity;
    
    public TotemPopEvent(final EntityPlayer a1) {
        this.entity = a1;
    }
    
    public EntityPlayer getEntity() {
        /*SL:15*/return this.entity;
    }
}
