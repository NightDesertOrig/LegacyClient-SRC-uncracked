package me.dev.legacy.api.event.events.move;

import net.minecraft.entity.MoverType;
import me.dev.legacy.api.event.EventStage;

public class PlayerMoveEvent extends EventStage
{
    private MoverType type;
    private double x;
    private double y;
    private double z;
    
    public PlayerMoveEvent(final MoverType a1, final double a2, final double a3, final double a4) {
        this.type = a1;
        this.x = a2;
        this.y = a3;
        this.z = a4;
    }
    
    public MoverType getType() {
        /*SL:22*/return this.type;
    }
    
    public void setType(final MoverType a1) {
        /*SL:26*/this.type = a1;
    }
    
    public double getX() {
        /*SL:30*/return this.x;
    }
    
    public double getY() {
        /*SL:34*/return this.y;
    }
    
    public double getZ() {
        /*SL:38*/return this.z;
    }
    
    public void setX(final double a1) {
        /*SL:42*/this.x = a1;
    }
    
    public void setY(final double a1) {
        /*SL:46*/this.y = a1;
    }
    
    public void setZ(final double a1) {
        /*SL:50*/this.z = a1;
    }
}
