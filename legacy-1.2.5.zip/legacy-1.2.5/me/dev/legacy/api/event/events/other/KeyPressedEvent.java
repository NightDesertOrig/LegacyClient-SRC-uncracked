package me.dev.legacy.api.event.events.other;

import me.dev.legacy.api.event.EventStage;

public class KeyPressedEvent extends EventStage
{
    public boolean info;
    public boolean pressed;
    
    public KeyPressedEvent(final boolean a1, final boolean a2) {
        this.info = a1;
        this.pressed = a2;
    }
}
