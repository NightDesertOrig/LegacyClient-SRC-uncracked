package me.dev.legacy.api.event.events.chat;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class ChatEvent extends EventStage
{
    private final String msg;
    
    public ChatEvent(final String a1) {
        this.msg = a1;
    }
    
    public String getMsg() {
        /*SL:16*/return this.msg;
    }
}
