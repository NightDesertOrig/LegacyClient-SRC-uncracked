package me.dev.legacy.api.event.events.move;

import net.minecraft.entity.MoverType;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class MoveEvent extends EventStage
{
    private MoverType type;
    private double x;
    private double y;
    private double z;
    private double motionX;
    private double motionY;
    private double motionZ;
    
    public MoveEvent(final int a1, final MoverType a2, final double a3, final double a4, final double a5) {
        super(a1);
        this.type = a2;
        this.x = a3;
        this.y = a4;
        this.z = a5;
    }
    
    public final double getMotionX() {
        /*SL:27*/return this.motionX;
    }
    
    public final double getMotionY() {
        /*SL:31*/return this.motionY;
    }
    
    public final double getMotionZ() {
        /*SL:35*/return this.motionZ;
    }
    
    public void setMotionX(final double a1) {
        /*SL:39*/this.motionX = a1;
    }
    
    public void setMotionY(final double a1) {
        /*SL:43*/this.motionY = a1;
    }
    
    public void setMotionZ(final double a1) {
        /*SL:47*/this.motionZ = a1;
    }
    
    public MoverType getType() {
        /*SL:50*/return this.type;
    }
    
    public void setType(final MoverType a1) {
        /*SL:54*/this.type = a1;
    }
    
    public double getX() {
        /*SL:58*/return this.x;
    }
    
    public void setX(final double a1) {
        /*SL:62*/this.x = a1;
    }
    
    public double getY() {
        /*SL:66*/return this.y;
    }
    
    public void setY(final double a1) {
        /*SL:70*/this.y = a1;
    }
    
    public double getZ() {
        /*SL:74*/return this.z;
    }
    
    public void setZ(final double a1) {
        /*SL:78*/this.z = a1;
    }
}
