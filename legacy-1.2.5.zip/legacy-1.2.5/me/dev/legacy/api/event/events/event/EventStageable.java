package me.dev.legacy.api.event.events.event;

public class EventStageable
{
    private EventStage stage;
    
    public EventStageable() {
    }
    
    public EventStageable(final EventStage a1) {
        this.stage = a1;
    }
    
    public EventStage getStage() {
        /*SL:16*/return this.stage;
    }
    
    public void setStage(final EventStage a1) {
        /*SL:20*/this.stage = a1;
    }
    
    public enum EventStage
    {
        PRE, 
        POST;
    }
}
