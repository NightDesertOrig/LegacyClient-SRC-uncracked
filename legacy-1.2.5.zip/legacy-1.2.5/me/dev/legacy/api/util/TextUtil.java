package me.dev.legacy.api.util;

import java.util.Random;
import java.util.regex.Pattern;

public class TextUtil
{
    public static final String SECTIONSIGN = "�";
    private static final Pattern STRIP_COLOR_PATTERN;
    public static final String BLACK = "�0";
    public static final String DARK_BLUE = "�1";
    public static final String DARK_GREEN = "�2";
    public static final String DARK_AQUA = "�3";
    public static final String DARK_RED = "�4";
    public static final String DARK_PURPLE = "�5";
    public static final String GOLD = "�6";
    public static final String GRAY = "�7";
    public static final String DARK_GRAY = "�8";
    public static final String BLUE = "�9";
    public static final String GREEN = "�a";
    public static final String AQUA = "�b";
    public static final String RED = "�c";
    public static final String LIGHT_PURPLE = "�d";
    public static final String YELLOW = "�e";
    public static final String WHITE = "�f";
    public static final String OBFUSCATED = "�k";
    public static final String BOLD = "�l";
    public static final String STRIKE = "�m";
    public static final String UNDERLINE = "�n";
    public static final String ITALIC = "�o";
    public static final String RESET = "�r";
    public static final String RAINBOW = "�+";
    public static final String blank = " \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592";
    public static final String line1 = " \u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588";
    public static final String line2 = " \u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592";
    public static final String line3 = " \u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588";
    public static final String line4 = " \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\u2592\u2588";
    public static final String line5 = " \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588";
    public static final String pword = "  \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\n \u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\n \u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\n \u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\n \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\u2592\u2588\n \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\n \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592";
    public static String shrug;
    private static final Random rand;
    
    public static String stripColor(final String a1) {
        /*SL:43*/if (a1 == null) {
            /*SL:44*/return null;
        }
        /*SL:46*/return TextUtil.STRIP_COLOR_PATTERN.matcher(a1).replaceAll("");
    }
    
    public static String coloredString(final String a1, final Color a2) {
        String v1 = /*EL:50*/a1;
        /*SL:51*/switch (a2) {
            case AQUA: {
                /*SL:53*/v1 = "�b" + v1 + "�r";
                /*SL:54*/break;
            }
            case WHITE: {
                /*SL:57*/v1 = "�f" + v1 + "�r";
                /*SL:58*/break;
            }
            case BLACK: {
                /*SL:61*/v1 = "�0" + v1 + "�r";
                /*SL:62*/break;
            }
            case DARK_BLUE: {
                /*SL:65*/v1 = "�1" + v1 + "�r";
                /*SL:66*/break;
            }
            case DARK_GREEN: {
                /*SL:69*/v1 = "�2" + v1 + "�r";
                /*SL:70*/break;
            }
            case DARK_AQUA: {
                /*SL:73*/v1 = "�3" + v1 + "�r";
                /*SL:74*/break;
            }
            case DARK_RED: {
                /*SL:77*/v1 = "�4" + v1 + "�r";
                /*SL:78*/break;
            }
            case DARK_PURPLE: {
                /*SL:81*/v1 = "�5" + v1 + "�r";
                /*SL:82*/break;
            }
            case GOLD: {
                /*SL:85*/v1 = "�6" + v1 + "�r";
                /*SL:86*/break;
            }
            case DARK_GRAY: {
                /*SL:89*/v1 = "�8" + v1 + "�r";
                /*SL:90*/break;
            }
            case GRAY: {
                /*SL:93*/v1 = "�7" + v1 + "�r";
                /*SL:94*/break;
            }
            case BLUE: {
                /*SL:97*/v1 = "�9" + v1 + "�r";
                /*SL:98*/break;
            }
            case RED: {
                /*SL:101*/v1 = "�c" + v1 + "�r";
                /*SL:102*/break;
            }
            case GREEN: {
                /*SL:105*/v1 = "�a" + v1 + "�r";
                /*SL:106*/break;
            }
            case LIGHT_PURPLE: {
                /*SL:109*/v1 = "�d" + v1 + "�r";
                /*SL:110*/break;
            }
            case YELLOW: {
                /*SL:113*/v1 = "�e" + v1 + "�r";
                break;
            }
        }
        /*SL:117*/return v1;
    }
    
    public static String cropMaxLengthMessage(final String a1, final int a2) {
        String v1 = /*EL:122*/"";
        /*SL:123*/if (a1.length() >= 256 - a2) {
            /*SL:124*/v1 = a1.substring(0, 256 - a2);
        }
        /*SL:126*/return v1;
    }
    
    static {
        STRIP_COLOR_PATTERN = Pattern.compile("(?i)" + String.valueOf("�") + "[0-9A-FK-OR]");
        TextUtil.shrug = "?\\_(\u30c4)_/?";
        rand = new Random();
    }
    
    public enum Color
    {
        NONE, 
        WHITE, 
        BLACK, 
        DARK_BLUE, 
        DARK_GREEN, 
        DARK_AQUA, 
        DARK_RED, 
        DARK_PURPLE, 
        GOLD, 
        GRAY, 
        DARK_GRAY, 
        BLUE, 
        GREEN, 
        AQUA, 
        RED, 
        LIGHT_PURPLE, 
        YELLOW;
    }
}
