package me.dev.legacy.api.util;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import me.dev.legacy.api.mixin.mixins.IEntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import java.awt.Color;
import net.minecraft.util.MovementInput;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import java.util.Objects;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import java.util.Collections;
import java.util.Collection;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockTallGrass;
import java.util.ArrayList;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityPigZombie;
import java.util.List;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.potion.Potion;
import net.minecraft.client.Minecraft;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.init.MobEffects;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.util.CombatRules;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import me.dev.legacy.Legacy;
import java.util.Iterator;
import me.dev.legacy.modules.player.Blink;
import me.dev.legacy.modules.player.FakePlayer;
import me.dev.legacy.modules.player.Freecam;
import net.minecraft.world.World;
import net.minecraft.world.Explosion;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.EnumHand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public class EntityUtil implements Util
{
    public static final Vec3d[] antiDropOffsetList;
    public static final Vec3d[] platformOffsetList;
    public static final Vec3d[] legOffsetList;
    public static final Vec3d[] OffsetList;
    public static final Vec3d[] antiStepOffsetList;
    public static final Vec3d[] antiScaffoldOffsetList;
    public static final Vec3d[] doubleLegOffsetList;
    
    public static void attackEntity(final Entity a1, final boolean a2, final boolean a3) {
        /*SL:57*/if (a2) {
            EntityUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:58*/(Packet)new CPacketUseEntity(a1));
        }
        else {
            EntityUtil.mc.field_71442_b.func_78764_a((EntityPlayer)EntityUtil.mc.field_71439_g, /*EL:60*/a1);
        }
        /*SL:62*/if (a3) {
            EntityUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
    }
    
    public static double getRelativeX(final float a1) {
        /*SL:68*/return MathHelper.func_76126_a(-a1 * 0.017453292f);
    }
    
    public static double getRelativeZ(final float a1) {
        /*SL:72*/return MathHelper.func_76134_b(a1 * 0.017453292f);
    }
    
    public static float calculate(final double a1, final double a2, final double a3, final EntityLivingBase a4) {
        final double v1 = /*EL:76*/a4.func_70011_f(a1, a2, a3) / 12.0;
        final Vec3d v2 = /*EL:77*/new Vec3d(a1, a2, a3);
        final double v3 = getBlockDensity(/*EL:78*/v2, a4.func_174813_aQ());
        final double v4 = /*EL:79*/(1.0 - v1) * v3;
        final float v5 = /*EL:80*/(int)((v4 * v4 + v4) / 2.0 * 7.0 * 12.0 + 1.0);
        /*SL:81*/return getBlastReduction(a4, getDamageMultiplied(v5), new Explosion((World)EntityUtil.mc.field_71441_e, (Entity)null, a1, a2, a3, 6.0f, false, true));
    }
    
    public static EntityPlayer getClosestPlayer(final float v-5) {
        EntityPlayer entityPlayer = /*EL:85*/null;
        double n = /*EL:86*/999.0;
        /*SL:88*/for (int size = EntityUtil.mc.field_71441_e.field_73010_i.size(), v0 = 0; v0 < size; ++v0) {
            final EntityPlayer v = EntityUtil.mc.field_71441_e.field_73010_i.get(/*EL:89*/v0);
            /*SL:90*/if (isPlayerValid(v, v-5)) {
                final double a1 = EntityUtil.mc.field_71439_g.func_70068_e(/*EL:91*/(Entity)v);
                /*SL:92*/if (n == 999.0 || a1 < n) {
                    /*SL:93*/n = a1;
                    /*SL:94*/entityPlayer = v;
                }
            }
        }
        /*SL:98*/return entityPlayer;
    }
    
    public static boolean isFakePlayer(final EntityPlayer v1) {
        final Freecam v2 = /*EL:102*/Freecam.getInstance();
        final FakePlayer v3 = /*EL:103*/FakePlayer.getInstance();
        final Blink v4 = /*EL:104*/Blink.getInstance();
        final int v5 = /*EL:105*/v1.func_145782_y();
        /*SL:106*/if (v2.isOn() && v5 == 69420) {
            /*SL:107*/return true;
        }
        /*SL:109*/if (v3.isOn()) {
            /*SL:110*/for (final int a1 : v3.fakePlayerIdList) {
                /*SL:111*/if (a1 == v5) {
                    /*SL:112*/return true;
                }
            }
        }
        /*SL:116*/return v4.isOn() && v5 == 6942069;
    }
    
    public static boolean isPlayerValid(final EntityPlayer a1, final float a2) {
        /*SL:120*/return a1 != EntityUtil.mc.field_71439_g && EntityUtil.mc.field_71439_g.func_70032_d((Entity)a1) < a2 && !isDead((Entity)a1) && !Legacy.friendManager.isFriend(a1.func_70005_c_());
    }
    
    private static float getBlastReduction(final EntityLivingBase v-6, final float v-5, final Explosion v-4) {
        /*SL:125*/if (v-6 instanceof EntityPlayer) {
            final EntityPlayer a1 = /*EL:126*/(EntityPlayer)v-6;
            final DamageSource a2 = /*EL:127*/DamageSource.func_94539_a(v-4);
            float n = /*EL:128*/CombatRules.func_189427_a(v-5, (float)a1.func_70658_aO(), (float)a1.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
            final int a3 = /*EL:129*/EnchantmentHelper.func_77508_a(a1.func_184193_aE(), a2);
            final float v1 = /*EL:130*/MathHelper.func_76131_a((float)a3, 0.0f, 20.0f);
            /*SL:131*/n *= 1.0f - v1 / 25.0f;
            /*SL:132*/if (v-6.func_70644_a(MobEffects.field_76429_m)) {
                /*SL:133*/n -= n / 4.0f;
            }
            /*SL:135*/return n;
        }
        float n = /*EL:137*/CombatRules.func_189427_a(v-5, (float)v-6.func_70658_aO(), (float)v-6.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
        /*SL:138*/return n;
    }
    
    private static float getDamageMultiplied(final float a1) {
        final int v1 = EntityUtil.mc.field_71441_e.func_175659_aa().func_151525_a();
        /*SL:143*/return a1 * ((v1 == 0) ? 0.0f : ((v1 == 2) ? 1.0f : ((v1 == 1) ? 0.5f : 1.5f)));
    }
    
    public static float getBlockDensity(final Vec3d v-20, final AxisAlignedBB v-19) {
        final double n = /*EL:147*/1.0 / ((v-19.field_72336_d - v-19.field_72340_a) * 2.0 + 1.0);
        final double n2 = /*EL:148*/1.0 / ((v-19.field_72337_e - v-19.field_72338_b) * 2.0 + 1.0);
        final double n3 = /*EL:149*/1.0 / ((v-19.field_72334_f - v-19.field_72339_c) * 2.0 + 1.0);
        final double n4 = /*EL:150*/(1.0 - Math.floor(1.0 / n) * n) / 2.0;
        final double n5 = /*EL:151*/(1.0 - Math.floor(1.0 / n3) * n3) / 2.0;
        /*SL:153*/if (n >= 0.0 && n2 >= 0.0 && n3 >= 0.0) {
            int n6 = /*EL:154*/0;
            int n7 = /*EL:155*/0;
            /*SL:157*/for (float n8 = 0.0f; n8 <= 1.0f; n8 += (float)n) {
                /*SL:158*/for (float n9 = 0.0f; n9 <= 1.0f; n9 += (float)n2) {
                    /*SL:159*/for (float n10 = 0.0f; n10 <= 1.0f; n10 += (float)n3) {
                        final double a1 = /*EL:160*/v-19.field_72340_a + (v-19.field_72336_d - v-19.field_72340_a) * n8;
                        final double a2 = /*EL:161*/v-19.field_72338_b + (v-19.field_72337_e - v-19.field_72338_b) * n9;
                        final double v1 = /*EL:162*/v-19.field_72339_c + (v-19.field_72334_f - v-19.field_72339_c) * n10;
                        /*SL:164*/if (rayTraceBlocks(new Vec3d(a1 + n4, a2, v1 + n5), v-20) == null) {
                            /*SL:165*/++n6;
                        }
                        /*SL:168*/++n7;
                    }
                }
            }
            /*SL:173*/return n6 / n7;
        }
        /*SL:175*/return 0.0f;
    }
    
    public static RayTraceResult rayTraceBlocks(Vec3d v-17, final Vec3d v-16) {
        final int func_76128_c = /*EL:180*/MathHelper.func_76128_c(v-16.field_72450_a);
        final int func_76128_c2 = /*EL:181*/MathHelper.func_76128_c(v-16.field_72448_b);
        final int func_76128_c3 = /*EL:182*/MathHelper.func_76128_c(v-16.field_72449_c);
        int func_76128_c4 = /*EL:183*/MathHelper.func_76128_c(v-17.field_72450_a);
        int func_76128_c5 = /*EL:184*/MathHelper.func_76128_c(v-17.field_72448_b);
        int func_76128_c6 = /*EL:185*/MathHelper.func_76128_c(v-17.field_72449_c);
        BlockPos blockPos = /*EL:186*/new BlockPos(func_76128_c4, func_76128_c5, func_76128_c6);
        IBlockState blockState = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:187*/blockPos);
        Block block = /*EL:188*/blockState.func_177230_c();
        /*SL:190*/if (block.func_176209_a(blockState, false) && block != Blocks.field_150321_G) {
            /*SL:191*/return blockState.func_185910_a((World)EntityUtil.mc.field_71441_e, blockPos, v-17, v-16);
        }
        int n = /*EL:194*/200;
        final double n2 = /*EL:195*/v-16.field_72450_a - v-17.field_72450_a;
        final double n3 = /*EL:196*/v-16.field_72448_b - v-17.field_72448_b;
        final double n4 = /*EL:197*/v-16.field_72449_c - v-17.field_72449_c;
        /*SL:198*/while (n-- >= 0) {
            /*SL:199*/if (func_76128_c4 == func_76128_c && func_76128_c5 == func_76128_c2 && func_76128_c6 == func_76128_c3) {
                /*SL:200*/return null;
            }
            boolean v1 = /*EL:203*/true;
            boolean v2 = /*EL:204*/true;
            boolean v3 = /*EL:205*/true;
            double v4 = /*EL:206*/999.0;
            double v5 = /*EL:207*/999.0;
            double v6 = /*EL:208*/999.0;
            /*SL:210*/if (func_76128_c > func_76128_c4) {
                /*SL:211*/v4 = func_76128_c4 + 1.0;
            }
            else/*SL:212*/ if (func_76128_c < func_76128_c4) {
                /*SL:213*/v4 = func_76128_c4 + 0.0;
            }
            else {
                /*SL:215*/v1 = false;
            }
            /*SL:218*/if (func_76128_c2 > func_76128_c5) {
                /*SL:219*/v5 = func_76128_c5 + 1.0;
            }
            else/*SL:220*/ if (func_76128_c2 < func_76128_c5) {
                /*SL:221*/v5 = func_76128_c5 + 0.0;
            }
            else {
                /*SL:223*/v2 = false;
            }
            /*SL:226*/if (func_76128_c3 > func_76128_c6) {
                /*SL:227*/v6 = func_76128_c6 + 1.0;
            }
            else/*SL:228*/ if (func_76128_c3 < func_76128_c6) {
                /*SL:229*/v6 = func_76128_c6 + 0.0;
            }
            else {
                /*SL:231*/v3 = false;
            }
            double v7 = /*EL:234*/999.0;
            double v8 = /*EL:235*/999.0;
            double v9 = /*EL:236*/999.0;
            /*SL:238*/if (v1) {
                /*SL:239*/v7 = (v4 - v-17.field_72450_a) / n2;
            }
            /*SL:242*/if (v2) {
                /*SL:243*/v8 = (v5 - v-17.field_72448_b) / n3;
            }
            /*SL:246*/if (v3) {
                /*SL:247*/v9 = (v6 - v-17.field_72449_c) / n4;
            }
            /*SL:250*/if (v7 == -0.0) {
                /*SL:251*/v7 = -1.0E-4;
            }
            /*SL:254*/if (v8 == -0.0) {
                /*SL:255*/v8 = -1.0E-4;
            }
            /*SL:258*/if (v9 == -0.0) {
                /*SL:259*/v9 = -1.0E-4;
            }
            final EnumFacing v10;
            /*SL:264*/if (v7 < v8 && v7 < v9) {
                final EnumFacing a1 = /*EL:265*/(func_76128_c > func_76128_c4) ? EnumFacing.WEST : EnumFacing.EAST;
                /*SL:266*/v-17 = new Vec3d(v4, v-17.field_72448_b + n3 * v7, v-17.field_72449_c + n4 * v7);
            }
            else/*SL:267*/ if (v8 < v9) {
                final EnumFacing a2 = /*EL:268*/(func_76128_c2 > func_76128_c5) ? EnumFacing.DOWN : EnumFacing.UP;
                /*SL:269*/v-17 = new Vec3d(v-17.field_72450_a + n2 * v8, v5, v-17.field_72449_c + n4 * v8);
            }
            else {
                /*SL:271*/v10 = ((func_76128_c3 > func_76128_c6) ? EnumFacing.NORTH : EnumFacing.SOUTH);
                /*SL:272*/v-17 = new Vec3d(v-17.field_72450_a + n2 * v9, v-17.field_72448_b + n3 * v9, v6);
            }
            /*SL:275*/func_76128_c4 = MathHelper.func_76128_c(v-17.field_72450_a) - ((v10 == EnumFacing.EAST) ? 1 : 0);
            /*SL:276*/func_76128_c5 = MathHelper.func_76128_c(v-17.field_72448_b) - ((v10 == EnumFacing.UP) ? 1 : 0);
            /*SL:277*/func_76128_c6 = MathHelper.func_76128_c(v-17.field_72449_c) - ((v10 == EnumFacing.SOUTH) ? 1 : 0);
            /*SL:278*/blockPos = new BlockPos(func_76128_c4, func_76128_c5, func_76128_c6);
            /*SL:279*/blockState = EntityUtil.mc.field_71441_e.func_180495_p(blockPos);
            /*SL:280*/block = blockState.func_177230_c();
            /*SL:282*/if (block.func_176209_a(blockState, false) && block != Blocks.field_150321_G) {
                /*SL:283*/return blockState.func_185910_a((World)EntityUtil.mc.field_71441_e, blockPos, v-17, v-16);
            }
        }
        /*SL:286*/return null;
    }
    
    public static boolean checkForLiquid(final Entity v1, final boolean v2) {
        /*SL:290*/if (v1 == null) {
            /*SL:291*/return false;
        }
        final double v3 = /*EL:293*/v1.field_70163_u;
        final double v4 = /*EL:294*/v2 ? 0.03 : ((v1 instanceof EntityPlayer) ? 0.2 : 0.5);
        final double v5 = /*EL:295*/v3 - v4;
        /*SL:296*/for (int a2 = MathHelper.func_76128_c(v1.field_70165_t); a2 < MathHelper.func_76143_f(v1.field_70165_t); ++a2) {
            /*SL:297*/for (int a2 = MathHelper.func_76128_c(v1.field_70161_v); a2 < MathHelper.func_76143_f(v1.field_70161_v); ++a2) {
                /*SL:298*/if (EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(a2, MathHelper.func_76128_c(v5), a2)).func_177230_c() instanceof BlockLiquid) {
                    /*SL:299*/return true;
                }
            }
        }
        /*SL:302*/return false;
    }
    
    public static boolean isAboveLiquid(final Entity v-2) {
        /*SL:306*/if (v-2 == null) {
            /*SL:307*/return false;
        }
        final double n = /*EL:309*/v-2.field_70163_u + 0.01;
        /*SL:310*/for (int v1 = MathHelper.func_76128_c(v-2.field_70165_t); v1 < MathHelper.func_76143_f(v-2.field_70165_t); ++v1) {
            /*SL:311*/for (int a1 = MathHelper.func_76128_c(v-2.field_70161_v); a1 < MathHelper.func_76143_f(v-2.field_70161_v); ++a1) {
                /*SL:312*/if (EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(v1, (int)n, a1)).func_177230_c() instanceof BlockLiquid) {
                    /*SL:313*/return true;
                }
            }
        }
        /*SL:316*/return false;
    }
    
    public static boolean isOnLiquid(final double v-5) {
        /*SL:320*/if (EntityUtil.mc.field_71439_g.field_70143_R >= 3.0f) {
            /*SL:321*/return false;
        }
        final AxisAlignedBB axisAlignedBB = (EntityUtil.mc.field_71439_g.func_184187_bx() != /*EL:323*/null) ? EntityUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(0.0, -v-5, 0.0) : EntityUtil.mc.field_71439_g.func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(0.0, -v-5, 0.0);
        boolean b = /*EL:324*/false;
        final int n = /*EL:325*/(int)axisAlignedBB.field_72338_b;
        /*SL:326*/for (int v0 = MathHelper.func_76128_c(axisAlignedBB.field_72340_a); v0 < MathHelper.func_76128_c(axisAlignedBB.field_72336_d + 1.0); ++v0) {
            /*SL:327*/for (int v = MathHelper.func_76128_c(axisAlignedBB.field_72339_c); v < MathHelper.func_76128_c(axisAlignedBB.field_72334_f + 1.0); ++v) {
                final Block a1 = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:328*/new BlockPos(v0, n, v)).func_177230_c();
                /*SL:329*/if (a1 != Blocks.field_150350_a) {
                    /*SL:330*/if (!(a1 instanceof BlockLiquid)) {
                        /*SL:331*/return false;
                    }
                    /*SL:333*/b = true;
                }
            }
        }
        /*SL:336*/return b;
    }
    
    public static boolean isOnLiquid() {
        final double n = EntityUtil.mc.field_71439_g.field_70163_u - /*EL:340*/0.03;
        /*SL:341*/for (int i = MathHelper.func_76128_c(EntityUtil.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f(EntityUtil.mc.field_71439_g.field_70165_t); ++i) {
            /*SL:342*/for (int v0 = MathHelper.func_76128_c(EntityUtil.mc.field_71439_g.field_70161_v); v0 < MathHelper.func_76143_f(EntityUtil.mc.field_71439_g.field_70161_v); ++v0) {
                final BlockPos v = /*EL:343*/new BlockPos(i, MathHelper.func_76128_c(n), v0);
                /*SL:344*/if (EntityUtil.mc.field_71441_e.func_180495_p(v).func_177230_c() instanceof BlockLiquid) {
                    /*SL:345*/return true;
                }
            }
        }
        /*SL:348*/return false;
    }
    
    public static boolean isInLiquid() {
        /*SL:352*/if (EntityUtil.mc.field_71439_g.field_70143_R >= 3.0f) {
            /*SL:353*/return false;
        }
        boolean b = /*EL:355*/false;
        final AxisAlignedBB axisAlignedBB = (EntityUtil.mc.field_71439_g.func_184187_bx() != /*EL:356*/null) ? EntityUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ() : EntityUtil.mc.field_71439_g.func_174813_aQ();
        final int n = /*EL:357*/(int)axisAlignedBB.field_72338_b;
        /*SL:358*/for (int i = MathHelper.func_76128_c(axisAlignedBB.field_72340_a); i < MathHelper.func_76128_c(axisAlignedBB.field_72336_d) + 1; ++i) {
            /*SL:359*/for (int v0 = MathHelper.func_76128_c(axisAlignedBB.field_72339_c); v0 < MathHelper.func_76128_c(axisAlignedBB.field_72334_f) + 1; ++v0) {
                final Block v = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:360*/new BlockPos(i, n, v0)).func_177230_c();
                /*SL:361*/if (!(v instanceof BlockAir)) {
                    /*SL:362*/if (!(v instanceof BlockLiquid)) {
                        /*SL:363*/return false;
                    }
                    /*SL:365*/b = true;
                }
            }
        }
        /*SL:368*/return b;
    }
    
    public static void resetTimer() {
        /*SL:372*/Minecraft.func_71410_x().field_71428_T.field_194149_e = 50.0f;
    }
    
    public static BlockPos getFlooredPos(final Entity a1) {
        /*SL:376*/return new BlockPos(Math.floor(a1.field_70165_t), Math.floor(a1.field_70163_u), Math.floor(a1.field_70161_v));
    }
    
    public static Vec3d interpolateEntity(final Entity a1, final float a2) {
        /*SL:380*/return new Vec3d(a1.field_70142_S + (a1.field_70165_t - a1.field_70142_S) * a2, a1.field_70137_T + (a1.field_70163_u - a1.field_70137_T) * a2, a1.field_70136_U + (a1.field_70161_v - a1.field_70136_U) * a2);
    }
    
    public static Vec3d getInterpolatedPos(final Entity a1, final float a2) {
        /*SL:384*/return new Vec3d(a1.field_70142_S, a1.field_70137_T, a1.field_70136_U).func_178787_e(getInterpolatedAmount(a1, a2));
    }
    
    public static Vec3d getInterpolatedRenderPos(final Entity a1, final float a2) {
        /*SL:388*/return getInterpolatedPos(a1, a2).func_178786_a(EntityUtil.mc.func_175598_ae().field_78725_b, EntityUtil.mc.func_175598_ae().field_78726_c, EntityUtil.mc.func_175598_ae().field_78723_d);
    }
    
    public static Vec3d getInterpolatedRenderPos(final Vec3d a1) {
        /*SL:392*/return new Vec3d(a1.field_72450_a, a1.field_72448_b, a1.field_72449_c).func_178786_a(EntityUtil.mc.func_175598_ae().field_78725_b, EntityUtil.mc.func_175598_ae().field_78726_c, EntityUtil.mc.func_175598_ae().field_78723_d);
    }
    
    public static Vec3d getInterpolatedAmount(final Entity a1, final double a2, final double a3, final double a4) {
        /*SL:396*/return new Vec3d((a1.field_70165_t - a1.field_70142_S) * a2, (a1.field_70163_u - a1.field_70137_T) * a3, (a1.field_70161_v - a1.field_70136_U) * a4);
    }
    
    public static Vec3d getInterpolatedAmount(final Entity a1, final Vec3d a2) {
        /*SL:400*/return getInterpolatedAmount(a1, a2.field_72450_a, a2.field_72448_b, a2.field_72449_c);
    }
    
    public static Vec3d getInterpolatedAmount(final Entity a1, final float a2) {
        /*SL:404*/return getInterpolatedAmount(a1, a2, a2, a2);
    }
    
    public static double getBaseMoveSpeed() {
        double n = /*EL:408*/0.2873;
        /*SL:409*/if (EntityUtil.mc.field_71439_g != null && EntityUtil.mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
            final int v1 = EntityUtil.mc.field_71439_g.func_70660_b(/*EL:410*/Potion.func_188412_a(1)).func_76458_c();
            /*SL:411*/n *= 1.0 + 0.2 * (v1 + 1);
        }
        /*SL:413*/return n;
    }
    
    public static boolean isPassive(final Entity a1) {
        /*SL:417*/return (!(a1 instanceof EntityWolf) || !((EntityWolf)a1).func_70919_bu()) && /*EL:420*/(a1 instanceof EntityAgeable || a1 instanceof EntityAmbientCreature || a1 instanceof EntitySquid || /*EL:423*/(a1 instanceof EntityIronGolem && ((EntityIronGolem)a1).func_70643_av() == null));
    }
    
    public static boolean isSafe(final Entity a1, final int a2, final boolean a3, final boolean a4) {
        /*SL:427*/return getUnsafeBlocks(a1, a2, a3).size() == 0;
    }
    
    public static boolean stopSneaking(final boolean a1) {
        /*SL:431*/if (a1 && EntityUtil.mc.field_71439_g != null) {
            EntityUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:432*/(Packet)new CPacketEntityAction((Entity)EntityUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
        /*SL:434*/return false;
    }
    
    public static boolean isSafe(final Entity a1) {
        /*SL:438*/return isSafe(a1, 0, false, true);
    }
    
    public static BlockPos getPlayerPos(final EntityPlayer a1) {
        /*SL:442*/return new BlockPos(Math.floor(a1.field_70165_t), Math.floor(a1.field_70163_u), Math.floor(a1.field_70161_v));
    }
    
    public static List<Vec3d> getUnsafeBlocks(final Entity a1, final int a2, final boolean a3) {
        /*SL:446*/return getUnsafeBlocksFromVec3d(a1.func_174791_d(), a2, a3);
    }
    
    public static boolean isMobAggressive(final Entity a1) {
        /*SL:450*/if (a1 instanceof EntityPigZombie) {
            /*SL:451*/if (((EntityPigZombie)a1).func_184734_db() || ((EntityPigZombie)a1).func_175457_ck()) {
                /*SL:452*/return true;
            }
        }
        else {
            /*SL:455*/if (a1 instanceof EntityWolf) {
                /*SL:456*/return ((EntityWolf)a1).func_70919_bu() && !EntityUtil.mc.field_71439_g.equals((Object)((EntityWolf)a1).func_70902_q());
            }
            /*SL:458*/if (a1 instanceof EntityEnderman) {
                /*SL:459*/return ((EntityEnderman)a1).func_70823_r();
            }
        }
        /*SL:462*/return isHostileMob(a1);
    }
    
    public static boolean isNeutralMob(final Entity a1) {
        /*SL:466*/return a1 instanceof EntityPigZombie || a1 instanceof EntityWolf || a1 instanceof EntityEnderman;
    }
    
    public static boolean isProjectile(final Entity a1) {
        /*SL:470*/return a1 instanceof EntityShulkerBullet || a1 instanceof EntityFireball;
    }
    
    public static boolean isVehicle(final Entity a1) {
        /*SL:474*/return a1 instanceof EntityBoat || a1 instanceof EntityMinecart;
    }
    
    public static boolean isFriendlyMob(final Entity a1) {
        /*SL:478*/return (a1.isCreatureType(EnumCreatureType.CREATURE, false) && !isNeutralMob(a1)) || a1.isCreatureType(EnumCreatureType.AMBIENT, false) || a1 instanceof EntityVillager || a1 instanceof EntityIronGolem || (isNeutralMob(a1) && !isMobAggressive(a1));
    }
    
    public static boolean isHostileMob(final Entity a1) {
        /*SL:482*/return a1.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(a1);
    }
    
    public static List<Vec3d> getUnsafeBlocksFromVec3d(final Vec3d v1, final int v2, final boolean v3) {
        final ArrayList<Vec3d> v4 = /*EL:486*/new ArrayList<Vec3d>();
        /*SL:487*/for (Block a3 : getOffsets(v2, v3)) {
            final BlockPos a2 = /*EL:488*/new BlockPos(v1).func_177963_a(a3.field_72450_a, a3.field_72448_b, a3.field_72449_c);
            /*SL:489*/a3 = EntityUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c();
            /*SL:490*/if (a3 instanceof BlockAir || a3 instanceof BlockLiquid || a3 instanceof BlockTallGrass || a3 instanceof BlockFire || a3 instanceof BlockDeadBush || a3 instanceof BlockSnow) {
                /*SL:492*/v4.add(a3);
            }
        }
        /*SL:494*/return v4;
    }
    
    public static boolean isInHole(final Entity a1) {
        /*SL:498*/return isBlockValid(new BlockPos(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v));
    }
    
    public static boolean isBlockValid(final BlockPos a1) {
        /*SL:502*/return isBedrockHole(a1) || isObbyHole(a1) || isBothHole(a1);
    }
    
    public static boolean isObbyHole(final BlockPos v-4) {
        final BlockPos[] array2;
        final BlockPos[] array = /*EL:507*/array2 = new BlockPos[] { v-4.func_177978_c(), v-4.func_177968_d(), v-4.func_177974_f(), v-4.func_177976_e(), v-4.func_177977_b() };
        for (final BlockPos v1 : array2) {
            final IBlockState a1 = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:508*/v1);
            /*SL:509*/if (a1.func_177230_c() == Blocks.field_150350_a || a1.func_177230_c() != Blocks.field_150343_Z) {
                /*SL:510*/return false;
            }
        }
        /*SL:512*/return true;
    }
    
    public static boolean isBedrockHole(final BlockPos v-4) {
        final BlockPos[] array2;
        final BlockPos[] array = /*EL:517*/array2 = new BlockPos[] { v-4.func_177978_c(), v-4.func_177968_d(), v-4.func_177974_f(), v-4.func_177976_e(), v-4.func_177977_b() };
        for (final BlockPos v1 : array2) {
            final IBlockState a1 = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:518*/v1);
            /*SL:519*/if (a1.func_177230_c() == Blocks.field_150350_a || a1.func_177230_c() != Blocks.field_150357_h) {
                /*SL:520*/return false;
            }
        }
        /*SL:522*/return true;
    }
    
    public static boolean isBothHole(final BlockPos v-4) {
        final BlockPos[] array2;
        final BlockPos[] array = /*EL:527*/array2 = new BlockPos[] { v-4.func_177978_c(), v-4.func_177968_d(), v-4.func_177974_f(), v-4.func_177976_e(), v-4.func_177977_b() };
        for (final BlockPos v1 : array2) {
            final IBlockState a1 = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:528*/v1);
            if (/*EL:529*/a1.func_177230_c() == Blocks.field_150350_a || (a1.func_177230_c() != Blocks.field_150357_h && a1.func_177230_c() != Blocks.field_150343_Z)) {
                /*SL:531*/return false;
            }
        }
        /*SL:533*/return true;
    }
    
    public static Vec3d[] getUnsafeBlockArray(final Entity a1, final int a2, final boolean a3) {
        final List<Vec3d> v1 = getUnsafeBlocks(/*EL:537*/a1, a2, a3);
        final Vec3d[] v2 = /*EL:538*/new Vec3d[v1.size()];
        /*SL:539*/return v1.<Vec3d>toArray(v2);
    }
    
    public static Vec3d[] getUnsafeBlockArrayFromVec3d(final Vec3d a1, final int a2, final boolean a3) {
        final List<Vec3d> v1 = getUnsafeBlocksFromVec3d(/*EL:543*/a1, a2, a3);
        final Vec3d[] v2 = /*EL:544*/new Vec3d[v1.size()];
        /*SL:545*/return v1.<Vec3d>toArray(v2);
    }
    
    public static double getDst(final Vec3d a1) {
        /*SL:549*/return EntityUtil.mc.field_71439_g.func_174791_d().func_72438_d(a1);
    }
    
    public static boolean isTrapped(final EntityPlayer a1, final boolean a2, final boolean a3, final boolean a4, final boolean a5, final boolean a6) {
        /*SL:553*/return getUntrappedBlocks(a1, a2, a3, a4, a5, a6).size() == 0;
    }
    
    public static boolean isTrappedExtended(final int a1, final EntityPlayer a2, final boolean a3, final boolean a4, final boolean a5, final boolean a6, final boolean a7, final boolean a8) {
        /*SL:557*/return getUntrappedBlocksExtended(a1, a2, a3, a4, a5, a6, a7, a8).size() == 0;
    }
    
    public static List<Vec3d> getUntrappedBlocks(final EntityPlayer a5, final boolean a6, final boolean v1, final boolean v2, final boolean v3, final boolean v4) {
        final ArrayList<Vec3d> v5 = /*EL:561*/new ArrayList<Vec3d>();
        /*SL:562*/if (!v1 && getUnsafeBlocks((Entity)a5, 2, false).size() == 4) {
            /*SL:563*/v5.addAll(getUnsafeBlocks((Entity)a5, 2, false));
        }
        /*SL:565*/for (int a7 = 0; a7 < getTrapOffsets(a6, v1, v2, v3, v4).length; ++a7) {
            final Vec3d a8 = /*EL:566*/getTrapOffsets(a6, v1, v2, v3, v4)[a7];
            final BlockPos a9 = /*EL:567*/new BlockPos(a5.func_174791_d()).func_177963_a(a8.field_72450_a, a8.field_72448_b, a8.field_72449_c);
            final Block a10 = EntityUtil.mc.field_71441_e.func_180495_p(/*EL:568*/a9).func_177230_c();
            /*SL:569*/if (a10 instanceof BlockAir || a10 instanceof BlockLiquid || a10 instanceof BlockTallGrass || a10 instanceof BlockFire || a10 instanceof BlockDeadBush || a10 instanceof BlockSnow) {
                /*SL:571*/v5.add(a8);
            }
        }
        /*SL:573*/return v5;
    }
    
    public static boolean isInWater(final Entity v-3) {
        /*SL:577*/if (v-3 == null) {
            /*SL:578*/return false;
        }
        final double n = /*EL:580*/v-3.field_70163_u + 0.01;
        /*SL:581*/for (int v0 = MathHelper.func_76128_c(v-3.field_70165_t); v0 < MathHelper.func_76143_f(v-3.field_70165_t); ++v0) {
            /*SL:582*/for (int v = MathHelper.func_76128_c(v-3.field_70161_v); v < MathHelper.func_76143_f(v-3.field_70161_v); ++v) {
                final BlockPos a1 = /*EL:583*/new BlockPos(v0, (int)n, v);
                /*SL:584*/if (EntityUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() instanceof BlockLiquid) {
                    /*SL:585*/return true;
                }
            }
        }
        /*SL:588*/return false;
    }
    
    public static boolean isDrivenByPlayer(final Entity a1) {
        /*SL:592*/return EntityUtil.mc.field_71439_g != null && a1 != null && a1.equals((Object)EntityUtil.mc.field_71439_g.func_184187_bx());
    }
    
    public static boolean isPlayer(final Entity a1) {
        /*SL:596*/return a1 instanceof EntityPlayer;
    }
    
    public static boolean isAboveWater(final Entity a1) {
        /*SL:600*/return isAboveWater(a1, false);
    }
    
    public static boolean isAboveWater(final Entity v-3, final boolean v-2) {
        /*SL:604*/if (v-3 == null) {
            /*SL:605*/return false;
        }
        final double n = /*EL:607*/v-3.field_70163_u - (v-2 ? 0.03 : (isPlayer(v-3) ? 0.2 : 0.5));
        /*SL:608*/for (int v1 = MathHelper.func_76128_c(v-3.field_70165_t); v1 < MathHelper.func_76143_f(v-3.field_70165_t); ++v1) {
            /*SL:609*/for (BlockPos a2 = (BlockPos)MathHelper.func_76128_c(v-3.field_70161_v); a2 < MathHelper.func_76143_f(v-3.field_70161_v); ++a2) {
                /*SL:610*/a2 = new BlockPos(v1, MathHelper.func_76128_c(n), a2);
                /*SL:611*/if (EntityUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c() instanceof BlockLiquid) {
                    /*SL:612*/return true;
                }
            }
        }
        /*SL:615*/return false;
    }
    
    public static double[] calculateLookAt(final double a1, final double a2, final double a3, final EntityPlayer a4) {
        double v1 = /*EL:618*/a4.field_70165_t - a1;
        double v2 = /*EL:619*/a4.field_70163_u - a2;
        double v3 = /*EL:620*/a4.field_70161_v - a3;
        final double v4 = /*EL:621*/Math.sqrt(v1 * v1 + v2 * v2 + v3 * v3);
        /*SL:622*/v1 /= v4;
        /*SL:623*/v2 /= v4;
        /*SL:624*/v3 /= v4;
        double v5 = /*EL:625*/Math.asin(v2);
        double v6 = /*EL:626*/Math.atan2(v3, v1);
        /*SL:627*/v5 = v5 * 180.0 / 3.141592653589793;
        /*SL:628*/v6 = v6 * 180.0 / 3.141592653589793;
        /*SL:629*/v6 += 90.0;
        /*SL:630*/return new double[] { v6, v5 };
    }
    
    public static List<Vec3d> getUntrappedBlocksExtended(final int a6, final EntityPlayer a7, final boolean a8, final boolean v1, final boolean v2, final boolean v3, final boolean v4, final boolean v5) {
        final ArrayList<Vec3d> v6 = /*EL:634*/new ArrayList<Vec3d>();
        /*SL:635*/if (a6 == 1) {
            /*SL:636*/v6.addAll(targets(a7.func_174791_d(), a8, v1, v2, v3, v4, v5));
        }
        else {
            int a9 = /*EL:638*/1;
            /*SL:639*/for (final Vec3d a10 : MathUtil.getBlockBlocks((Entity)a7)) {
                /*SL:640*/if (a9 > a6) {
                    break;
                }
                /*SL:641*/v6.addAll(targets(a10, a8, v1, v2, v3, v4, v5));
                /*SL:642*/++a9;
            }
        }
        final ArrayList<Vec3d> a11 = /*EL:645*/new ArrayList<Vec3d>();
        /*SL:646*/for (final Vec3d a12 : v6) {
            final BlockPos a13 = /*EL:647*/new BlockPos(a12);
            /*SL:648*/if (BlockUtil.isPositionPlaceable(a13, v5) != -1) {
                continue;
            }
            /*SL:649*/a11.add(a12);
        }
        /*SL:651*/for (final Vec3d a14 : a11) {
            /*SL:652*/v6.remove(a14);
        }
        /*SL:654*/return v6;
    }
    
    public static List<Vec3d> targets(final Vec3d a4, final boolean a5, final boolean a6, final boolean a7, final boolean v1, final boolean v2, final boolean v3) {
        final ArrayList<Vec3d> v4 = /*EL:658*/new ArrayList<Vec3d>();
        /*SL:659*/if (v2) {
            /*SL:660*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.antiDropOffsetList));
        }
        /*SL:662*/if (v1) {
            /*SL:663*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.platformOffsetList));
        }
        /*SL:665*/if (a7) {
            /*SL:666*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.legOffsetList));
        }
        /*SL:668*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.OffsetList));
        /*SL:669*/if (a6) {
            /*SL:670*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.antiStepOffsetList));
        }
        else {
            final List<Vec3d> a8 = getUnsafeBlocksFromVec3d(/*EL:672*/a4, 2, false);
            /*SL:673*/if (a8.size() == 4) {
                /*SL:675*/for (final Vec3d a9 : a8) {
                    final BlockPos a10 = /*EL:676*/new BlockPos(a4).func_177963_a(a9.field_72450_a, a9.field_72448_b, a9.field_72449_c);
                    /*SL:677*/switch (BlockUtil.isPositionPlaceable(a10, v3)) {
                        case -1:
                        case 1:
                        case 2: {
                            /*SL:684*/continue;
                        }
                        case 3: {
                            /*SL:687*/v4.add(a4.func_178787_e(a9));
                            break;
                        }
                    }
                    /*SL:691*/if (a5) {
                        /*SL:692*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.antiScaffoldOffsetList));
                    }
                    /*SL:694*/return v4;
                }
            }
        }
        /*SL:698*/if (a5) {
            /*SL:699*/Collections.<Vec3d>addAll(v4, BlockUtil.convertVec3ds(a4, EntityUtil.antiScaffoldOffsetList));
        }
        /*SL:701*/return v4;
    }
    
    public static List<Vec3d> getOffsetList(final int a1, final boolean a2) {
        final ArrayList<Vec3d> v1 = /*EL:705*/new ArrayList<Vec3d>();
        /*SL:706*/v1.add(new Vec3d(-1.0, (double)a1, 0.0));
        /*SL:707*/v1.add(new Vec3d(1.0, (double)a1, 0.0));
        /*SL:708*/v1.add(new Vec3d(0.0, (double)a1, -1.0));
        /*SL:709*/v1.add(new Vec3d(0.0, (double)a1, 1.0));
        /*SL:710*/if (a2) {
            /*SL:711*/v1.add(new Vec3d(0.0, (double)(a1 - 1), 0.0));
        }
        /*SL:713*/return v1;
    }
    
    public static Vec3d[] getOffsets(final int a1, final boolean a2) {
        final List<Vec3d> v1 = getOffsetList(/*EL:717*/a1, a2);
        final Vec3d[] v2 = /*EL:718*/new Vec3d[v1.size()];
        /*SL:719*/return v1.<Vec3d>toArray(v2);
    }
    
    public static Vec3d[] getTrapOffsets(final boolean a1, final boolean a2, final boolean a3, final boolean a4, final boolean a5) {
        final List<Vec3d> v1 = getTrapOffsetsList(/*EL:723*/a1, a2, a3, a4, a5);
        final Vec3d[] v2 = /*EL:724*/new Vec3d[v1.size()];
        /*SL:725*/return v1.<Vec3d>toArray(v2);
    }
    
    public static List<Vec3d> getTrapOffsetsList(final boolean a1, final boolean a2, final boolean a3, final boolean a4, final boolean a5) {
        final ArrayList<Vec3d> v1 = /*EL:729*/new ArrayList<Vec3d>(getOffsetList(1, false));
        /*SL:730*/v1.add(new Vec3d(0.0, 2.0, 0.0));
        /*SL:731*/if (a1) {
            /*SL:732*/v1.add(new Vec3d(0.0, 3.0, 0.0));
        }
        /*SL:734*/if (a2) {
            /*SL:735*/v1.addAll(getOffsetList(2, false));
        }
        /*SL:737*/if (a3) {
            /*SL:738*/v1.addAll(getOffsetList(0, false));
        }
        /*SL:740*/if (a4) {
            /*SL:741*/v1.addAll(getOffsetList(-1, false));
            /*SL:742*/v1.add(new Vec3d(0.0, -1.0, 0.0));
        }
        /*SL:744*/if (a5) {
            /*SL:745*/v1.add(new Vec3d(0.0, -2.0, 0.0));
        }
        /*SL:747*/return v1;
    }
    
    public static Vec3d[] getHeightOffsets(final int a2, final int v1) {
        final ArrayList<Vec3d> v2 = /*EL:751*/new ArrayList<Vec3d>();
        /*SL:752*/for (int a3 = a2; a3 <= v1; ++a3) {
            /*SL:753*/v2.add(new Vec3d(0.0, (double)a3, 0.0));
        }
        final Vec3d[] v3 = /*EL:755*/new Vec3d[v2.size()];
        /*SL:756*/return v2.<Vec3d>toArray(v3);
    }
    
    public static BlockPos getRoundedBlockPos(final Entity a1) {
        /*SL:760*/return new BlockPos(MathUtil.roundVec(a1.func_174791_d(), 0));
    }
    
    public static boolean isLiving(final Entity a1) {
        /*SL:764*/return a1 instanceof EntityLivingBase;
    }
    
    public static boolean isAlive(final Entity a1) {
        /*SL:768*/return isLiving(a1) && !a1.field_70128_L && ((EntityLivingBase)a1).func_110143_aJ() > 0.0f;
    }
    
    public static boolean isDead(final Entity a1) {
        /*SL:772*/return !isAlive(a1);
    }
    
    public static float getHealth(final Entity v1) {
        /*SL:776*/if (isLiving(v1)) {
            final EntityLivingBase a1 = /*EL:777*/(EntityLivingBase)v1;
            /*SL:778*/return a1.func_110143_aJ() + a1.func_110139_bj();
        }
        /*SL:780*/return 0.0f;
    }
    
    public static float getHealth(final Entity a2, final boolean v1) {
        /*SL:784*/if (isLiving(a2)) {
            final EntityLivingBase a3 = /*EL:785*/(EntityLivingBase)a2;
            /*SL:786*/return a3.func_110143_aJ() + (v1 ? a3.func_110139_bj() : 0.0f);
        }
        /*SL:788*/return 0.0f;
    }
    
    public static boolean canEntityFeetBeSeen(final Entity a1) {
        /*SL:792*/return EntityUtil.mc.field_71441_e.func_147447_a(new Vec3d(EntityUtil.mc.field_71439_g.field_70165_t, EntityUtil.mc.field_71439_g.field_70165_t + EntityUtil.mc.field_71439_g.func_70047_e(), EntityUtil.mc.field_71439_g.field_70161_v), new Vec3d(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v), false, true, false) == null;
    }
    
    public static boolean isntValid(final Entity a1, final double a2) {
        /*SL:796*/return a1 == null || isDead(a1) || a1.equals((Object)EntityUtil.mc.field_71439_g) || (a1 instanceof EntityPlayer && Legacy.friendManager.isFriend(a1.func_70005_c_())) || EntityUtil.mc.field_71439_g.func_70068_e(a1) > MathUtil.square(a2);
    }
    
    public static boolean isValid(final Entity a1, final double a2) {
        /*SL:800*/return !isntValid(a1, a2);
    }
    
    public static boolean holdingWeapon(final EntityPlayer a1) {
        /*SL:804*/return a1.func_184614_ca().func_77973_b() instanceof ItemSword || a1.func_184614_ca().func_77973_b() instanceof ItemAxe;
    }
    
    public static double getMaxSpeed() {
        double v1 = /*EL:808*/0.2873;
        /*SL:809*/if (EntityUtil.mc.field_71439_g.func_70644_a((Potion)Objects.<Potion>requireNonNull(Potion.func_188412_a(1)))) {
            /*SL:810*/v1 *= 1.0 + 0.2 * (Objects.<PotionEffect>requireNonNull(EntityUtil.mc.field_71439_g.func_70660_b((Potion)Objects.<Potion>requireNonNull(Potion.func_188412_a(1)))).func_76458_c() + 1);
        }
        /*SL:812*/return v1;
    }
    
    public static void mutliplyEntitySpeed(final Entity a1, final double a2) {
        /*SL:816*/if (a1 != null) {
            /*SL:817*/a1.field_70159_w *= a2;
            /*SL:818*/a1.field_70179_y *= a2;
        }
    }
    
    public static boolean isEntityMoving(final Entity a1) {
        /*SL:823*/if (a1 == null) {
            /*SL:824*/return false;
        }
        /*SL:826*/if (a1 instanceof EntityPlayer) {
            /*SL:827*/return EntityUtil.mc.field_71474_y.field_74351_w.func_151470_d() || EntityUtil.mc.field_71474_y.field_74368_y.func_151470_d() || EntityUtil.mc.field_71474_y.field_74370_x.func_151470_d() || EntityUtil.mc.field_71474_y.field_74366_z.func_151470_d();
        }
        /*SL:829*/return a1.field_70159_w != 0.0 || a1.field_70181_x != 0.0 || a1.field_70179_y != 0.0;
    }
    
    public static double getEntitySpeed(final Entity v-2) {
        /*SL:833*/if (v-2 != null) {
            final double a1 = /*EL:834*/v-2.field_70165_t - v-2.field_70169_q;
            final double v1 = /*EL:835*/v-2.field_70161_v - v-2.field_70166_s;
            final double v2 = /*EL:836*/MathHelper.func_76133_a(a1 * a1 + v1 * v1);
            /*SL:837*/return v2 * 20.0;
        }
        /*SL:839*/return 0.0;
    }
    
    public static boolean is32k(final ItemStack a1) {
        /*SL:843*/return EnchantmentHelper.func_77506_a(Enchantments.field_185302_k, a1) >= 1000;
    }
    
    public static void moveEntityStrafe(final double v-5, final Entity v-3) {
        /*SL:847*/if (v-3 != null) {
            final MovementInput a1 = EntityUtil.mc.field_71439_g.field_71158_b;
            double a2 = /*EL:849*/a1.field_192832_b;
            double v1 = /*EL:850*/a1.field_78902_a;
            float v2 = EntityUtil.mc.field_71439_g.field_70177_z;
            /*SL:852*/if (a2 == 0.0 && v1 == 0.0) {
                /*SL:853*/v-3.field_70159_w = 0.0;
                /*SL:854*/v-3.field_70179_y = 0.0;
            }
            else {
                /*SL:856*/if (a2 != 0.0) {
                    /*SL:857*/if (v1 > 0.0) {
                        /*SL:858*/v2 += ((a2 > 0.0) ? -45 : 45);
                    }
                    else/*SL:859*/ if (v1 < 0.0) {
                        /*SL:860*/v2 += ((a2 > 0.0) ? 45 : -45);
                    }
                    /*SL:862*/v1 = 0.0;
                    /*SL:863*/if (a2 > 0.0) {
                        /*SL:864*/a2 = 1.0;
                    }
                    else/*SL:865*/ if (a2 < 0.0) {
                        /*SL:866*/a2 = -1.0;
                    }
                }
                /*SL:869*/v-3.field_70159_w = a2 * v-5 * Math.cos(Math.toRadians(v2 + 90.0f)) + v1 * v-5 * Math.sin(Math.toRadians(v2 + 90.0f));
                /*SL:870*/v-3.field_70179_y = a2 * v-5 * Math.sin(Math.toRadians(v2 + 90.0f)) - v1 * v-5 * Math.cos(Math.toRadians(v2 + 90.0f));
            }
        }
    }
    
    public static boolean rayTraceHitCheck(final Entity a1, final boolean a2) {
        /*SL:876*/return !a2 || EntityUtil.mc.field_71439_g.func_70685_l(a1);
    }
    
    public static Color getColor(final Entity a1, final int a2, final int a3, final int a4, final int a5, final boolean a6) {
        Color v1 = /*EL:880*/new Color(a2 / 255.0f, a3 / 255.0f, a4 / 255.0f, a5 / 255.0f);
        /*SL:881*/if (a1 instanceof EntityPlayer && a6 && Legacy.friendManager.isFriend((EntityPlayer)a1)) {
            /*SL:882*/v1 = new Color(0.33333334f, 1.0f, 1.0f, a5 / 255.0f);
        }
        /*SL:884*/return v1;
    }
    
    public static boolean isMoving() {
        /*SL:888*/return EntityUtil.mc.field_71439_g.field_191988_bg != 0.0 || EntityUtil.mc.field_71439_g.field_70702_br != 0.0;
    }
    
    public static boolean isMoving(final EntityLivingBase a1) {
        /*SL:892*/return a1.field_191988_bg != 0.0f || a1.field_70702_br != 0.0f;
    }
    
    public static EntityPlayer getClosestEnemy(final double v1) {
        EntityPlayer v2 = /*EL:896*/null;
        /*SL:897*/for (final EntityPlayer a1 : EntityUtil.mc.field_71441_e.field_73010_i) {
            /*SL:898*/if (isntValid((Entity)a1, v1)) {
                continue;
            }
            /*SL:899*/if (v2 == null) {
                /*SL:900*/v2 = a1;
            }
            else {
                /*SL:903*/if (EntityUtil.mc.field_71439_g.func_70068_e((Entity)a1) >= EntityUtil.mc.field_71439_g.func_70068_e((Entity)v2)) {
                    /*SL:904*/continue;
                }
                /*SL:905*/v2 = a1;
            }
        }
        /*SL:907*/return v2;
    }
    
    public static boolean checkCollide() {
        /*SL:914*/return !EntityUtil.mc.field_71439_g.func_70093_af() && (EntityUtil.mc.field_71439_g.func_184187_bx() == null || EntityUtil.mc.field_71439_g.func_184187_bx().field_70143_R < 3.0f) && EntityUtil.mc.field_71439_g.field_70143_R < /*EL:917*/3.0f;
    }
    
    public static BlockPos getPlayerPosWithEntity() {
        /*SL:921*/return new BlockPos((EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? EntityUtil.mc.field_71439_g.func_184187_bx().field_70165_t : EntityUtil.mc.field_71439_g.field_70165_t, (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? EntityUtil.mc.field_71439_g.func_184187_bx().field_70163_u : EntityUtil.mc.field_71439_g.field_70163_u, (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? EntityUtil.mc.field_71439_g.func_184187_bx().field_70161_v : EntityUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static boolean isCrystalAtFeet(final EntityEnderCrystal v1, final double v2) {
        /*SL:924*/for (Vec3d a2 : EntityUtil.mc.field_71441_e.field_73010_i) {
            /*SL:925*/if (EntityUtil.mc.field_71439_g.func_70068_e((Entity)a2) > v2 * v2) {
                /*SL:926*/continue;
            }
            /*SL:928*/if (Legacy.friendManager.isFriend(a2)) {
                /*SL:929*/continue;
            }
            final Vec3d[] doubleLegOffsetList = EntityUtil.doubleLegOffsetList;
            /*SL:931*/for (int length = doubleLegOffsetList.length, i = 0; i < length; ++i) {
                a2 = doubleLegOffsetList[i];
                /*SL:932*/if (new BlockPos(a2.func_174791_d()).func_177963_a(a2.field_72450_a, a2.field_72448_b, a2.field_72449_c) == v1.func_180425_c()) {
                    /*SL:933*/return true;
                }
            }
        }
        /*SL:937*/return false;
    }
    
    public static double[] forward(final double a1) {
        float v1 = EntityUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float v2 = EntityUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float v3 = EntityUtil.mc.field_71439_g.field_70126_B + (EntityUtil.mc.field_71439_g.field_70177_z - EntityUtil.mc.field_71439_g.field_70126_B) * EntityUtil.mc.func_184121_ak();
        /*SL:945*/if (v1 != 0.0f) {
            /*SL:946*/if (v2 > 0.0f) {
                /*SL:947*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:948*/ if (v2 < 0.0f) {
                /*SL:949*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:951*/v2 = 0.0f;
            /*SL:952*/if (v1 > 0.0f) {
                /*SL:953*/v1 = 1.0f;
            }
            else/*SL:954*/ if (v1 < 0.0f) {
                /*SL:955*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:958*/Math.sin(Math.toRadians(v3 + 90.0f));
        final double v5 = /*EL:959*/Math.cos(Math.toRadians(v3 + 90.0f));
        final double v6 = /*EL:960*/v1 * a1 * v5 + v2 * a1 * v4;
        final double v7 = /*EL:961*/v1 * a1 * v4 - v2 * a1 * v5;
        /*SL:962*/return new double[] { v6, v7 };
    }
    
    public static void swingArmNoPacket(final EnumHand a1, final EntityLivingBase a2) {
        final ItemStack v1 = /*EL:965*/a2.func_184586_b(a1);
        /*SL:966*/if (!v1.func_190926_b() && v1.func_77973_b().onEntitySwing(a2, v1)) {
            /*SL:967*/return;
        }
        /*SL:969*/if (!a2.field_82175_bq || a2.field_110158_av >= ((IEntityLivingBase)a2).getArmSwingAnimationEnd() / 2 || a2.field_110158_av < 0) {
            /*SL:970*/a2.field_110158_av = -1;
            /*SL:971*/a2.field_82175_bq = true;
            /*SL:972*/a2.field_184622_au = a1;
        }
    }
    
    public static Map<String, Integer> getTextRadarPlayers() {
        Map<String, Integer> sortByValue = /*EL:977*/new HashMap<String, Integer>();
        final DecimalFormat decimalFormat = /*EL:978*/new DecimalFormat("#.#");
        /*SL:979*/decimalFormat.setRoundingMode(RoundingMode.CEILING);
        final DecimalFormat decimalFormat2 = /*EL:980*/new DecimalFormat("#.#");
        /*SL:981*/decimalFormat2.setRoundingMode(RoundingMode.CEILING);
        final StringBuilder sb = /*EL:982*/new StringBuilder();
        final StringBuilder sb2 = /*EL:983*/new StringBuilder();
        /*SL:984*/for (final EntityPlayer v0 : EntityUtil.mc.field_71441_e.field_73010_i) {
            /*SL:985*/if (!v0.func_82150_aj()) {
                if (v0.func_70005_c_().equals(EntityUtil.mc.field_71439_g.func_70005_c_())) {
                    continue;
                }
                final int v = (int)getHealth(/*EL:986*/(Entity)v0);
                final String v2 = /*EL:987*/decimalFormat.format(v);
                /*SL:988*/sb.append("\u00c2�");
                /*SL:989*/if (v >= 20) {
                    /*SL:990*/sb.append("a");
                }
                else/*SL:991*/ if (v >= 10) {
                    /*SL:992*/sb.append("e");
                }
                else/*SL:993*/ if (v >= 5) {
                    /*SL:994*/sb.append("6");
                }
                else {
                    /*SL:996*/sb.append("c");
                }
                /*SL:998*/sb.append(v2);
                final int v3 = (int)EntityUtil.mc.field_71439_g.func_70032_d(/*EL:999*/(Entity)v0);
                final String v4 = /*EL:1000*/decimalFormat2.format(v3);
                /*SL:1001*/sb2.append("\u00c2�");
                /*SL:1002*/if (v3 >= 25) {
                    /*SL:1003*/sb2.append("a");
                }
                else/*SL:1004*/ if (v3 > 10) {
                    /*SL:1005*/sb2.append("6");
                }
                else {
                    /*SL:1007*/sb2.append("c");
                }
                /*SL:1009*/sb2.append(v4);
                /*SL:1010*/sortByValue.put(sb.toString() + " " + (Legacy.friendManager.isFriend(v0) ? ChatFormatting.AQUA : ChatFormatting.RED) + v0.func_70005_c_() + " " + sb2.toString() + " \u00c2�f0", (int)EntityUtil.mc.field_71439_g.func_70032_d((Entity)v0));
                /*SL:1011*/sb.setLength(0);
                /*SL:1012*/sb2.setLength(0);
            }
        }
        /*SL:1014*/if (!sortByValue.isEmpty()) {
            /*SL:1015*/sortByValue = MathUtil.<String, Integer>sortByValue(sortByValue, false);
        }
        /*SL:1017*/return sortByValue;
    }
    
    public static void setTimer(final float a1) {
        /*SL:1021*/Minecraft.func_71410_x().field_71428_T.field_194149_e = 50.0f / a1;
    }
    
    public static Block isColliding(final double v-7, final double v-5, final double v-3) {
        Block func_177230_c = /*EL:1025*/null;
        /*SL:1026*/if (EntityUtil.mc.field_71439_g != null) {
            AxisAlignedBB a3 = (EntityUtil.mc.field_71439_g.func_184187_bx() != /*EL:1027*/null) ? EntityUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(v-7, v-5, v-3) : EntityUtil.mc.field_71439_g.func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(v-7, v-5, v-3);
            final int v1 = /*EL:1028*/(int)a3.field_72338_b;
            /*SL:1029*/for (int a2 = MathHelper.func_76128_c(a3.field_72340_a); a2 < MathHelper.func_76128_c(a3.field_72336_d) + 1; ++a2) {
                /*SL:1030*/for (a3 = MathHelper.func_76128_c(a3.field_72339_c); a3 < MathHelper.func_76128_c(a3.field_72334_f) + 1; ++a3) {
                    /*SL:1031*/func_177230_c = EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(a2, v1, a3)).func_177230_c();
                }
            }
        }
        /*SL:1035*/return func_177230_c;
    }
    
    public static boolean isAboveBlock(final Entity a1, final BlockPos a2) {
        /*SL:1040*/return a1.field_70163_u >= a2.func_177956_o();
    }
    
    static {
        antiDropOffsetList = new Vec3d[] { new Vec3d(0.0, -2.0, 0.0) };
        platformOffsetList = new Vec3d[] { new Vec3d(0.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(1.0, -1.0, 0.0) };
        legOffsetList = new Vec3d[] { new Vec3d(-1.0, 0.0, 0.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(0.0, 0.0, 1.0) };
        OffsetList = new Vec3d[] { new Vec3d(1.0, 1.0, 0.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(0.0, 2.0, 0.0) };
        antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0, 2.0, 0.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(0.0, 2.0, -1.0) };
        antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0, 3.0, 0.0) };
        doubleLegOffsetList = new Vec3d[] { new Vec3d(-1.0, 0.0, 0.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-2.0, 0.0, 0.0), new Vec3d(2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -2.0), new Vec3d(0.0, 0.0, 2.0) };
    }
}
