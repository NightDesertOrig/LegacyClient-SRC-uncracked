package me.dev.legacy.api.util;

import net.minecraft.client.Minecraft;

public interface Util
{
    public static final Minecraft mc = Minecraft.func_71410_x();
}
