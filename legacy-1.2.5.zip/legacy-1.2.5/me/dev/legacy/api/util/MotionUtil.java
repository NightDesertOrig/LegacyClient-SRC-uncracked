package me.dev.legacy.api.util;

import net.minecraft.potion.Potion;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;

public class MotionUtil
{
    public static boolean isMoving(final EntityLivingBase a1) {
        /*SL:9*/return a1.field_191988_bg != 0.0f || a1.field_70702_br != 0.0f;
    }
    
    public static void setSpeed(final EntityLivingBase a1, final double a2) {
        final double[] v1 = forward(/*EL:13*/a2);
        /*SL:14*/a1.field_70159_w = v1[0];
        /*SL:15*/a1.field_70179_y = v1[1];
    }
    
    public static double getBaseMoveSpeed() {
        double n = /*EL:19*/0.2873;
        /*SL:20*/if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
            final int v1 = /*EL:21*/Minecraft.func_71410_x().field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
            /*SL:22*/n *= 1.0 + 0.2 * (v1 + 1);
        }
        /*SL:24*/return n;
    }
    
    public static double[] forward(final double a1) {
        float v1 = /*EL:28*/Minecraft.func_71410_x().field_71439_g.field_71158_b.field_192832_b;
        float v2 = /*EL:29*/Minecraft.func_71410_x().field_71439_g.field_71158_b.field_78902_a;
        float v3 = /*EL:30*/Minecraft.func_71410_x().field_71439_g.field_70126_B + (Minecraft.func_71410_x().field_71439_g.field_70177_z - Minecraft.func_71410_x().field_71439_g.field_70126_B) * Minecraft.func_71410_x().func_184121_ak();
        /*SL:31*/if (v1 != 0.0f) {
            /*SL:32*/if (v2 > 0.0f) {
                /*SL:33*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:34*/ if (v2 < 0.0f) {
                /*SL:35*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:37*/v2 = 0.0f;
            /*SL:38*/if (v1 > 0.0f) {
                /*SL:39*/v1 = 1.0f;
            }
            else/*SL:40*/ if (v1 < 0.0f) {
                /*SL:41*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:44*/Math.sin(Math.toRadians(v3 + 90.0f));
        final double v5 = /*EL:45*/Math.cos(Math.toRadians(v3 + 90.0f));
        final double v6 = /*EL:46*/v1 * a1 * v5 + v2 * a1 * v4;
        final double v7 = /*EL:47*/v1 * a1 * v4 - v2 * a1 * v5;
        /*SL:48*/return new double[] { v6, v7 };
    }
}
