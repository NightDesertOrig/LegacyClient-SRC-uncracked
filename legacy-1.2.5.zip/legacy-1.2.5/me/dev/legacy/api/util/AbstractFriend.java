package me.dev.legacy.api.util;

public abstract class AbstractFriend implements INameable, IFriendable
{
    private String name;
    private String alias;
    
    public AbstractFriend(final String a1, final String a2) {
        this.name = a1;
        this.alias = a2;
    }
    
    @Override
    public String getAlias() {
        /*SL:15*/return this.alias;
    }
    
    @Override
    public void setAlias(final String a1) {
        /*SL:20*/this.alias = a1;
    }
    
    @Override
    public String getName() {
        /*SL:25*/return this.name;
    }
    
    @Override
    public String getDisplayName() {
        /*SL:30*/return this.name;
    }
    
    @Override
    public void setName(final String a1) {
        /*SL:35*/this.name = a1;
    }
    
    @Override
    public void setDisplayName(final String a1) {
        /*SL:40*/this.name = this.name;
    }
}
