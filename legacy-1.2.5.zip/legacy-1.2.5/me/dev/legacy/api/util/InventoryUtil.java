package me.dev.legacy.api.util;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemArmor;
import net.minecraft.client.Minecraft;
import net.minecraft.inventory.EntityEquipmentSlot;
import me.dev.legacy.Legacy;
import java.util.HashMap;
import net.minecraft.inventory.Slot;
import net.minecraft.init.Items;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.item.Item;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;

public class InventoryUtil implements Util
{
    public static void switchToHotbarSlot(final int a1, final boolean a2) {
        /*SL:24*/if (InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == a1 || a1 < 0) {
            /*SL:25*/return;
        }
        /*SL:27*/if (a2) {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:28*/(Packet)new CPacketHeldItemChange(a1));
            InventoryUtil.mc.field_71442_b.func_78765_e();
        }
        else {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:31*/(Packet)new CPacketHeldItemChange(a1));
            InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:32*/a1;
            InventoryUtil.mc.field_71442_b.func_78765_e();
        }
    }
    
    public static void switchToHotbarSlot(final Class a1, final boolean a2) {
        final int v1 = findHotbarBlock(/*EL:38*/a1);
        /*SL:39*/if (v1 > -1) {
            switchToHotbarSlot(/*EL:40*/v1, a2);
        }
    }
    
    public static boolean isNull(final ItemStack a1) {
        /*SL:45*/return a1 == null || a1.func_77973_b() instanceof ItemAir;
    }
    
    public static int findHotbarBlock(final Class v-2) {
        /*SL:49*/for (int i = 0; i < 9; ++i) {
            final ItemStack v1 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:51*/i);
            /*SL:52*/if (v1 != ItemStack.field_190927_a) {
                /*SL:53*/if (v-2.isInstance(v1.func_77973_b())) {
                    /*SL:54*/return i;
                }
                /*SL:56*/if (v1.func_77973_b() instanceof ItemBlock) {
                    final Block a1;
                    if (v-2.isInstance(a1 = ((ItemBlock)v1.func_77973_b()).func_179223_d())) {
                        /*SL:58*/return i;
                    }
                }
            }
        }
        /*SL:60*/return -1;
    }
    
    public static int findHotbarBlock(final Block v-2) {
        /*SL:64*/for (int i = 0; i < 9; ++i) {
            final ItemStack v1 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:66*/i);
            final Block a1;
            if (/*EL:67*/v1 != ItemStack.field_190927_a && v1.func_77973_b() instanceof ItemBlock && (a1 = ((ItemBlock)v1.func_77973_b()).func_179223_d()) == v-2) {
                /*SL:69*/return i;
            }
        }
        /*SL:71*/return -1;
    }
    
    public static int getItemHotbar(final Item v0) {
        /*SL:75*/for (int v = 0; v < 9; ++v) {
            final Item a1 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:76*/v).func_77973_b();
            /*SL:77*/if (Item.func_150891_b(a1) == Item.func_150891_b(v0)) {
                /*SL:78*/return v;
            }
        }
        /*SL:80*/return -1;
    }
    
    public static int findStackInventory(final Item a1) {
        /*SL:84*/return findStackInventory(a1, false);
    }
    
    public static int findStackInventory(final Item a2, final boolean v1) {
        int v3;
        /*SL:90*/for (int v2 = v3 = (v1 ? 0 : 9); v2 < 36; /*SL:95*/++v2) {
            final Item a3 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(v2).func_77973_b();
            if (Item.func_150891_b(a2) == Item.func_150891_b(a3)) {
                return v2 + ((v2 < 9) ? 36 : 0);
            }
        }
        /*SL:97*/return -1;
    }
    
    public static int findItemInventorySlot(final Item a2, final boolean v1) {
        final AtomicInteger v2 = /*EL:101*/new AtomicInteger();
        /*SL:102*/v2.set(-1);
        /*SL:103*/for (final Map.Entry<Integer, ItemStack> a3 : getInventoryAndHotbarSlots().entrySet()) {
            /*SL:104*/if (a3.getValue().func_77973_b() == a2) {
                if (a3.getKey() == 45 && !v1) {
                    continue;
                }
                /*SL:105*/v2.set(a3.getKey());
                /*SL:106*/return v2.get();
            }
        }
        /*SL:108*/return v2.get();
    }
    
    public static List<Integer> getItemInventory(final Item v-1) {
        final List<Integer> v0 = /*EL:111*/new ArrayList<Integer>();
        /*SL:112*/for (int v = 9; v < 36; ++v) {
            final Item a1 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:114*/v).func_77973_b();
            /*SL:116*/if (v-1 instanceof ItemBlock && ((ItemBlock)v-1).func_179223_d().equals(v-1)) {
                v0.add(v);
            }
        }
        /*SL:119*/if (v0.size() == 0) {
            v0.add(-1);
        }
        /*SL:121*/return v0;
    }
    
    public static List<Integer> findEmptySlots(final boolean v-2) {
        final ArrayList<Integer> list = /*EL:124*/new ArrayList<Integer>();
        /*SL:125*/for (final Map.Entry<Integer, ItemStack> a1 : getInventoryAndHotbarSlots().entrySet()) {
            /*SL:126*/if (!a1.getValue().field_190928_g && a1.getValue().func_77973_b() != Items.field_190931_a) {
                continue;
            }
            /*SL:127*/list.add(a1.getKey());
        }
        /*SL:129*/if (v-2) {
            /*SL:130*/for (int v0 = 1; v0 < 5; ++v0) {
                final Slot v = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:131*/v0);
                final ItemStack v2 = /*EL:132*/v.func_75211_c();
                /*SL:133*/if (v2.func_190926_b() || v2.func_77973_b() == Items.field_190931_a) {
                    /*SL:134*/list.add(v0);
                }
            }
        }
        /*SL:137*/return list;
    }
    
    public static int findInventoryBlock(final Class a2, final boolean v1) {
        final AtomicInteger v2 = /*EL:141*/new AtomicInteger();
        /*SL:142*/v2.set(-1);
        /*SL:143*/for (final Map.Entry<Integer, ItemStack> a3 : getInventoryAndHotbarSlots().entrySet()) {
            /*SL:144*/if (isBlock(a3.getValue().func_77973_b(), a2)) {
                if (a3.getKey() == 45 && !v1) {
                    continue;
                }
                /*SL:145*/v2.set(a3.getKey());
                /*SL:146*/return v2.get();
            }
        }
        /*SL:148*/return v2.get();
    }
    
    public static boolean isBlock(final Item a2, final Class v1) {
        /*SL:152*/if (a2 instanceof ItemBlock) {
            final Block a3 = /*EL:153*/((ItemBlock)a2).func_179223_d();
            /*SL:154*/return v1.isInstance(a3);
        }
        /*SL:156*/return false;
    }
    
    public static void confirmSlot(final int a1) {
        InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:160*/(Packet)new CPacketHeldItemChange(a1));
        InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:161*/a1;
        InventoryUtil.mc.field_71442_b.func_78765_e();
    }
    
    public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        /*SL:166*/return getInventorySlots(9, 44);
    }
    
    private static Map<Integer, ItemStack> getInventorySlots(final int a2, final int v1) {
        final HashMap<Integer, ItemStack> v2 = /*EL:170*/new HashMap<Integer, ItemStack>();
        /*SL:171*/for (int a3 = a2; a3 <= v1; ++a3) {
            /*SL:172*/v2.put(a3, (ItemStack)InventoryUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(a3));
        }
        /*SL:174*/return v2;
    }
    
    public static boolean[] switchItem(final boolean a1, final int a2, final boolean a3, final Switch a4, final Class a5) {
        final boolean[] v1 = /*EL:178*/{ a3, false };
        /*SL:179*/switch (a4) {
            case NORMAL: {
                /*SL:181*/if (!a1 && !a3) {
                    switchToHotbarSlot(findHotbarBlock(/*EL:182*/a5), false);
                    /*SL:183*/v1[0] = true;
                }
                else/*SL:184*/ if (a1 && a3) {
                    switchToHotbarSlot(/*EL:185*/a2, false);
                    /*SL:186*/v1[0] = false;
                }
                /*SL:188*/v1[1] = true;
                /*SL:189*/break;
            }
            case SILENT: {
                /*SL:192*/if (!a1 && !a3) {
                    switchToHotbarSlot(findHotbarBlock(/*EL:193*/a5), true);
                    /*SL:194*/v1[0] = true;
                }
                else/*SL:195*/ if (a1 && a3) {
                    /*SL:196*/v1[0] = false;
                    Legacy.inventoryManager.recoverSilent(/*EL:197*/a2);
                }
                /*SL:199*/v1[1] = true;
                /*SL:200*/break;
            }
            case NONE: {
                /*SL:203*/v1[1] = (a1 || InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == findHotbarBlock(a5));
                break;
            }
        }
        /*SL:206*/return v1;
    }
    
    public static boolean[] switchItemToItem(final boolean a1, final int a2, final boolean a3, final Switch a4, final Item a5) {
        final boolean[] v1 = /*EL:210*/{ a3, false };
        /*SL:211*/switch (a4) {
            case NORMAL: {
                /*SL:213*/if (!a1 && !a3) {
                    switchToHotbarSlot(getItemHotbar(/*EL:214*/a5), false);
                    /*SL:215*/v1[0] = true;
                }
                else/*SL:216*/ if (a1 && a3) {
                    switchToHotbarSlot(/*EL:217*/a2, false);
                    /*SL:218*/v1[0] = false;
                }
                /*SL:220*/v1[1] = true;
                /*SL:221*/break;
            }
            case SILENT: {
                /*SL:224*/if (!a1 && !a3) {
                    switchToHotbarSlot(getItemHotbar(/*EL:225*/a5), true);
                    /*SL:226*/v1[0] = true;
                }
                else/*SL:227*/ if (a1 && a3) {
                    /*SL:228*/v1[0] = false;
                    Legacy.inventoryManager.recoverSilent(/*EL:229*/a2);
                }
                /*SL:231*/v1[1] = true;
                /*SL:232*/break;
            }
            case NONE: {
                /*SL:235*/v1[1] = (a1 || InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == getItemHotbar(a5));
                break;
            }
        }
        /*SL:238*/return v1;
    }
    
    public static boolean holdingItem(final Class v1) {
        boolean v2 = /*EL:242*/false;
        final ItemStack v3 = InventoryUtil.mc.field_71439_g.func_184614_ca();
        /*SL:244*/v2 = isInstanceOf(v3, v1);
        /*SL:245*/if (!v2) {
            final ItemStack a1 = InventoryUtil.mc.field_71439_g.func_184592_cb();
            /*SL:247*/v2 = isInstanceOf(v3, v1);
        }
        /*SL:249*/return v2;
    }
    
    public static boolean isInstanceOf(final ItemStack a2, final Class v1) {
        /*SL:253*/if (a2 == null) {
            /*SL:254*/return false;
        }
        final Item v2 = /*EL:256*/a2.func_77973_b();
        /*SL:257*/if (v1.isInstance(v2)) {
            /*SL:258*/return true;
        }
        /*SL:260*/if (v2 instanceof ItemBlock) {
            final Block a3 = /*EL:261*/Block.func_149634_a(v2);
            /*SL:262*/return v1.isInstance(a3);
        }
        /*SL:264*/return false;
    }
    
    public static int getEmptyXCarry() {
        /*SL:268*/for (int v0 = 1; v0 < 5; ++v0) {
            final Slot v = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:269*/v0);
            final ItemStack v2 = /*EL:270*/v.func_75211_c();
            /*SL:271*/if (v2.func_190926_b() || v2.func_77973_b() == Items.field_190931_a) {
                /*SL:272*/return v0;
            }
        }
        /*SL:274*/return -1;
    }
    
    public static boolean isSlotEmpty(final int a1) {
        final Slot v1 = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:278*/a1);
        final ItemStack v2 = /*EL:279*/v1.func_75211_c();
        /*SL:280*/return v2.func_190926_b();
    }
    
    public static int convertHotbarToInv(final int a1) {
        /*SL:284*/return 36 + a1;
    }
    
    public static boolean areStacksCompatible(final ItemStack v1, final ItemStack v2) {
        /*SL:288*/if (!v1.func_77973_b().equals(v2.func_77973_b())) {
            /*SL:289*/return false;
        }
        /*SL:291*/if (v1.func_77973_b() instanceof ItemBlock && v2.func_77973_b() instanceof ItemBlock) {
            final Block a1 = /*EL:292*/((ItemBlock)v1.func_77973_b()).func_179223_d();
            final Block a2 = /*EL:293*/((ItemBlock)v2.func_77973_b()).func_179223_d();
            /*SL:294*/if (!a1.field_149764_J.equals(a2.field_149764_J)) {
                /*SL:295*/return false;
            }
        }
        /*SL:298*/return v1.func_82833_r().equals(v2.func_82833_r()) && /*EL:301*/v1.func_77952_i() == v2.func_77952_i();
    }
    
    public static EntityEquipmentSlot getEquipmentFromSlot(final int a1) {
        /*SL:305*/if (a1 == 5) {
            /*SL:306*/return EntityEquipmentSlot.HEAD;
        }
        /*SL:308*/if (a1 == 6) {
            /*SL:309*/return EntityEquipmentSlot.CHEST;
        }
        /*SL:311*/if (a1 == 7) {
            /*SL:312*/return EntityEquipmentSlot.LEGS;
        }
        /*SL:314*/return EntityEquipmentSlot.FEET;
    }
    
    public static int findArmorSlot(final EntityEquipmentSlot v-6, final boolean v-5) {
        int n = /*EL:318*/-1;
        float n2 = /*EL:319*/0.0f;
        /*SL:320*/for (int i = 9; i < 45; ++i) {
            final ItemStack v1 = /*EL:323*/Minecraft.func_71410_x().field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            /*SL:324*/if (v1.func_77973_b() != Items.field_190931_a && v1.func_77973_b() instanceof ItemArmor) {
                ItemArmor a2;
                boolean a2;
                if ((a2 = (ItemArmor)v1.func_77973_b()).func_185083_B_() == v-6) {
                    final float v2 = /*EL:326*/a2.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, v1);
                    final boolean v3;
                    /*SL:327*/a2 = (v3 = (v-5 && EnchantmentHelper.func_190938_b(v1)));
                    /*SL:328*/if (v2 > n2) {
                        if (!a2) {
                            /*SL:329*/n2 = v2;
                            /*SL:330*/n = i;
                        }
                    }
                }
            }
        }
        /*SL:332*/return n;
    }
    
    public static int findArmorSlot(final EntityEquipmentSlot v-8, final boolean v-7, final boolean v-6) {
        int armorSlot = findArmorSlot(/*EL:336*/v-8, v-7);
        /*SL:337*/if (armorSlot == -1 && v-6) {
            float n = /*EL:338*/0.0f;
            /*SL:339*/for (int i = 1; i < 5; ++i) {
                Slot a3 = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:342*/i);
                final ItemStack v1 = /*EL:343*/a3.func_75211_c();
                /*SL:344*/if (v1.func_77973_b() != Items.field_190931_a && v1.func_77973_b() instanceof ItemArmor) {
                    final ItemArmor a2;
                    if ((a2 = (ItemArmor)v1.func_77973_b()).func_185083_B_() == v-8) {
                        final float v2 = /*EL:346*/a2.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, v1);
                        final boolean v3;
                        /*SL:347*/a3 = (v3 = (v-7 && EnchantmentHelper.func_190938_b(v1)));
                        /*SL:348*/if (v2 > n) {
                            if (!a3) {
                                /*SL:349*/n = v2;
                                /*SL:350*/armorSlot = i;
                            }
                        }
                    }
                }
            }
        }
        /*SL:353*/return armorSlot;
    }
    
    public static int findItemInventorySlot(final Item v-3, final boolean v-2, final boolean v-1) {
        int v0 = findItemInventorySlot(/*EL:357*/v-3, v-2);
        /*SL:358*/if (v0 == -1 && v-1) {
            /*SL:359*/for (int v = 1; v < 5; ++v) {
                Slot a2 = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:361*/v);
                /*SL:362*/a2 = a2.func_75211_c();
                /*SL:363*/if (a2.func_77973_b() != Items.field_190931_a) {
                    final Item a3;
                    if ((a3 = a2.func_77973_b()) == v-3) {
                        /*SL:365*/v0 = v;
                    }
                }
            }
        }
        /*SL:368*/return v0;
    }
    
    public static int findBlockSlotInventory(final Class v-7, final boolean v-6, final boolean v-5) {
        int inventoryBlock = findInventoryBlock(/*EL:372*/v-7, v-6);
        /*SL:373*/if (inventoryBlock == -1 && v-5) {
            /*SL:374*/for (int i = 1; i < 5; ++i) {
                Slot a2 = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:376*/i);
                /*SL:377*/a2 = a2.func_75211_c();
                /*SL:378*/if (a2.func_77973_b() != Items.field_190931_a) {
                    final Item v1 = /*EL:379*/a2.func_77973_b();
                    /*SL:380*/if (v-7.isInstance(v1)) {
                        /*SL:381*/inventoryBlock = i;
                    }
                    else/*SL:384*/ if (v1 instanceof ItemBlock) {
                        final Block a3;
                        if (v-7.isInstance(a3 = ((ItemBlock)v1).func_179223_d())) {
                            /*SL:386*/inventoryBlock = i;
                        }
                    }
                }
            }
        }
        /*SL:389*/return inventoryBlock;
    }
    
    public enum Switch
    {
        NORMAL, 
        SILENT, 
        NONE;
    }
    
    public static class Task
    {
        private final int slot;
        private final boolean update;
        private final boolean quickClick;
        
        public Task() {
            this.update = true;
            this.slot = -1;
            this.quickClick = false;
        }
        
        public Task(final int a1) {
            this.slot = a1;
            this.quickClick = false;
            this.update = false;
        }
        
        public Task(final int a1, final boolean a2) {
            this.slot = a1;
            this.quickClick = a2;
            this.update = false;
        }
        
        public void run() {
            /*SL:423*/if (this.update) {
                Util.mc.field_71442_b.func_78765_e();
            }
            /*SL:426*/if (this.slot != -1) {
                Util.mc.field_71442_b.func_187098_a(/*EL:427*/0, this.slot, 0, this.quickClick ? ClickType.QUICK_MOVE : ClickType.PICKUP, (EntityPlayer)Util.mc.field_71439_g);
            }
        }
        
        public boolean isSwitching() {
            /*SL:432*/return !this.update;
        }
    }
}
