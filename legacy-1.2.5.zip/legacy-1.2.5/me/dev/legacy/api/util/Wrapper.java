package me.dev.legacy.api.util;

import org.lwjgl.input.Keyboard;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class Wrapper
{
    private static FontRenderer fontRenderer;
    public static Minecraft mc;
    
    public static Minecraft getMinecraft() {
        /*SL:17*/return Minecraft.func_71410_x();
    }
    
    public static Minecraft GetMC() {
        /*SL:22*/return Wrapper.mc;
    }
    
    public static EntityPlayerSP GetPlayer() {
        /*SL:27*/return Wrapper.mc.field_71439_g;
    }
    
    public static EntityPlayerSP getPlayer() {
        /*SL:31*/return getMinecraft().field_71439_g;
    }
    
    public static Entity getRenderEntity() {
        /*SL:35*/return Wrapper.mc.func_175606_aa();
    }
    
    public static World getWorld() {
        /*SL:39*/return (World)getMinecraft().field_71441_e;
    }
    
    public static int getKey(final String a1) {
        /*SL:43*/return Keyboard.getKeyIndex(a1.toUpperCase());
    }
    
    public static FontRenderer getFontRenderer() {
        /*SL:47*/return Wrapper.fontRenderer;
    }
    
    static {
        Wrapper.mc = Minecraft.func_71410_x();
    }
}
