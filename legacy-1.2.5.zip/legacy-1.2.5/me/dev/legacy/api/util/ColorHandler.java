package me.dev.legacy.api.util;

import java.awt.Color;

public class ColorHandler
{
    private static Color color;
    
    public static int getColorInt() {
        /*SL:10*/return ColorHandler.color.getRGB();
    }
    
    public static Color getColor() {
        /*SL:14*/return ColorHandler.color;
    }
    
    public static void setColor(final int a1, final int a2, final int a3) {
        ColorHandler.color = /*EL:18*/new Color(a1, a2, a3);
    }
    
    public static void setColor(final Color a1) {
        ColorHandler.color = /*EL:22*/a1;
    }
    
    static {
        ColorHandler.color = new Color(255, 255, 255);
    }
}
