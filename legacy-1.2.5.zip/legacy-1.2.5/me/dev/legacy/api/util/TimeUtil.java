package me.dev.legacy.api.util;

import java.util.Calendar;

public class TimeUtil implements Util
{
    public static int get_hour() {
        /*SL:8*/return Calendar.getInstance().get(11);
    }
    
    public static int get_day() {
        /*SL:12*/return Calendar.getInstance().get(5);
    }
    
    public static int get_month() {
        /*SL:16*/return Calendar.getInstance().get(2);
    }
    
    public static int get_year() {
        /*SL:19*/return Calendar.getInstance().get(1);
    }
    
    public static int get_minuite() {
        /*SL:22*/return Calendar.getInstance().get(12);
    }
    
    public static int get_second() {
        /*SL:26*/return Calendar.getInstance().get(13);
    }
}
