package me.dev.legacy;

import org.apache.logging.log4j.LogManager;
import me.dev.legacy.api.util.Title;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import java.io.InputStream;
import org.lwjgl.opengl.Display;
import me.dev.legacy.api.util.IconUtil;
import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import me.dev.legacy.api.util.Enemy;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.impl.gui.font.CustomFont;
import me.dev.legacy.api.manager.TextManager;
import me.dev.legacy.api.manager.EventManager;
import me.dev.legacy.api.manager.ServerManager;
import me.dev.legacy.api.manager.ConfigManager;
import me.dev.legacy.api.manager.FileManager;
import me.dev.legacy.api.manager.ReloadManager;
import me.dev.legacy.api.manager.SpeedManager;
import me.dev.legacy.api.manager.PositionManager;
import me.dev.legacy.api.manager.RotationManager;
import me.dev.legacy.api.manager.PotionManager;
import me.dev.legacy.api.manager.InventoryManager;
import me.dev.legacy.api.manager.HoleManager;
import me.dev.legacy.api.manager.ColorManager;
import me.dev.legacy.api.manager.PacketManager;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.api.manager.FriendManager;
import me.dev.legacy.api.manager.CommandManager;
import me.dev.legacy.api.manager.TotemPopManager;
import me.dev.legacy.api.manager.TimerManager;
import org.apache.logging.log4j.Logger;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "legacy", name = "legacy", version = "1.2.5")
public class Legacy
{
    public static final String MODID = "legacy";
    public static final String MODNAME = "Legacy";
    public static final String MODVER = "v1.2.5";
    public static final Logger LOGGER;
    public static TimerManager timerManager;
    public static TotemPopManager totemPopManager;
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static CustomFont fontRenderer;
    public static Render3DEvent render3DEvent;
    public static Enemy enemy;
    public static me.zero.alpine.EventManager eventManager1;
    @Mod.Instance
    public static Legacy INSTANCE;
    private static boolean unloaded;
    
    public static me.zero.alpine.EventManager getEventManager() {
        /*SL:57*/if (Legacy.eventManager1 == null) {
            Legacy.eventManager1 = /*EL:58*/new me.zero.alpine.EventManager();
        }
        /*SL:61*/return Legacy.eventManager1;
    }
    
    public static void load() {
        Legacy.LOGGER.info(/*EL:69*/"loading legacy");
        Legacy.unloaded = /*EL:70*/false;
        /*SL:71*/if (Legacy.reloadManager != null) {
            Legacy.reloadManager.unload();
            Legacy.reloadManager = /*EL:73*/null;
        }
        Legacy.textManager = /*EL:75*/new TextManager();
        Legacy.commandManager = /*EL:76*/new CommandManager();
        Legacy.friendManager = /*EL:77*/new FriendManager();
        Legacy.moduleManager = /*EL:78*/new ModuleManager();
        Legacy.rotationManager = /*EL:79*/new RotationManager();
        Legacy.packetManager = /*EL:80*/new PacketManager();
        Legacy.eventManager = /*EL:81*/new EventManager();
        Legacy.speedManager = /*EL:82*/new SpeedManager();
        Legacy.potionManager = /*EL:83*/new PotionManager();
        Legacy.inventoryManager = /*EL:84*/new InventoryManager();
        Legacy.serverManager = /*EL:85*/new ServerManager();
        Legacy.fileManager = /*EL:86*/new FileManager();
        Legacy.colorManager = /*EL:87*/new ColorManager();
        Legacy.positionManager = /*EL:88*/new PositionManager();
        Legacy.configManager = /*EL:89*/new ConfigManager();
        Legacy.holeManager = /*EL:90*/new HoleManager();
        Legacy.LOGGER.info(/*EL:91*/"Managers loaded.");
        Legacy.moduleManager.init();
        Legacy.LOGGER.info(/*EL:93*/"Modules loaded.");
        Legacy.configManager.init();
        Legacy.eventManager.init();
        Legacy.LOGGER.info(/*EL:96*/"EventManager loaded.");
        Legacy.textManager.init(/*EL:97*/true);
        Legacy.moduleManager.onLoad();
        Legacy.LOGGER.info(/*EL:99*/"legacy successfully loaded!\n");
    }
    
    public static void unload(final boolean a1) {
        Legacy.LOGGER.info(/*EL:103*/"unloading legacy");
        /*SL:104*/if (a1) {
            (Legacy.reloadManager = /*EL:105*/new ReloadManager()).init((Legacy.commandManager != /*EL:106*/null) ? Legacy.commandManager.getPrefix() : ".");
        }
        onUnload();
        Legacy.eventManager = /*EL:109*/null;
        Legacy.friendManager = /*EL:110*/null;
        Legacy.speedManager = /*EL:111*/null;
        Legacy.holeManager = /*EL:112*/null;
        Legacy.positionManager = /*EL:113*/null;
        Legacy.rotationManager = /*EL:114*/null;
        Legacy.configManager = /*EL:115*/null;
        Legacy.commandManager = /*EL:116*/null;
        Legacy.colorManager = /*EL:117*/null;
        Legacy.serverManager = /*EL:118*/null;
        Legacy.fileManager = /*EL:119*/null;
        Legacy.potionManager = /*EL:120*/null;
        Legacy.inventoryManager = /*EL:121*/null;
        Legacy.moduleManager = /*EL:122*/null;
        Legacy.textManager = /*EL:123*/null;
        Legacy.LOGGER.info(/*EL:124*/"legacy unloaded!\n");
    }
    
    public static void reload() {
        unload(/*EL:128*/false);
        load();
    }
    
    public static void onUnload() {
        /*SL:133*/if (!Legacy.unloaded) {
            Legacy.eventManager.onUnload();
            Legacy.moduleManager.onUnload();
            Legacy.configManager.saveConfig(Legacy.configManager.config.replaceFirst(/*EL:136*/"legacy/", ""));
            Legacy.moduleManager.onUnloadPost();
            Legacy.unloaded = /*EL:138*/true;
        }
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent a1) {
        Legacy.LOGGER.info(/*EL:144*/"blackbro4 n' rianix cool ppl's");
    }
    
    public static void setWindowIcon() {
        /*SL:149*/if (Util.func_110647_a() != Util.EnumOS.OSX) {
            try (/*SL:150*/final InputStream resourceAsStream = Minecraft.class.getResourceAsStream("/assets/legacy/icons/legacy-16x.png");
                 /*SL:151*/final InputStream resourceAsStream2 = Minecraft.class.getResourceAsStream("/assets/legacy/icons/legacy-32x.png")) {
                final ByteBuffer[] v1 = /*EL:152*/{ IconUtil.INSTANCE.readImageToBuffer(resourceAsStream), IconUtil.INSTANCE.readImageToBuffer(resourceAsStream2) };
                /*SL:153*/Display.setIcon(v1);
            }
            catch (Exception ex) {
                Legacy.LOGGER.error(/*EL:155*/"Couldn't set Windows Icon", (Throwable)ex);
            }
        }
    }
    
    private void setWindowsIcon() {
        setWindowIcon();
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent a1) {
        MinecraftForge.EVENT_BUS.register(/*EL:166*/(Object)new Title());
        load();
        /*SL:168*/this.setWindowsIcon();
    }
    
    static {
        LOGGER = LogManager.getLogger("legacy");
        Legacy.unloaded = false;
    }
}
