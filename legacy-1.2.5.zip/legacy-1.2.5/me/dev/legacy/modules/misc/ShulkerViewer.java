package me.dev.legacy.modules.misc;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.client.renderer.RenderHelper;
import me.dev.legacy.api.util.ColorUtil;
import java.awt.Color;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.api.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import java.util.Iterator;
import me.dev.legacy.api.AbstractModule;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.world.World;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.tileentity.TileEntityShulkerBox;
import java.util.concurrent.ConcurrentHashMap;
import me.dev.legacy.api.util.Timer;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import net.minecraft.util.ResourceLocation;
import me.dev.legacy.modules.Module;

public class ShulkerViewer extends Module
{
    private static final ResourceLocation SHULKER_GUI_TEXTURE;
    private static ShulkerViewer INSTANCE;
    public Map<EntityPlayer, ItemStack> spiedPlayers;
    public Map<EntityPlayer, Timer> playerTimers;
    private int textRadarY;
    
    public ShulkerViewer() {
        super("ShulkerViewer", "Several tweaks for tooltips.", Category.MISC, true, false, false);
        this.spiedPlayers = new ConcurrentHashMap<EntityPlayer, ItemStack>();
        this.playerTimers = new ConcurrentHashMap<EntityPlayer, Timer>();
        this.textRadarY = 0;
        this.setInstance();
    }
    
    public static ShulkerViewer getInstance() {
        /*SL:41*/if (ShulkerViewer.INSTANCE == null) {
            ShulkerViewer.INSTANCE = /*EL:42*/new ShulkerViewer();
        }
        /*SL:44*/return ShulkerViewer.INSTANCE;
    }
    
    public static void displayInv(final ItemStack v-3, final String v-2) {
        try {
            final Item a1 = /*EL:49*/v-3.func_77973_b();
            final TileEntityShulkerBox a2 = /*EL:50*/new TileEntityShulkerBox();
            final ItemShulkerBox v1 = /*EL:51*/(ItemShulkerBox)a1;
            /*SL:52*/a2.field_145854_h = v1.func_179223_d();
            /*SL:53*/a2.func_145834_a((World)ShulkerViewer.mc.field_71441_e);
            /*SL:54*/ItemStackHelper.func_191283_b(v-3.func_77978_p().func_74775_l("BlockEntityTag"), a2.field_190596_f);
            /*SL:55*/a2.func_145839_a(v-3.func_77978_p().func_74775_l("BlockEntityTag"));
            /*SL:56*/a2.func_190575_a((v-2 == null) ? v-3.func_82833_r() : v-2);
            final IInventory inventory;
            /*SL:57*/new Thread(() -> {
                try {
                    Thread.sleep(200L);
                }
                catch (InterruptedException ex) {}
                ShulkerViewer.mc.field_71439_g.func_71007_a(inventory);
            }).start();
        }
        catch (Exception ex2) {}
    }
    
    private void setInstance() {
        ShulkerViewer.INSTANCE = /*EL:71*/this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:76*/if (AbstractModule.fullNullCheck()) {
            /*SL:77*/return;
        }
        /*SL:79*/for (final EntityPlayer v0 : ShulkerViewer.mc.field_71441_e.field_73010_i) {
            /*SL:80*/if (v0 != null && v0.func_184614_ca().func_77973_b() instanceof ItemShulkerBox) {
                if (ShulkerViewer.mc.field_71439_g == v0) {
                    /*SL:81*/continue;
                }
                final ItemStack v = /*EL:82*/v0.func_184614_ca();
                /*SL:83*/this.spiedPlayers.put(v0, v);
            }
        }
    }
    
    @Override
    public void onRender2D(final Render2DEvent v-4) {
        /*SL:89*/if (AbstractModule.fullNullCheck()) {
            /*SL:90*/return;
        }
        final int v-5 = /*EL:92*/-3;
        int v-6 = /*EL:93*/124;
        /*SL:94*/this.textRadarY = 0;
        /*SL:95*/for (final EntityPlayer v0 : ShulkerViewer.mc.field_71441_e.field_73010_i) {
            /*SL:97*/if (this.spiedPlayers.get(v0) == null) {
                continue;
            }
            /*SL:98*/if (v0.func_184614_ca() == null || !(v0.func_184614_ca().func_77973_b() instanceof ItemShulkerBox)) {
                final Timer v = /*EL:99*/this.playerTimers.get(v0);
                /*SL:100*/if (v == null) {
                    final Timer a1 = /*EL:101*/new Timer();
                    /*SL:102*/a1.reset();
                    /*SL:103*/this.playerTimers.put(v0, a1);
                }
                else/*SL:104*/ if (v.passedS(3.0)) {
                    /*SL:105*/continue;
                }
            }
            else {
                final Timer v;
                /*SL:107*/if (v0.func_184614_ca().func_77973_b() instanceof ItemShulkerBox && (v = this.playerTimers.get(v0)) != null) {
                    /*SL:108*/v.reset();
                    /*SL:109*/this.playerTimers.put(v0, v);
                }
            }
            final ItemStack v2 = /*EL:111*/this.spiedPlayers.get(v0);
            /*SL:112*/this.renderShulkerToolTip(v2, v-5, v-6, v0.func_70005_c_());
            /*SL:113*/v-6 += 78;
            this.textRadarY = v-6 - 10 - 114 + 2;
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void makeTooltip(final ItemTooltipEvent a1) {
    }
    
    public void renderShulkerToolTip(final ItemStack v-5, final int v-4, final int v-3, final String v-2) {
        final NBTTagCompound v0 = /*EL:123*/v-5.func_77978_p();
        final NBTTagCompound func_74775_l;
        /*SL:124*/if (v0 != null && v0.func_150297_b("BlockEntityTag", 10) && (func_74775_l = v0.func_74775_l("BlockEntityTag")).func_150297_b("Items", 9)) {
            /*SL:125*/GlStateManager.func_179098_w();
            /*SL:126*/GlStateManager.func_179140_f();
            /*SL:127*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
            /*SL:128*/GlStateManager.func_179147_l();
            /*SL:129*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            ShulkerViewer.mc.func_110434_K().func_110577_a(ShulkerViewer.SHULKER_GUI_TEXTURE);
            /*SL:131*/RenderUtil.drawTexturedRect(v-4, v-3, 0, 0, 176, 16, 500);
            /*SL:132*/RenderUtil.drawTexturedRect(v-4, v-3 + 16, 0, 16, 176, 57, 500);
            /*SL:133*/RenderUtil.drawTexturedRect(v-4, v-3 + 16 + 54, 0, 160, 176, 8, 500);
            /*SL:134*/GlStateManager.func_179097_i();
            final Color v = /*EL:135*/new Color(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue(), 200);
            /*SL:136*/this.renderer.drawStringWithShadow((v-2 == null) ? v-5.func_82833_r() : v-2, v-4 + 8, v-3 + 6, ColorUtil.toRGBA(v));
            /*SL:137*/GlStateManager.func_179126_j();
            /*SL:138*/RenderHelper.func_74520_c();
            /*SL:139*/GlStateManager.func_179091_B();
            /*SL:140*/GlStateManager.func_179142_g();
            /*SL:141*/GlStateManager.func_179145_e();
            final NonNullList v2 = /*EL:142*/NonNullList.func_191197_a(27, (Object)ItemStack.field_190927_a);
            /*SL:143*/ItemStackHelper.func_191283_b(func_74775_l, v2);
            /*SL:144*/for (ItemStack a4 = (ItemStack)0; a4 < v2.size(); ++a4) {
                final int a2 = /*EL:145*/v-4 + a4 % 9 * 18 + 8;
                final int a3 = /*EL:146*/v-3 + a4 / 9 * 18 + 18;
                /*SL:147*/a4 = (ItemStack)v2.get(a4);
                ShulkerViewer.mc.func_175597_ag().field_178112_h.field_77023_b = /*EL:148*/501.0f;
                RenderUtil.itemRender.func_180450_b(/*EL:149*/a4, a2, a3);
                RenderUtil.itemRender.func_180453_a(ShulkerViewer.mc.field_71466_p, /*EL:150*/a4, a2, a3, (String)null);
                ShulkerViewer.mc.func_175597_ag().field_178112_h.field_77023_b = /*EL:151*/0.0f;
            }
            /*SL:153*/GlStateManager.func_179140_f();
            /*SL:154*/GlStateManager.func_179084_k();
            /*SL:155*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
    
    static {
        SHULKER_GUI_TEXTURE = new ResourceLocation("textures/gui/container/shulker_box.png");
        ShulkerViewer.INSTANCE = new ShulkerViewer();
    }
}
