package me.dev.legacy.modules.player;

import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.move.MoveEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Freecam extends Module
{
    private static Freecam INSTANCE;
    public Setting<Double> speed;
    public Setting<Boolean> packet;
    private double posX;
    private double posY;
    private double posZ;
    private float pitch;
    private float yaw;
    private EntityOtherPlayerMP clonedPlayer;
    private boolean isRidingEntity;
    private Entity ridingEntity;
    
    public Freecam() {
        super("Freecam", "Look around freely.", Category.PLAYER, true, false, false);
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)0.5, (T)0.1, (T)5.0));
        this.packet = (Setting<Boolean>)this.register(new Setting("Cancel Packets", (T)true));
        this.setInstance();
    }
    
    public static Freecam getInstance() {
        /*SL:34*/if (Freecam.INSTANCE == null) {
            Freecam.INSTANCE = /*EL:35*/new Freecam();
        }
        /*SL:36*/return Freecam.INSTANCE;
    }
    
    private void setInstance() {
        Freecam.INSTANCE = /*EL:40*/this;
    }
    
    @Override
    public void onEnable() {
        /*SL:45*/if (Freecam.mc.field_71439_g != null) {
            /*SL:46*/this.isRidingEntity = (Freecam.mc.field_71439_g.func_184187_bx() != null);
            /*SL:48*/if (Freecam.mc.field_71439_g.func_184187_bx() == null) {
                /*SL:49*/this.posX = Freecam.mc.field_71439_g.field_70165_t;
                /*SL:50*/this.posY = Freecam.mc.field_71439_g.field_70163_u;
                /*SL:51*/this.posZ = Freecam.mc.field_71439_g.field_70161_v;
            }
            else {
                /*SL:53*/this.ridingEntity = Freecam.mc.field_71439_g.func_184187_bx();
                Freecam.mc.field_71439_g.func_184210_p();
            }
            /*SL:57*/this.pitch = Freecam.mc.field_71439_g.field_70125_A;
            /*SL:58*/this.yaw = Freecam.mc.field_71439_g.field_70177_z;
            /*SL:60*/(this.clonedPlayer = new EntityOtherPlayerMP((World)Freecam.mc.field_71441_e, Freecam.mc.func_110432_I().func_148256_e())).func_82149_j((Entity)Freecam.mc.field_71439_g);
            /*SL:62*/this.clonedPlayer.field_70759_as = Freecam.mc.field_71439_g.field_70759_as;
            Freecam.mc.field_71441_e.func_73027_a(/*EL:63*/-100, (Entity)this.clonedPlayer);
            Freecam.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:64*/true;
            Freecam.mc.field_71439_g.field_71075_bZ.func_75092_a(/*EL:65*/(float)(this.speed.getValue() / 100.0));
            Freecam.mc.field_71439_g.field_70145_X = /*EL:66*/true;
        }
    }
    
    @Override
    public void onDisable() {
        final EntityPlayer v1 = (EntityPlayer)Freecam.mc.field_71439_g;
        /*SL:73*/if (v1 != null) {
            Freecam.mc.field_71439_g.func_70080_a(/*EL:74*/this.posX, this.posY, this.posZ, this.yaw, this.pitch);
            Freecam.mc.field_71441_e.func_73028_b(/*EL:75*/-100);
            /*SL:76*/this.clonedPlayer = null;
            final double posX = /*EL:77*/0.0;
            this.posZ = posX;
            this.posY = posX;
            this.posX = posX;
            final float n = /*EL:78*/0.0f;
            this.yaw = n;
            this.pitch = n;
            Freecam.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:79*/false;
            Freecam.mc.field_71439_g.field_71075_bZ.func_75092_a(/*EL:80*/0.05f);
            Freecam.mc.field_71439_g.field_70145_X = /*EL:81*/false;
            final EntityPlayerSP field_71439_g = Freecam.mc.field_71439_g;
            final EntityPlayerSP field_71439_g2 = Freecam.mc.field_71439_g;
            final EntityPlayerSP field_71439_g3 = Freecam.mc.field_71439_g;
            final double field_70159_w = /*EL:82*/0.0;
            field_71439_g3.field_70179_y = field_70159_w;
            field_71439_g2.field_70181_x = field_70159_w;
            field_71439_g.field_70159_w = field_70159_w;
            /*SL:84*/if (this.isRidingEntity) {
                Freecam.mc.field_71439_g.func_184205_a(/*EL:85*/this.ridingEntity, true);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        Freecam.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:92*/true;
        Freecam.mc.field_71439_g.field_71075_bZ.func_75092_a(/*EL:93*/(float)(this.speed.getValue() / 100.0));
        Freecam.mc.field_71439_g.field_70145_X = /*EL:94*/true;
        Freecam.mc.field_71439_g.field_70122_E = /*EL:95*/false;
        Freecam.mc.field_71439_g.field_70143_R = /*EL:96*/0.0f;
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent a1) {
        Freecam.mc.field_71439_g.field_70145_X = /*EL:101*/true;
    }
    
    @SubscribeEvent
    public void onPlayerPushOutOfBlock(final PlayerSPPushOutOfBlocksEvent a1) {
        /*SL:106*/a1.setCanceled(true);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent a1) {
        /*SL:111*/if ((a1.getPacket() instanceof CPacketPlayer || a1.getPacket() instanceof CPacketInput) && this.packet.getValue()) {
            /*SL:112*/a1.setCanceled(true);
        }
    }
    
    static {
        Freecam.INSTANCE = new Freecam();
    }
}
