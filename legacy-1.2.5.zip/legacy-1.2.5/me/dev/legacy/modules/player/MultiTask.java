package me.dev.legacy.modules.player;

import me.dev.legacy.modules.Module;

public class MultiTask extends Module
{
    private static MultiTask INSTANCE;
    
    public MultiTask() {
        super("MultiTask", "Allows you to eat while mining.", Category.PLAYER, false, false, false);
        this.setInstance();
    }
    
    public static MultiTask getInstance() {
        /*SL:14*/if (MultiTask.INSTANCE == null) {
            MultiTask.INSTANCE = /*EL:15*/new MultiTask();
        }
        /*SL:17*/return MultiTask.INSTANCE;
    }
    
    private void setInstance() {
        MultiTask.INSTANCE = /*EL:21*/this;
    }
    
    static {
        MultiTask.INSTANCE = new MultiTask();
    }
}
