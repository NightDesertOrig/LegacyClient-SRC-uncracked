package me.dev.legacy.modules.movement;

import me.dev.legacy.api.AbstractModule;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.move.MoveEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Sprint extends Module
{
    public Setting<Mode> mode;
    private static Sprint INSTANCE;
    
    public Sprint() {
        super("Sprint", "Modifies sprinting", Category.MOVEMENT, false, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.LEGIT));
        this.setInstance();
    }
    
    private void setInstance() {
        Sprint.INSTANCE = /*EL:18*/this;
    }
    
    public static Sprint getInstance() {
        /*SL:22*/if (Sprint.INSTANCE == null) {
            Sprint.INSTANCE = /*EL:23*/new Sprint();
        }
        /*SL:25*/return Sprint.INSTANCE;
    }
    
    @SubscribeEvent
    public void onSprint(final MoveEvent a1) {
        /*SL:30*/if (a1.getStage() == 1 && this.mode.getValue() == Mode.RAGE && (Sprint.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || Sprint.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f)) {
            /*SL:31*/a1.setCanceled(true);
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:37*/switch (this.mode.getValue()) {
            case RAGE: {
                /*SL:39*/if ((!Sprint.mc.field_71474_y.field_74351_w.func_151470_d() && !Sprint.mc.field_71474_y.field_74368_y.func_151470_d() && !Sprint.mc.field_71474_y.field_74370_x.func_151470_d() && !Sprint.mc.field_71474_y.field_74366_z.func_151470_d()) || Sprint.mc.field_71439_g.func_70093_af() || Sprint.mc.field_71439_g.field_70123_F) {
                    break;
                }
                if (Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f) {
                    break;
                }
                Sprint.mc.field_71439_g.func_70031_b(/*EL:40*/true);
                /*SL:41*/break;
            }
            case LEGIT: {
                /*SL:44*/if (!Sprint.mc.field_71474_y.field_74351_w.func_151470_d() || Sprint.mc.field_71439_g.func_70093_af() || Sprint.mc.field_71439_g.func_184587_cr() || Sprint.mc.field_71439_g.field_70123_F || Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f) {
                    break;
                }
                if (Sprint.mc.field_71462_r != null) {
                    break;
                }
                Sprint.mc.field_71439_g.func_70031_b(/*EL:45*/true);
                break;
            }
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:52*/if (!AbstractModule.nullCheck()) {
            Sprint.mc.field_71439_g.func_70031_b(/*EL:53*/false);
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:59*/return this.mode.currentEnumName();
    }
    
    static {
        Sprint.INSTANCE = new Sprint();
    }
    
    public enum Mode
    {
        LEGIT, 
        RAGE;
    }
}
