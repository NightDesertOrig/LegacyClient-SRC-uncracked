package me.dev.legacy.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import org.lwjgl.input.Keyboard;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.Legacy;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWeb;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.block.BlockCollisionBoundingBoxEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class NoWeb extends Module
{
    public Setting<Boolean> disableBB;
    public Setting<Float> bbOffset;
    public Setting<Boolean> onGround;
    public Setting<Float> motionY;
    public Setting<Float> motionX;
    
    public NoWeb() {
        super("NoWeb", "aw", Category.MOVEMENT, true, false, false);
        this.disableBB = (Setting<Boolean>)this.register(new Setting("AddBB", (T)true));
        this.bbOffset = (Setting<Float>)this.register(new Setting("BBOffset", (T)0.4f, (T)(-2.0f), (T)2.0f));
        this.onGround = (Setting<Boolean>)this.register(new Setting("On Ground", (T)true));
        this.motionY = (Setting<Float>)this.register(new Setting("Set MotionY", (T)0.0f, (T)0.0f, (T)20.0f));
        this.motionX = (Setting<Float>)this.register(new Setting("Set MotionX", (T)0.8f, (T)(-1.0f), (T)5.0f));
    }
    
    @SubscribeEvent
    public void bbEvent(final BlockCollisionBoundingBoxEvent a1) {
        /*SL:32*/if (AbstractModule.nullCheck()) {
            /*SL:33*/return;
        }
        /*SL:35*/if (NoWeb.mc.field_71441_e.func_180495_p(a1.getPos()).func_177230_c() instanceof BlockWeb && this.disableBB.getValue()) {
            /*SL:36*/a1.setCanceled(true);
            /*SL:37*/a1.setBoundingBox(Block.field_185505_j.func_191195_a(0.0, (double)this.bbOffset.getValue(), 0.0));
        }
    }
    
    @Override
    public void onUpdate() {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:43*/if (ModuleManager.isModuleEnabled("WebTP")) {
            /*SL:44*/return;
        }
        Label_0061: {
            /*SL:46*/if (NoWeb.mc.field_71439_g.field_70134_J) {
                final ModuleManager moduleManager2 = Legacy.moduleManager;
                if (!ModuleManager.isModuleEnabled("Step")) {
                    break Label_0061;
                }
            }
            if (!NoWeb.mc.field_71439_g.field_70134_J) {
                return;
            }
            final ModuleManager moduleManager3 = Legacy.moduleManager;
            if (ModuleManager.isModuleEnabled("StepTwo")) {
                return;
            }
        }
        /*SL:47*/if (Keyboard.isKeyDown(NoWeb.mc.field_71474_y.field_74311_E.field_74512_d)) {
            NoWeb.mc.field_71439_g.field_70134_J = /*EL:48*/true;
            final EntityPlayerSP field_71439_g;
            final EntityPlayerSP v1 = /*EL:50*/field_71439_g = NoWeb.mc.field_71439_g;
            field_71439_g.field_70181_x *= this.motionY.getValue();
        }
        else/*SL:52*/ if (this.onGround.getValue()) {
            NoWeb.mc.field_71439_g.field_70122_E = /*EL:53*/false;
        }
        /*SL:55*/if (Keyboard.isKeyDown(NoWeb.mc.field_71474_y.field_74351_w.field_74512_d) || Keyboard.isKeyDown(NoWeb.mc.field_71474_y.field_74368_y.field_74512_d) || Keyboard.isKeyDown(NoWeb.mc.field_71474_y.field_74370_x.field_74512_d) || Keyboard.isKeyDown(NoWeb.mc.field_71474_y.field_74366_z.field_74512_d)) {
            NoWeb.mc.field_71439_g.field_70134_J = /*EL:56*/false;
            final EntityPlayerSP field_71439_g2;
            final EntityPlayerSP v1 = /*EL:58*/field_71439_g2 = NoWeb.mc.field_71439_g;
            field_71439_g2.field_70159_w *= this.motionX.getValue();
            final EntityPlayerSP field_71439_g3;
            final EntityPlayerSP v2 = /*EL:60*/field_71439_g3 = NoWeb.mc.field_71439_g;
            field_71439_g3.field_70179_y *= this.motionX.getValue();
        }
    }
}
