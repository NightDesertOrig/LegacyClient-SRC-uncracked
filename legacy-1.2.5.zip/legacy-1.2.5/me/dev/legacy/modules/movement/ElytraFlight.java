package me.dev.legacy.modules.movement;

import me.dev.legacy.api.AbstractModule;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.util.MathUtil;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import me.dev.legacy.Legacy;
import net.minecraft.item.ItemElytra;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import me.dev.legacy.api.event.events.move.MoveEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.modules.Module;

public class ElytraFlight extends Module
{
    private static ElytraFlight INSTANCE;
    private final Timer timer;
    private final Timer bypassTimer;
    public Setting<Mode> mode;
    public Setting<Integer> devMode;
    public Setting<Float> speed;
    public Setting<Float> vSpeed;
    public Setting<Float> hSpeed;
    public Setting<Float> glide;
    public Setting<Float> tooBeeSpeed;
    public Setting<Boolean> autoStart;
    public Setting<Boolean> disableInLiquid;
    public Setting<Boolean> infiniteDura;
    public Setting<Boolean> noKick;
    public Setting<Boolean> allowUp;
    public Setting<Boolean> lockPitch;
    private boolean vertical;
    private Double posX;
    private Double flyHeight;
    private Double posZ;
    
    public ElytraFlight() {
        super("ElytraFlight", "Makes Elytra Flight better.", Category.MOVEMENT, true, false, false);
        this.timer = new Timer();
        this.bypassTimer = new Timer();
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.FLY));
        this.devMode = (Setting<Integer>)this.register(new Setting("Type", (T)2, (T)1, (T)3, a1 -> this.mode.getValue() == Mode.BYPASS || this.mode.getValue() == Mode.BETTER, "EventMode"));
        this.speed = (Setting<Float>)this.register(new Setting("Speed", (T)1.0f, (T)0.0f, (T)10.0f, a1 -> this.mode.getValue() != Mode.FLY && this.mode.getValue() != Mode.BOOST && this.mode.getValue() != Mode.BETTER && this.mode.getValue() != Mode.OHARE, "The Speed."));
        this.vSpeed = (Setting<Float>)this.register(new Setting("VSpeed", (T)0.3f, (T)0.0f, (T)10.0f, a1 -> this.mode.getValue() == Mode.BETTER || this.mode.getValue() == Mode.OHARE, "Vertical Speed"));
        this.hSpeed = (Setting<Float>)this.register(new Setting("HSpeed", (T)1.0f, (T)0.0f, (T)10.0f, a1 -> this.mode.getValue() == Mode.BETTER || this.mode.getValue() == Mode.OHARE, "Horizontal Speed"));
        this.glide = (Setting<Float>)this.register(new Setting("Glide", (T)1.0E-4f, (T)0.0f, (T)0.2f, a1 -> this.mode.getValue() == Mode.BETTER, "Glide Speed"));
        this.tooBeeSpeed = (Setting<Float>)this.register(new Setting("TooBeeSpeed", (T)1.8000001f, (T)1.0f, (T)2.0f, a1 -> this.mode.getValue() == Mode.TOOBEE, "Speed for flight on 2b2t"));
        this.autoStart = (Setting<Boolean>)this.register(new Setting("AutoStart", (T)true));
        this.disableInLiquid = (Setting<Boolean>)this.register(new Setting("NoLiquid", (T)true));
        this.infiniteDura = (Setting<Boolean>)this.register(new Setting("InfiniteDura", (T)false));
        this.noKick = (Setting<Boolean>)this.register(new Setting("NoKick", (T)false, a1 -> this.mode.getValue() == Mode.PACKET));
        this.allowUp = (Setting<Boolean>)this.register(new Setting("AllowUp", (T)true, a1 -> this.mode.getValue() == Mode.BETTER));
        this.lockPitch = (Setting<Boolean>)this.register(new Setting("LockPitch", (T)false));
        this.setInstance();
    }
    
    public static ElytraFlight getInstance() {
        /*SL:49*/if (ElytraFlight.INSTANCE == null) {
            ElytraFlight.INSTANCE = /*EL:50*/new ElytraFlight();
        }
        /*SL:52*/return ElytraFlight.INSTANCE;
    }
    
    private void setInstance() {
        ElytraFlight.INSTANCE = /*EL:56*/this;
    }
    
    @Override
    public void onEnable() {
        /*SL:61*/if (this.mode.getValue() == Mode.BETTER && !this.autoStart.getValue() && this.devMode.getValue() == 1) {
            ElytraFlight.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:62*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
        }
        /*SL:64*/this.flyHeight = null;
        /*SL:65*/this.posX = null;
        /*SL:66*/this.posZ = null;
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:71*/return this.mode.currentEnumName();
    }
    
    @Override
    public void onUpdate() {
        /*SL:76*/if (this.mode.getValue() == Mode.BYPASS && this.devMode.getValue() == 1 && ElytraFlight.mc.field_71439_g.func_184613_cA()) {
            ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:77*/0.0;
            ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:78*/-1.0E-4;
            ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:79*/0.0;
            final double v1 = ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b;
            final double v2 = ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a;
            final double[] v3 = /*EL:82*/this.forwardStrafeYaw(v1, v2, ElytraFlight.mc.field_71439_g.field_70177_z);
            final double v4 = /*EL:83*/v3[0];
            final double v5 = /*EL:84*/v3[1];
            final double v6 = /*EL:85*/v3[2];
            /*SL:86*/if (v1 != 0.0 || v2 != 0.0) {
                ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:87*/v4 * this.speed.getValue() * Math.cos(Math.toRadians(v6 + 90.0)) + v5 * this.speed.getValue() * Math.sin(Math.toRadians(v6 + 90.0));
                ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:88*/v4 * this.speed.getValue() * Math.sin(Math.toRadians(v6 + 90.0)) - v5 * this.speed.getValue() * Math.cos(Math.toRadians(v6 + 90.0));
            }
            /*SL:90*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:91*/-1.0;
            }
        }
    }
    
    @SubscribeEvent
    public void onSendPacket(final PacketEvent.Send v0) {
        /*SL:99*/if (v0.getPacket() instanceof CPacketPlayer && this.mode.getValue() == Mode.TOOBEE) {
            final CPacketPlayer a1 = /*EL:100*/(CPacketPlayer)v0.getPacket();
            /*SL:101*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {}
        }
        /*SL:105*/if (v0.getPacket() instanceof CPacketPlayer && this.mode.getValue() == Mode.TOOBEEBYPASS) {
            final CPacketPlayer v = /*EL:106*/(CPacketPlayer)v0.getPacket();
            /*SL:107*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {}
        }
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent v-8) {
        /*SL:115*/if (this.mode.getValue() == Mode.OHARE) {
            final ItemStack func_184582_a = ElytraFlight.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST);
            /*SL:117*/if (func_184582_a.func_77973_b() == Items.field_185160_cR && ItemElytra.func_185069_d(func_184582_a) && ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                /*SL:118*/v-8.setY(ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d() ? ((double)this.vSpeed.getValue()) : (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d() ? (-this.vSpeed.getValue()) : 0.0));
                ElytraFlight.mc.field_71439_g.func_70024_g(/*EL:119*/0.0, ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d() ? ((double)this.vSpeed.getValue()) : (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d() ? (-this.vSpeed.getValue()) : 0.0), 0.0);
                ElytraFlight.mc.field_71439_g.field_184835_a = /*EL:120*/0.0f;
                ElytraFlight.mc.field_71439_g.field_184836_b = /*EL:121*/0.0f;
                ElytraFlight.mc.field_71439_g.field_184837_c = /*EL:122*/0.0f;
                ElytraFlight.mc.field_71439_g.field_70701_bs = (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d() ? /*EL:123*/this.vSpeed.getValue() : (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d() ? (-this.vSpeed.getValue()) : 0.0f));
                double n = ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b;
                double n2 = ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a;
                float field_70177_z = ElytraFlight.mc.field_71439_g.field_70177_z;
                /*SL:127*/if (n == 0.0 && n2 == 0.0) {
                    /*SL:128*/v-8.setX(0.0);
                    /*SL:129*/v-8.setZ(0.0);
                }
                else {
                    /*SL:131*/if (n != 0.0) {
                        /*SL:132*/if (n2 > 0.0) {
                            /*SL:133*/field_70177_z += ((n > 0.0) ? -45 : 45);
                        }
                        else/*SL:134*/ if (n2 < 0.0) {
                            /*SL:135*/field_70177_z += ((n > 0.0) ? 45 : -45);
                        }
                        /*SL:137*/n2 = 0.0;
                        /*SL:138*/if (n > 0.0) {
                            /*SL:139*/n = 1.0;
                        }
                        else/*SL:140*/ if (n < 0.0) {
                            /*SL:141*/n = -1.0;
                        }
                    }
                    final double a1 = /*EL:144*/Math.cos(Math.toRadians(field_70177_z + 90.0f));
                    final double v1 = /*EL:145*/Math.sin(Math.toRadians(field_70177_z + 90.0f));
                    /*SL:146*/v-8.setX(n * this.hSpeed.getValue() * a1 + n2 * this.hSpeed.getValue() * v1);
                    /*SL:147*/v-8.setZ(n * this.hSpeed.getValue() * v1 - n2 * this.hSpeed.getValue() * a1);
                }
            }
        }
        else/*SL:150*/ if (v-8.getStage() == 0 && this.mode.getValue() == Mode.BYPASS && this.devMode.getValue() == 3) {
            /*SL:151*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                /*SL:152*/v-8.setX(0.0);
                /*SL:153*/v-8.setY(-1.0E-4);
                /*SL:154*/v-8.setZ(0.0);
                final double radians = ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b;
                final double a2 = ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a;
                final double[] forwardStrafeYaw = /*EL:157*/this.forwardStrafeYaw(radians, a2, ElytraFlight.mc.field_71439_g.field_70177_z);
                final double n3 = /*EL:158*/forwardStrafeYaw[0];
                final double v2 = /*EL:159*/forwardStrafeYaw[1];
                final double v3 = /*EL:160*/forwardStrafeYaw[2];
                /*SL:161*/if (radians != 0.0 || a2 != 0.0) {
                    /*SL:162*/v-8.setX(n3 * this.speed.getValue() * Math.cos(Math.toRadians(v3 + 90.0)) + v2 * this.speed.getValue() * Math.sin(Math.toRadians(v3 + 90.0)));
                    /*SL:163*/v-8.setY(n3 * this.speed.getValue() * Math.sin(Math.toRadians(v3 + 90.0)) - v2 * this.speed.getValue() * Math.cos(Math.toRadians(v3 + 90.0)));
                }
                /*SL:165*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                    /*SL:166*/v-8.setY(-1.0);
                }
            }
        }
        else/*SL:169*/ if (this.mode.getValue() == Mode.TOOBEE) {
            /*SL:170*/if (!ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                /*SL:171*/return;
            }
            /*SL:173*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78901_c) {
                /*SL:182*/return;
            }
            if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78899_d) {
                ElytraFlight.mc.field_71439_g.field_70181_x = -(this.tooBeeSpeed.getValue() / 2.0f);
                v-8.setY(-(this.speed.getValue() / 2.0f));
            }
            else if (v-8.getY() != -1.01E-4) {
                v-8.setY(-1.01E-4);
                ElytraFlight.mc.field_71439_g.field_70181_x = -1.01E-4;
            }
            /*SL:184*/this.setMoveSpeed(v-8, this.tooBeeSpeed.getValue());
        }
        else/*SL:185*/ if (this.mode.getValue() == Mode.TOOBEEBYPASS) {
            /*SL:186*/if (!ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                /*SL:187*/return;
            }
            /*SL:189*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78901_c) {
                /*SL:194*/return;
            }
            if (this.lockPitch.getValue()) {
                ElytraFlight.mc.field_71439_g.field_70125_A = 4.0f;
            }
            /*SL:196*/if (Legacy.speedManager.getSpeedKpH() > 180.0) {
                /*SL:197*/return;
            }
            final double radians = /*EL:199*/Math.toRadians(ElytraFlight.mc.field_71439_g.field_70177_z);
            final EntityPlayerSP field_71439_g = ElytraFlight.mc.field_71439_g;
            /*SL:200*/field_71439_g.field_70159_w -= ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b * Math.sin(radians) * 0.04;
            final EntityPlayerSP field_71439_g2 = ElytraFlight.mc.field_71439_g;
            /*SL:201*/field_71439_g2.field_70179_y += ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b * Math.cos(radians) * 0.04;
        }
    }
    
    private void setMoveSpeed(final MoveEvent v2, final double v3) {
        double v4 = ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b;
        double v5 = ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a;
        float v6 = ElytraFlight.mc.field_71439_g.field_70177_z;
        /*SL:209*/if (v4 == 0.0 && v5 == 0.0) {
            /*SL:210*/v2.setX(0.0);
            /*SL:211*/v2.setZ(0.0);
            ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:212*/0.0;
            ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:213*/0.0;
        }
        else {
            /*SL:215*/if (v4 != 0.0) {
                /*SL:216*/if (v5 > 0.0) {
                    /*SL:217*/v6 += ((v4 > 0.0) ? -45 : 45);
                }
                else/*SL:218*/ if (v5 < 0.0) {
                    /*SL:219*/v6 += ((v4 > 0.0) ? 45 : -45);
                }
                /*SL:221*/v5 = 0.0;
                /*SL:222*/if (v4 > 0.0) {
                    /*SL:223*/v4 = 1.0;
                }
                else/*SL:224*/ if (v4 < 0.0) {
                    /*SL:225*/v4 = -1.0;
                }
            }
            final double a1 = /*EL:228*/v4 * v3 * -Math.sin(Math.toRadians(v6)) + v5 * v3 * Math.cos(Math.toRadians(v6));
            final double a2 = /*EL:229*/v4 * v3 * Math.cos(Math.toRadians(v6)) - v5 * v3 * -Math.sin(Math.toRadians(v6));
            /*SL:230*/v2.setX(a1);
            /*SL:231*/v2.setZ(a2);
            ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:232*/a1;
            ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:233*/a2;
        }
    }
    
    @Override
    public void onTick() {
        /*SL:239*/if (!ElytraFlight.mc.field_71439_g.func_184613_cA()) {
            /*SL:240*/return;
        }
        /*SL:242*/switch (this.mode.getValue()) {
            case BOOST: {
                /*SL:244*/if (ElytraFlight.mc.field_71439_g.func_70090_H()) {
                    ElytraFlight.mc.func_147114_u().func_147297_a(/*EL:245*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                    /*SL:246*/return;
                }
                /*SL:248*/if (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    final EntityPlayerSP field_71439_g = ElytraFlight.mc.field_71439_g;
                    /*SL:249*/field_71439_g.field_70181_x += 0.08;
                }
                else/*SL:250*/ if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                    final EntityPlayerSP field_71439_g2 = ElytraFlight.mc.field_71439_g;
                    /*SL:251*/field_71439_g2.field_70181_x -= 0.04;
                }
                /*SL:253*/if (ElytraFlight.mc.field_71474_y.field_74351_w.func_151470_d()) {
                    final float v1 = /*EL:254*/(float)Math.toRadians(ElytraFlight.mc.field_71439_g.field_70177_z);
                    final EntityPlayerSP field_71439_g3 = ElytraFlight.mc.field_71439_g;
                    /*SL:255*/field_71439_g3.field_70159_w -= MathHelper.func_76126_a(v1) * 0.05f;
                    final EntityPlayerSP field_71439_g4 = ElytraFlight.mc.field_71439_g;
                    /*SL:256*/field_71439_g4.field_70179_y += MathHelper.func_76134_b(v1) * 0.05f;
                    /*SL:257*/break;
                }
                /*SL:259*/if (!ElytraFlight.mc.field_71474_y.field_74368_y.func_151470_d()) {
                    break;
                }
                final float v1 = /*EL:260*/(float)Math.toRadians(ElytraFlight.mc.field_71439_g.field_70177_z);
                final EntityPlayerSP field_71439_g5 = ElytraFlight.mc.field_71439_g;
                /*SL:261*/field_71439_g5.field_70159_w += MathHelper.func_76126_a(v1) * 0.05f;
                final EntityPlayerSP field_71439_g6 = ElytraFlight.mc.field_71439_g;
                /*SL:262*/field_71439_g6.field_70179_y -= MathHelper.func_76134_b(v1) * 0.05f;
                /*SL:263*/break;
            }
            case FLY: {
                ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:266*/true;
                break;
            }
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent v-2) {
        /*SL:273*/if (ElytraFlight.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_185160_cR) {
            /*SL:274*/return;
        }
        /*SL:276*/switch (v-2.getStage()) {
            case 0: {
                /*SL:278*/if (this.disableInLiquid.getValue() && (ElytraFlight.mc.field_71439_g.func_70090_H() || ElytraFlight.mc.field_71439_g.func_180799_ab())) {
                    /*SL:279*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                        ElytraFlight.mc.func_147114_u().func_147297_a(/*EL:280*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                    }
                    /*SL:282*/return;
                }
                /*SL:284*/if (this.autoStart.getValue() && ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d() && !ElytraFlight.mc.field_71439_g.func_184613_cA() && ElytraFlight.mc.field_71439_g.field_70181_x < 0.0 && this.timer.passedMs(250L)) {
                    ElytraFlight.mc.func_147114_u().func_147297_a(/*EL:285*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                    /*SL:286*/this.timer.reset();
                }
                /*SL:288*/if (this.mode.getValue() == Mode.BETTER) {
                    final double[] a1 = /*EL:289*/MathUtil.directionSpeed((this.devMode.getValue() == 1) ? ((double)this.speed.getValue()) : ((double)this.hSpeed.getValue()));
                    /*SL:290*/switch (this.devMode.getValue()) {
                        case 1: {
                            ElytraFlight.mc.field_71439_g.func_70016_h(/*EL:292*/0.0, 0.0, 0.0);
                            ElytraFlight.mc.field_71439_g.field_70747_aH = /*EL:293*/this.speed.getValue();
                            /*SL:294*/if (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                                final EntityPlayerSP field_71439_g = ElytraFlight.mc.field_71439_g;
                                /*SL:295*/field_71439_g.field_70181_x += this.speed.getValue();
                            }
                            /*SL:297*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                                final EntityPlayerSP field_71439_g2 = ElytraFlight.mc.field_71439_g;
                                /*SL:298*/field_71439_g2.field_70181_x -= this.speed.getValue();
                            }
                            /*SL:300*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                                ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:301*/a1[0];
                                ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:302*/a1[1];
                                /*SL:303*/break;
                            }
                            ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:305*/0.0;
                            ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:306*/0.0;
                            /*SL:307*/break;
                        }
                        case 2: {
                            /*SL:310*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                                /*SL:311*/if (this.flyHeight == null) {
                                    /*SL:312*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u;
                                }
                                /*SL:318*/if (this.noKick.getValue()) {
                                    /*SL:319*/this.flyHeight -= (Double)this.glide.getValue();
                                }
                                /*SL:321*/this.posX = 0.0;
                                /*SL:322*/this.posZ = 0.0;
                                /*SL:323*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                                    /*SL:324*/this.posX = a1[0];
                                    /*SL:325*/this.posZ = a1[1];
                                }
                                /*SL:327*/if (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                                    /*SL:328*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u + this.vSpeed.getValue();
                                }
                                /*SL:330*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                                    /*SL:331*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u - this.vSpeed.getValue();
                                }
                                ElytraFlight.mc.field_71439_g.func_70107_b(ElytraFlight.mc.field_71439_g.field_70165_t + /*EL:333*/this.posX, (double)this.flyHeight, ElytraFlight.mc.field_71439_g.field_70161_v + this.posZ);
                                ElytraFlight.mc.field_71439_g.func_70016_h(/*EL:334*/0.0, 0.0, 0.0);
                                /*SL:335*/break;
                            }
                            this.flyHeight = null;
                            return;
                        }
                        case 3: {
                            /*SL:338*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                                /*SL:339*/if (this.flyHeight == null || this.posX == null || this.posX == 0.0 || this.posZ == null || this.posZ == 0.0) {
                                    /*SL:340*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u;
                                    /*SL:341*/this.posX = ElytraFlight.mc.field_71439_g.field_70165_t;
                                    /*SL:342*/this.posZ = ElytraFlight.mc.field_71439_g.field_70161_v;
                                }
                                /*SL:350*/if (this.noKick.getValue()) {
                                    /*SL:351*/this.flyHeight -= (Double)this.glide.getValue();
                                }
                                /*SL:353*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                                    /*SL:354*/this.posX += a1[0];
                                    /*SL:355*/this.posZ += a1[1];
                                }
                                /*SL:357*/if (this.allowUp.getValue() && ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                                    /*SL:358*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u + this.vSpeed.getValue() / 10.0f;
                                }
                                /*SL:360*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                                    /*SL:361*/this.flyHeight = ElytraFlight.mc.field_71439_g.field_70163_u - this.vSpeed.getValue() / 10.0f;
                                }
                                ElytraFlight.mc.field_71439_g.func_70107_b(/*EL:363*/(double)this.posX, (double)this.flyHeight, (double)this.posZ);
                                ElytraFlight.mc.field_71439_g.func_70016_h(/*EL:364*/0.0, 0.0, 0.0);
                                break;
                            }
                            this.flyHeight = null;
                            this.posX = null;
                            this.posZ = null;
                            return;
                        }
                    }
                }
                final double radians = /*EL:368*/Math.toRadians(ElytraFlight.mc.field_71439_g.field_70177_z);
                /*SL:369*/if (ElytraFlight.mc.field_71439_g.func_184613_cA()) {
                    /*SL:370*/switch (this.mode.getValue()) {
                        case VANILLA: {
                            final float v1 = /*EL:372*/this.speed.getValue() * 0.05f;
                            /*SL:373*/if (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                                final EntityPlayerSP field_71439_g3 = ElytraFlight.mc.field_71439_g;
                                /*SL:374*/field_71439_g3.field_70181_x += v1;
                            }
                            /*SL:376*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                                final EntityPlayerSP field_71439_g4 = ElytraFlight.mc.field_71439_g;
                                /*SL:377*/field_71439_g4.field_70181_x -= v1;
                            }
                            /*SL:379*/if (ElytraFlight.mc.field_71474_y.field_74351_w.func_151470_d()) {
                                final EntityPlayerSP field_71439_g5 = ElytraFlight.mc.field_71439_g;
                                /*SL:380*/field_71439_g5.field_70159_w -= Math.sin(radians) * v1;
                                final EntityPlayerSP field_71439_g6 = ElytraFlight.mc.field_71439_g;
                                /*SL:381*/field_71439_g6.field_70179_y += Math.cos(radians) * v1;
                            }
                            /*SL:383*/if (!ElytraFlight.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                break;
                            }
                            final EntityPlayerSP field_71439_g7 = ElytraFlight.mc.field_71439_g;
                            /*SL:384*/field_71439_g7.field_70159_w += Math.sin(radians) * v1;
                            final EntityPlayerSP field_71439_g8 = ElytraFlight.mc.field_71439_g;
                            /*SL:385*/field_71439_g8.field_70179_y -= Math.cos(radians) * v1;
                            /*SL:386*/break;
                        }
                        case PACKET: {
                            /*SL:389*/this.freezePlayer((EntityPlayer)ElytraFlight.mc.field_71439_g);
                            /*SL:390*/this.runNoKick((EntityPlayer)ElytraFlight.mc.field_71439_g);
                            final double[] v2 = /*EL:391*/MathUtil.directionSpeed(this.speed.getValue());
                            /*SL:392*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78901_c) {
                                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:393*/this.speed.getValue();
                            }
                            /*SL:395*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78899_d) {
                                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:396*/-this.speed.getValue();
                            }
                            /*SL:398*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                                ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:399*/v2[0];
                                ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:400*/v2[1];
                            }
                            ElytraFlight.mc.func_147114_u().func_147297_a(/*EL:402*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                            ElytraFlight.mc.func_147114_u().func_147297_a(/*EL:403*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                            /*SL:404*/break;
                        }
                        case BYPASS: {
                            /*SL:407*/if (this.devMode.getValue() != 3) {
                                break;
                            }
                            /*SL:408*/if (ElytraFlight.mc.field_71474_y.field_74314_A.func_151470_d()) {
                                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:409*/0.019999999552965164;
                            }
                            /*SL:411*/if (ElytraFlight.mc.field_71474_y.field_74311_E.func_151470_d()) {
                                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:412*/-0.20000000298023224;
                            }
                            /*SL:414*/if (ElytraFlight.mc.field_71439_g.field_70173_aa % 8 == 0 && ElytraFlight.mc.field_71439_g.field_70163_u <= 240.0) {
                                ElytraFlight.mc.field_71439_g.field_70181_x = /*EL:415*/0.019999999552965164;
                            }
                            ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:417*/true;
                            ElytraFlight.mc.field_71439_g.field_71075_bZ.func_75092_a(/*EL:418*/0.025f);
                            final double[] v2 = /*EL:419*/MathUtil.directionSpeed(0.5199999809265137);
                            /*SL:420*/if (ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                                ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:421*/v2[0];
                                ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:422*/v2[1];
                                /*SL:423*/break;
                            }
                            ElytraFlight.mc.field_71439_g.field_70159_w = /*EL:425*/0.0;
                            ElytraFlight.mc.field_71439_g.field_70179_y = /*EL:426*/0.0;
                            break;
                        }
                    }
                }
                /*SL:430*/if (!this.infiniteDura.getValue()) {
                    break;
                }
                ElytraFlight.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:431*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                /*SL:432*/break;
            }
            case 1: {
                /*SL:435*/if (!this.infiniteDura.getValue()) {
                    break;
                }
                ElytraFlight.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:436*/(Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
                break;
            }
        }
    }
    
    private double[] forwardStrafeYaw(final double a1, final double a2, final double a3) {
        final double[] v1 = /*EL:442*/{ a1, a2, a3 };
        /*SL:443*/if ((a1 != 0.0 || a2 != 0.0) && a1 != 0.0) {
            /*SL:444*/if (a2 > 0.0) {
                /*SL:445*/v1[2] += ((a1 > 0.0) ? -45 : 45);
            }
            else/*SL:446*/ if (a2 < 0.0) {
                /*SL:447*/v1[2] += ((a1 > 0.0) ? 45 : -45);
            }
            /*SL:449*/v1[1] = 0.0;
            /*SL:450*/if (a1 > 0.0) {
                /*SL:451*/v1[0] = 1.0;
            }
            else/*SL:452*/ if (a1 < 0.0) {
                /*SL:453*/v1[0] = -1.0;
            }
        }
        /*SL:456*/return v1;
    }
    
    private void freezePlayer(final EntityPlayer a1) {
        /*SL:460*/a1.field_70159_w = 0.0;
        /*SL:461*/a1.field_70181_x = 0.0;
        /*SL:462*/a1.field_70179_y = 0.0;
    }
    
    private void runNoKick(final EntityPlayer a1) {
        /*SL:466*/if (this.noKick.getValue() && !a1.func_184613_cA() && a1.field_70173_aa % 4 == 0) {
            /*SL:467*/a1.field_70181_x = -0.03999999910593033;
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:473*/if (AbstractModule.fullNullCheck() || ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75098_d) {
            /*SL:474*/return;
        }
        ElytraFlight.mc.field_71439_g.field_71075_bZ.field_75100_b = /*EL:476*/false;
    }
    
    static {
        ElytraFlight.INSTANCE = new ElytraFlight();
    }
    
    public enum Mode
    {
        VANILLA, 
        PACKET, 
        BOOST, 
        FLY, 
        BYPASS, 
        BETTER, 
        OHARE, 
        TOOBEE, 
        TOOBEEBYPASS;
    }
}
