package me.dev.legacy.modules.combat;

import net.minecraft.util.EnumHand;
import net.minecraft.block.BlockEnderChest;
import me.dev.legacy.api.util.MathUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import java.util.Iterator;
import me.dev.legacy.api.util.BlockUtil;
import java.util.Comparator;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.AbstractModule;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import java.util.Map;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoTrap extends Module
{
    public static boolean isPlacing;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerPlace;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> raytrace;
    private final Setting<Boolean> antiScaffold;
    private final Setting<Boolean> antiStep;
    private final Setting<Boolean> noGhost;
    private final Timer timer;
    private final Map<BlockPos, Integer> retries;
    private final Timer retryTimer;
    public EntityPlayer target;
    private boolean didPlace;
    private boolean switchedItem;
    private boolean isSneaking;
    private int lastHotbarSlot;
    private int placements;
    private BlockPos startPos;
    private boolean offHand;
    
    public AutoTrap() {
        super("AutoTrap", "Traps other players", Category.COMBAT, true, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)50, (T)0, (T)250));
        this.blocksPerPlace = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)8, (T)1, (T)30));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.raytrace = (Setting<Boolean>)this.register(new Setting("Raytrace", (T)false));
        this.antiScaffold = (Setting<Boolean>)this.register(new Setting("AntiScaffold", (T)false));
        this.antiStep = (Setting<Boolean>)this.register(new Setting("AntiStep", (T)false));
        this.noGhost = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.timer = new Timer();
        this.retries = new HashMap<BlockPos, Integer>();
        this.retryTimer = new Timer();
        this.didPlace = false;
        this.placements = 0;
        this.startPos = null;
        this.offHand = false;
    }
    
    @Override
    public void onEnable() {
        /*SL:48*/if (AbstractModule.fullNullCheck()) {
            /*SL:49*/return;
        }
        /*SL:51*/this.startPos = EntityUtil.getRoundedBlockPos((Entity)AutoTrap.mc.field_71439_g);
        /*SL:52*/this.lastHotbarSlot = AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c;
        /*SL:53*/this.retries.clear();
    }
    
    @Override
    public void onTick() {
        /*SL:58*/if (AbstractModule.fullNullCheck()) {
            /*SL:59*/return;
        }
        /*SL:61*/this.doTrap();
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:66*/if (this.target != null) {
            /*SL:67*/return this.target.func_70005_c_();
        }
        /*SL:69*/return null;
    }
    
    @Override
    public void onDisable() {
        AutoTrap.isPlacing = /*EL:74*/false;
        /*SL:75*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }
    
    private void doTrap() {
        /*SL:79*/if (this.check()) {
            /*SL:80*/return;
        }
        /*SL:82*/this.doStaticTrap();
        /*SL:83*/if (this.didPlace) {
            /*SL:84*/this.timer.reset();
        }
    }
    
    private void doStaticTrap() {
        final List<Vec3d> v1 = /*EL:89*/EntityUtil.targets(this.target.func_174791_d(), this.antiScaffold.getValue(), this.antiStep.getValue(), false, false, false, this.raytrace.getValue());
        /*SL:90*/this.placeList(v1);
    }
    
    private void placeList(final List<Vec3d> v-3) {
        /*SL:94*/v-3.sort((a1, a2) -> /*EL:96*/Double.compare(AutoTrap.mc.field_71439_g.func_70092_e(a2.field_72450_a, a2.field_72448_b, a2.field_72449_c), AutoTrap.mc.field_71439_g.func_70092_e(a1.field_72450_a, a1.field_72448_b, a1.field_72449_c)));
        v-3.sort(Comparator.<? super Vec3d>comparingDouble(a1 -> a1.field_72448_b));
        for (final Vec3d vec3d : v-3) {
            final BlockPos a3 = /*EL:97*/new BlockPos(vec3d);
            final int v1 = /*EL:98*/BlockUtil.isPositionPlaceable(a3, this.raytrace.getValue());
            /*SL:99*/if (v1 == 1 && (this.retries.get(a3) == null || this.retries.get(a3) < 4)) {
                /*SL:100*/this.placeBlock(a3);
                /*SL:101*/this.retries.put(a3, (this.retries.get(a3) == null) ? 1 : (this.retries.get(a3) + 1));
                /*SL:102*/this.retryTimer.reset();
            }
            else {
                /*SL:105*/if (v1 != 3) {
                    continue;
                }
                /*SL:106*/this.placeBlock(a3);
            }
        }
    }
    
    private boolean check() {
        AutoTrap.isPlacing = /*EL:111*/false;
        /*SL:112*/this.didPlace = false;
        /*SL:113*/this.placements = 0;
        final int v1 = /*EL:114*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
        /*SL:115*/if (v1 == -1) {
            /*SL:116*/this.toggle();
        }
        final int v2 = /*EL:118*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
        /*SL:119*/if (this.isOff()) {
            /*SL:120*/return true;
        }
        /*SL:122*/if (!this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)AutoTrap.mc.field_71439_g))) {
            /*SL:123*/this.disable();
            /*SL:124*/return true;
        }
        /*SL:126*/if (this.retryTimer.passedMs(2000L)) {
            /*SL:127*/this.retries.clear();
            /*SL:128*/this.retryTimer.reset();
        }
        /*SL:130*/if (v2 == -1) {
            /*SL:131*/Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No Obsidian in hotbar disabling...");
            /*SL:132*/this.disable();
            /*SL:133*/return true;
        }
        /*SL:135*/if (AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c != v2) {
            /*SL:136*/this.lastHotbarSlot = AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c;
        }
        /*SL:138*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        /*SL:139*/this.target = this.getTarget(10.0, true);
        /*SL:140*/return this.target == null || !this.timer.passedMs(this.delay.getValue());
    }
    
    private EntityPlayer getTarget(final double v1, final boolean v3) {
        EntityPlayer v4 = /*EL:144*/null;
        double v5 = /*EL:145*/Math.pow(v1, 2.0) + 1.0;
        /*SL:146*/for (final EntityPlayer a1 : AutoTrap.mc.field_71441_e.field_73010_i) {
            /*SL:147*/if (!EntityUtil.isntValid((Entity)a1, v1) && (!v3 || !EntityUtil.isTrapped(a1, this.antiScaffold.getValue(), this.antiStep.getValue(), false, false, false))) {
                if (Legacy.speedManager.getPlayerSpeed(a1) > 10.0) {
                    /*SL:148*/continue;
                }
                /*SL:149*/if (v4 == null) {
                    /*SL:150*/v4 = a1;
                    /*SL:151*/v5 = AutoTrap.mc.field_71439_g.func_70068_e((Entity)a1);
                }
                else {
                    /*SL:154*/if (AutoTrap.mc.field_71439_g.func_70068_e((Entity)a1) >= v5) {
                        continue;
                    }
                    /*SL:155*/v4 = a1;
                    /*SL:156*/v5 = AutoTrap.mc.field_71439_g.func_70068_e((Entity)a1);
                }
            }
        }
        /*SL:158*/return v4;
    }
    
    private void placeBlock(final BlockPos v-1) {
        /*SL:162*/if (this.placements < this.blocksPerPlace.getValue() && AutoTrap.mc.field_71439_g.func_174818_b(v-1) <= MathUtil.square(5.0)) {
            AutoTrap.isPlacing = /*EL:163*/true;
            final int a1 = AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c;
            final int v1 = /*EL:165*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int v2 = /*EL:166*/InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            /*SL:167*/if (v1 == -1 && v2 == -1) {
                /*SL:168*/this.toggle();
            }
            /*SL:170*/if (this.rotate.getValue()) {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:171*/((v1 == -1) ? v2 : v1);
                AutoTrap.mc.field_71442_b.func_78765_e();
                /*SL:173*/this.isSneaking = BlockUtil.placeBlock(v-1, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getValue(), this.noGhost.getValue(), this.isSneaking);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:174*/a1;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
            else {
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:177*/((v1 == -1) ? v2 : v1);
                AutoTrap.mc.field_71442_b.func_78765_e();
                /*SL:179*/this.isSneaking = BlockUtil.placeBlock(v-1, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getValue(), this.noGhost.getValue(), this.isSneaking);
                AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:180*/a1;
                AutoTrap.mc.field_71442_b.func_78765_e();
            }
            /*SL:183*/this.didPlace = true;
            /*SL:184*/++this.placements;
        }
    }
    
    static {
        AutoTrap.isPlacing = false;
    }
}
