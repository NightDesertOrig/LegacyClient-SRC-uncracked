package me.dev.legacy.modules.combat;

import net.minecraft.util.EnumHand;
import me.dev.legacy.api.util.MathUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.block.BlockWeb;
import java.util.Iterator;
import me.dev.legacy.api.util.BlockUtil;
import java.util.Comparator;
import java.util.ArrayList;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.AbstractModule;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoWeb extends Module
{
    public static boolean isPlacing;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerPlace;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> disable;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> raytrace;
    private final Setting<Boolean> lowerbody;
    private final Setting<Boolean> upperBody;
    private final Timer timer;
    public EntityPlayer target;
    private boolean didPlace;
    private boolean switchedItem;
    private boolean isSneaking;
    private int lastHotbarSlot;
    private int placements;
    private boolean smartRotate;
    private BlockPos startPos;
    
    public AutoWeb() {
        super("AutoWeb", "Traps other players in webs", Category.COMBAT, true, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)50, (T)0, (T)250));
        this.blocksPerPlace = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)8, (T)1, (T)30));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
        this.disable = (Setting<Boolean>)this.register(new Setting("AutoDisable", (T)false));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.raytrace = (Setting<Boolean>)this.register(new Setting("Raytrace", (T)false));
        this.lowerbody = (Setting<Boolean>)this.register(new Setting("Feet", (T)true));
        this.upperBody = (Setting<Boolean>)this.register(new Setting("Face", (T)false));
        this.timer = new Timer();
        this.didPlace = false;
        this.placements = 0;
        this.smartRotate = false;
        this.startPos = null;
    }
    
    @Override
    public void onEnable() {
        /*SL:45*/if (AbstractModule.fullNullCheck()) {
            /*SL:46*/return;
        }
        /*SL:48*/this.startPos = EntityUtil.getRoundedBlockPos((Entity)AutoWeb.mc.field_71439_g);
        /*SL:49*/this.lastHotbarSlot = AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c;
    }
    
    @Override
    public void onTick() {
        /*SL:54*/this.smartRotate = false;
        /*SL:55*/this.doTrap();
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:60*/if (this.target != null) {
            /*SL:61*/return this.target.func_70005_c_();
        }
        /*SL:63*/return null;
    }
    
    @Override
    public void onDisable() {
        AutoWeb.isPlacing = /*EL:68*/false;
        /*SL:69*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        /*SL:70*/this.switchItem(true);
    }
    
    private void doTrap() {
        /*SL:74*/if (this.check()) {
            /*SL:75*/return;
        }
        /*SL:77*/this.doWebTrap();
        /*SL:78*/if (this.didPlace) {
            /*SL:79*/this.timer.reset();
        }
    }
    
    private void doWebTrap() {
        final List<Vec3d> v1 = /*EL:84*/this.getPlacements();
        /*SL:85*/this.placeList(v1);
    }
    
    private List<Vec3d> getPlacements() {
        final ArrayList<Vec3d> v1 = /*EL:89*/new ArrayList<Vec3d>();
        final Vec3d v2 = /*EL:90*/this.target.func_174791_d();
        /*SL:91*/if (this.lowerbody.getValue()) {
            /*SL:92*/v1.add(v2);
        }
        /*SL:94*/if (this.upperBody.getValue()) {
            /*SL:95*/v1.add(v2.func_72441_c(0.0, 1.0, 0.0));
        }
        /*SL:97*/return v1;
    }
    
    private void placeList(final List<Vec3d> v-3) {
        /*SL:101*/v-3.sort((a1, a2) -> /*EL:103*/Double.compare(AutoWeb.mc.field_71439_g.func_70092_e(a2.field_72450_a, a2.field_72448_b, a2.field_72449_c), AutoWeb.mc.field_71439_g.func_70092_e(a1.field_72450_a, a1.field_72448_b, a1.field_72449_c)));
        v-3.sort(Comparator.<? super Vec3d>comparingDouble(a1 -> a1.field_72448_b));
        for (final Vec3d vec3d : v-3) {
            final BlockPos a3 = /*EL:104*/new BlockPos(vec3d);
            final int v1 = /*EL:105*/BlockUtil.isPositionPlaceable(a3, this.raytrace.getValue());
            /*SL:106*/if (v1 != 3 && v1 != 1) {
                continue;
            }
            /*SL:107*/this.placeBlock(a3);
        }
    }
    
    private boolean check() {
        AutoWeb.isPlacing = /*EL:112*/false;
        /*SL:113*/this.didPlace = false;
        /*SL:114*/this.placements = 0;
        final int v1 = /*EL:115*/InventoryUtil.findHotbarBlock(BlockWeb.class);
        /*SL:116*/if (this.isOff()) {
            /*SL:117*/return true;
        }
        /*SL:119*/if (this.disable.getValue() && !this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)AutoWeb.mc.field_71439_g))) {
            /*SL:120*/this.disable();
            /*SL:121*/return true;
        }
        /*SL:123*/if (v1 == -1) {
            /*SL:124*/Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No Webs in hotbar disabling...");
            /*SL:125*/this.toggle();
            /*SL:126*/return true;
        }
        /*SL:128*/if (AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c != v1) {
            /*SL:129*/this.lastHotbarSlot = AutoWeb.mc.field_71439_g.field_71071_by.field_70461_c;
        }
        /*SL:131*/this.switchItem(true);
        /*SL:132*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        /*SL:133*/this.target = this.getTarget(10.0);
        /*SL:134*/return this.target == null || !this.timer.passedMs(this.delay.getValue());
    }
    
    private EntityPlayer getTarget(final double v2) {
        EntityPlayer v3 = /*EL:138*/null;
        double v4 = /*EL:139*/Math.pow(v2, 2.0) + 1.0;
        /*SL:140*/for (final EntityPlayer a1 : AutoWeb.mc.field_71441_e.field_73010_i) {
            /*SL:141*/if (!EntityUtil.isntValid((Entity)a1, v2) && !a1.field_70134_J) {
                if (Legacy.speedManager.getPlayerSpeed(a1) > 30.0) {
                    /*SL:142*/continue;
                }
                /*SL:143*/if (v3 == null) {
                    /*SL:144*/v3 = a1;
                    /*SL:145*/v4 = AutoWeb.mc.field_71439_g.func_70068_e((Entity)a1);
                }
                else {
                    /*SL:148*/if (AutoWeb.mc.field_71439_g.func_70068_e((Entity)a1) >= v4) {
                        continue;
                    }
                    /*SL:149*/v3 = a1;
                    /*SL:150*/v4 = AutoWeb.mc.field_71439_g.func_70068_e((Entity)a1);
                }
            }
        }
        /*SL:152*/return v3;
    }
    
    private void placeBlock(final BlockPos a1) {
        /*SL:156*/if (this.placements < this.blocksPerPlace.getValue() && AutoWeb.mc.field_71439_g.func_174818_b(a1) <= MathUtil.square(6.0) && this.switchItem(false)) {
            AutoWeb.isPlacing = /*EL:157*/true;
            /*SL:158*/this.isSneaking = (this.smartRotate ? BlockUtil.placeBlockSmartRotate(a1, EnumHand.MAIN_HAND, true, this.packet.getValue(), this.isSneaking) : BlockUtil.placeBlock(a1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), this.isSneaking));
            /*SL:159*/this.didPlace = true;
            /*SL:160*/++this.placements;
        }
    }
    
    private boolean switchItem(final boolean a1) {
        final boolean[] v1 = /*EL:165*/InventoryUtil.switchItem(a1, this.lastHotbarSlot, this.switchedItem, InventoryUtil.Switch.NORMAL, BlockWeb.class);
        /*SL:166*/this.switchedItem = v1[0];
        /*SL:167*/return v1[1];
    }
    
    static {
        AutoWeb.isPlacing = false;
    }
}
