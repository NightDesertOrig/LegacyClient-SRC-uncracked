package me.dev.legacy.modules.combat;

import java.util.HashSet;
import io.netty.util.internal.ConcurrentSet;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.item.ItemPickaxe;
import org.lwjgl.input.Mouse;
import net.minecraft.init.Items;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import me.dev.legacy.api.event.ClientEvent;
import me.dev.legacy.impl.command.Command;
import me.dev.legacy.impl.gui.LegacyGui;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import java.util.Iterator;
import me.dev.legacy.modules.misc.NoSoundLag;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketExplosion;
import me.dev.legacy.api.util.DamageUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.network.play.server.SPacketSpawnObject;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.util.EnumHand;
import me.dev.legacy.api.util.EntityUtil;
import java.util.Objects;
import net.minecraft.world.World;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import net.minecraft.entity.Entity;
import me.dev.legacy.impl.setting.Bind;
import net.minecraft.network.play.client.CPacketUseEntity;
import java.util.Queue;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import net.minecraft.util.math.BlockPos;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.modules.Module;

public class AutoCrystal extends Module
{
    public static EntityPlayer target;
    public static Set<BlockPos> lowDmgPos;
    public static Set<BlockPos> placedPos;
    public static Set<BlockPos> brokenPos;
    private static AutoCrystal instance;
    public final Timer threadTimer;
    private final Setting<Settings> setting;
    public final Setting<Boolean> attackOppositeHand;
    public final Setting<Boolean> removeAfterAttack;
    public final Setting<Boolean> antiBlock;
    private final Setting<Integer> switchCooldown;
    private final Setting<Integer> eventMode;
    private final Timer switchTimer;
    private final Timer manualTimer;
    private final Timer breakTimer;
    private final Timer placeTimer;
    private final Timer syncTimer;
    private final Timer predictTimer;
    private final Timer renderTimer;
    private final AtomicBoolean shouldInterrupt;
    private final Timer syncroTimer;
    private final Map<EntityPlayer, Timer> totemPops;
    private final Queue<CPacketUseEntity> packetUseEntities;
    private final AtomicBoolean threadOngoing;
    public Setting<Raytrace> raytrace;
    public Setting<Boolean> place;
    public Setting<Integer> placeDelay;
    public Setting<Float> placeRange;
    public Setting<Float> minDamage;
    public Setting<Float> maxSelfPlace;
    public Setting<Integer> wasteAmount;
    public Setting<Boolean> wasteMinDmgCount;
    public Setting<Float> facePlace;
    public Setting<Float> placetrace;
    public Setting<Boolean> antiSurround;
    public Setting<Boolean> limitFacePlace;
    public Setting<Boolean> oneDot15;
    public Setting<Boolean> doublePop;
    public Setting<Double> popHealth;
    public Setting<Float> popDamage;
    public Setting<Integer> popTime;
    public Setting<Boolean> explode;
    public Setting<Switch> switchMode;
    public Setting<Integer> breakDelay;
    public Setting<Float> breakRange;
    public Setting<Integer> packets;
    public Setting<Float> maxSelfBreak;
    public Setting<Float> breaktrace;
    public Setting<Boolean> manual;
    public Setting<Boolean> manualMinDmg;
    public Setting<Integer> manualBreak;
    public Setting<Boolean> sync;
    public Setting<Boolean> instant;
    public Setting<PredictTimer> instantTimer;
    public Setting<Boolean> resetBreakTimer;
    public Setting<Integer> predictDelay;
    public Setting<Boolean> predictCalc;
    public Setting<Boolean> superSafe;
    public Setting<Boolean> antiCommit;
    public Setting<Boolean> render;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    private final Setting<Integer> alpha;
    public Setting<Boolean> colorSync;
    public Setting<Boolean> box;
    private final Setting<Integer> boxAlpha;
    public Setting<Boolean> outline;
    private final Setting<Float> lineWidth;
    public Setting<Boolean> text;
    public Setting<Boolean> customOutline;
    private final Setting<Integer> cRed;
    private final Setting<Integer> cGreen;
    private final Setting<Integer> cBlue;
    private final Setting<Integer> cAlpha;
    public Setting<Boolean> holdFacePlace;
    public Setting<Boolean> holdFaceBreak;
    public Setting<Boolean> slowFaceBreak;
    public Setting<Boolean> actualSlowBreak;
    public Setting<Integer> facePlaceSpeed;
    public Setting<Boolean> antiNaked;
    public Setting<Float> range;
    public Setting<Target> targetMode;
    public Setting<Integer> minArmor;
    public Setting<AutoSwitch> autoSwitch;
    public Setting<Bind> switchBind;
    public Setting<Boolean> offhandSwitch;
    public Setting<Boolean> switchBack;
    public Setting<Boolean> lethalSwitch;
    public Setting<Boolean> mineSwitch;
    public Setting<Rotate> rotate;
    public Setting<Boolean> suicide;
    public Setting<Boolean> webAttack;
    public Setting<Boolean> fullCalc;
    public Setting<Boolean> sound;
    public Setting<Float> soundRange;
    public Setting<Float> soundPlayer;
    public Setting<Boolean> soundConfirm;
    public Setting<Boolean> extraSelfCalc;
    public Setting<AntiFriendPop> antiFriendPop;
    public Setting<Boolean> noCount;
    public Setting<Boolean> calcEvenIfNoDamage;
    public Setting<Boolean> predictFriendDmg;
    public Setting<Float> minMinDmg;
    public Setting<Boolean> breakSwing;
    public Setting<Boolean> placeSwing;
    public Setting<Boolean> exactHand;
    public Setting<Boolean> justRender;
    public Setting<Boolean> fakeSwing;
    public Setting<Logic> logic;
    public Setting<DamageSync> damageSync;
    public Setting<Integer> damageSyncTime;
    public Setting<Float> dropOff;
    public Setting<Integer> confirm;
    public Setting<Boolean> syncedFeetPlace;
    public Setting<Boolean> fullSync;
    public Setting<Boolean> syncCount;
    public Setting<Boolean> hyperSync;
    public Setting<Boolean> gigaSync;
    public Setting<Boolean> syncySync;
    public Setting<Boolean> enormousSync;
    public Setting<Boolean> holySync;
    public Setting<Boolean> rotateFirst;
    public Setting<ThreadMode> threadMode;
    public Setting<Integer> threadDelay;
    public Setting<Boolean> syncThreadBool;
    public Setting<Integer> syncThreads;
    public Setting<Boolean> predictPos;
    public Setting<Boolean> renderExtrapolation;
    public Setting<Integer> predictTicks;
    public Setting<Integer> rotations;
    public Setting<Boolean> predictRotate;
    public Setting<Float> predictOffset;
    public Setting<Boolean> brownZombie;
    public Setting<Boolean> doublePopOnDamage;
    public boolean rotating;
    private Queue<Entity> attackList;
    private Map<Entity, Float> crystalMap;
    private Entity efficientTarget;
    private double currentDamage;
    private double renderDamage;
    private double lastDamage;
    private boolean didRotation;
    private boolean switching;
    private BlockPos placePos;
    private BlockPos renderPos;
    private boolean mainHand;
    private boolean offHand;
    private int crystalCount;
    private int minDmgCount;
    private int lastSlot;
    private float yaw;
    private float pitch;
    private BlockPos webPos;
    private BlockPos lastPos;
    private boolean posConfirmed;
    private boolean foundDoublePop;
    private int rotationPacketsSpoofed;
    private ScheduledExecutorService executor;
    private Thread thread;
    private EntityPlayer currentSyncTarget;
    private BlockPos syncedPlayerPos;
    private BlockPos syncedCrystalPos;
    private PlaceInfo placeInfo;
    private boolean addTolowDmg;
    private Object BlockPos;
    
    public AutoCrystal() {
        super("AutoCrystal", "Best CA on the market", Category.COMBAT, true, false, false);
        this.threadTimer = new Timer();
        this.setting = (Setting<Settings>)this.register(new Setting("Settings", (T)Settings.PLACE));
        this.attackOppositeHand = (Setting<Boolean>)this.register(new Setting("OppositeHand", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.removeAfterAttack = (Setting<Boolean>)this.register(new Setting("AttackRemove", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.antiBlock = (Setting<Boolean>)this.register(new Setting("AntiFeetPlace", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.switchCooldown = (Setting<Integer>)this.register(new Setting("Cooldown", (T)500, (T)0, (T)1000, a1 -> this.setting.getValue() == Settings.MISC));
        this.eventMode = (Setting<Integer>)this.register(new Setting("Updates", (T)3, (T)1, (T)3, a1 -> this.setting.getValue() == Settings.DEV));
        this.switchTimer = new Timer();
        this.manualTimer = new Timer();
        this.breakTimer = new Timer();
        this.placeTimer = new Timer();
        this.syncTimer = new Timer();
        this.predictTimer = new Timer();
        this.renderTimer = new Timer();
        this.shouldInterrupt = new AtomicBoolean(false);
        this.syncroTimer = new Timer();
        this.totemPops = new ConcurrentHashMap<EntityPlayer, Timer>();
        this.packetUseEntities = new LinkedList<CPacketUseEntity>();
        this.threadOngoing = new AtomicBoolean(false);
        this.raytrace = (Setting<Raytrace>)this.register(new Setting("Raytrace", (T)Raytrace.NONE, a1 -> this.setting.getValue() == Settings.MISC));
        this.place = (Setting<Boolean>)this.register(new Setting("Place", (T)true, a1 -> this.setting.getValue() == Settings.PLACE));
        this.placeDelay = (Setting<Integer>)this.register(new Setting("PlaceDelay", (T)25, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.placeRange = (Setting<Float>)this.register(new Setting("PlaceRange", (T)6.0f, (T)0.0f, (T)10.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.minDamage = (Setting<Float>)this.register(new Setting("MinDamage", (T)7.0f, (T)0.1f, (T)20.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.maxSelfPlace = (Setting<Float>)this.register(new Setting("MaxSelfPlace", (T)10.0f, (T)0.1f, (T)36.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.wasteAmount = (Setting<Integer>)this.register(new Setting("WasteAmount", (T)2, (T)1, (T)5, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.wasteMinDmgCount = (Setting<Boolean>)this.register(new Setting("CountMinDmg", (T)true, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.facePlace = (Setting<Float>)this.register(new Setting("FacePlace", (T)8.0f, (T)0.1f, (T)20.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.placetrace = (Setting<Float>)this.register(new Setting("Placetrace", (T)4.5f, (T)0.0f, (T)10.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue() && this.raytrace.getValue() != Raytrace.NONE && this.raytrace.getValue() != Raytrace.BREAK));
        this.antiSurround = (Setting<Boolean>)this.register(new Setting("AntiSurround", (T)true, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.limitFacePlace = (Setting<Boolean>)this.register(new Setting("LimitFacePlace", (T)true, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.oneDot15 = (Setting<Boolean>)this.register(new Setting("1.15", (T)false, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.doublePop = (Setting<Boolean>)this.register(new Setting("AntiTotem", (T)false, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue()));
        this.popHealth = (Setting<Double>)this.register(new Setting("PopHealth", (T)1.0, (T)0.0, (T)3.0, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue() && this.doublePop.getValue()));
        this.popDamage = (Setting<Float>)this.register(new Setting("PopDamage", (T)4.0f, (T)0.0f, (T)6.0f, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue() && this.doublePop.getValue()));
        this.popTime = (Setting<Integer>)this.register(new Setting("PopTime", (T)500, (T)0, (T)1000, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue() && this.doublePop.getValue()));
        this.explode = (Setting<Boolean>)this.register(new Setting("Break", (T)true, a1 -> this.setting.getValue() == Settings.BREAK));
        this.switchMode = (Setting<Switch>)this.register(new Setting("Attack", (T)Switch.BREAKSLOT, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue()));
        this.breakDelay = (Setting<Integer>)this.register(new Setting("BreakDelay", (T)50, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue()));
        this.breakRange = (Setting<Float>)this.register(new Setting("BreakRange", (T)6.0f, (T)0.0f, (T)10.0f, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue()));
        this.packets = (Setting<Integer>)this.register(new Setting("Packets", (T)1, (T)1, (T)6, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue()));
        this.maxSelfBreak = (Setting<Float>)this.register(new Setting("MaxSelfBreak", (T)10.0f, (T)0.1f, (T)36.0f, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue()));
        this.breaktrace = (Setting<Float>)this.register(new Setting("Breaktrace", (T)4.5f, (T)0.0f, (T)10.0f, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.raytrace.getValue() != Raytrace.NONE && this.raytrace.getValue() != Raytrace.PLACE));
        this.manual = (Setting<Boolean>)this.register(new Setting("Manual", (T)true, a1 -> this.setting.getValue() == Settings.BREAK));
        this.manualMinDmg = (Setting<Boolean>)this.register(new Setting("ManMinDmg", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.manual.getValue()));
        this.manualBreak = (Setting<Integer>)this.register(new Setting("ManualDelay", (T)500, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.BREAK && this.manual.getValue()));
        this.sync = (Setting<Boolean>)this.register(new Setting("Sync", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && (this.explode.getValue() || this.manual.getValue())));
        this.instant = (Setting<Boolean>)this.register(new Setting("Predict", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue()));
        this.instantTimer = (Setting<PredictTimer>)this.register(new Setting("PredictTimer", (T)PredictTimer.NONE, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue()));
        this.resetBreakTimer = (Setting<Boolean>)this.register(new Setting("ResetBreakTimer", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue()));
        this.predictDelay = (Setting<Integer>)this.register(new Setting("PredictDelay", (T)12, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue() && this.instantTimer.getValue() == PredictTimer.PREDICT));
        this.predictCalc = (Setting<Boolean>)this.register(new Setting("PredictCalc", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue()));
        this.superSafe = (Setting<Boolean>)this.register(new Setting("SuperSafe", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue()));
        this.antiCommit = (Setting<Boolean>)this.register(new Setting("AntiOverCommit", (T)true, a1 -> this.setting.getValue() == Settings.BREAK && this.explode.getValue() && this.place.getValue() && this.instant.getValue()));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)true, a1 -> this.setting.getValue() == Settings.RENDER));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.colorSync = (Setting<Boolean>)this.register(new Setting("ColorSync", (T)false, a1 -> this.setting.getValue() == Settings.RENDER));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)true, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)125, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.box.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.5f, (T)0.1f, (T)5.0f, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.outline.getValue()));
        this.text = (Setting<Boolean>)this.register(new Setting("Text", (T)false, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue()));
        this.customOutline = (Setting<Boolean>)this.register(new Setting("CustomLine", (T)false, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.outline.getValue()));
        this.cRed = (Setting<Integer>)this.register(new Setting("OL-Red", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.customOutline.getValue() && this.outline.getValue()));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OL-Green", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.customOutline.getValue() && this.outline.getValue()));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OL-Blue", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.customOutline.getValue() && this.outline.getValue()));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OL-Alpha", (T)255, (T)0, (T)255, a1 -> this.setting.getValue() == Settings.RENDER && this.render.getValue() && this.customOutline.getValue() && this.outline.getValue()));
        this.holdFacePlace = (Setting<Boolean>)this.register(new Setting("HoldFacePlace", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.holdFaceBreak = (Setting<Boolean>)this.register(new Setting("HoldSlowBreak", (T)false, a1 -> this.setting.getValue() == Settings.MISC && this.holdFacePlace.getValue()));
        this.slowFaceBreak = (Setting<Boolean>)this.register(new Setting("SlowFaceBreak", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.actualSlowBreak = (Setting<Boolean>)this.register(new Setting("ActuallySlow", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.facePlaceSpeed = (Setting<Integer>)this.register(new Setting("FaceSpeed", (T)500, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.MISC));
        this.antiNaked = (Setting<Boolean>)this.register(new Setting("AntiNaked", (T)true, a1 -> this.setting.getValue() == Settings.MISC));
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)12.0f, (T)0.1f, (T)20.0f, a1 -> this.setting.getValue() == Settings.MISC));
        this.targetMode = (Setting<Target>)this.register(new Setting("Target", (T)Target.CLOSEST, a1 -> this.setting.getValue() == Settings.MISC));
        this.minArmor = (Setting<Integer>)this.register(new Setting("MinArmor", (T)5, (T)0, (T)125, a1 -> this.setting.getValue() == Settings.MISC));
        this.autoSwitch = (Setting<AutoSwitch>)this.register(new Setting("Switch", (T)AutoSwitch.TOGGLE, a1 -> this.setting.getValue() == Settings.MISC));
        this.switchBind = (Setting<Bind>)this.register(new Setting("SwitchBind", (T)new Bind(-1), a1 -> this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() == AutoSwitch.TOGGLE));
        this.offhandSwitch = (Setting<Boolean>)this.register(new Setting("Offhand", (T)true, a1 -> this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE));
        this.switchBack = (Setting<Boolean>)this.register(new Setting("Switchback", (T)true, a1 -> this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE && this.offhandSwitch.getValue()));
        this.lethalSwitch = (Setting<Boolean>)this.register(new Setting("LethalSwitch", (T)false, a1 -> this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE));
        this.mineSwitch = (Setting<Boolean>)this.register(new Setting("MineSwitch", (T)true, a1 -> this.setting.getValue() == Settings.MISC && this.autoSwitch.getValue() != AutoSwitch.NONE));
        this.rotate = (Setting<Rotate>)this.register(new Setting("Rotate", (T)Rotate.OFF, a1 -> this.setting.getValue() == Settings.MISC));
        this.suicide = (Setting<Boolean>)this.register(new Setting("Suicide", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.webAttack = (Setting<Boolean>)this.register(new Setting("WebAttack", (T)true, a1 -> this.setting.getValue() == Settings.MISC && this.targetMode.getValue() != Target.DAMAGE));
        this.fullCalc = (Setting<Boolean>)this.register(new Setting("ExtraCalc", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.sound = (Setting<Boolean>)this.register(new Setting("Sound", (T)true, a1 -> this.setting.getValue() == Settings.MISC));
        this.soundRange = (Setting<Float>)this.register(new Setting("SoundRange", (T)12.0f, (T)0.0f, (T)12.0f, a1 -> this.setting.getValue() == Settings.MISC));
        this.soundPlayer = (Setting<Float>)this.register(new Setting("SoundPlayer", (T)6.0f, (T)0.0f, (T)12.0f, a1 -> this.setting.getValue() == Settings.MISC));
        this.soundConfirm = (Setting<Boolean>)this.register(new Setting("SoundConfirm", (T)true, a1 -> this.setting.getValue() == Settings.MISC));
        this.extraSelfCalc = (Setting<Boolean>)this.register(new Setting("MinSelfDmg", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.antiFriendPop = (Setting<AntiFriendPop>)this.register(new Setting("FriendPop", (T)AntiFriendPop.NONE, a1 -> this.setting.getValue() == Settings.MISC));
        this.noCount = (Setting<Boolean>)this.register(new Setting("AntiCount", (T)false, a1 -> this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK)));
        this.calcEvenIfNoDamage = (Setting<Boolean>)this.register(new Setting("BigFriendCalc", (T)false, a1 -> this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK) && this.targetMode.getValue() != Target.DAMAGE));
        this.predictFriendDmg = (Setting<Boolean>)this.register(new Setting("PredictFriend", (T)false, a1 -> this.setting.getValue() == Settings.MISC && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.BREAK) && this.instant.getValue()));
        this.minMinDmg = (Setting<Float>)this.register(new Setting("MinMinDmg", (T)0.0f, (T)0.0f, (T)3.0f, a1 -> this.setting.getValue() == Settings.DEV && this.place.getValue()));
        this.breakSwing = (Setting<Boolean>)this.register(new Setting("BreakSwing", (T)true, a1 -> this.setting.getValue() == Settings.DEV));
        this.placeSwing = (Setting<Boolean>)this.register(new Setting("PlaceSwing", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.exactHand = (Setting<Boolean>)this.register(new Setting("ExactHand", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.placeSwing.getValue()));
        this.justRender = (Setting<Boolean>)this.register(new Setting("JustRender", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.fakeSwing = (Setting<Boolean>)this.register(new Setting("FakeSwing", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.justRender.getValue()));
        this.logic = (Setting<Logic>)this.register(new Setting("Logic", (T)Logic.BREAKPLACE, a1 -> this.setting.getValue() == Settings.DEV));
        this.damageSync = (Setting<DamageSync>)this.register(new Setting("DamageSync", (T)DamageSync.NONE, a1 -> this.setting.getValue() == Settings.DEV));
        this.damageSyncTime = (Setting<Integer>)this.register(new Setting("SyncDelay", (T)500, (T)0, (T)500, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE));
        this.dropOff = (Setting<Float>)this.register(new Setting("DropOff", (T)5.0f, (T)0.0f, (T)10.0f, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() == DamageSync.BREAK));
        this.confirm = (Setting<Integer>)this.register(new Setting("Confirm", (T)250, (T)0, (T)1000, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE));
        this.syncedFeetPlace = (Setting<Boolean>)this.register(new Setting("FeetSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE));
        this.fullSync = (Setting<Boolean>)this.register(new Setting("FullSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.syncCount = (Setting<Boolean>)this.register(new Setting("SyncCount", (T)true, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.hyperSync = (Setting<Boolean>)this.register(new Setting("HyperSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.gigaSync = (Setting<Boolean>)this.register(new Setting("GigaSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.syncySync = (Setting<Boolean>)this.register(new Setting("SyncySync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.enormousSync = (Setting<Boolean>)this.register(new Setting("EnormousSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.holySync = (Setting<Boolean>)this.register(new Setting("UnbelievableSync", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.damageSync.getValue() != DamageSync.NONE && this.syncedFeetPlace.getValue()));
        this.rotateFirst = (Setting<Boolean>)this.register(new Setting("FirstRotation", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.rotate.getValue() != Rotate.OFF && this.eventMode.getValue() == 2));
        this.threadMode = (Setting<ThreadMode>)this.register(new Setting("Thread", (T)ThreadMode.NONE, a1 -> this.setting.getValue() == Settings.DEV));
        this.threadDelay = (Setting<Integer>)this.register(new Setting("ThreadDelay", (T)50, (T)1, (T)1000, a1 -> this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE));
        this.syncThreadBool = (Setting<Boolean>)this.register(new Setting("ThreadSync", (T)true, a1 -> this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE));
        this.syncThreads = (Setting<Integer>)this.register(new Setting("SyncThreads", (T)1000, (T)1, (T)10000, a1 -> this.setting.getValue() == Settings.DEV && this.threadMode.getValue() != ThreadMode.NONE && this.syncThreadBool.getValue()));
        this.predictPos = (Setting<Boolean>)this.register(new Setting("PredictPos", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.renderExtrapolation = (Setting<Boolean>)this.register(new Setting("RenderExtrapolation", (T)false, a1 -> this.setting.getValue() == Settings.DEV && this.predictPos.getValue()));
        this.predictTicks = (Setting<Integer>)this.register(new Setting("ExtrapolationTicks", (T)2, (T)1, (T)20, a1 -> this.setting.getValue() == Settings.DEV && this.predictPos.getValue()));
        this.rotations = (Setting<Integer>)this.register(new Setting("Spoofs", (T)1, (T)1, (T)20, a1 -> this.setting.getValue() == Settings.DEV));
        this.predictRotate = (Setting<Boolean>)this.register(new Setting("PredictRotate", (T)false, a1 -> this.setting.getValue() == Settings.DEV));
        this.predictOffset = (Setting<Float>)this.register(new Setting("PredictOffset", (T)0.0f, (T)0.0f, (T)4.0f, a1 -> this.setting.getValue() == Settings.DEV));
        this.brownZombie = (Setting<Boolean>)this.register(new Setting("BrownZombieMode", (T)false, a1 -> this.setting.getValue() == Settings.MISC));
        this.doublePopOnDamage = (Setting<Boolean>)this.register(new Setting("DamagePop", (T)false, a1 -> this.setting.getValue() == Settings.PLACE && this.place.getValue() && this.doublePop.getValue() && this.targetMode.getValue() == Target.DAMAGE));
        this.rotating = false;
        this.attackList = new ConcurrentLinkedQueue<Entity>();
        this.crystalMap = new HashMap<Entity, Float>();
        this.efficientTarget = null;
        this.currentDamage = 0.0;
        this.renderDamage = 0.0;
        this.lastDamage = 0.0;
        this.didRotation = false;
        this.switching = false;
        this.placePos = null;
        this.renderPos = null;
        this.mainHand = false;
        this.offHand = false;
        this.crystalCount = 0;
        this.minDmgCount = 0;
        this.lastSlot = -1;
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.webPos = null;
        this.lastPos = null;
        this.posConfirmed = false;
        this.foundDoublePop = false;
        this.rotationPacketsSpoofed = 0;
        AutoCrystal.instance = this;
    }
    
    public static AutoCrystal getInstance() {
        /*SL:228*/if (AutoCrystal.instance == null) {
            AutoCrystal.instance = /*EL:229*/new AutoCrystal();
        }
        /*SL:231*/return AutoCrystal.instance;
    }
    
    @Override
    public void onTick() {
        /*SL:236*/if (this.threadMode.getValue() == ThreadMode.NONE && this.eventMode.getValue() == 3) {
            /*SL:237*/this.doAutoCrystal();
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent a1) {
        /*SL:243*/if (a1.getStage() == 1) {
            /*SL:244*/this.postProcessing();
        }
        /*SL:246*/if (a1.getStage() != 0) {
            /*SL:247*/return;
        }
        /*SL:249*/if (this.eventMode.getValue() == 2) {
            /*SL:250*/this.doAutoCrystal();
        }
    }
    
    public void postTick() {
        /*SL:255*/if (this.threadMode.getValue() != ThreadMode.NONE) {
            /*SL:256*/this.processMultiThreading();
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:262*/if (this.threadMode.getValue() == ThreadMode.NONE && this.eventMode.getValue() == 1) {
            /*SL:263*/this.doAutoCrystal();
        }
    }
    
    @Override
    public void onToggle() {
        AutoCrystal.brokenPos.clear();
        AutoCrystal.placedPos.clear();
        /*SL:271*/this.totemPops.clear();
        /*SL:272*/this.rotating = false;
    }
    
    @Override
    public void onDisable() {
        /*SL:277*/if (this.thread != null) {
            /*SL:278*/this.shouldInterrupt.set(true);
        }
        /*SL:280*/if (this.executor != null) {
            /*SL:281*/this.executor.shutdown();
        }
    }
    
    @Override
    public void onEnable() {
        /*SL:287*/if (this.threadMode.getValue() != ThreadMode.NONE) {
            /*SL:288*/this.processMultiThreading();
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:294*/if (this.switching) {
            /*SL:295*/return "�aSwitch";
        }
        /*SL:297*/if (AutoCrystal.target != null) {
            /*SL:298*/return AutoCrystal.target.func_70005_c_();
        }
        /*SL:300*/return null;
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v0) {
        /*SL:306*/if (v0.getStage() == 0 && this.rotate.getValue() != Rotate.OFF && this.rotating && this.eventMode.getValue() != 2 && v0.getPacket() instanceof CPacketPlayer) {
            final CPacketPlayer a1 = /*EL:307*/(CPacketPlayer)v0.getPacket();
            /*SL:308*/a1.field_149476_e = this.yaw;
            /*SL:309*/a1.field_149473_f = this.pitch;
            /*SL:310*/++this.rotationPacketsSpoofed;
            /*SL:311*/if (this.rotationPacketsSpoofed >= this.rotations.getValue()) {
                /*SL:312*/this.rotating = false;
                /*SL:313*/this.rotationPacketsSpoofed = 0;
            }
        }
        BlockPos v = /*EL:316*/null;
        CPacketUseEntity v2;
        /*SL:317*/if (v0.getStage() == 0 && v0.getPacket() instanceof CPacketUseEntity && (v2 = (CPacketUseEntity)v0.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK && v2.func_149564_a((World)AutoCrystal.mc.field_71441_e) instanceof EntityEnderCrystal) {
            /*SL:318*/v = v2.func_149564_a((World)AutoCrystal.mc.field_71441_e).func_180425_c();
            /*SL:319*/if (this.removeAfterAttack.getValue()) {
                /*SL:320*/Objects.<Entity>requireNonNull(v2.func_149564_a((World)AutoCrystal.mc.field_71441_e)).func_70106_y();
                AutoCrystal.mc.field_71441_e.func_73028_b(/*EL:321*/v2.field_149567_a);
            }
        }
        /*SL:324*/if (v0.getStage() == 0 && v0.getPacket() instanceof CPacketUseEntity && (v2 = (CPacketUseEntity)v0.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK && v2.func_149564_a((World)AutoCrystal.mc.field_71441_e) instanceof EntityEnderCrystal) {
            final EntityEnderCrystal v3 = /*EL:325*/(EntityEnderCrystal)v2.func_149564_a((World)AutoCrystal.mc.field_71441_e);
            /*SL:326*/if (this.antiBlock.getValue() && EntityUtil.isCrystalAtFeet(v3, this.range.getValue()) && v != null) {
                /*SL:327*/this.rotateToPos(v);
                /*SL:328*/BlockUtil.placeCrystalOnBlock(this.placePos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.placeSwing.getValue(), this.exactHand.getValue());
            }
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH, receiveCanceled = true)
    public void onPacketReceive(final PacketEvent.Receive v-3) {
        /*SL:336*/if (AbstractModule.fullNullCheck()) {
            /*SL:337*/return;
        }
        /*SL:339*/if (!this.justRender.getValue() && this.switchTimer.passedMs(this.switchCooldown.getValue()) && this.explode.getValue() && this.instant.getValue() && v-3.getPacket() instanceof SPacketSpawnObject && (this.syncedCrystalPos == null || !this.syncedFeetPlace.getValue() || this.damageSync.getValue() == DamageSync.NONE)) {
            final SPacketSpawnObject v0 = /*EL:341*/(SPacketSpawnObject)v-3.getPacket();
            final BlockPos blockPos;
            /*SL:342*/if (v0.func_148993_l() == 51 && AutoCrystal.mc.field_71439_g.func_174818_b(blockPos = new BlockPos(v0.func_186880_c(), v0.func_186882_d(), v0.func_186881_e())) + this.predictOffset.getValue() <= MathUtil.square(this.breakRange.getValue()) && (this.instantTimer.getValue() == PredictTimer.NONE || (this.instantTimer.getValue() == PredictTimer.BREAK && this.breakTimer.passedMs(this.breakDelay.getValue())) || (this.instantTimer.getValue() == PredictTimer.PREDICT && this.predictTimer.passedMs(this.predictDelay.getValue())))) {
                /*SL:343*/if (this.predictSlowBreak(blockPos.func_177977_b())) {
                    /*SL:344*/return;
                }
                /*SL:346*/if (this.predictFriendDmg.getValue() && (this.antiFriendPop.getValue() == AntiFriendPop.BREAK || this.antiFriendPop.getValue() == AntiFriendPop.ALL) && this.isRightThread()) {
                    /*SL:347*/for (final EntityPlayer a1 : AutoCrystal.mc.field_71441_e.field_73010_i) {
                        /*SL:348*/if (a1 != null && !AutoCrystal.mc.field_71439_g.equals((Object)a1) && a1.func_174818_b(blockPos) <= MathUtil.square(this.range.getValue() + this.placeRange.getValue()) && Legacy.friendManager.isFriend(a1)) {
                            if (DamageUtil.calculateDamage(blockPos, (Entity)a1) <= EntityUtil.getHealth((Entity)a1) + 0.5) {
                                /*SL:349*/continue;
                            }
                            /*SL:350*/return;
                        }
                    }
                }
                /*SL:353*/if (AutoCrystal.placedPos.contains(blockPos.func_177977_b())) {
                    Label_0623: {
                        /*SL:355*/if (this.isRightThread() && this.superSafe.getValue()) {
                            if (!DamageUtil.canTakeDamage(this.suicide.getValue())) {
                                break Label_0623;
                            }
                            final float v;
                            if ((v = DamageUtil.calculateDamage(blockPos, (Entity)AutoCrystal.mc.field_71439_g)) - 0.5 <= EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g)) {
                                if (v <= this.maxSelfBreak.getValue()) {
                                    break Label_0623;
                                }
                            }
                        }
                        else if (!this.superSafe.getValue()) {
                            break Label_0623;
                        }
                        /*SL:356*/return;
                    }
                    /*SL:358*/this.attackCrystalPredict(v0.func_149001_c(), blockPos);
                }
                else/*SL:359*/ if (this.predictCalc.getValue() && this.isRightThread()) {
                    float v = /*EL:360*/-1.0f;
                    /*SL:361*/if (DamageUtil.canTakeDamage(this.suicide.getValue())) {
                        /*SL:362*/v = DamageUtil.calculateDamage(blockPos, (Entity)AutoCrystal.mc.field_71439_g);
                    }
                    /*SL:364*/if (v + 0.5 < EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) && v <= this.maxSelfBreak.getValue()) {
                        /*SL:365*/for (final EntityPlayer v2 : AutoCrystal.mc.field_71441_e.field_73010_i) {
                            /*SL:367*/if (v2.func_174818_b(blockPos) <= MathUtil.square(this.range.getValue()) && EntityUtil.isValid((Entity)v2, this.range.getValue() + this.breakRange.getValue()) && (!this.antiNaked.getValue() || !DamageUtil.isNaked(v2))) {
                                final float v3;
                                if ((v3 = DamageUtil.calculateDamage(blockPos, (Entity)v2)) <= v && (v3 <= this.minDamage.getValue() || DamageUtil.canTakeDamage(this.suicide.getValue())) && v3 <= EntityUtil.getHealth((Entity)v2)) {
                                    /*SL:368*/continue;
                                }
                                /*SL:369*/if (this.predictRotate.getValue() && this.eventMode.getValue() != 2 && (this.rotate.getValue() == Rotate.BREAK || this.rotate.getValue() == Rotate.ALL)) {
                                    /*SL:370*/this.rotateToPos(blockPos);
                                }
                                /*SL:372*/this.attackCrystalPredict(v0.func_149001_c(), blockPos);
                                break;
                            }
                        }
                    }
                }
            }
        }
        else/*SL:378*/ if (!this.soundConfirm.getValue() && v-3.getPacket() instanceof SPacketExplosion) {
            final SPacketExplosion sPacketExplosion = /*EL:379*/(SPacketExplosion)v-3.getPacket();
            final BlockPos v4 = /*EL:380*/new BlockPos(sPacketExplosion.func_149148_f(), sPacketExplosion.func_149143_g(), sPacketExplosion.func_149145_h()).func_177977_b();
            /*SL:381*/this.removePos(v4);
        }
        else/*SL:382*/ if (v-3.getPacket() instanceof SPacketDestroyEntities) {
            final SPacketDestroyEntities sPacketDestroyEntities = /*EL:383*/(SPacketDestroyEntities)v-3.getPacket();
            /*SL:384*/for (final int v5 : sPacketDestroyEntities.func_149098_c()) {
                final Entity v6 = AutoCrystal.mc.field_71441_e.func_73045_a(/*EL:385*/v5);
                /*SL:386*/if (v6 instanceof EntityEnderCrystal) {
                    AutoCrystal.brokenPos.remove(/*EL:387*/new BlockPos(v6.func_174791_d()).func_177977_b());
                    AutoCrystal.placedPos.remove(/*EL:388*/new BlockPos(v6.func_174791_d()).func_177977_b());
                }
            }
        }
        else/*SL:390*/ if (v-3.getPacket() instanceof SPacketEntityStatus) {
            final SPacketEntityStatus sPacketEntityStatus = /*EL:391*/(SPacketEntityStatus)v-3.getPacket();
            /*SL:392*/if (sPacketEntityStatus.func_149160_c() == 35 && sPacketEntityStatus.func_149161_a((World)AutoCrystal.mc.field_71441_e) instanceof EntityPlayer) {
                /*SL:393*/this.totemPops.put((EntityPlayer)sPacketEntityStatus.func_149161_a((World)AutoCrystal.mc.field_71441_e), new Timer().reset());
            }
        }
        else {
            final SPacketSoundEffect v7;
            /*SL:395*/if (v-3.getPacket() instanceof SPacketSoundEffect && (v7 = (SPacketSoundEffect)v-3.getPacket()).func_186977_b() == SoundCategory.BLOCKS && v7.func_186978_a() == SoundEvents.field_187539_bB) {
                final BlockPos blockPos = /*EL:396*/new BlockPos(v7.func_149207_d(), v7.func_149211_e(), v7.func_149210_f());
                /*SL:397*/if (this.sound.getValue() || this.threadMode.getValue() == ThreadMode.SOUND) {
                    /*SL:398*/NoSoundLag.removeEntities(v7, this.soundRange.getValue());
                }
                /*SL:400*/if (this.soundConfirm.getValue()) {
                    /*SL:401*/this.removePos(blockPos);
                }
                /*SL:403*/if (this.threadMode.getValue() == ThreadMode.SOUND && this.isRightThread() && AutoCrystal.mc.field_71439_g != null && AutoCrystal.mc.field_71439_g.func_174818_b(blockPos) < MathUtil.square(this.soundPlayer.getValue())) {
                    /*SL:404*/this.handlePool(true);
                }
            }
        }
    }
    
    private boolean predictSlowBreak(final BlockPos a1) {
        /*SL:410*/return this.antiCommit.getValue() && AutoCrystal.lowDmgPos.remove(a1) && /*EL:411*/this.shouldSlowBreak(false);
    }
    
    private boolean isRightThread() {
        /*SL:417*/return AutoCrystal.mc.func_152345_ab() || (!Legacy.eventManager.ticksOngoing() && !this.threadOngoing.get());
    }
    
    private void attackCrystalPredict(final int a1, final BlockPos a2) {
        /*SL:421*/if (this.predictRotate.getValue() && (this.eventMode.getValue() != 2 || this.threadMode.getValue() != ThreadMode.NONE) && (this.rotate.getValue() == Rotate.BREAK || this.rotate.getValue() == Rotate.ALL)) {
            /*SL:422*/this.rotateToPos(a2);
        }
        final CPacketUseEntity v1 = /*EL:424*/new CPacketUseEntity();
        /*SL:425*/v1.field_149567_a = a1;
        /*SL:426*/v1.field_149566_b = CPacketUseEntity.Action.ATTACK;
        AutoCrystal.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:427*/(Packet)v1);
        /*SL:428*/if (this.breakSwing.getValue()) {
            AutoCrystal.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:429*/(Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
        }
        /*SL:431*/if (this.resetBreakTimer.getValue()) {
            /*SL:432*/this.breakTimer.reset();
        }
        /*SL:434*/this.predictTimer.reset();
    }
    
    private void removePos(final BlockPos a1) {
        /*SL:438*/if (this.damageSync.getValue() == DamageSync.PLACE) {
            /*SL:439*/if (AutoCrystal.placedPos.remove(a1)) {
                /*SL:440*/this.posConfirmed = true;
            }
        }
        else/*SL:442*/ if (this.damageSync.getValue() == DamageSync.BREAK && AutoCrystal.brokenPos.remove(a1)) {
            /*SL:443*/this.posConfirmed = true;
        }
    }
    
    @Override
    public void onRender3D(final Render3DEvent a1) {
        /*SL:448*/if ((this.offHand || this.mainHand || this.switchMode.getValue() == Switch.CALC) && this.renderPos != null && this.render.getValue() && (this.box.getValue() || this.text.getValue() || this.outline.getValue())) {
            /*SL:449*/RenderUtil.drawBoxESP(this.renderPos, ((boolean)this.colorSync.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.customOutline.getValue(), ((boolean)this.colorSync.getValue()) ? this.getCurrentColor() : new Color(this.cRed.getValue(), this.cGreen.getValue(), this.cBlue.getValue(), this.cAlpha.getValue()), this.lineWidth.getValue(), this.outline.getValue(), this.box.getValue(), this.boxAlpha.getValue(), false);
            /*SL:450*/if (this.text.getValue()) {
                /*SL:451*/RenderUtil.drawText(this.renderPos, ((Math.floor(this.renderDamage) == this.renderDamage) ? ((int)this.renderDamage) : String.format("%.1f", this.renderDamage)) + "");
            }
        }
    }
    
    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent v2) {
        /*SL:458*/if (Keyboard.getEventKeyState() && !(AutoCrystal.mc.field_71462_r instanceof LegacyGui) && this.switchBind.getValue().getKey() == Keyboard.getEventKey()) {
            /*SL:459*/if (this.switchBack.getValue() && this.offhandSwitch.getValue() && this.offHand) {
                final Offhand a1 = Legacy.moduleManager.<Offhand>getModuleByClass(/*EL:460*/Offhand.class);
                /*SL:461*/if (a1.isOff()) {
                    /*SL:462*/Command.sendMessage("<" + this.getDisplayName() + "> �cSwitch failed. Enable the Offhand module.");
                }
                else {
                    /*SL:464*/a1.setMode(Offhand.Mode2.TOTEMS);
                    /*SL:465*/a1.doSwitch();
                }
                /*SL:467*/return;
            }
            /*SL:469*/this.switching = !this.switching;
        }
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent a1) {
        /*SL:475*/if (a1.getStage() == 2 && a1.getSetting() != null && a1.getSetting().getFeature() != null && a1.getSetting().getFeature().equals(this) && this.isEnabled() && (a1.getSetting().equals(this.threadDelay) || a1.getSetting().equals(this.threadMode))) {
            /*SL:476*/if (this.executor != null) {
                /*SL:477*/this.executor.shutdown();
            }
            /*SL:479*/if (this.thread != null) {
                /*SL:480*/this.shouldInterrupt.set(true);
            }
        }
    }
    
    private void postProcessing() {
        /*SL:486*/if (this.threadMode.getValue() != ThreadMode.NONE || this.eventMode.getValue() != 2 || this.rotate.getValue() == Rotate.OFF || !this.rotateFirst.getValue()) {
            /*SL:487*/return;
        }
        /*SL:489*/switch (this.logic.getValue()) {
            case BREAKPLACE: {
                /*SL:491*/this.postProcessBreak();
                /*SL:492*/this.postProcessPlace();
                /*SL:493*/break;
            }
            case PLACEBREAK: {
                /*SL:496*/this.postProcessPlace();
                /*SL:497*/this.postProcessBreak();
                break;
            }
        }
    }
    
    private void postProcessBreak() {
        /*SL:505*/while (!this.packetUseEntities.isEmpty()) {
            final CPacketUseEntity v1 = /*EL:506*/this.packetUseEntities.poll();
            AutoCrystal.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:507*/(Packet)v1);
            /*SL:508*/if (this.breakSwing.getValue()) {
                AutoCrystal.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            }
            /*SL:511*/this.breakTimer.reset();
        }
    }
    
    private void postProcessPlace() {
        /*SL:516*/if (this.placeInfo != null) {
            /*SL:517*/this.placeInfo.runPlace();
            /*SL:518*/this.placeTimer.reset();
            /*SL:519*/this.placeInfo = null;
        }
    }
    
    private void processMultiThreading() {
        /*SL:524*/if (this.isOff()) {
            /*SL:525*/return;
        }
        /*SL:527*/if (this.threadMode.getValue() == ThreadMode.WHILE) {
            /*SL:528*/this.handleWhile();
        }
        else/*SL:529*/ if (this.threadMode.getValue() != ThreadMode.NONE) {
            /*SL:530*/this.handlePool(false);
        }
    }
    
    private void handlePool(final boolean a1) {
        /*SL:535*/if (a1 || this.executor == null || this.executor.isTerminated() || this.executor.isShutdown() || (this.syncroTimer.passedMs(this.syncThreads.getValue()) && this.syncThreadBool.getValue())) {
            /*SL:536*/if (this.executor != null) {
                /*SL:537*/this.executor.shutdown();
            }
            /*SL:539*/this.executor = this.getExecutor();
            /*SL:540*/this.syncroTimer.reset();
        }
    }
    
    private void handleWhile() {
        /*SL:545*/if (this.thread == null || this.thread.isInterrupted() || !this.thread.isAlive() || (this.syncroTimer.passedMs(this.syncThreads.getValue()) && this.syncThreadBool.getValue())) {
            /*SL:546*/if (this.thread == null) {
                /*SL:547*/this.thread = new Thread(RAutoCrystal.getInstance(this));
            }
            else/*SL:548*/ if (this.syncroTimer.passedMs(this.syncThreads.getValue()) && !this.shouldInterrupt.get() && this.syncThreadBool.getValue()) {
                /*SL:549*/this.shouldInterrupt.set(true);
                /*SL:550*/this.syncroTimer.reset();
                /*SL:551*/return;
            }
            /*SL:553*/if (this.thread != null && (this.thread.isInterrupted() || !this.thread.isAlive())) {
                /*SL:554*/this.thread = new Thread(RAutoCrystal.getInstance(this));
            }
            /*SL:556*/if (this.thread != null && this.thread.getState() == Thread.State.NEW) {
                try {
                    /*SL:558*/this.thread.start();
                }
                catch (Exception v1) {
                    /*SL:560*/v1.printStackTrace();
                }
                /*SL:562*/this.syncroTimer.reset();
            }
        }
    }
    
    private ScheduledExecutorService getExecutor() {
        final ScheduledExecutorService v1 = /*EL:568*/Executors.newSingleThreadScheduledExecutor();
        /*SL:569*/v1.scheduleAtFixedRate(RAutoCrystal.getInstance(this), 0L, this.threadDelay.getValue(), TimeUnit.MILLISECONDS);
        /*SL:570*/return v1;
    }
    
    public void doAutoCrystal() {
        /*SL:574*/if (this.brownZombie.getValue()) {
            /*SL:575*/return;
        }
        /*SL:577*/if (this.check()) {
            /*SL:578*/switch (this.logic.getValue()) {
                case PLACEBREAK: {
                    /*SL:580*/this.placeCrystal();
                    /*SL:581*/this.breakCrystal();
                    /*SL:582*/break;
                }
                case BREAKPLACE: {
                    /*SL:585*/this.breakCrystal();
                    /*SL:586*/this.placeCrystal();
                    break;
                }
            }
            /*SL:590*/this.manualBreaker();
        }
    }
    
    private boolean check() {
        /*SL:595*/if (AbstractModule.fullNullCheck()) {
            /*SL:596*/return false;
        }
        /*SL:598*/if (this.syncTimer.passedMs(this.damageSyncTime.getValue())) {
            /*SL:599*/this.currentSyncTarget = null;
            /*SL:600*/this.syncedCrystalPos = null;
            /*SL:601*/this.syncedPlayerPos = null;
        }
        else/*SL:602*/ if (this.syncySync.getValue() && this.syncedCrystalPos != null) {
            /*SL:603*/this.posConfirmed = true;
        }
        /*SL:605*/this.foundDoublePop = false;
        /*SL:606*/if (this.renderTimer.passedMs(500L)) {
            /*SL:607*/this.renderPos = null;
            /*SL:608*/this.renderTimer.reset();
        }
        /*SL:610*/this.mainHand = (AutoCrystal.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP);
        /*SL:611*/this.offHand = (AutoCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
        /*SL:612*/this.currentDamage = 0.0;
        /*SL:613*/this.placePos = null;
        /*SL:614*/if (this.lastSlot != AutoCrystal.mc.field_71439_g.field_71071_by.field_70461_c || AutoTrap.isPlacing || Surround.isPlacing) {
            /*SL:615*/this.lastSlot = AutoCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
            /*SL:616*/this.switchTimer.reset();
        }
        /*SL:618*/if (!this.offHand && !this.mainHand) {
            /*SL:619*/this.placeInfo = null;
            /*SL:620*/this.packetUseEntities.clear();
        }
        /*SL:622*/if (this.offHand || this.mainHand) {
            /*SL:623*/this.switching = false;
        }
        /*SL:625*/if ((!this.offHand && !this.mainHand && this.switchMode.getValue() == Switch.BREAKSLOT && !this.switching) || !DamageUtil.canBreakWeakness((EntityPlayer)AutoCrystal.mc.field_71439_g) || !this.switchTimer.passedMs(this.switchCooldown.getValue())) {
            /*SL:626*/this.renderPos = null;
            AutoCrystal.target = /*EL:627*/null;
            /*SL:629*/return this.rotating = false;
        }
        /*SL:631*/if (this.mineSwitch.getValue() && Mouse.isButtonDown(0) && (this.switching || this.autoSwitch.getValue() == AutoSwitch.ALWAYS) && Mouse.isButtonDown(1) && AutoCrystal.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemPickaxe) {
            /*SL:632*/this.switchItem();
        }
        /*SL:634*/this.mapCrystals();
        /*SL:635*/if (!this.posConfirmed && this.damageSync.getValue() != DamageSync.NONE && this.syncTimer.passedMs(this.confirm.getValue())) {
            /*SL:636*/this.syncTimer.setMs(this.damageSyncTime.getValue() + 1);
        }
        /*SL:638*/return true;
    }
    
    private void mapCrystals() {
        /*SL:642*/this.efficientTarget = null;
        /*SL:643*/if (this.packets.getValue() != 1) {
            /*SL:644*/this.attackList = new ConcurrentLinkedQueue<Entity>();
            /*SL:645*/this.crystalMap = new HashMap<Entity, Float>();
        }
        /*SL:647*/this.crystalCount = 0;
        /*SL:648*/this.minDmgCount = 0;
        Entity efficientTarget = /*EL:649*/null;
        float n = /*EL:650*/0.5f;
        /*SL:651*/for (final Entity efficientTarget2 : AutoCrystal.mc.field_71441_e.field_72996_f) {
            /*SL:652*/if (!efficientTarget2.field_70128_L && efficientTarget2 instanceof EntityEnderCrystal) {
                if (!this.isValid(efficientTarget2)) {
                    continue;
                }
                /*SL:653*/if (this.syncedFeetPlace.getValue() && efficientTarget2.func_180425_c().func_177977_b().equals((Object)this.syncedCrystalPos) && this.damageSync.getValue() != DamageSync.NONE) {
                    /*SL:654*/++this.minDmgCount;
                    /*SL:655*/++this.crystalCount;
                    /*SL:656*/if (this.syncCount.getValue()) {
                        /*SL:657*/this.minDmgCount = this.wasteAmount.getValue() + 1;
                        /*SL:658*/this.crystalCount = this.wasteAmount.getValue() + 1;
                    }
                    /*SL:660*/if (!this.hyperSync.getValue()) {
                        continue;
                    }
                    /*SL:661*/efficientTarget = null;
                    /*SL:662*/break;
                }
                else {
                    boolean b = /*EL:664*/false;
                    boolean b2 = /*EL:665*/false;
                    float calculateDamage = /*EL:666*/-1.0f;
                    /*SL:667*/if (DamageUtil.canTakeDamage(this.suicide.getValue())) {
                        /*SL:668*/calculateDamage = DamageUtil.calculateDamage(efficientTarget2, (Entity)AutoCrystal.mc.field_71439_g);
                    }
                    /*SL:670*/if (calculateDamage + 0.5 < EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g) && calculateDamage <= this.maxSelfBreak.getValue()) {
                        final Entity entity = /*EL:671*/efficientTarget;
                        final float n2 = /*EL:672*/n;
                        /*SL:673*/for (final EntityPlayer v0 : AutoCrystal.mc.field_71441_e.field_73010_i) {
                            /*SL:675*/if (v0.func_70068_e(efficientTarget2) > MathUtil.square(this.range.getValue())) {
                                /*SL:676*/continue;
                            }
                            /*SL:677*/if (EntityUtil.isValid((Entity)v0, this.range.getValue() + this.breakRange.getValue())) {
                                /*SL:678*/if (this.antiNaked.getValue() && DamageUtil.isNaked(v0)) {
                                    continue;
                                }
                                final float v;
                                if ((v = DamageUtil.calculateDamage(efficientTarget2, (Entity)v0)) <= calculateDamage && (v <= this.minDamage.getValue() || DamageUtil.canTakeDamage(this.suicide.getValue())) && v <= EntityUtil.getHealth((Entity)v0)) {
                                    /*SL:679*/continue;
                                }
                                /*SL:680*/if (v > n) {
                                    /*SL:681*/n = v;
                                    /*SL:682*/efficientTarget = efficientTarget2;
                                }
                                /*SL:684*/if (this.packets.getValue() == 1) {
                                    /*SL:685*/if (v >= this.minDamage.getValue() || !this.wasteMinDmgCount.getValue()) {
                                        /*SL:686*/b = true;
                                    }
                                    /*SL:688*/b2 = true;
                                }
                                else {
                                    /*SL:691*/if (this.crystalMap.get(efficientTarget2) != null && this.crystalMap.get(efficientTarget2) >= v) {
                                        /*SL:692*/continue;
                                    }
                                    /*SL:693*/this.crystalMap.put(efficientTarget2, v);
                                }
                            }
                            else {
                                /*SL:696*/if ((this.antiFriendPop.getValue() != AntiFriendPop.BREAK && this.antiFriendPop.getValue() != AntiFriendPop.ALL) || !Legacy.friendManager.isFriend(v0.func_70005_c_())) {
                                    continue;
                                }
                                final float v;
                                if ((v = DamageUtil.calculateDamage(efficientTarget2, (Entity)v0)) <= EntityUtil.getHealth((Entity)v0) + 0.5) {
                                    /*SL:697*/continue;
                                }
                                /*SL:698*/efficientTarget = entity;
                                /*SL:699*/n = n2;
                                /*SL:700*/this.crystalMap.remove(efficientTarget2);
                                /*SL:701*/if (!this.noCount.getValue()) {
                                    break;
                                }
                                /*SL:702*/b = false;
                                /*SL:703*/b2 = false;
                                break;
                            }
                        }
                    }
                    /*SL:707*/if (!b2) {
                        continue;
                    }
                    /*SL:708*/++this.minDmgCount;
                    /*SL:709*/if (!b) {
                        continue;
                    }
                    /*SL:710*/++this.crystalCount;
                }
            }
        }
        /*SL:712*/if (this.damageSync.getValue() == DamageSync.BREAK && (n > this.lastDamage || this.syncTimer.passedMs(this.damageSyncTime.getValue()) || this.damageSync.getValue() == DamageSync.NONE)) {
            /*SL:713*/this.lastDamage = n;
        }
        /*SL:715*/if (this.enormousSync.getValue() && this.syncedFeetPlace.getValue() && this.damageSync.getValue() != DamageSync.NONE && this.syncedCrystalPos != null) {
            /*SL:716*/if (this.syncCount.getValue()) {
                /*SL:717*/this.minDmgCount = this.wasteAmount.getValue() + 1;
                /*SL:718*/this.crystalCount = this.wasteAmount.getValue() + 1;
            }
            /*SL:720*/return;
        }
        /*SL:722*/if (this.webAttack.getValue() && this.webPos != null) {
            /*SL:723*/if (AutoCrystal.mc.field_71439_g.func_174818_b(this.webPos.func_177984_a()) > MathUtil.square(this.breakRange.getValue())) {
                /*SL:724*/this.webPos = null;
            }
            else {
                /*SL:726*/for (final Entity efficientTarget2 : AutoCrystal.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(this.webPos.func_177984_a()))) {
                    /*SL:727*/if (!(efficientTarget2 instanceof EntityEnderCrystal)) {
                        continue;
                    }
                    /*SL:728*/this.attackList.add(efficientTarget2);
                    /*SL:729*/this.efficientTarget = efficientTarget2;
                    /*SL:730*/this.webPos = null;
                    /*SL:731*/this.lastDamage = 0.5;
                    /*SL:732*/return;
                }
            }
        }
        /*SL:736*/if (this.shouldSlowBreak(true) && n < this.minDamage.getValue() && (AutoCrystal.target == null || EntityUtil.getHealth((Entity)AutoCrystal.target) > this.facePlace.getValue() || (!this.breakTimer.passedMs(this.facePlaceSpeed.getValue()) && this.slowFaceBreak.getValue() && Mouse.isButtonDown(0) && this.holdFacePlace.getValue() && this.holdFaceBreak.getValue()))) {
            /*SL:737*/this.efficientTarget = null;
            /*SL:738*/return;
        }
        /*SL:740*/if (this.packets.getValue() == 1) {
            /*SL:741*/this.efficientTarget = efficientTarget;
        }
        else {
            /*SL:743*/this.crystalMap = MathUtil.<Entity, Float>sortByValue(this.crystalMap, true);
            /*SL:744*/for (final Map.Entry entry : this.crystalMap.entrySet()) {
                final Entity entity2 = /*EL:745*/entry.getKey();
                final float floatValue = /*EL:746*/entry.getValue();
                /*SL:747*/if (floatValue >= this.minDamage.getValue() || !this.wasteMinDmgCount.getValue()) {
                    /*SL:748*/++this.crystalCount;
                }
                /*SL:750*/this.attackList.add(entity2);
                /*SL:751*/++this.minDmgCount;
            }
        }
    }
    
    private boolean shouldSlowBreak(final boolean a1) {
        /*SL:757*/return (a1 && this.manual.getValue() && this.manualMinDmg.getValue() && Mouse.isButtonDown(1) && (!Mouse.isButtonDown(0) || !this.holdFacePlace.getValue())) || (this.holdFacePlace.getValue() && this.holdFaceBreak.getValue() && Mouse.isButtonDown(0) && !this.breakTimer.passedMs(this.facePlaceSpeed.getValue())) || (this.slowFaceBreak.getValue() && !this.breakTimer.passedMs(this.facePlaceSpeed.getValue()));
    }
    
    private void placeCrystal() {
        int v0 = /*EL:761*/this.wasteAmount.getValue();
        /*SL:762*/if (this.placeTimer.passedMs(this.placeDelay.getValue()) && this.place.getValue() && (this.offHand || this.mainHand || this.switchMode.getValue() == Switch.CALC || (this.switchMode.getValue() == Switch.BREAKSLOT && this.switching))) {
            /*SL:763*/if ((this.offHand || this.mainHand || (this.switchMode.getValue() != Switch.ALWAYS && !this.switching)) && this.crystalCount >= v0 && (!this.antiSurround.getValue() || this.lastPos == null || !this.lastPos.equals((Object)this.placePos))) {
                /*SL:764*/return;
            }
            /*SL:766*/this.calculateDamage(this.getTarget(this.targetMode.getValue() == Target.UNSAFE));
            /*SL:767*/if (AutoCrystal.target != null && this.placePos != null) {
                /*SL:768*/if (!this.offHand && !this.mainHand && this.autoSwitch.getValue() != AutoSwitch.NONE && (this.currentDamage > this.minDamage.getValue() || (this.lethalSwitch.getValue() && EntityUtil.getHealth((Entity)AutoCrystal.target) <= this.facePlace.getValue())) && !this.switchItem()) {
                    /*SL:769*/return;
                }
                /*SL:771*/if (this.currentDamage < this.minDamage.getValue() && this.limitFacePlace.getValue()) {
                    /*SL:772*/v0 = 1;
                }
                /*SL:774*/if (this.currentDamage >= this.minMinDmg.getValue() && (this.offHand || this.mainHand || this.autoSwitch.getValue() != AutoSwitch.NONE) && (this.crystalCount < v0 || (this.antiSurround.getValue() && this.lastPos != null && this.lastPos.equals((Object)this.placePos))) && (this.currentDamage > this.minDamage.getValue() || this.minDmgCount < v0) && this.currentDamage >= 1.0 && (DamageUtil.isArmorLow(AutoCrystal.target, this.minArmor.getValue()) || EntityUtil.getHealth((Entity)AutoCrystal.target) <= this.facePlace.getValue() || this.currentDamage > this.minDamage.getValue() || this.shouldHoldFacePlace())) {
                    final float v = /*EL:775*/(this.damageSync.getValue() == DamageSync.BREAK) ? (this.dropOff.getValue() - 5.0f) : 0.0f;
                    boolean v2 = /*EL:776*/false;
                    /*SL:777*/if (this.syncedFeetPlace.getValue() && this.placePos.equals((Object)this.lastPos) && this.isEligableForFeetSync(AutoCrystal.target, this.placePos) && !this.syncTimer.passedMs(this.damageSyncTime.getValue()) && AutoCrystal.target.equals((Object)this.currentSyncTarget) && AutoCrystal.target.func_180425_c().equals((Object)this.syncedPlayerPos) && this.damageSync.getValue() != DamageSync.NONE) {
                        /*SL:778*/this.syncedCrystalPos = this.placePos;
                        /*SL:779*/this.lastDamage = this.currentDamage;
                        /*SL:780*/if (this.fullSync.getValue()) {
                            /*SL:781*/this.lastDamage = 100.0;
                        }
                        /*SL:783*/v2 = true;
                    }
                    /*SL:785*/if (v2 || this.currentDamage - v > this.lastDamage || this.syncTimer.passedMs(this.damageSyncTime.getValue()) || this.damageSync.getValue() == DamageSync.NONE) {
                        /*SL:786*/if (!v2 && this.damageSync.getValue() != DamageSync.BREAK) {
                            /*SL:787*/this.lastDamage = this.currentDamage;
                        }
                        /*SL:789*/this.renderPos = this.placePos;
                        /*SL:790*/this.renderDamage = this.currentDamage;
                        /*SL:791*/if (this.switchItem()) {
                            /*SL:792*/this.currentSyncTarget = AutoCrystal.target;
                            /*SL:793*/this.syncedPlayerPos = AutoCrystal.target.func_180425_c();
                            /*SL:794*/if (this.foundDoublePop) {
                                /*SL:795*/this.totemPops.put(AutoCrystal.target, new Timer().reset());
                            }
                            /*SL:797*/this.rotateToPos(this.placePos);
                            /*SL:798*/if (this.addTolowDmg || (this.actualSlowBreak.getValue() && this.currentDamage < this.minDamage.getValue())) {
                                AutoCrystal.lowDmgPos.add(/*EL:799*/this.placePos);
                            }
                            AutoCrystal.placedPos.add(/*EL:801*/this.placePos);
                            /*SL:802*/if (!this.justRender.getValue()) {
                                /*SL:803*/if (this.eventMode.getValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE && this.rotateFirst.getValue() && this.rotate.getValue() != Rotate.OFF) {
                                    /*SL:804*/this.placeInfo = new PlaceInfo(this.placePos, this.offHand, this.placeSwing.getValue(), this.exactHand.getValue());
                                }
                                else {
                                    /*SL:806*/BlockUtil.placeCrystalOnBlock(this.placePos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.placeSwing.getValue(), this.exactHand.getValue());
                                }
                            }
                            /*SL:809*/this.lastPos = this.placePos;
                            /*SL:810*/this.placeTimer.reset();
                            /*SL:811*/this.posConfirmed = false;
                            /*SL:812*/if (this.syncTimer.passedMs(this.damageSyncTime.getValue())) {
                                /*SL:813*/this.syncedCrystalPos = null;
                                /*SL:814*/this.syncTimer.reset();
                            }
                        }
                    }
                }
            }
            else {
                /*SL:820*/this.renderPos = null;
            }
        }
    }
    
    private boolean shouldHoldFacePlace() {
        /*SL:826*/this.addTolowDmg = false;
        /*SL:827*/return this.holdFacePlace.getValue() && Mouse.isButtonDown(0) && /*EL:828*/(this.addTolowDmg = true);
    }
    
    private boolean switchItem() {
        /*SL:835*/if (this.offHand || this.mainHand) {
            /*SL:836*/return true;
        }
        /*SL:838*/switch (this.autoSwitch.getValue()) {
            case NONE: {
                /*SL:840*/return false;
            }
            case TOGGLE: {
                /*SL:843*/if (!this.switching) {
                    /*SL:844*/return false;
                }
            }
            case ALWAYS: {
                /*SL:848*/if (!this.doSwitch()) {
                    break;
                }
                /*SL:849*/return true;
            }
        }
        /*SL:852*/return false;
    }
    
    private boolean doSwitch() {
        /*SL:856*/if (!this.offhandSwitch.getValue()) {
            /*SL:866*/if (AutoCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
                /*SL:867*/this.mainHand = false;
            }
            else {
                /*SL:869*/InventoryUtil.switchToHotbarSlot(ItemEndCrystal.class, false);
                /*SL:870*/this.mainHand = true;
            }
            /*SL:872*/this.switching = false;
            /*SL:873*/return true;
        }
        final Offhand v1 = Legacy.moduleManager.<Offhand>getModuleByClass(Offhand.class);
        if (v1.isOff()) {
            Command.sendMessage("<" + this.getDisplayName() + "> �cSwitch failed. Enable the Offhand module.");
            return this.switching = false;
        }
        this.switching = false;
        return true;
    }
    
    private void calculateDamage(final EntityPlayer v-1) {
        /*SL:879*/if (v-1 == null && this.targetMode.getValue() != Target.DAMAGE && !this.fullCalc.getValue()) {
            /*SL:880*/return;
        }
        float v2 = /*EL:882*/0.5f;
        /*SL:883*/v2 = null;
        BlockPos v3 = /*EL:884*/null;
        float v4 = /*EL:885*/0.0f;
        /*SL:886*/this.foundDoublePop = false;
        BlockPos v5 = /*EL:887*/null;
        IBlockState v6 = /*EL:888*/null;
        final BlockPos a1;
        final Block v7;
        /*SL:889*/if (this.webAttack.getValue() && v-1 != null && (v7 = AutoCrystal.mc.field_71441_e.func_180495_p(a1 = new BlockPos(v-1.func_174791_d())).func_177230_c()) == Blocks.field_150321_G) {
            /*SL:890*/v5 = a1;
            /*SL:891*/v6 = AutoCrystal.mc.field_71441_e.func_180495_p(a1);
            AutoCrystal.mc.field_71441_e.func_175698_g(/*EL:892*/a1);
        }
        /*SL:895*/for (final BlockPos v8 : BlockUtil.possiblePlacePositions(this.placeRange.getValue(), this.antiSurround.getValue(), this.oneDot15.getValue())) {
            /*SL:896*/if (!BlockUtil.rayTracePlaceCheck(v8, (this.raytrace.getValue() == Raytrace.PLACE || this.raytrace.getValue() == Raytrace.FULL) && AutoCrystal.mc.field_71439_g.func_174818_b(v8) > MathUtil.square(this.placetrace.getValue()), 1.0f)) {
                /*SL:897*/continue;
            }
            float v9 = /*EL:898*/-1.0f;
            /*SL:899*/if (DamageUtil.canTakeDamage(this.suicide.getValue())) {
                /*SL:900*/v9 = DamageUtil.calculateDamage(v8, (Entity)AutoCrystal.mc.field_71439_g);
            }
            /*SL:902*/if (v9 + 0.5 >= EntityUtil.getHealth((Entity)AutoCrystal.mc.field_71439_g)) {
                continue;
            }
            if (v9 > this.maxSelfPlace.getValue()) {
                /*SL:903*/continue;
            }
            /*SL:904*/if (v-1 != null) {
                final float v10 = /*EL:905*/DamageUtil.calculateDamage(v8, (Entity)v-1);
                /*SL:906*/if (this.calcEvenIfNoDamage.getValue() && (this.antiFriendPop.getValue() == AntiFriendPop.ALL || this.antiFriendPop.getValue() == AntiFriendPop.PLACE)) {
                    boolean v11 = /*EL:907*/false;
                    /*SL:908*/for (final EntityPlayer v12 : AutoCrystal.mc.field_71441_e.field_73010_i) {
                        /*SL:910*/if (v12 != null && !AutoCrystal.mc.field_71439_g.equals((Object)v12) && v12.func_174818_b(v8) <= MathUtil.square(this.range.getValue() + this.placeRange.getValue()) && Legacy.friendManager.isFriend(v12)) {
                            final float v13;
                            if ((v13 = DamageUtil.calculateDamage(v8, (Entity)v12)) <= EntityUtil.getHealth((Entity)v12) + 0.5) {
                                /*SL:911*/continue;
                            }
                            /*SL:912*/v11 = true;
                            break;
                        }
                    }
                    /*SL:915*/if (v11) {
                        continue;
                    }
                }
                /*SL:917*/if (this.isDoublePoppable(v-1, v10) && (v3 == null || v-1.func_174818_b(v8) < v-1.func_174818_b(v3))) {
                    /*SL:918*/v2 = v-1;
                    /*SL:919*/v2 = v10;
                    /*SL:920*/v3 = v8;
                    /*SL:921*/this.foundDoublePop = true;
                }
                else {
                    /*SL:924*/if (this.foundDoublePop || (v10 <= v2 && (!this.extraSelfCalc.getValue() || v10 < v2 || v9 >= v4))) {
                        continue;
                    }
                    if (v10 <= v9 && (v10 <= this.minDamage.getValue() || DamageUtil.canTakeDamage(this.suicide.getValue())) && v10 <= EntityUtil.getHealth((Entity)v-1)) {
                        /*SL:925*/continue;
                    }
                    /*SL:926*/v2 = v10;
                    /*SL:927*/v2 = v-1;
                    /*SL:928*/v3 = v8;
                    /*SL:929*/v4 = v9;
                }
            }
            else {
                final float v10 = /*EL:932*/v2;
                final EntityPlayer v14 = /*EL:933*/v2;
                final BlockPos v15 = /*EL:934*/v3;
                final float v16 = /*EL:935*/v4;
                /*SL:936*/for (final EntityPlayer v17 : AutoCrystal.mc.field_71441_e.field_73010_i) {
                    /*SL:938*/if (EntityUtil.isValid((Entity)v17, this.placeRange.getValue() + this.range.getValue())) {
                        /*SL:939*/if (this.antiNaked.getValue() && DamageUtil.isNaked(v17)) {
                            continue;
                        }
                        final float v18 = /*EL:940*/DamageUtil.calculateDamage(v8, (Entity)v17);
                        /*SL:941*/if (this.doublePopOnDamage.getValue() && this.isDoublePoppable(v17, v18) && (v3 == null || v17.func_174818_b(v8) < v17.func_174818_b(v3))) {
                            /*SL:942*/v2 = v17;
                            /*SL:943*/v2 = v18;
                            /*SL:944*/v3 = v8;
                            /*SL:945*/v4 = v9;
                            /*SL:946*/this.foundDoublePop = true;
                            /*SL:947*/if (this.antiFriendPop.getValue() != AntiFriendPop.BREAK && this.antiFriendPop.getValue() != AntiFriendPop.PLACE) {
                                /*SL:948*/continue;
                            }
                            break;
                        }
                        else {
                            /*SL:951*/if (this.foundDoublePop || (v18 <= v2 && (!this.extraSelfCalc.getValue() || v18 < v2 || v9 >= v4))) {
                                continue;
                            }
                            if (v18 <= v9 && (v18 <= this.minDamage.getValue() || DamageUtil.canTakeDamage(this.suicide.getValue())) && v18 <= EntityUtil.getHealth((Entity)v17)) {
                                /*SL:952*/continue;
                            }
                            /*SL:953*/v2 = v18;
                            /*SL:954*/v2 = v17;
                            /*SL:955*/v3 = v8;
                            /*SL:956*/v4 = v9;
                        }
                    }
                    else {
                        /*SL:959*/if ((this.antiFriendPop.getValue() != AntiFriendPop.ALL && this.antiFriendPop.getValue() != AntiFriendPop.PLACE) || v17 == null || v17.func_174818_b(v8) > MathUtil.square(this.range.getValue() + this.placeRange.getValue()) || !Legacy.friendManager.isFriend(v17)) {
                            continue;
                        }
                        final float v19;
                        if ((v19 = DamageUtil.calculateDamage(v8, (Entity)v17)) <= EntityUtil.getHealth((Entity)v17) + 0.5) {
                            /*SL:960*/continue;
                        }
                        /*SL:961*/v2 = v10;
                        /*SL:962*/v2 = v14;
                        /*SL:963*/v3 = v15;
                        /*SL:964*/v4 = v16;
                        /*SL:965*/break;
                    }
                }
            }
        }
        /*SL:968*/if (v5 != null) {
            AutoCrystal.mc.field_71441_e.func_175656_a(/*EL:969*/v5, v6);
            /*SL:970*/this.webPos = v3;
        }
        AutoCrystal.target = /*EL:972*/v2;
        /*SL:973*/this.currentDamage = v2;
        /*SL:974*/this.placePos = v3;
    }
    
    private EntityPlayer getTarget(final boolean v-1) {
        /*SL:978*/if (this.targetMode.getValue() == Target.DAMAGE) {
            /*SL:979*/return null;
        }
        EntityPlayer v0 = /*EL:981*/null;
        /*SL:982*/for (final EntityPlayer a1 : AutoCrystal.mc.field_71441_e.field_73010_i) {
            /*SL:983*/if (!EntityUtil.isntValid((Entity)a1, this.placeRange.getValue() + this.range.getValue()) && (!this.antiNaked.getValue() || !DamageUtil.isNaked(a1))) {
                if (v-1 && EntityUtil.isSafe((Entity)a1)) {
                    /*SL:984*/continue;
                }
                /*SL:985*/if (this.minArmor.getValue() > 0 && DamageUtil.isArmorLow(a1, this.minArmor.getValue())) {
                    /*SL:986*/v0 = a1;
                    /*SL:987*/break;
                }
                /*SL:989*/if (v0 == null) {
                    /*SL:990*/v0 = a1;
                }
                else {
                    /*SL:993*/if (AutoCrystal.mc.field_71439_g.func_70068_e((Entity)a1) >= AutoCrystal.mc.field_71439_g.func_70068_e((Entity)v0)) {
                        /*SL:994*/continue;
                    }
                    /*SL:995*/v0 = a1;
                }
            }
        }
        /*SL:997*/if (v-1 && v0 == null) {
            /*SL:998*/return this.getTarget(false);
        }
        /*SL:1000*/if (this.predictPos.getValue() && v0 != null) {
            final GameProfile v = /*EL:1001*/new GameProfile((v0.func_110124_au() == null) ? UUID.fromString("8af022c8-b926-41a0-8b79-2b544ff00fcf") : v0.func_110124_au(), v0.func_70005_c_());
            final EntityOtherPlayerMP v2 = /*EL:1002*/new EntityOtherPlayerMP((World)AutoCrystal.mc.field_71441_e, v);
            final Vec3d v3 = /*EL:1003*/MathUtil.extrapolatePlayerPosition(v0, this.predictTicks.getValue());
            /*SL:1004*/v2.func_82149_j((Entity)v0);
            /*SL:1005*/v2.field_70165_t = v3.field_72450_a;
            /*SL:1006*/v2.field_70163_u = v3.field_72448_b;
            /*SL:1007*/v2.field_70161_v = v3.field_72449_c;
            /*SL:1008*/v2.func_70606_j(EntityUtil.getHealth((Entity)v0));
            /*SL:1009*/v2.field_71071_by.func_70455_b(v0.field_71071_by);
            /*SL:1010*/v0 = (EntityPlayer)v2;
        }
        /*SL:1012*/return v0;
    }
    
    private void breakCrystal() {
        /*SL:1016*/if (this.explode.getValue() && this.breakTimer.passedMs(this.breakDelay.getValue()) && (this.switchMode.getValue() == Switch.ALWAYS || this.mainHand || this.offHand)) {
            /*SL:1017*/if (this.packets.getValue() == 1 && this.efficientTarget != null) {
                /*SL:1018*/if (this.justRender.getValue()) {
                    /*SL:1019*/this.doFakeSwing();
                    /*SL:1020*/return;
                }
                /*SL:1022*/if (this.syncedFeetPlace.getValue() && this.gigaSync.getValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != DamageSync.NONE) {
                    /*SL:1023*/return;
                }
                /*SL:1025*/this.rotateTo(this.efficientTarget);
                /*SL:1026*/this.attackEntity(this.efficientTarget);
                /*SL:1027*/this.breakTimer.reset();
            }
            else/*SL:1028*/ if (!this.attackList.isEmpty()) {
                /*SL:1029*/if (this.justRender.getValue()) {
                    /*SL:1030*/this.doFakeSwing();
                    /*SL:1031*/return;
                }
                /*SL:1033*/if (this.syncedFeetPlace.getValue() && this.gigaSync.getValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != DamageSync.NONE) {
                    /*SL:1034*/return;
                }
                /*SL:1036*/for (int v0 = 0; v0 < this.packets.getValue(); ++v0) {
                    final Entity v = /*EL:1037*/this.attackList.poll();
                    /*SL:1038*/if (v != null) {
                        /*SL:1039*/this.rotateTo(v);
                        /*SL:1040*/this.attackEntity(v);
                    }
                }
                /*SL:1042*/this.breakTimer.reset();
            }
        }
    }
    
    private void attackEntity(final Entity a1) {
        /*SL:1048*/if (a1 != null) {
            /*SL:1049*/if (this.eventMode.getValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE && this.rotateFirst.getValue() && this.rotate.getValue() != Rotate.OFF) {
                /*SL:1050*/this.packetUseEntities.add(new CPacketUseEntity(a1));
            }
            else {
                /*SL:1052*/EntityUtil.attackEntity(a1, this.sync.getValue(), this.breakSwing.getValue());
                AutoCrystal.brokenPos.add(/*EL:1053*/new BlockPos(a1.func_174791_d()).func_177977_b());
            }
        }
    }
    
    private void doFakeSwing() {
        /*SL:1059*/if (this.fakeSwing.getValue()) {
            /*SL:1060*/EntityUtil.swingArmNoPacket(EnumHand.MAIN_HAND, (EntityLivingBase)AutoCrystal.mc.field_71439_g);
        }
    }
    
    private void manualBreaker() {
        /*SL:1066*/if (this.rotate.getValue() != Rotate.OFF && this.eventMode.getValue() != 2 && this.rotating) {
            /*SL:1067*/if (this.didRotation) {
                AutoCrystal.mc.field_71439_g.field_70125_A += /*EL:1068*/4.0E-4;
                /*SL:1069*/this.didRotation = false;
            }
            else {
                AutoCrystal.mc.field_71439_g.field_70125_A -= /*EL:1071*/4.0E-4;
                /*SL:1072*/this.didRotation = true;
            }
        }
        final RayTraceResult v0;
        /*SL:1075*/if ((this.offHand || this.mainHand) && this.manual.getValue() && this.manualTimer.passedMs(this.manualBreak.getValue()) && Mouse.isButtonDown(1) && AutoCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_151153_ao && AutoCrystal.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151153_ao && AutoCrystal.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151031_f && AutoCrystal.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151062_by && (v0 = AutoCrystal.mc.field_71476_x) != null) {
            /*SL:1076*/switch (v0.field_72313_a) {
                case ENTITY: {
                    final Entity v = /*EL:1078*/v0.field_72308_g;
                    /*SL:1079*/if (!(v instanceof EntityEnderCrystal)) {
                        break;
                    }
                    /*SL:1080*/EntityUtil.attackEntity(v, this.sync.getValue(), this.breakSwing.getValue());
                    /*SL:1081*/this.manualTimer.reset();
                    /*SL:1082*/break;
                }
                case BLOCK: {
                    final BlockPos v2 = AutoCrystal.mc.field_71476_x.func_178782_a().func_177984_a();
                    /*SL:1086*/for (final Entity v3 : AutoCrystal.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(v2))) {
                        /*SL:1087*/if (!(v3 instanceof EntityEnderCrystal)) {
                            continue;
                        }
                        /*SL:1088*/EntityUtil.attackEntity(v3, this.sync.getValue(), this.breakSwing.getValue());
                        /*SL:1089*/this.manualTimer.reset();
                    }
                    break;
                }
            }
        }
    }
    
    private void rotateTo(final Entity v2) {
        /*SL:1098*/switch (this.rotate.getValue()) {
            case OFF: {
                /*SL:1100*/this.rotating = false;
            }
            case BREAK:
            case ALL: {
                final float[] a1 = /*EL:1107*/MathUtil.calcAngle(AutoCrystal.mc.field_71439_g.func_174824_e(AutoCrystal.mc.func_184121_ak()), v2.func_174791_d());
                /*SL:1108*/if (this.eventMode.getValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE) {
                    Legacy.rotationManager.setPlayerRotations(/*EL:1109*/a1[0], a1[1]);
                    /*SL:1110*/break;
                }
                /*SL:1112*/this.yaw = a1[0];
                /*SL:1113*/this.pitch = a1[1];
                /*SL:1114*/this.rotating = true;
                break;
            }
        }
    }
    
    private void rotateToPos(final BlockPos v2) {
        /*SL:1120*/switch (this.rotate.getValue()) {
            case OFF: {
                /*SL:1122*/this.rotating = false;
            }
            case PLACE:
            case ALL: {
                final float[] a1 = /*EL:1129*/MathUtil.calcAngle(AutoCrystal.mc.field_71439_g.func_174824_e(AutoCrystal.mc.func_184121_ak()), new Vec3d((double)(v2.func_177958_n() + 0.5f), (double)(v2.func_177956_o() - 0.5f), (double)(v2.func_177952_p() + 0.5f)));
                /*SL:1130*/if (this.eventMode.getValue() == 2 && this.threadMode.getValue() == ThreadMode.NONE) {
                    Legacy.rotationManager.setPlayerRotations(/*EL:1131*/a1[0], a1[1]);
                    /*SL:1132*/break;
                }
                /*SL:1134*/this.yaw = a1[0];
                /*SL:1135*/this.pitch = a1[1];
                /*SL:1136*/this.rotating = true;
                break;
            }
        }
    }
    
    private boolean isDoublePoppable(final EntityPlayer v2, final float v3) {
        float a2;
        Timer a2;
        /*SL:1143*/if (this.doublePop.getValue() && (a2 = EntityUtil.getHealth((Entity)v2)) <= this.popHealth.getValue() && v3 > a2 + 0.5 && v3 <= this.popDamage.getValue()) {
            /*SL:1144*/a2 = this.totemPops.get(v2);
            /*SL:1145*/return a2 == null || a2.passedMs(this.popTime.getValue());
        }
        /*SL:1147*/return false;
    }
    
    private boolean isValid(final Entity a1) {
        /*SL:1151*/return a1 != null && AutoCrystal.mc.field_71439_g.func_70068_e(a1) <= MathUtil.square(this.breakRange.getValue()) && (this.raytrace.getValue() == Raytrace.NONE || this.raytrace.getValue() == Raytrace.PLACE || AutoCrystal.mc.field_71439_g.func_70685_l(a1) || (!AutoCrystal.mc.field_71439_g.func_70685_l(a1) && AutoCrystal.mc.field_71439_g.func_70068_e(a1) <= MathUtil.square(this.breaktrace.getValue())));
    }
    
    private boolean isEligableForFeetSync(final EntityPlayer v-1, final BlockPos v0) {
        /*SL:1155*/if (this.holySync.getValue()) {
            final BlockPos v = /*EL:1156*/new BlockPos(v-1.func_174791_d());
            /*SL:1157*/for (BlockPos a2 : EnumFacing.values()) {
                if (/*EL:1159*/a2 != EnumFacing.DOWN && a2 != EnumFacing.UP && v0.equals((Object)(a2 = v.func_177977_b().func_177972_a(a2)))) {
                    /*SL:1161*/return true;
                }
            }
            /*SL:1163*/return false;
        }
        /*SL:1165*/return true;
    }
    
    public Color getCurrentColor() {
        /*SL:1362*/return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }
    
    static {
        AutoCrystal.target = null;
        AutoCrystal.lowDmgPos = (Set<BlockPos>)new ConcurrentSet();
        AutoCrystal.placedPos = new HashSet<BlockPos>();
        AutoCrystal.brokenPos = new HashSet<BlockPos>();
    }
    
    public enum PredictTimer
    {
        NONE, 
        BREAK, 
        PREDICT;
    }
    
    public enum AntiFriendPop
    {
        NONE, 
        PLACE, 
        BREAK, 
        ALL;
    }
    
    public enum ThreadMode
    {
        NONE, 
        POOL, 
        SOUND, 
        WHILE;
    }
    
    public enum AutoSwitch
    {
        NONE, 
        TOGGLE, 
        ALWAYS;
    }
    
    public enum Raytrace
    {
        NONE, 
        PLACE, 
        BREAK, 
        FULL;
    }
    
    public enum Switch
    {
        ALWAYS, 
        BREAKSLOT, 
        CALC;
    }
    
    public enum Logic
    {
        BREAKPLACE, 
        PLACEBREAK;
    }
    
    public enum Target
    {
        CLOSEST, 
        UNSAFE, 
        DAMAGE;
    }
    
    public enum Rotate
    {
        OFF, 
        PLACE, 
        BREAK, 
        ALL;
    }
    
    public enum DamageSync
    {
        NONE, 
        PLACE, 
        BREAK;
    }
    
    public enum Settings
    {
        PLACE, 
        BREAK, 
        RENDER, 
        MISC, 
        DEV;
    }
    
    public static class PlaceInfo
    {
        private final BlockPos pos;
        private final boolean offhand;
        private final boolean placeSwing;
        private final boolean exactHand;
        
        public PlaceInfo(final BlockPos a1, final boolean a2, final boolean a3, final boolean a4) {
            this.pos = a1;
            this.offhand = a2;
            this.placeSwing = a3;
            this.exactHand = a4;
        }
        
        public void runPlace() {
            /*SL:1264*/BlockUtil.placeCrystalOnBlock(this.pos, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.placeSwing, this.exactHand);
        }
    }
    
    private static class RAutoCrystal implements Runnable
    {
        private static RAutoCrystal instance;
        private AutoCrystal autoCrystal;
        
        public static RAutoCrystal getInstance(final AutoCrystal a1) {
            /*SL:1277*/if (RAutoCrystal.instance == null) {
                RAutoCrystal.instance = /*EL:1278*/new RAutoCrystal();
                RAutoCrystal.instance.autoCrystal = /*EL:1279*/a1;
            }
            /*SL:1281*/return RAutoCrystal.instance;
        }
        
        @Override
        public void run() {
            /*SL:1286*/if (this.autoCrystal.threadMode.getValue() == ThreadMode.WHILE) {
                /*SL:1287*/while (this.autoCrystal.isOn() && this.autoCrystal.threadMode.getValue() == ThreadMode.WHILE) {
                    /*SL:1288*/while (Legacy.eventManager.ticksOngoing()) {}
                    /*SL:1290*/if (this.autoCrystal.shouldInterrupt.get()) {
                        /*SL:1291*/this.autoCrystal.shouldInterrupt.set(false);
                        /*SL:1292*/this.autoCrystal.syncroTimer.reset();
                        /*SL:1293*/this.autoCrystal.thread.interrupt();
                        /*SL:1294*/break;
                    }
                    /*SL:1296*/this.autoCrystal.threadOngoing.set(true);
                    /*SL:1297*/this.autoCrystal.doAutoCrystal();
                    /*SL:1298*/this.autoCrystal.threadOngoing.set(false);
                    try {
                        /*SL:1300*/Thread.sleep(this.autoCrystal.threadDelay.getValue());
                    }
                    catch (InterruptedException v1) {
                        /*SL:1302*/this.autoCrystal.thread.interrupt();
                        /*SL:1303*/v1.printStackTrace();
                    }
                }
            }
            else/*SL:1306*/ if (this.autoCrystal.threadMode.getValue() != ThreadMode.NONE && this.autoCrystal.isOn()) {
                /*SL:1307*/while (Legacy.eventManager.ticksOngoing()) {}
                /*SL:1309*/this.autoCrystal.threadOngoing.set(true);
                /*SL:1310*/this.autoCrystal.doAutoCrystal();
                /*SL:1311*/this.autoCrystal.threadOngoing.set(false);
            }
        }
    }
    
    public class switchTimer
    {
        private long time;
        
        public switchTimer() {
            this.time = -1L;
        }
        
        public boolean passedS(final double a1) {
            /*SL:1320*/return this.passedMs((long)a1 * 1000L);
        }
        
        public boolean passedDms(final double a1) {
            /*SL:1324*/return this.passedMs((long)a1 * 10L);
        }
        
        public boolean passedDs(final double a1) {
            /*SL:1328*/return this.passedMs((long)a1 * 100L);
        }
        
        public boolean passedMs(final long a1) {
            /*SL:1332*/return this.passedNS(this.convertToNS(a1));
        }
        
        public void setMs(final long a1) {
            /*SL:1336*/this.time = System.nanoTime() - this.convertToNS(a1);
        }
        
        public boolean passedNS(final long a1) {
            /*SL:1340*/return System.nanoTime() - this.time >= a1;
        }
        
        public long getPassedTimeMs() {
            /*SL:1344*/return this.getMs(System.nanoTime() - this.time);
        }
        
        public switchTimer reset() {
            /*SL:1348*/this.time = System.nanoTime();
            /*SL:1349*/return this;
        }
        
        public long getMs(final long a1) {
            /*SL:1353*/return a1 / 1000000L;
        }
        
        public long convertToNS(final long a1) {
            /*SL:1357*/return a1 * 1000000L;
        }
    }
}
