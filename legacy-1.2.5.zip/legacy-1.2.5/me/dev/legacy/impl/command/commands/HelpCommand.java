package me.dev.legacy.impl.command.commands;

import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;

public class HelpCommand extends Command
{
    public HelpCommand() {
        super("help");
    }
    
    @Override
    public void execute(final String[] v2) {
        /*SL:15*/Command.sendMessage("Commands: ");
        /*SL:16*/for (final Command a1 : Legacy.commandManager.getCommands()) {
            /*SL:17*/Command.sendMessage(ChatFormatting.GRAY + Legacy.commandManager.getPrefix() + a1.getName());
        }
    }
}
