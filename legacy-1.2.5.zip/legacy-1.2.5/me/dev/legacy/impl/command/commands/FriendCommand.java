package me.dev.legacy.impl.command.commands;

import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.api.manager.FriendManager;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;

public class FriendCommand extends Command
{
    public FriendCommand() {
        super("friend", new String[] { "<add/del/name/clear>", "<name>" });
    }
    
    @Override
    public void execute(final String[] v0) {
        /*SL:16*/if (v0.length == 1) {
            /*SL:17*/if (Legacy.friendManager.getFriends().isEmpty()) {
                /*SL:18*/Command.sendMessage("Friend list empty D:.");
            }
            else {
                String v = /*EL:20*/"Friends: ";
                /*SL:21*/for (final FriendManager.Friend a1 : Legacy.friendManager.getFriends()) {
                    try {
                        /*SL:23*/v = v + a1.getUsername() + ", ";
                    }
                    catch (Exception ex) {}
                }
                /*SL:27*/Command.sendMessage(v);
            }
            /*SL:29*/return;
        }
        /*SL:31*/if (v0.length != 2) {
            /*SL:42*/if (v0.length >= 2) {
                final String s = /*EL:43*/v0[0];
                switch (s) {
                    case "add": {
                        Legacy.friendManager.addFriend(/*EL:45*/v0[1]);
                        /*SL:46*/Command.sendMessage(ChatFormatting.GREEN + v0[1] + " has been friended");
                    }
                    case "del": {
                        Legacy.friendManager.removeFriend(/*EL:50*/v0[1]);
                        /*SL:51*/Command.sendMessage(ChatFormatting.RED + v0[1] + " has been unfriended");
                    }
                    default: {
                        /*SL:55*/Command.sendMessage("Unknown Command, try friend add/del (name)");
                        break;
                    }
                }
            }
            /*SL:57*/return;
        }
        final String s2 = v0[0];
        switch (s2) {
            case "reset": {
                Legacy.friendManager.onLoad();
                Command.sendMessage("Friends got reset.");
            }
            default: {
                Command.sendMessage(v0[0] + (Legacy.friendManager.isFriend(v0[0]) ? " is friended." : " isn't friended."));
            }
        }
    }
}
