package me.dev.legacy.impl.setting;

import com.google.gson.JsonPrimitive;
import com.google.gson.JsonElement;
import com.google.common.base.Converter;
import org.lwjgl.input.Keyboard;

public class Bind
{
    private int key;
    
    public Bind(final int a1) {
        this.key = a1;
    }
    
    public static Bind none() {
        /*SL:16*/return new Bind(-1);
    }
    
    public int getKey() {
        /*SL:20*/return this.key;
    }
    
    public void setKey(final int a1) {
        /*SL:24*/this.key = a1;
    }
    
    public boolean isEmpty() {
        /*SL:28*/return this.key < 0;
    }
    
    @Override
    public String toString() {
        /*SL:32*/return this.isEmpty() ? "None" : ((this.key < 0) ? "None" : this.capitalise(Keyboard.getKeyName(this.key)));
    }
    
    public boolean isDown() {
        /*SL:36*/return !this.isEmpty() && Keyboard.isKeyDown(this.getKey());
    }
    
    private String capitalise(final String a1) {
        /*SL:40*/if (a1.isEmpty()) {
            /*SL:41*/return "";
        }
        /*SL:43*/return Character.toUpperCase(a1.charAt(0)) + ((a1.length() != 1) ? a1.substring(1).toLowerCase() : "");
    }
    
    public static class BindConverter extends Converter<Bind, JsonElement>
    {
        public JsonElement doForward(final Bind a1) {
            /*SL:49*/return (JsonElement)new JsonPrimitive(a1.toString());
        }
        
        public Bind doBackward(final JsonElement a1) {
            final String v1 = /*EL:53*/a1.getAsString();
            /*SL:54*/if (v1.equalsIgnoreCase("None")) {
                /*SL:55*/return Bind.none();
            }
            int v2 = /*EL:57*/-1;
            try {
                /*SL:59*/v2 = Keyboard.getKeyIndex(v1.toUpperCase());
            }
            catch (Exception ex) {}
            /*SL:63*/if (v2 == 0) {
                /*SL:64*/return Bind.none();
            }
            /*SL:66*/return new Bind(v2);
        }
    }
}
