package me.dev.legacy.impl.setting;

import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.ClientEvent;
import me.dev.legacy.api.AbstractModule;
import java.util.function.Predicate;

public class Setting<T>
{
    private final String name;
    private final T defaultValue;
    private T value;
    private T plannedValue;
    private T min;
    private T max;
    private boolean hasRestriction;
    private Predicate<T> visibility;
    private String description;
    private AbstractModule feature;
    private int key;
    
    public Setting(final String a1, final T a2) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.plannedValue = a2;
        this.description = "";
    }
    
    public Setting(final String a1, final T a2, final String a3) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.plannedValue = a2;
        this.description = a3;
    }
    
    public Setting(final String a1, final T a2, final T a3, final T a4, final String a5) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.min = a3;
        this.max = a4;
        this.plannedValue = a2;
        this.description = a5;
        this.hasRestriction = true;
    }
    
    public Setting(final String a1, final T a2, final T a3, final T a4) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.min = a3;
        this.max = a4;
        this.plannedValue = a2;
        this.description = "";
        this.hasRestriction = true;
    }
    
    public Setting(final String a1, final T a2, final T a3, final T a4, final Predicate<T> a5, final String a6) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.min = a3;
        this.max = a4;
        this.plannedValue = a2;
        this.visibility = a5;
        this.description = a6;
        this.hasRestriction = true;
    }
    
    public Setting(final String a1, final T a2, final T a3, final T a4, final Predicate<T> a5) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.min = a3;
        this.max = a4;
        this.plannedValue = a2;
        this.visibility = a5;
        this.description = "";
        this.hasRestriction = true;
    }
    
    public Setting(final String a1, final T a2, final Predicate<T> a3) {
        this.name = a1;
        this.defaultValue = a2;
        this.value = a2;
        this.visibility = a3;
        this.plannedValue = a2;
    }
    
    public String getName() {
        /*SL:94*/return this.name;
    }
    
    public T getValue() {
        /*SL:98*/return this.value;
    }
    
    public void setValue(final T a1) {
        /*SL:102*/this.setPlannedValue(a1);
        /*SL:103*/if (this.hasRestriction) {
            /*SL:104*/if (((Number)this.min).floatValue() > ((Number)a1).floatValue()) {
                /*SL:105*/this.setPlannedValue(this.min);
            }
            /*SL:107*/if (((Number)this.max).floatValue() < ((Number)a1).floatValue()) {
                /*SL:108*/this.setPlannedValue(this.max);
            }
        }
        final ClientEvent v1 = /*EL:111*/new ClientEvent(this);
        MinecraftForge.EVENT_BUS.post(/*EL:112*/(Event)v1);
        /*SL:113*/if (!v1.isCanceled()) {
            /*SL:114*/this.value = this.plannedValue;
        }
        else {
            /*SL:116*/this.plannedValue = this.value;
        }
    }
    
    public T getPlannedValue() {
        /*SL:121*/return this.plannedValue;
    }
    
    public void setPlannedValue(final T a1) {
        /*SL:125*/this.plannedValue = a1;
    }
    
    public T getMin() {
        /*SL:129*/return this.min;
    }
    
    public void setMin(final T a1) {
        /*SL:133*/this.min = a1;
    }
    
    public T getMax() {
        /*SL:137*/return this.max;
    }
    
    public void setMax(final T a1) {
        /*SL:141*/this.max = a1;
    }
    
    public void setValueNoEvent(final T a1) {
        /*SL:145*/this.setPlannedValue(a1);
        /*SL:146*/if (this.hasRestriction) {
            /*SL:147*/if (((Number)this.min).floatValue() > ((Number)a1).floatValue()) {
                /*SL:148*/this.setPlannedValue(this.min);
            }
            /*SL:150*/if (((Number)this.max).floatValue() < ((Number)a1).floatValue()) {
                /*SL:151*/this.setPlannedValue(this.max);
            }
        }
        /*SL:154*/this.value = this.plannedValue;
    }
    
    public AbstractModule getFeature() {
        /*SL:158*/return this.feature;
    }
    
    public void setFeature(final AbstractModule a1) {
        /*SL:162*/this.feature = a1;
    }
    
    public int getEnum(final String v0) {
        /*SL:166*/for (int v = 0; v < this.value.getClass().getEnumConstants().length; ++v) {
            final Enum a1 = /*EL:167*/(Enum)this.value.getClass().getEnumConstants()[v];
            /*SL:168*/if (a1.name().equalsIgnoreCase(v0)) {
                /*SL:169*/return v;
            }
        }
        /*SL:171*/return -1;
    }
    
    public void setEnumValue(final String v2) {
        /*SL:175*/for (final Enum a1 : (Enum[])((Enum)this.value).getClass().getEnumConstants()) {
            /*SL:176*/if (a1.name().equalsIgnoreCase(v2)) {
                /*SL:177*/this.value = (T)a1;
            }
        }
    }
    
    public String currentEnumName() {
        /*SL:182*/return EnumConverter.getProperName((Enum)this.value);
    }
    
    public int currentEnum() {
        /*SL:186*/return EnumConverter.currentEnum((Enum)this.value);
    }
    
    public void increaseEnum() {
        /*SL:190*/this.plannedValue = (T)EnumConverter.increaseEnum((Enum)this.value);
        final ClientEvent v1 = /*EL:191*/new ClientEvent(this);
        MinecraftForge.EVENT_BUS.post(/*EL:192*/(Event)v1);
        /*SL:193*/if (!v1.isCanceled()) {
            /*SL:194*/this.value = this.plannedValue;
        }
        else {
            /*SL:196*/this.plannedValue = this.value;
        }
    }
    
    public void increaseEnumNoEvent() {
        /*SL:201*/this.value = (T)EnumConverter.increaseEnum((Enum)this.value);
    }
    
    public String getType() {
        /*SL:205*/if (this.isEnumSetting()) {
            /*SL:206*/return "Enum";
        }
        /*SL:208*/return this.<T>getClassName(this.defaultValue);
    }
    
    public <T> String getClassName(final T a1) {
        /*SL:212*/return a1.getClass().getSimpleName();
    }
    
    public String getDescription() {
        /*SL:216*/if (this.description == null) {
            /*SL:217*/return "";
        }
        /*SL:219*/return this.description;
    }
    
    public boolean isNumberSetting() {
        /*SL:223*/return this.value instanceof Double || this.value instanceof Integer || this.value instanceof Short || this.value instanceof Long || this.value instanceof Float;
    }
    
    public boolean isEnumSetting() {
        /*SL:227*/return !this.isNumberSetting() && !(this.value instanceof String) && !(this.value instanceof Bind) && !(this.value instanceof Character) && !(this.value instanceof Boolean);
    }
    
    public boolean isStringSetting() {
        /*SL:231*/return this.value instanceof String;
    }
    
    public T getDefaultValue() {
        /*SL:235*/return this.defaultValue;
    }
    
    public String getValueAsString() {
        /*SL:239*/return this.value.toString();
    }
    
    public boolean hasRestriction() {
        /*SL:243*/return this.hasRestriction;
    }
    
    public void setVisibility(final Predicate<T> a1) {
        /*SL:247*/this.visibility = a1;
    }
    
    public boolean isVisible() {
        /*SL:251*/return this.visibility == null || /*EL:254*/this.visibility.test(this.getValue());
    }
    
    public boolean is(final String a1) {
        /*SL:258*/return false;
    }
    
    public int getKey() {
        /*SL:262*/return this.key;
    }
    
    public boolean isEmpty() {
        /*SL:266*/return this.key < 0;
    }
    
    public boolean isDown() {
        /*SL:270*/return !this.isEmpty() && Keyboard.isKeyDown(this.getKey());
    }
}
