package me.dev.legacy.impl.setting;

import com.google.gson.JsonPrimitive;
import com.google.gson.JsonElement;
import com.google.common.base.Converter;

public class EnumConverter extends Converter<Enum, JsonElement>
{
    private final Class<? extends Enum> clazz;
    
    public EnumConverter(final Class<? extends Enum> a1) {
        this.clazz = a1;
    }
    
    public static int currentEnum(final Enum v0) {
        /*SL:16*/for (int v = 0; v < ((Enum[])v0.getClass().getEnumConstants()).length; ++v) {
            final Enum a1 = /*EL:17*/((Enum[])v0.getClass().getEnumConstants())[v];
            /*SL:18*/if (a1.name().equalsIgnoreCase(v0.name())) {
                /*SL:19*/return v;
            }
        }
        /*SL:21*/return -1;
    }
    
    public static Enum increaseEnum(final Enum v-1) {
        final int v0 = currentEnum(/*EL:25*/v-1);
        /*SL:26*/for (int v = 0; v < ((Enum[])v-1.getClass().getEnumConstants()).length; ++v) {
            final Enum a1 = /*EL:27*/((Enum[])v-1.getClass().getEnumConstants())[v];
            /*SL:28*/if (v == v0 + 1) {
                /*SL:29*/return a1;
            }
        }
        /*SL:31*/return ((Enum[])v-1.getClass().getEnumConstants())[0];
    }
    
    public static String getProperName(final Enum a1) {
        /*SL:35*/return Character.toUpperCase(a1.name().charAt(0)) + a1.name().toLowerCase().substring(1);
    }
    
    public JsonElement doForward(final Enum a1) {
        /*SL:39*/return (JsonElement)new JsonPrimitive(a1.toString());
    }
    
    public Enum doBackward(final JsonElement v2) {
        try {
            /*SL:44*/return (Enum)Enum.<? extends Enum<Enum>>valueOf(this.clazz, v2.getAsString());
        }
        catch (IllegalArgumentException a1) {
            /*SL:46*/return null;
        }
    }
}
