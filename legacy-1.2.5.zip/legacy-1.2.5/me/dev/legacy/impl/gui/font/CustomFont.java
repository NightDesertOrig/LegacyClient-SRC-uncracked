package me.dev.legacy.impl.gui.font;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import java.awt.Font;
import net.minecraft.client.renderer.texture.DynamicTexture;

public class CustomFont extends CFont
{
    private final int[] colorCode;
    private final String colorcodeIdentifiers = "0123456789abcdefklmnor";
    protected CharData[] boldChars;
    protected CharData[] italicChars;
    protected CharData[] boldItalicChars;
    protected DynamicTexture texBold;
    protected DynamicTexture texItalic;
    protected DynamicTexture texItalicBold;
    
    public CustomFont(final Font a1, final boolean a2, final boolean a3) {
        super(a1, a2, a3);
        this.colorCode = new int[32];
        this.boldChars = new CharData[256];
        this.italicChars = new CharData[256];
        this.boldItalicChars = new CharData[256];
        this.setupMinecraftColorcodes();
        this.setupBoldItalicIDs();
    }
    
    public float drawStringWithShadow(final String a1, final double a2, final double a3, final int a4) {
        final float v1 = /*EL:29*/this.drawString(a1, a2 + 1.0, a3 + 1.0, a4, true);
        /*SL:30*/return Math.max(v1, this.drawString(a1, a2, a3, a4, false));
    }
    
    public float drawString(final String a1, final float a2, final float a3, final int a4) {
        /*SL:34*/return this.drawString(a1, a2, a3, a4, false);
    }
    
    public float drawCenteredStringWithShadow(final String a1, final float a2, final float a3, final int a4) {
        /*SL:38*/return this.drawStringWithShadow(a1, a2 - this.getStringWidth(a1) / 2, a3, a4);
    }
    
    public float drawCenteredString(final String a1, final float a2, final float a3, final int a4) {
        /*SL:42*/return this.drawString(a1, a2 - this.getStringWidth(a1) / 2, a3, a4);
    }
    
    public float drawString(final String v2, double v3, double v5, int v7, final boolean v8) {
        /*SL:46*/--v3;
        /*SL:47*/v5 -= 2.0;
        /*SL:48*/if (v2 == null) {
            /*SL:49*/return 0.0f;
        }
        /*SL:51*/if (v7 == 553648127) {
            /*SL:52*/v7 = 16777215;
        }
        /*SL:54*/if ((v7 & 0xFC000000) == 0x0) {
            /*SL:55*/v7 |= 0xFF000000;
        }
        /*SL:58*/if (v8) {
            /*SL:59*/v7 = ((v7 & 0xFCFCFC) >> 2 | (v7 & 0xFF000000));
        }
        CharData[] v9 = /*EL:62*/this.charData;
        final float v10 = /*EL:63*/(v7 >> 24 & 0xFF) / 255.0f;
        boolean v11 = /*EL:64*/false;
        boolean v12 = /*EL:65*/false;
        boolean v13 = /*EL:66*/false;
        boolean v14 = /*EL:67*/false;
        boolean v15 = /*EL:68*/false;
        final boolean v16 = /*EL:69*/true;
        /*SL:70*/v3 *= 2.0;
        /*SL:71*/v5 *= 2.0;
        /*SL:72*/if (v16) {
            /*SL:73*/GL11.glPushMatrix();
            /*SL:74*/GlStateManager.func_179139_a(0.5, 0.5, 0.5);
            /*SL:75*/GlStateManager.func_179147_l();
            /*SL:76*/GlStateManager.func_179112_b(770, 771);
            /*SL:77*/GlStateManager.func_179131_c((v7 >> 16 & 0xFF) / 255.0f, (v7 >> 8 & 0xFF) / 255.0f, (v7 & 0xFF) / 255.0f, v10);
            int a5 = /*EL:78*/v2.length();
            /*SL:79*/GlStateManager.func_179098_w();
            /*SL:80*/GlStateManager.func_179144_i(this.tex.func_110552_b());
            /*SL:81*/GL11.glBindTexture(3553, this.tex.func_110552_b());
            /*SL:82*/for (int a2 = 0; a2 < a5; ++a2) {
                final char a3 = /*EL:83*/v2.charAt(a2);
                /*SL:84*/if (a3 == '�' && a2 < a5) {
                    int a4 = /*EL:85*/21;
                    try {
                        /*SL:87*/a4 = "0123456789abcdefklmnor".indexOf(v2.charAt(a2 + 1));
                    }
                    catch (Exception ex) {}
                    /*SL:90*/if (a4 < 16) {
                        /*SL:91*/v12 = false;
                        /*SL:92*/v13 = false;
                        /*SL:93*/v11 = false;
                        /*SL:94*/v15 = false;
                        /*SL:95*/v14 = false;
                        /*SL:96*/GlStateManager.func_179144_i(this.tex.func_110552_b());
                        /*SL:99*/v9 = this.charData;
                        /*SL:100*/if (a4 < 0 || a4 > 15) {
                            a4 = 15;
                        }
                        /*SL:101*/if (v8) {
                            a4 += 16;
                        }
                        /*SL:102*/a5 = this.colorCode[a4];
                        /*SL:103*/GlStateManager.func_179131_c((a5 >> 16 & 0xFF) / 255.0f, (a5 >> 8 & 0xFF) / 255.0f, (a5 & 0xFF) / 255.0f, v10);
                    }
                    else/*SL:104*/ if (a4 == 16) {
                        v11 = true;
                    }
                    else/*SL:105*/ if (a4 == 17) {
                        /*SL:106*/v12 = true;
                        /*SL:107*/if (v13) {
                            /*SL:108*/GlStateManager.func_179144_i(this.texItalicBold.func_110552_b());
                            /*SL:111*/v9 = this.boldItalicChars;
                        }
                        else {
                            /*SL:113*/GlStateManager.func_179144_i(this.texBold.func_110552_b());
                            /*SL:116*/v9 = this.boldChars;
                        }
                    }
                    else/*SL:118*/ if (a4 == 18) {
                        v14 = true;
                    }
                    else/*SL:119*/ if (a4 == 19) {
                        v15 = true;
                    }
                    else/*SL:120*/ if (a4 == 20) {
                        /*SL:121*/v13 = true;
                        /*SL:122*/if (v12) {
                            /*SL:123*/GlStateManager.func_179144_i(this.texItalicBold.func_110552_b());
                            /*SL:126*/v9 = this.boldItalicChars;
                        }
                        else {
                            /*SL:128*/GlStateManager.func_179144_i(this.texItalic.func_110552_b());
                            /*SL:131*/v9 = this.italicChars;
                        }
                    }
                    else/*SL:133*/ if (a4 == 21) {
                        /*SL:134*/v12 = false;
                        /*SL:135*/v13 = false;
                        /*SL:136*/v11 = false;
                        /*SL:137*/v15 = false;
                        /*SL:138*/v14 = false;
                        /*SL:139*/GlStateManager.func_179131_c((v7 >> 16 & 0xFF) / 255.0f, (v7 >> 8 & 0xFF) / 255.0f, (v7 & 0xFF) / 255.0f, v10);
                        /*SL:140*/GlStateManager.func_179144_i(this.tex.func_110552_b());
                        /*SL:143*/v9 = this.charData;
                    }
                    /*SL:145*/++a2;
                }
                else/*SL:146*/ if (a3 < v9.length && a3 >= '\0') {
                    /*SL:147*/GL11.glBegin(4);
                    /*SL:148*/this.drawChar(v9, a3, (float)v3, (float)v5);
                    /*SL:149*/GL11.glEnd();
                    /*SL:150*/if (v14) {
                        /*SL:151*/this.drawLine(v3, v5 + v9[a3].height / 2, v3 + v9[a3].width - 8.0, v5 + v9[a3].height / 2, 1.0f);
                    }
                    /*SL:152*/if (v15) {
                        /*SL:153*/this.drawLine(v3, v5 + v9[a3].height - 2.0, v3 + v9[a3].width - 8.0, v5 + v9[a3].height - 2.0, 1.0f);
                    }
                    /*SL:154*/v3 += v9[a3].width - 8 + this.charOffset;
                }
            }
            /*SL:157*/GL11.glHint(3155, 4352);
            /*SL:158*/GL11.glPopMatrix();
        }
        /*SL:160*/return (float)v3 / 2.0f;
    }
    
    @Override
    public int getStringWidth(final String v-6) {
        /*SL:165*/if (v-6 == null) {
            /*SL:166*/return 0;
        }
        int n = /*EL:168*/0;
        CharData[] array = /*EL:169*/this.charData;
        boolean b = /*EL:170*/false;
        boolean b2 = /*EL:171*/false;
        /*SL:174*/for (int length = v-6.length(), v0 = 0; v0 < length; ++v0) {
            final char v = /*EL:175*/v-6.charAt(v0);
            /*SL:176*/if (v == '�' && v0 < length) {
                final int a1 = /*EL:177*/"0123456789abcdefklmnor".indexOf(v);
                /*SL:178*/if (a1 < 16) {
                    /*SL:179*/b = false;
                    /*SL:180*/b2 = false;
                }
                else/*SL:181*/ if (a1 == 17) {
                    /*SL:182*/b = true;
                    /*SL:183*/if (b2) {
                        array = this.boldItalicChars;
                    }
                    else {
                        /*SL:184*/array = this.boldChars;
                    }
                }
                else/*SL:185*/ if (a1 == 20) {
                    /*SL:186*/b2 = true;
                    /*SL:187*/if (b) {
                        array = this.boldItalicChars;
                    }
                    else {
                        /*SL:188*/array = this.italicChars;
                    }
                }
                else/*SL:189*/ if (a1 == 21) {
                    /*SL:190*/b = false;
                    /*SL:191*/b2 = false;
                    /*SL:192*/array = this.charData;
                }
                /*SL:194*/++v0;
            }
            else/*SL:195*/ if (v < array.length && v >= '\0') {
                /*SL:196*/n += array[v].width - 8 + this.charOffset;
            }
        }
        /*SL:200*/return n / 2;
    }
    
    @Override
    public void setFont(final Font a1) {
        /*SL:204*/super.setFont(a1);
        /*SL:205*/this.setupBoldItalicIDs();
    }
    
    @Override
    public void setAntiAlias(final boolean a1) {
        /*SL:209*/super.setAntiAlias(a1);
        /*SL:210*/this.setupBoldItalicIDs();
    }
    
    @Override
    public void setFractionalMetrics(final boolean a1) {
        /*SL:214*/super.setFractionalMetrics(a1);
        /*SL:215*/this.setupBoldItalicIDs();
    }
    
    private void setupBoldItalicIDs() {
        /*SL:219*/this.texBold = this.setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
        /*SL:220*/this.texItalic = this.setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
        /*SL:221*/this.texItalicBold = this.setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
    }
    
    private void drawLine(final double a1, final double a2, final double a3, final double a4, final float a5) {
        /*SL:225*/GL11.glDisable(3553);
        /*SL:226*/GL11.glLineWidth(a5);
        /*SL:227*/GL11.glBegin(1);
        /*SL:228*/GL11.glVertex2d(a1, a2);
        /*SL:229*/GL11.glVertex2d(a3, a4);
        /*SL:230*/GL11.glEnd();
        /*SL:231*/GL11.glEnable(3553);
    }
    
    public List<String> wrapWords(final String v-9, final double v-8) {
        final List list = /*EL:235*/new ArrayList();
        /*SL:236*/if (this.getStringWidth(v-9) > v-8) {
            final String[] split = /*EL:237*/v-9.split(" ");
            String s = /*EL:238*/"";
            char c = /*EL:239*/'\uffff';
            /*SL:241*/for (final String v1 : split) {
                /*SL:242*/for (char a2 = 0; a2 < v1.toCharArray().length; ++a2) {
                    /*SL:243*/a2 = v1.toCharArray()[a2];
                    /*SL:245*/if (a2 == '�' && a2 < v1.toCharArray().length - 1) {
                        /*SL:246*/c = v1.toCharArray()[a2 + 1];
                    }
                }
                /*SL:249*/if (this.getStringWidth(s + v1 + " ") < v-8) {
                    /*SL:250*/s = s + v1 + " ";
                }
                else {
                    /*SL:252*/list.add(s);
                    /*SL:253*/s = "�" + c + v1 + " ";
                }
            }
            /*SL:256*/if (s.length() > 0) {
                if (this.getStringWidth(s) < v-8) {
                    /*SL:257*/list.add("�" + c + s + " ");
                    /*SL:258*/s = "";
                }
                else {
                    /*SL:260*/for (final String s2 : this.formatString(s, v-8)) {
                        /*SL:261*/list.add(s2);
                    }
                }
            }
        }
        else {
            /*SL:264*/list.add(v-9);
        }
        /*SL:266*/return (List<String>)list;
    }
    
    public List<String> formatString(final String v2, final double v3) {
        final List v4 = /*EL:270*/new ArrayList();
        String v5 = /*EL:271*/"";
        char v6 = /*EL:272*/'\uffff';
        final char[] v7 = /*EL:273*/v2.toCharArray();
        /*SL:274*/for (char a2 = 0; a2 < v7.length; ++a2) {
            /*SL:275*/a2 = v7[a2];
            /*SL:277*/if (a2 == '�' && a2 < v7.length - 1) {
                /*SL:278*/v6 = v7[a2 + 1];
            }
            /*SL:281*/if (this.getStringWidth(v5 + a2) < v3) {
                /*SL:282*/v5 += a2;
            }
            else {
                /*SL:284*/v4.add(v5);
                /*SL:285*/v5 = "�" + v6 + a2;
            }
        }
        /*SL:289*/if (v5.length() > 0) {
            /*SL:290*/v4.add(v5);
        }
        /*SL:293*/return (List<String>)v4;
    }
    
    private void setupMinecraftColorcodes() {
        /*SL:297*/for (int v0 = 0; v0 < 32; ++v0) {
            final int v = /*EL:298*/(v0 >> 3 & 0x1) * 85;
            int v2 = /*EL:299*/(v0 >> 2 & 0x1) * 170 + v;
            int v3 = /*EL:300*/(v0 >> 1 & 0x1) * 170 + v;
            int v4 = /*EL:301*/(v0 >> 0 & 0x1) * 170 + v;
            /*SL:303*/if (v0 == 6) {
                /*SL:304*/v2 += 85;
            }
            /*SL:307*/if (v0 >= 16) {
                /*SL:308*/v2 /= 4;
                /*SL:309*/v3 /= 4;
                /*SL:310*/v4 /= 4;
            }
            /*SL:313*/this.colorCode[v0] = ((v2 & 0xFF) << 16 | (v3 & 0xFF) << 8 | (v4 & 0xFF));
        }
    }
}
