package me.dev.legacy.impl.gui.components.items;

import me.dev.legacy.api.AbstractModule;

public class Item extends AbstractModule
{
    protected float x;
    protected float y;
    protected int width;
    protected int height;
    private boolean hidden;
    
    public Item(final String a1) {
        super(a1);
    }
    
    public void setLocation(final float a1, final float a2) {
        /*SL:18*/this.x = a1;
        /*SL:19*/this.y = a2;
    }
    
    public void drawScreen(final int a1, final int a2, final float a3) {
    }
    
    public void mouseClicked(final int a1, final int a2, final int a3) {
    }
    
    public void mouseReleased(final int a1, final int a2, final int a3) {
    }
    
    public void update() {
    }
    
    public void onKeyTyped(final char a1, final int a2) {
    }
    
    public float getX() {
        /*SL:38*/return this.x;
    }
    
    public float getY() {
        /*SL:42*/return this.y;
    }
    
    public int getWidth() {
        /*SL:46*/return this.width;
    }
    
    public void setWidth(final int a1) {
        /*SL:50*/this.width = a1;
    }
    
    public int getHeight() {
        /*SL:54*/return this.height;
    }
    
    public void setHeight(final int a1) {
        /*SL:58*/this.height = a1;
    }
    
    public boolean isHidden() {
        /*SL:62*/return this.hidden;
    }
    
    public boolean setHidden(final boolean a1) {
        /*SL:67*/return this.hidden = a1;
    }
}
