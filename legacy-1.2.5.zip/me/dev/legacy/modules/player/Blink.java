package me.dev.legacy.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketClientStatus;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import me.dev.legacy.api.AbstractModule;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import java.util.Queue;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Blink extends Module
{
    public Setting<Boolean> cPacketPlayer;
    public Setting<Mode> autoOff;
    public Setting<Integer> timeLimit;
    public Setting<Integer> packetLimit;
    public Setting<Float> distance;
    private Timer timer;
    private Queue<Packet<?>> packets;
    private EntityOtherPlayerMP entity;
    private int packetsCanceled;
    private BlockPos startPos;
    private static Blink INSTANCE;
    
    public Blink() {
        super("Blink", "Fake lag.", Category.PLAYER, true, false, false);
        this.cPacketPlayer = (Setting<Boolean>)this.register(new Setting("CPacketPlayer", (T)true));
        this.autoOff = (Setting<Mode>)this.register(new Setting("AutoOff", (T)Mode.MANUAL));
        this.timeLimit = (Setting<Integer>)this.register(new Setting("Time", (T)20, (T)1, (T)500, a1 -> this.autoOff.getValue() == Mode.TIME));
        this.packetLimit = (Setting<Integer>)this.register(new Setting("Packets", (T)20, (T)1, (T)500, a1 -> this.autoOff.getValue() == Mode.PACKETS));
        this.distance = (Setting<Float>)this.register(new Setting("Distance", (T)10.0f, (T)1.0f, (T)100.0f, a1 -> this.autoOff.getValue() == Mode.DISTANCE));
        this.timer = new Timer();
        this.packets = new ConcurrentLinkedQueue<Packet<?>>();
        this.packetsCanceled = 0;
        this.startPos = null;
        this.setInstance();
    }
    
    private void setInstance() {
        Blink.INSTANCE = /*EL:43*/this;
    }
    
    public static Blink getInstance() {
        /*SL:47*/if (Blink.INSTANCE == null) {
            Blink.INSTANCE = /*EL:48*/new Blink();
        }
        /*SL:50*/return Blink.INSTANCE;
    }
    
    @Override
    public void onEnable() {
        /*SL:55*/if (!AbstractModule.fullNullCheck()) {
            /*SL:56*/(this.entity = new EntityOtherPlayerMP((World)Blink.mc.field_71441_e, Blink.mc.field_71449_j.func_148256_e())).func_82149_j((Entity)Blink.mc.field_71439_g);
            /*SL:58*/this.entity.field_70177_z = Blink.mc.field_71439_g.field_70177_z;
            /*SL:59*/this.entity.field_70759_as = Blink.mc.field_71439_g.field_70759_as;
            /*SL:60*/this.entity.field_71071_by.func_70455_b(Blink.mc.field_71439_g.field_71071_by);
            Blink.mc.field_71441_e.func_73027_a(/*EL:61*/6942069, (Entity)this.entity);
            /*SL:62*/this.startPos = Blink.mc.field_71439_g.func_180425_c();
        }
        else {
            /*SL:64*/this.disable();
        }
        /*SL:66*/this.packetsCanceled = 0;
        /*SL:67*/this.timer.reset();
    }
    
    @Override
    public void onUpdate() {
        /*SL:72*/if (AbstractModule.nullCheck() || (this.autoOff.getValue() == Mode.TIME && this.timer.passedS(this.timeLimit.getValue())) || (this.autoOff.getValue() == Mode.DISTANCE && this.startPos != null && Blink.mc.field_71439_g.func_174818_b(this.startPos) >= MathUtil.square(this.distance.getValue())) || (this.autoOff.getValue() == Mode.PACKETS && this.packetsCanceled >= this.packetLimit.getValue())) {
            /*SL:73*/this.disable();
        }
    }
    
    @Override
    public void onLogout() {
        /*SL:79*/if (this.isOn()) {
            /*SL:80*/this.disable();
        }
    }
    
    @SubscribeEvent
    public void onSendPacket(final PacketEvent.Send v2) {
        /*SL:86*/if (v2.getStage() == 0 && Blink.mc.field_71441_e != null && !Blink.mc.func_71356_B()) {
            final Object a1 = /*EL:87*/v2.getPacket();
            /*SL:88*/if (this.cPacketPlayer.getValue() && a1 instanceof CPacketPlayer) {
                /*SL:89*/v2.setCanceled(true);
                /*SL:90*/this.packets.add((Packet<?>)a1);
                /*SL:91*/++this.packetsCanceled;
            }
            /*SL:93*/if (!this.cPacketPlayer.getValue()) {
                /*SL:94*/if (a1 instanceof CPacketChatMessage || a1 instanceof CPacketConfirmTeleport || a1 instanceof CPacketKeepAlive || a1 instanceof CPacketTabComplete || a1 instanceof CPacketClientStatus) {
                    /*SL:95*/return;
                }
                /*SL:97*/this.packets.add((Packet<?>)a1);
                /*SL:98*/v2.setCanceled(true);
                /*SL:99*/++this.packetsCanceled;
            }
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:106*/if (!AbstractModule.fullNullCheck()) {
            Blink.mc.field_71441_e.func_72900_e(/*EL:107*/(Entity)this.entity);
            /*SL:108*/while (!this.packets.isEmpty()) {
                Blink.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:109*/(Packet)this.packets.poll());
            }
        }
        /*SL:112*/this.startPos = null;
    }
    
    static {
        Blink.INSTANCE = new Blink();
    }
    
    public enum Mode
    {
        MANUAL, 
        TIME, 
        DISTANCE, 
        PACKETS;
    }
}
