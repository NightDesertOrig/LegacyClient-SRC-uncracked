package me.dev.legacy.modules.player;

import net.minecraft.item.Item;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemExpBottle;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class FastPlace extends Module
{
    Setting<Boolean> xp;
    Setting<Boolean> crystals;
    Setting<Boolean> everything;
    
    public FastPlace() {
        super("FastPlace", "Fast place items.", Category.PLAYER, true, false, false);
        this.xp = (Setting<Boolean>)this.register(new Setting("XP", (T)true));
        this.crystals = (Setting<Boolean>)this.register(new Setting("Crystals", (T)true));
        this.everything = (Setting<Boolean>)this.register(new Setting("Everything", (T)false));
    }
    
    @Override
    public void onUpdate() {
        final Item v1 = FastPlace.mc.field_71439_g.func_184614_ca().func_77973_b();
        final Item v2 = FastPlace.mc.field_71439_g.func_184592_cb().func_77973_b();
        final boolean v3 = /*EL:23*/v1 instanceof ItemExpBottle;
        final boolean v4 = /*EL:24*/v2 instanceof ItemExpBottle;
        final boolean v5 = /*EL:25*/v1 instanceof ItemEndCrystal;
        final boolean v6 = /*EL:26*/v2 instanceof ItemEndCrystal;
        /*SL:28*/if ((v3 | v4) && this.xp.getValue()) {
            FastPlace.mc.field_71467_ac = /*EL:29*/0;
        }
        /*SL:32*/if ((v5 | v6) && this.crystals.getValue()) {
            FastPlace.mc.field_71467_ac = /*EL:33*/0;
        }
        /*SL:36*/if (this.everything.getValue()) {
            FastPlace.mc.field_71467_ac = /*EL:37*/0;
        }
    }
}
