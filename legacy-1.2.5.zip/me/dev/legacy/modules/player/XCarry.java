package me.dev.legacy.modules.player;

import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.util.Util;
import me.dev.legacy.api.util.ReflectionUtil;
import me.dev.legacy.impl.gui.LegacyGui;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import me.dev.legacy.impl.command.Command;
import me.dev.legacy.api.event.ClientEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketCloseWindow;
import me.dev.legacy.api.AbstractModule;
import java.util.Iterator;
import net.minecraft.inventory.Slot;
import org.lwjgl.input.Mouse;
import org.lwjgl.input.Keyboard;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.List;
import me.dev.legacy.api.util.InventoryUtil;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.gui.inventory.GuiInventory;
import me.dev.legacy.impl.setting.Bind;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class XCarry extends Module
{
    private final Setting<Boolean> simpleMode;
    private final Setting<Bind> autoStore;
    private final Setting<Integer> obbySlot;
    private final Setting<Integer> slot1;
    private final Setting<Integer> slot2;
    private final Setting<Integer> slot3;
    private final Setting<Integer> tasks;
    private final Setting<Boolean> store;
    private final Setting<Boolean> shiftClicker;
    private final Setting<Boolean> withShift;
    private final Setting<Bind> keyBind;
    private static XCarry INSTANCE;
    private GuiInventory openedGui;
    private final AtomicBoolean guiNeedsClose;
    private boolean guiCloseGuard;
    private boolean autoDuelOn;
    private final Queue<InventoryUtil.Task> taskList;
    private boolean obbySlotDone;
    private boolean slot1done;
    private boolean slot2done;
    private boolean slot3done;
    private List<Integer> doneSlots;
    
    public XCarry() {
        super("XCarry", "Uses the crafting inventory for storage", Category.PLAYER, true, false, false);
        this.simpleMode = (Setting<Boolean>)this.register(new Setting("Simple", (T)false));
        this.autoStore = (Setting<Bind>)this.register(new Setting("AutoDuel", (T)new Bind(-1)));
        this.obbySlot = (Setting<Integer>)this.register(new Setting("ObbySlot", (T)2, (T)1, (T)9, a1 -> this.autoStore.getValue().getKey() != -1));
        this.slot1 = (Setting<Integer>)this.register(new Setting("Slot1", (T)22, (T)9, (T)44, a1 -> this.autoStore.getValue().getKey() != -1));
        this.slot2 = (Setting<Integer>)this.register(new Setting("Slot2", (T)23, (T)9, (T)44, a1 -> this.autoStore.getValue().getKey() != -1));
        this.slot3 = (Setting<Integer>)this.register(new Setting("Slot3", (T)24, (T)9, (T)44, a1 -> this.autoStore.getValue().getKey() != -1));
        this.tasks = (Setting<Integer>)this.register(new Setting("Actions", (T)3, (T)1, (T)12, a1 -> this.autoStore.getValue().getKey() != -1));
        this.store = (Setting<Boolean>)this.register(new Setting("Store", (T)false));
        this.shiftClicker = (Setting<Boolean>)this.register(new Setting("ShiftClick", (T)false));
        this.withShift = (Setting<Boolean>)this.register(new Setting("WithShift", (T)true, a1 -> this.shiftClicker.getValue()));
        this.keyBind = (Setting<Bind>)this.register(new Setting("ShiftBind", (T)new Bind(-1), a1 -> this.shiftClicker.getValue()));
        this.openedGui = null;
        this.guiNeedsClose = new AtomicBoolean(false);
        this.guiCloseGuard = false;
        this.autoDuelOn = false;
        this.taskList = new ConcurrentLinkedQueue<InventoryUtil.Task>();
        this.obbySlotDone = false;
        this.slot1done = false;
        this.slot2done = false;
        this.slot3done = false;
        this.doneSlots = new ArrayList<Integer>();
        this.setInstance();
    }
    
    private void setInstance() {
        XCarry.INSTANCE = /*EL:64*/this;
    }
    
    public static XCarry getInstance() {
        /*SL:68*/if (XCarry.INSTANCE == null) {
            XCarry.INSTANCE = /*EL:69*/new XCarry();
        }
        /*SL:71*/return XCarry.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        /*SL:76*/if (this.shiftClicker.getValue() && XCarry.mc.field_71462_r instanceof GuiInventory) {
            final boolean b2;
            final boolean b = /*EL:79*/b2 = (this.keyBind.getValue().getKey() != -1 && Keyboard.isKeyDown(this.keyBind.getValue().getKey()) && !Keyboard.isKeyDown(42));
            final Slot slotUnderMouse;
            /*SL:80*/if (((Keyboard.isKeyDown(42) && this.withShift.getValue()) || b) && Mouse.isButtonDown(0) && (slotUnderMouse = ((GuiInventory)XCarry.mc.field_71462_r).getSlotUnderMouse()) != null && InventoryUtil.getEmptyXCarry() != -1) {
                final int field_75222_d = /*EL:81*/slotUnderMouse.field_75222_d;
                /*SL:82*/if (field_75222_d > 4 && b) {
                    /*SL:83*/this.taskList.add(new InventoryUtil.Task(field_75222_d));
                    /*SL:84*/this.taskList.add(new InventoryUtil.Task(InventoryUtil.getEmptyXCarry()));
                }
                else/*SL:85*/ if (field_75222_d > 4 && this.withShift.getValue()) {
                    boolean b3 = /*EL:86*/true;
                    boolean b4 = /*EL:87*/true;
                    /*SL:88*/for (final int v1 : InventoryUtil.findEmptySlots(false)) {
                        /*SL:89*/if (v1 > 4 && v1 < 36) {
                            /*SL:90*/b4 = false;
                        }
                        else {
                            /*SL:93*/if (v1 <= 35) {
                                continue;
                            }
                            if (v1 >= 45) {
                                continue;
                            }
                            /*SL:94*/b3 = false;
                        }
                    }
                    /*SL:96*/if (field_75222_d > 35 && field_75222_d < 45) {
                        /*SL:97*/if (b4) {
                            /*SL:98*/this.taskList.add(new InventoryUtil.Task(field_75222_d));
                            /*SL:99*/this.taskList.add(new InventoryUtil.Task(InventoryUtil.getEmptyXCarry()));
                        }
                    }
                    else/*SL:101*/ if (b3) {
                        /*SL:102*/this.taskList.add(new InventoryUtil.Task(field_75222_d));
                        /*SL:103*/this.taskList.add(new InventoryUtil.Task(InventoryUtil.getEmptyXCarry()));
                    }
                }
            }
        }
        /*SL:108*/if (this.autoDuelOn) {
            /*SL:109*/this.doneSlots = new ArrayList<Integer>();
            /*SL:110*/if (InventoryUtil.getEmptyXCarry() == -1 || (this.obbySlotDone && this.slot1done && this.slot2done && this.slot3done)) {
                /*SL:111*/this.autoDuelOn = false;
            }
            /*SL:113*/if (this.autoDuelOn) {
                /*SL:114*/if (!this.obbySlotDone && !XCarry.mc.field_71439_g.field_71071_by.func_70301_a(this.obbySlot.getValue() - 1).field_190928_g) {
                    /*SL:115*/this.addTasks(36 + this.obbySlot.getValue() - 1);
                }
                /*SL:117*/this.obbySlotDone = true;
                /*SL:118*/if (!this.slot1done && !XCarry.mc.field_71439_g.field_71069_bz.field_75151_b.get(this.slot1.getValue()).func_75211_c().field_190928_g) {
                    /*SL:119*/this.addTasks(this.slot1.getValue());
                }
                /*SL:121*/this.slot1done = true;
                /*SL:122*/if (!this.slot2done && !XCarry.mc.field_71439_g.field_71069_bz.field_75151_b.get(this.slot2.getValue()).func_75211_c().field_190928_g) {
                    /*SL:123*/this.addTasks(this.slot2.getValue());
                }
                /*SL:125*/this.slot2done = true;
                /*SL:126*/if (!this.slot3done && !XCarry.mc.field_71439_g.field_71069_bz.field_75151_b.get(this.slot3.getValue()).func_75211_c().field_190928_g) {
                    /*SL:127*/this.addTasks(this.slot3.getValue());
                }
                /*SL:129*/this.slot3done = true;
            }
        }
        else {
            /*SL:132*/this.obbySlotDone = false;
            /*SL:133*/this.slot1done = false;
            /*SL:134*/this.slot2done = false;
            /*SL:135*/this.slot3done = false;
        }
        /*SL:137*/if (!this.taskList.isEmpty()) {
            /*SL:138*/for (int i = 0; i < this.tasks.getValue(); ++i) {
                final InventoryUtil.Task task = /*EL:139*/this.taskList.poll();
                /*SL:140*/if (task != null) {
                    /*SL:141*/task.run();
                }
            }
        }
    }
    
    private void addTasks(final int v2) {
        /*SL:147*/if (InventoryUtil.getEmptyXCarry() != -1) {
            int a1 = /*EL:148*/InventoryUtil.getEmptyXCarry();
            /*SL:149*/if ((this.doneSlots.contains(a1) || !InventoryUtil.isSlotEmpty(a1)) && (this.doneSlots.contains(++a1) || !InventoryUtil.isSlotEmpty(a1)) && (this.doneSlots.contains(++a1) || !InventoryUtil.isSlotEmpty(a1)) && (this.doneSlots.contains(++a1) || !InventoryUtil.isSlotEmpty(a1))) {
                /*SL:150*/return;
            }
            /*SL:152*/if (a1 > 4) {
                /*SL:153*/return;
            }
            /*SL:155*/this.doneSlots.add(a1);
            /*SL:156*/this.taskList.add(new InventoryUtil.Task(v2));
            /*SL:157*/this.taskList.add(new InventoryUtil.Task(a1));
            /*SL:158*/this.taskList.add(new InventoryUtil.Task());
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:164*/if (!AbstractModule.fullNullCheck()) {
            /*SL:165*/if (!this.simpleMode.getValue()) {
                /*SL:166*/this.closeGui();
                /*SL:167*/this.close();
            }
            else {
                XCarry.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:169*/(Packet)new CPacketCloseWindow(XCarry.mc.field_71439_g.field_71069_bz.field_75152_c));
            }
        }
    }
    
    @Override
    public void onLogout() {
        /*SL:176*/this.onDisable();
    }
    
    @SubscribeEvent
    public void onCloseGuiScreen(final PacketEvent.Send v2) {
        /*SL:181*/if (this.simpleMode.getValue() && v2.getPacket() instanceof CPacketCloseWindow) {
            final CPacketCloseWindow a1 = /*EL:182*/(CPacketCloseWindow)v2.getPacket();
            /*SL:183*/if (a1.field_149556_a == XCarry.mc.field_71439_g.field_71069_bz.field_75152_c) {
                /*SL:184*/v2.setCanceled(true);
            }
        }
    }
    
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGuiOpen(final GuiOpenEvent a1) {
        /*SL:191*/if (!this.simpleMode.getValue()) {
            /*SL:192*/if (this.guiCloseGuard) {
                /*SL:193*/a1.setCanceled(true);
            }
            else/*SL:194*/ if (a1.getGui() instanceof GuiInventory) {
                /*SL:196*/a1.setGui((GuiScreen)(this.openedGui = this.createGuiWrapper((GuiInventory)a1.getGui())));
                /*SL:197*/this.guiNeedsClose.set(false);
            }
        }
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent v-1) {
        /*SL:204*/if (v-1.getStage() == 2 && v-1.getSetting() != null && v-1.getSetting().getFeature() != null && v-1.getSetting().getFeature().equals(this)) {
            final Setting a1 = /*EL:205*/v-1.getSetting();
            final String v1 = /*EL:206*/v-1.getSetting().getName();
            /*SL:207*/if (a1.equals(this.simpleMode) && a1.getPlannedValue() != a1.getValue()) {
                /*SL:208*/this.disable();
            }
            else/*SL:209*/ if (v1.equalsIgnoreCase("Store")) {
                /*SL:210*/v-1.setCanceled(true);
                /*SL:211*/this.autoDuelOn = !this.autoDuelOn;
                /*SL:212*/Command.sendMessage("<XCarry> �aAutostoring...");
            }
        }
    }
    
    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent a1) {
        /*SL:219*/if (Keyboard.getEventKeyState() && !(XCarry.mc.field_71462_r instanceof LegacyGui) && this.autoStore.getValue().getKey() == Keyboard.getEventKey()) {
            /*SL:220*/this.autoDuelOn = !this.autoDuelOn;
            /*SL:221*/Command.sendMessage("<XCarry> �aAutostoring...");
        }
    }
    
    private void close() {
        /*SL:226*/this.openedGui = null;
        /*SL:227*/this.guiNeedsClose.set(false);
        /*SL:228*/this.guiCloseGuard = false;
    }
    
    private void closeGui() {
        /*SL:232*/if (this.guiNeedsClose.compareAndSet(true, false) && !AbstractModule.fullNullCheck()) {
            /*SL:233*/this.guiCloseGuard = true;
            XCarry.mc.field_71439_g.func_71053_j();
            /*SL:235*/if (this.openedGui != null) {
                /*SL:236*/this.openedGui.func_146281_b();
                /*SL:237*/this.openedGui = null;
            }
            /*SL:239*/this.guiCloseGuard = false;
        }
    }
    
    private GuiInventory createGuiWrapper(final GuiInventory v0) {
        try {
            final GuiInventoryWrapper a1 = /*EL:245*/new GuiInventoryWrapper();
            /*SL:246*/ReflectionUtil.<GuiInventory, GuiInventoryWrapper>copyOf(v0, a1);
            /*SL:247*/return a1;
        }
        catch (IllegalAccessException | NoSuchFieldException v) {
            /*SL:250*/v.printStackTrace();
            /*SL:251*/return null;
        }
    }
    
    static {
        XCarry.INSTANCE = new XCarry();
    }
    
    private class GuiInventoryWrapper extends GuiInventory
    {
        GuiInventoryWrapper() {
            super((EntityPlayer)Util.mc.field_71439_g);
        }
        
        protected void func_73869_a(final char a1, final int a2) throws IOException {
            /*SL:262*/if (XCarry.this.isEnabled() && (a2 == 1 || this.field_146297_k.field_71474_y.field_151445_Q.isActiveAndMatches(a2))) {
                /*SL:263*/XCarry.this.guiNeedsClose.set(true);
                /*SL:264*/this.field_146297_k.func_147108_a((GuiScreen)null);
            }
            else {
                /*SL:266*/super.func_73869_a(a1, a2);
            }
        }
        
        public void func_146281_b() {
            /*SL:271*/if (XCarry.this.guiCloseGuard || !XCarry.this.isEnabled()) {
                /*SL:272*/super.func_146281_b();
            }
        }
    }
}
