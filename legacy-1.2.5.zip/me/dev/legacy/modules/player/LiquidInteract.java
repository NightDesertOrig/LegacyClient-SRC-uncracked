package me.dev.legacy.modules.player;

import me.dev.legacy.modules.Module;

public class LiquidInteract extends Module
{
    private static LiquidInteract INSTANCE;
    
    public LiquidInteract() {
        super("LiquidInteract", "Interact with liquids", Category.PLAYER, false, false, false);
        this.setInstance();
    }
    
    public static LiquidInteract getInstance() {
        /*SL:14*/if (LiquidInteract.INSTANCE == null) {
            LiquidInteract.INSTANCE = /*EL:15*/new LiquidInteract();
        }
        /*SL:17*/return LiquidInteract.INSTANCE;
    }
    
    private void setInstance() {
        LiquidInteract.INSTANCE = /*EL:21*/this;
    }
    
    static {
        LiquidInteract.INSTANCE = new LiquidInteract();
    }
}
