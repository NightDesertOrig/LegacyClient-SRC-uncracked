package me.dev.legacy.modules.player;

import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Reach extends Module
{
    public Setting<Boolean> override;
    public Setting<Float> add;
    public Setting<Float> reach;
    private static Reach INSTANCE;
    
    public Reach() {
        super("Reach", "Extends your block reach", Category.PLAYER, true, false, false);
        this.override = (Setting<Boolean>)this.register(new Setting("Override", (T)false));
        this.add = (Setting<Float>)this.register(new Setting("Add", (T)3.0f, a1 -> !this.override.getValue()));
        this.reach = (Setting<Float>)this.register(new Setting("Reach", (T)6.0f, a1 -> this.override.getValue()));
        this.setInstance();
    }
    
    private void setInstance() {
        Reach.INSTANCE = /*EL:19*/this;
    }
    
    public static Reach getInstance() {
        /*SL:23*/if (Reach.INSTANCE == null) {
            Reach.INSTANCE = /*EL:24*/new Reach();
        }
        /*SL:26*/return Reach.INSTANCE;
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:31*/return this.override.getValue() ? this.reach.getValue().toString() : this.add.getValue().toString();
    }
    
    static {
        Reach.INSTANCE = new Reach();
    }
}
