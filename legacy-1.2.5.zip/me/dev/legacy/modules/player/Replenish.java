package me.dev.legacy.modules.player;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import me.dev.legacy.api.AbstractModule;
import net.minecraft.item.Item;
import java.util.ArrayList;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Replenish extends Module
{
    private final Setting<Integer> delay;
    private final Setting<Integer> gapStack;
    private final Setting<Integer> xpStackAt;
    private final Timer timer;
    private final ArrayList<Item> Hotbar;
    
    public Replenish() {
        super("Replenish", "Replenishes your hotbar", Category.PLAYER, false, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)10));
        this.gapStack = (Setting<Integer>)this.register(new Setting("GapStack", (T)32, (T)1, (T)64));
        this.xpStackAt = (Setting<Integer>)this.register(new Setting("XPStack", (T)32, (T)1, (T)64));
        this.timer = new Timer();
        this.Hotbar = new ArrayList<Item>();
    }
    
    @Override
    public void onEnable() {
        /*SL:26*/if (AbstractModule.fullNullCheck()) {
            /*SL:27*/return;
        }
        /*SL:29*/this.Hotbar.clear();
        /*SL:30*/for (int v0 = 0; v0 < 9; ++v0) {
            final ItemStack v = Replenish.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:31*/v0);
            /*SL:32*/if (!v.func_190926_b() && !this.Hotbar.contains(v.func_77973_b())) {
                /*SL:33*/this.Hotbar.add(v.func_77973_b());
            }
            else {
                /*SL:36*/this.Hotbar.add(Items.field_190931_a);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:42*/if (Replenish.mc.field_71462_r != null) {
            /*SL:43*/return;
        }
        /*SL:45*/if (!this.timer.passedMs(this.delay.getValue() * 1000)) {
            /*SL:46*/return;
        }
        /*SL:48*/for (int v1 = 0; v1 < 9; ++v1) {
            /*SL:49*/if (this.RefillSlotIfNeed(v1)) {
                /*SL:50*/this.timer.reset();
                /*SL:51*/return;
            }
        }
    }
    
    private boolean RefillSlotIfNeed(final int v-1) {
        final ItemStack v0 = Replenish.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:56*/v-1);
        /*SL:57*/if (v0.func_190926_b() || v0.func_77973_b() == Items.field_190931_a) {
            /*SL:58*/return false;
        }
        /*SL:60*/if (!v0.func_77985_e()) {
            /*SL:61*/return false;
        }
        /*SL:63*/if (v0.func_190916_E() >= v0.func_77976_d()) {
            /*SL:64*/return false;
        }
        /*SL:66*/if (v0.func_77973_b().equals(Items.field_151153_ao) && v0.func_190916_E() >= this.gapStack.getValue()) {
            /*SL:67*/return false;
        }
        /*SL:69*/if (v0.func_77973_b().equals(Items.field_151062_by) && v0.func_190916_E() > this.xpStackAt.getValue()) {
            /*SL:70*/return false;
        }
        /*SL:72*/for (int v = 9; v < 36; ++v) {
            final ItemStack a1 = Replenish.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:73*/v);
            if (/*EL:74*/!a1.func_190926_b() && this.CanItemBeMergedWith(v0, a1)) {
                Replenish.mc.field_71442_b.func_187098_a(Replenish.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:75*/v, 0, ClickType.QUICK_MOVE, (EntityPlayer)Replenish.mc.field_71439_g);
                Replenish.mc.field_71442_b.func_78765_e();
                /*SL:77*/return true;
            }
        }
        /*SL:79*/return false;
    }
    
    private boolean CanItemBeMergedWith(final ItemStack a1, final ItemStack a2) {
        /*SL:83*/return a1.func_77973_b() == a2.func_77973_b() && a1.func_82833_r().equals(a2.func_82833_r());
    }
}
