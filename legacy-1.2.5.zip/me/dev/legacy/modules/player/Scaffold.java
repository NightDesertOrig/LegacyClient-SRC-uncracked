package me.dev.legacy.modules.player;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumFacing;
import me.dev.legacy.api.util.BlockUtil;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.modules.Module;

public class Scaffold extends Module
{
    private final Timer timer;
    public Setting<Boolean> rotation;
    
    public Scaffold() {
        super("Scaffold", "Places Blocks underneath you.", Category.PLAYER, true, false, false);
        this.timer = new Timer();
        this.rotation = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
    }
    
    @Override
    public void onEnable() {
        /*SL:34*/this.timer.reset();
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerPost(final UpdateWalkingPlayerEvent a1) {
        /*SL:40*/if (this.isOff() || AbstractModule.fullNullCheck() || a1.getStage() == 0) {
            /*SL:41*/return;
        }
        /*SL:43*/if (!Scaffold.mc.field_71474_y.field_74314_A.func_151470_d()) {
            /*SL:44*/this.timer.reset();
        }
        final BlockPos v1;
        /*SL:46*/if (BlockUtil.isScaffoldPos((v1 = EntityUtil.getPlayerPosWithEntity()).func_177982_a(0, -1, 0))) {
            /*SL:47*/if (BlockUtil.isValidBlock(v1.func_177982_a(0, -2, 0))) {
                /*SL:48*/this.place(v1.func_177982_a(0, -1, 0), EnumFacing.UP);
            }
            else/*SL:49*/ if (BlockUtil.isValidBlock(v1.func_177982_a(-1, -1, 0))) {
                /*SL:50*/this.place(v1.func_177982_a(0, -1, 0), EnumFacing.EAST);
            }
            else/*SL:51*/ if (BlockUtil.isValidBlock(v1.func_177982_a(1, -1, 0))) {
                /*SL:52*/this.place(v1.func_177982_a(0, -1, 0), EnumFacing.WEST);
            }
            else/*SL:53*/ if (BlockUtil.isValidBlock(v1.func_177982_a(0, -1, -1))) {
                /*SL:54*/this.place(v1.func_177982_a(0, -1, 0), EnumFacing.SOUTH);
            }
            else/*SL:55*/ if (BlockUtil.isValidBlock(v1.func_177982_a(0, -1, 1))) {
                /*SL:56*/this.place(v1.func_177982_a(0, -1, 0), EnumFacing.NORTH);
            }
            else/*SL:57*/ if (BlockUtil.isValidBlock(v1.func_177982_a(1, -1, 1))) {
                /*SL:58*/if (BlockUtil.isValidBlock(v1.func_177982_a(0, -1, 1))) {
                    /*SL:59*/this.place(v1.func_177982_a(0, -1, 1), EnumFacing.NORTH);
                }
                /*SL:61*/this.place(v1.func_177982_a(1, -1, 1), EnumFacing.EAST);
            }
            else/*SL:62*/ if (BlockUtil.isValidBlock(v1.func_177982_a(-1, -1, 1))) {
                /*SL:63*/if (BlockUtil.isValidBlock(v1.func_177982_a(-1, -1, 0))) {
                    /*SL:64*/this.place(v1.func_177982_a(0, -1, 1), EnumFacing.WEST);
                }
                /*SL:66*/this.place(v1.func_177982_a(-1, -1, 1), EnumFacing.SOUTH);
            }
            else/*SL:67*/ if (BlockUtil.isValidBlock(v1.func_177982_a(1, -1, 1))) {
                /*SL:68*/if (BlockUtil.isValidBlock(v1.func_177982_a(0, -1, 1))) {
                    /*SL:69*/this.place(v1.func_177982_a(0, -1, 1), EnumFacing.SOUTH);
                }
                /*SL:71*/this.place(v1.func_177982_a(1, -1, 1), EnumFacing.WEST);
            }
            else/*SL:72*/ if (BlockUtil.isValidBlock(v1.func_177982_a(1, -1, 1))) {
                /*SL:73*/if (BlockUtil.isValidBlock(v1.func_177982_a(0, -1, 1))) {
                    /*SL:74*/this.place(v1.func_177982_a(0, -1, 1), EnumFacing.EAST);
                }
                /*SL:76*/this.place(v1.func_177982_a(1, -1, 1), EnumFacing.NORTH);
            }
        }
    }
    
    public void place(final BlockPos v-1, final EnumFacing v0) {
        BlockPos v = /*EL:83*/v-1;
        /*SL:84*/if (v0 == EnumFacing.UP) {
            /*SL:85*/v = v.func_177982_a(0, -1, 0);
        }
        else/*SL:86*/ if (v0 == EnumFacing.NORTH) {
            /*SL:87*/v = v.func_177982_a(0, 0, 1);
        }
        else/*SL:88*/ if (v0 == EnumFacing.SOUTH) {
            /*SL:89*/v = v.func_177982_a(0, 0, -1);
        }
        else/*SL:90*/ if (v0 == EnumFacing.EAST) {
            /*SL:91*/v = v.func_177982_a(-1, 0, 0);
        }
        else/*SL:92*/ if (v0 == EnumFacing.WEST) {
            /*SL:93*/v = v.func_177982_a(1, 0, 0);
        }
        final int v2 = Scaffold.mc.field_71439_g.field_71071_by.field_70461_c;
        int v3 = /*EL:96*/-1;
        /*SL:97*/for (ItemStack a2 = (ItemStack)0; a2 < 9; ++a2) {
            /*SL:98*/a2 = Scaffold.mc.field_71439_g.field_71071_by.func_70301_a(a2);
            if (/*EL:99*/!InventoryUtil.isNull(a2) && a2.func_77973_b() instanceof ItemBlock && Block.func_149634_a(a2.func_77973_b()).func_176223_P().func_185913_b()) {
                /*SL:101*/v3 = a2;
                /*SL:102*/break;
            }
        }
        /*SL:104*/if (v3 == -1) {
            /*SL:105*/return;
        }
        boolean v4 = /*EL:107*/false;
        final Block v5;
        /*SL:108*/if (!Scaffold.mc.field_71439_g.func_70093_af() && BlockUtil.blackList.contains(v5 = Scaffold.mc.field_71441_e.func_180495_p(v).func_177230_c())) {
            Scaffold.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:109*/(Packet)new CPacketEntityAction((Entity)Scaffold.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            /*SL:110*/v4 = true;
        }
        /*SL:112*/if (!(Scaffold.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBlock)) {
            Scaffold.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:113*/(Packet)new CPacketHeldItemChange(v3));
            Scaffold.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:114*/v3;
            Scaffold.mc.field_71442_b.func_78765_e();
        }
        /*SL:117*/if (Scaffold.mc.field_71474_y.field_74314_A.func_151470_d()) {
            final EntityPlayerSP field_71439_g = Scaffold.mc.field_71439_g;
            /*SL:118*/field_71439_g.field_70159_w *= 0.3;
            final EntityPlayerSP field_71439_g2 = Scaffold.mc.field_71439_g;
            /*SL:119*/field_71439_g2.field_70179_y *= 0.3;
            Scaffold.mc.field_71439_g.func_70664_aZ();
            /*SL:121*/if (this.timer.passedMs(1500L)) {
                Scaffold.mc.field_71439_g.field_70181_x = /*EL:122*/-0.28;
                /*SL:123*/this.timer.reset();
            }
        }
        /*SL:126*/if (this.rotation.getValue()) {
            final float[] v6 = /*EL:127*/MathUtil.calcAngle(Scaffold.mc.field_71439_g.func_174824_e(Scaffold.mc.func_184121_ak()), new Vec3d((double)(v.func_177958_n() + 0.5f), (double)(v.func_177956_o() - 0.5f), (double)(v.func_177952_p() + 0.5f)));
            Scaffold.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:128*/(Packet)new CPacketPlayer.Rotation(v6[0], (float)MathHelper.func_180184_b((int)v6[1], 360), Scaffold.mc.field_71439_g.field_70122_E));
        }
        Scaffold.mc.field_71442_b.func_187099_a(Scaffold.mc.field_71439_g, Scaffold.mc.field_71441_e, /*EL:130*/v, v0, new Vec3d(0.5, 0.5, 0.5), EnumHand.MAIN_HAND);
        Scaffold.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        Scaffold.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:132*/(Packet)new CPacketHeldItemChange(v2));
        Scaffold.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:133*/v2;
        Scaffold.mc.field_71442_b.func_78765_e();
        /*SL:135*/if (v4) {
            Scaffold.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:136*/(Packet)new CPacketEntityAction((Entity)Scaffold.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
    }
}
