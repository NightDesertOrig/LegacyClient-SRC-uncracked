package me.dev.legacy.modules.movement;

import net.minecraft.init.Blocks;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class IceSpeed extends Module
{
    private Setting<Float> speed;
    private static IceSpeed INSTANCE;
    
    public IceSpeed() {
        super("IceSpeed", "Speeds you up on ice.", Category.MOVEMENT, false, false, false);
        this.speed = (Setting<Float>)this.register(new Setting("Speed", (T)1.0f, (T)0.5f, (T)1.5f));
        IceSpeed.INSTANCE = this;
    }
    
    public static IceSpeed getINSTANCE() {
        /*SL:17*/if (IceSpeed.INSTANCE == null) {
            IceSpeed.INSTANCE = /*EL:18*/new IceSpeed();
        }
        /*SL:20*/return IceSpeed.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        Blocks.field_150432_aD.field_149765_K = /*EL:25*/this.speed.getValue();
        Blocks.field_150403_cj.field_149765_K = /*EL:26*/this.speed.getValue();
        Blocks.field_185778_de.field_149765_K = /*EL:27*/this.speed.getValue();
    }
    
    @Override
    public void onDisable() {
        Blocks.field_150432_aD.field_149765_K = /*EL:32*/0.98f;
        Blocks.field_150403_cj.field_149765_K = /*EL:33*/0.98f;
        Blocks.field_185778_de.field_149765_K = /*EL:34*/0.98f;
    }
    
    static {
        IceSpeed.INSTANCE = new IceSpeed();
    }
}
