package me.dev.legacy.modules.movement;

import net.minecraft.entity.EntityLivingBase;
import me.dev.legacy.api.util.MathUtil;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.util.PlayerUtil;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Speed extends Module
{
    Setting<Mode> mode;
    Setting<Double> yPortSpeed;
    Setting<Boolean> step;
    Setting<Double> vanillaSpeed;
    private double playerSpeed;
    private final Timer timer;
    
    public Speed() {
        super("Speed", "YPort Speed.", Category.MOVEMENT, false, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.yPort));
        this.yPortSpeed = (Setting<Double>)this.register(new Setting("YPort Speed", (T)0.6, (T)0.5, (T)1.5, a1 -> this.mode.getValue() == Mode.yPort));
        this.step = (Setting<Boolean>)this.register(new Setting("Step", (T)true, a1 -> this.mode.getValue() == Mode.yPort));
        this.vanillaSpeed = (Setting<Double>)this.register(new Setting("Vanilla Speed", (T)1.0, (T)1.7, (T)10.0, a1 -> this.mode.getValue() == Mode.Vanilla));
        this.timer = new Timer();
    }
    
    @Override
    public void onEnable() {
        /*SL:31*/this.playerSpeed = PlayerUtil.getBaseMoveSpeed();
        /*SL:32*/if (this.step.getValue()) {
            /*SL:33*/if (AbstractModule.fullNullCheck()) {
                /*SL:34*/return;
            }
            Speed.mc.field_71439_g.field_70138_W = /*EL:36*/2.0f;
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:42*/EntityUtil.resetTimer();
        /*SL:43*/this.timer.reset();
        /*SL:44*/if (this.step.getValue()) {
            Speed.mc.field_71439_g.field_70138_W = /*EL:45*/0.6f;
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:51*/if (AbstractModule.nullCheck()) {
            /*SL:52*/this.disable();
            /*SL:53*/return;
        }
        /*SL:56*/if (this.mode.getValue() == Mode.Vanilla) {
            /*SL:57*/if (Speed.mc.field_71439_g == null || Speed.mc.field_71441_e == null) {
                /*SL:58*/return;
            }
            final double[] v1 = /*EL:60*/MathUtil.directionSpeed(this.vanillaSpeed.getValue() / 10.0);
            Speed.mc.field_71439_g.field_70159_w = /*EL:61*/v1[0];
            Speed.mc.field_71439_g.field_70179_y = /*EL:62*/v1[1];
        }
        /*SL:65*/if (this.mode.getValue() == Mode.yPort) {
            /*SL:66*/if (!PlayerUtil.isMoving((EntityLivingBase)Speed.mc.field_71439_g) || (Speed.mc.field_71439_g.func_70090_H() && Speed.mc.field_71439_g.func_180799_ab()) || Speed.mc.field_71439_g.field_70123_F) {
                /*SL:67*/return;
            }
            /*SL:69*/if (Speed.mc.field_71439_g.field_70122_E) {
                /*SL:70*/EntityUtil.setTimer(1.15f);
                Speed.mc.field_71439_g.func_70664_aZ();
                /*SL:72*/PlayerUtil.setSpeed((EntityLivingBase)Speed.mc.field_71439_g, PlayerUtil.getBaseMoveSpeed() + this.yPortSpeed.getValue() / 10.0);
            }
            else {
                Speed.mc.field_71439_g.field_70181_x = /*EL:74*/-1.0;
                /*SL:75*/EntityUtil.resetTimer();
            }
        }
    }
    
    public enum Mode
    {
        yPort, 
        Vanilla;
    }
}
