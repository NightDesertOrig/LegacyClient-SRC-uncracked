package me.dev.legacy.modules.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import java.util.ArrayList;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Anchor extends Module
{
    public Setting<Boolean> pull;
    public Setting<Integer> pitch;
    private final ArrayList<BlockPos> holes;
    int holeblocks;
    public static boolean AnchorING;
    private Vec3d Center;
    
    public Anchor() {
        super("Anchor", "Stops all movement if player is above a hole.", Category.MOVEMENT, false, false, false);
        this.pull = (Setting<Boolean>)this.register(new Setting("Pull", (T)true));
        this.pitch = (Setting<Integer>)this.register(new Setting("Pitch", (T)60, (T)0, (T)90));
        this.holes = new ArrayList<BlockPos>();
        this.Center = Vec3d.field_186680_a;
    }
    
    public boolean isBlockHole(final BlockPos a1) {
        /*SL:25*/this.holeblocks = 0;
        /*SL:26*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 3, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        /*SL:28*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 2, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        /*SL:30*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        /*SL:32*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 0, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        /*SL:34*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        /*SL:36*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        /*SL:38*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        /*SL:40*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        /*SL:42*/if (Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        /*SL:44*/return this.holeblocks >= 9;
    }
    
    public Vec3d GetCenter(final double a1, final double a2, final double a3) {
        final double v1 = /*EL:50*/Math.floor(a1) + 0.5;
        final double v2 = /*EL:51*/Math.floor(a2);
        final double v3 = /*EL:52*/Math.floor(a3) + 0.5;
        /*SL:54*/return new Vec3d(v1, v2, v3);
    }
    
    @SubscribeEvent
    @Override
    public void onUpdate() {
        /*SL:59*/if (Anchor.mc.field_71441_e == null) {
            /*SL:60*/return;
        }
        /*SL:62*/if (Anchor.mc.field_71439_g.field_70163_u < 0.0) {
            /*SL:63*/return;
        }
        /*SL:65*/if (Anchor.mc.field_71439_g.field_70125_A >= this.pitch.getValue()) {
            /*SL:67*/if (this.isBlockHole(this.getPlayerPos().func_177979_c(1)) || this.isBlockHole(this.getPlayerPos().func_177979_c(2)) || this.isBlockHole(this.getPlayerPos().func_177979_c(3)) || this.isBlockHole(this.getPlayerPos().func_177979_c(4))) {
                Anchor.AnchorING = /*EL:68*/true;
                /*SL:70*/if (!this.pull.getValue()) {
                    Anchor.mc.field_71439_g.field_70159_w = /*EL:71*/0.0;
                    Anchor.mc.field_71439_g.field_70179_y = /*EL:72*/0.0;
                }
                else {
                    /*SL:74*/this.Center = this.GetCenter(Anchor.mc.field_71439_g.field_70165_t, Anchor.mc.field_71439_g.field_70163_u, Anchor.mc.field_71439_g.field_70161_v);
                    final double abs = /*EL:75*/Math.abs(this.Center.field_72450_a - Anchor.mc.field_71439_g.field_70165_t);
                    final double abs2 = /*EL:76*/Math.abs(this.Center.field_72449_c - Anchor.mc.field_71439_g.field_70161_v);
                    /*SL:78*/if (abs <= 0.1 && abs2 <= 0.1) {
                        /*SL:79*/this.Center = Vec3d.field_186680_a;
                    }
                    else {
                        final double v1 = /*EL:82*/this.Center.field_72450_a - Anchor.mc.field_71439_g.field_70165_t;
                        final double v2 = /*EL:83*/this.Center.field_72449_c - Anchor.mc.field_71439_g.field_70161_v;
                        Anchor.mc.field_71439_g.field_70159_w = /*EL:85*/v1 / 2.0;
                        Anchor.mc.field_71439_g.field_70179_y = /*EL:86*/v2 / 2.0;
                    }
                }
            }
            else {
                Anchor.AnchorING = /*EL:89*/false;
            }
        }
    }
    
    @Override
    public void onDisable() {
        Anchor.AnchorING = /*EL:94*/false;
        /*SL:95*/this.holeblocks = 0;
    }
    
    public BlockPos getPlayerPos() {
        /*SL:99*/return new BlockPos(Math.floor(Anchor.mc.field_71439_g.field_70165_t), Math.floor(Anchor.mc.field_71439_g.field_70163_u), Math.floor(Anchor.mc.field_71439_g.field_70161_v));
    }
}
