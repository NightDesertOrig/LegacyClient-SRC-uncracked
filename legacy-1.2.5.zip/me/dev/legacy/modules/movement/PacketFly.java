package me.dev.legacy.modules.movement;

import me.dev.legacy.api.util.Timer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.api.AbstractModule;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import me.dev.legacy.api.event.events.move.PushEvent;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.event.events.move.MoveEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import java.util.concurrent.ConcurrentHashMap;
import io.netty.util.internal.ConcurrentSet;
import java.util.Map;
import net.minecraft.network.play.client.CPacketPlayer;
import java.util.Set;
import me.dev.legacy.modules.Module;

public class PacketFly extends Module
{
    private final Set<CPacketPlayer> packets;
    private final Map<Integer, IDtime> teleportmap;
    private int flightCounter;
    private int teleportID;
    private static PacketFly instance;
    private boolean setMove;
    private boolean nocliperino;
    
    public PacketFly() {
        super("PacketFly", "WAN BLOCK BLYAT!", Category.MOVEMENT, true, false, false);
        this.flightCounter = 0;
        this.teleportID = 0;
        this.setMove = false;
        this.nocliperino = true;
        this.packets = (Set<CPacketPlayer>)new ConcurrentSet();
        this.teleportmap = new ConcurrentHashMap<Integer, IDtime>();
        PacketFly.instance = this;
    }
    
    public static PacketFly getInstance() {
        /*SL:46*/if (PacketFly.instance == null) {
            PacketFly.instance = /*EL:47*/new PacketFly();
        }
        /*SL:49*/return PacketFly.instance;
    }
    
    @Override
    public void onToggle() {
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent v-7) {
        /*SL:58*/if (v-7.getStage() == 1) {
            /*SL:59*/return;
        }
        PacketFly.mc.field_71439_g.func_70016_h(/*EL:61*/0.0, 0.0, 0.0);
        final boolean checkHitBoxes = /*EL:62*/this.checkHitBoxes();
        double n = (PacketFly.mc.field_71439_g.field_71158_b.field_78901_c && /*EL:63*/(checkHitBoxes || !EntityUtil.isMoving())) ? (checkHitBoxes ? 0.062 : (this.resetCounter(10) ? -0.032 : 0.062)) : (PacketFly.mc.field_71439_g.field_71158_b.field_78899_d ? -0.062 : (checkHitBoxes ? 0.0 : (this.resetCounter(4) ? -0.04 : 0.0)));
        /*SL:64*/if (checkHitBoxes && EntityUtil.isMoving() && n != 0.0) {
            final double a1 = /*EL:65*/2.5;
            /*SL:66*/n /= 2.5;
        }
        final boolean b = /*EL:68*/true;
        final double[] motion = /*EL:69*/this.getMotion(checkHitBoxes ? 0.031 : 0.26);
        /*SL:70*/for (int n2 = 1, v0 = 1; v0 < n2 + 1; ++v0) {
            final double v = /*EL:71*/1.0;
            PacketFly.mc.field_71439_g.field_70159_w = /*EL:72*/motion[0] * v0 * 1.0;
            PacketFly.mc.field_71439_g.field_70181_x = /*EL:73*/n * v0;
            PacketFly.mc.field_71439_g.field_70179_y = /*EL:74*/motion[1] * v0 * 1.0;
            final boolean v2 = /*EL:75*/true;
            /*SL:76*/this.sendPackets(PacketFly.mc.field_71439_g.field_70159_w, PacketFly.mc.field_71439_g.field_70181_x, PacketFly.mc.field_71439_g.field_70179_y, true);
        }
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent a1) {
        /*SL:82*/if (this.setMove && this.flightCounter != 0) {
            /*SL:83*/a1.setX(PacketFly.mc.field_71439_g.field_70159_w);
            /*SL:84*/a1.setY(PacketFly.mc.field_71439_g.field_70181_x);
            /*SL:85*/a1.setZ(PacketFly.mc.field_71439_g.field_70179_y);
            /*SL:86*/if (this.nocliperino && this.checkHitBoxes()) {
                PacketFly.mc.field_71439_g.field_70145_X = /*EL:87*/true;
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send a1) {
        /*SL:94*/if (a1.getPacket() instanceof CPacketPlayer && !this.packets.remove(a1.getPacket())) {
            /*SL:95*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPushOutOfBlocks(final PushEvent a1) {
        /*SL:101*/if (a1.getStage() == 1) {
            /*SL:102*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive v2) {
        /*SL:108*/if (v2.getPacket() instanceof SPacketPlayerPosLook && !AbstractModule.fullNullCheck()) {
            final SPacketPlayerPosLook a1 = /*EL:109*/(SPacketPlayerPosLook)v2.getPacket();
            /*SL:110*/if (PacketFly.mc.field_71439_g.func_70089_S() && PacketFly.mc.field_71441_e.func_175668_a(new BlockPos(PacketFly.mc.field_71439_g.field_70165_t, PacketFly.mc.field_71439_g.field_70163_u, PacketFly.mc.field_71439_g.field_70161_v), false) && !(PacketFly.mc.field_71462_r instanceof GuiDownloadTerrain)) {
                /*SL:111*/this.teleportmap.remove(a1.func_186965_f());
            }
            /*SL:113*/this.teleportID = a1.func_186965_f();
        }
    }
    
    private boolean checkHitBoxes() {
        /*SL:118*/return !PacketFly.mc.field_71441_e.func_184144_a((Entity)PacketFly.mc.field_71439_g, PacketFly.mc.field_71439_g.func_174813_aQ().func_72321_a(-0.0, -0.1, -0.0)).isEmpty();
    }
    
    private boolean resetCounter(final int a1) {
        /*SL:122*/if (++this.flightCounter >= a1) {
            /*SL:123*/this.flightCounter = 0;
            /*SL:124*/return true;
        }
        /*SL:126*/return false;
    }
    
    private double[] getMotion(final double a1) {
        float v1 = PacketFly.mc.field_71439_g.field_71158_b.field_192832_b;
        float v2 = PacketFly.mc.field_71439_g.field_71158_b.field_78902_a;
        float v3 = PacketFly.mc.field_71439_g.field_70126_B + (PacketFly.mc.field_71439_g.field_70177_z - PacketFly.mc.field_71439_g.field_70126_B) * PacketFly.mc.func_184121_ak();
        /*SL:133*/if (v1 != 0.0f) {
            /*SL:134*/if (v2 > 0.0f) {
                /*SL:135*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:137*/ if (v2 < 0.0f) {
                /*SL:138*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:140*/v2 = 0.0f;
            /*SL:141*/if (v1 > 0.0f) {
                /*SL:142*/v1 = 1.0f;
            }
            else/*SL:144*/ if (v1 < 0.0f) {
                /*SL:145*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:148*/v1 * a1 * -Math.sin(Math.toRadians(v3)) + v2 * a1 * Math.cos(Math.toRadians(v3));
        final double v5 = /*EL:149*/v1 * a1 * Math.cos(Math.toRadians(v3)) - v2 * a1 * -Math.sin(Math.toRadians(v3));
        /*SL:150*/return new double[] { v4, v5 };
    }
    
    private void sendPackets(final double a1, final double a2, final double a3, final boolean a4) {
        final Vec3d v1 = /*EL:154*/new Vec3d(a1, a2, a3);
        final Vec3d v2 = PacketFly.mc.field_71439_g.func_174791_d().func_178787_e(/*EL:155*/v1);
        final Vec3d v3 = /*EL:156*/this.outOfBoundsVec(v2);
        /*SL:157*/this.packetSender((CPacketPlayer)new CPacketPlayer.Position(v2.field_72450_a, v2.field_72448_b, v2.field_72449_c, PacketFly.mc.field_71439_g.field_70122_E));
        /*SL:158*/this.packetSender((CPacketPlayer)new CPacketPlayer.Position(v3.field_72450_a, v3.field_72448_b, v3.field_72449_c, PacketFly.mc.field_71439_g.field_70122_E));
        /*SL:159*/this.teleportPacket(v2, a4);
    }
    
    private void teleportPacket(final Vec3d a1, final boolean a2) {
        /*SL:163*/if (a2) {
            PacketFly.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:164*/(Packet)new CPacketConfirmTeleport(++this.teleportID));
            /*SL:165*/this.teleportmap.put(this.teleportID, new IDtime(a1, new Timer()));
        }
    }
    
    private Vec3d outOfBoundsVec(final Vec3d a1) {
        /*SL:170*/return a1.func_72441_c(0.0, 1337.0, 0.0);
    }
    
    private void packetSender(final CPacketPlayer a1) {
        /*SL:174*/this.packets.add(a1);
        PacketFly.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:175*/(Packet)a1);
    }
    
    public static class IDtime
    {
        private final Vec3d pos;
        private final Timer timer;
        
        public IDtime(final Vec3d a1, final Timer a2) {
            this.pos = a1;
            (this.timer = a2).reset();
        }
        
        public Vec3d getPos() {
            /*SL:189*/return this.pos;
        }
        
        public Timer getTimer() {
            /*SL:193*/return this.timer;
        }
    }
}
