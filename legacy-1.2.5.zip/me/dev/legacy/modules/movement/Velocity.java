package me.dev.legacy.modules.movement;

import me.dev.legacy.api.event.events.move.PushEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.world.World;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Velocity extends Module
{
    public Setting<Boolean> noPush;
    public Setting<Float> horizontal;
    public Setting<Float> vertical;
    public Setting<Boolean> explosions;
    public Setting<Boolean> bobbers;
    public Setting<Boolean> water;
    public Setting<Boolean> blocks;
    public Setting<Boolean> ice;
    private static Velocity INSTANCE;
    
    public Velocity() {
        super("Velocity", "Allows you to control your velocity", Category.MOVEMENT, true, false, false);
        this.noPush = (Setting<Boolean>)this.register(new Setting("NoPush", (T)true));
        this.horizontal = (Setting<Float>)this.register(new Setting("Horizontal", (T)0.0f, (T)0.0f, (T)100.0f));
        this.vertical = (Setting<Float>)this.register(new Setting("Vertical", (T)0.0f, (T)0.0f, (T)100.0f));
        this.explosions = (Setting<Boolean>)this.register(new Setting("Explosions", (T)true));
        this.bobbers = (Setting<Boolean>)this.register(new Setting("Bobbers", (T)true));
        this.water = (Setting<Boolean>)this.register(new Setting("Water", (T)false));
        this.blocks = (Setting<Boolean>)this.register(new Setting("Blocks", (T)false));
        this.ice = (Setting<Boolean>)this.register(new Setting("Ice", (T)false));
        this.setInstance();
    }
    
    private void setInstance() {
        Velocity.INSTANCE = /*EL:40*/this;
    }
    
    public static Velocity getINSTANCE() {
        /*SL:44*/if (Velocity.INSTANCE == null) {
            Velocity.INSTANCE = /*EL:45*/new Velocity();
        }
        /*SL:47*/return Velocity.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @SubscribeEvent
    public void onPacketReceived(final PacketEvent.Receive v-2) {
        /*SL:60*/if (v-2.getStage() == 0 && Velocity.mc.field_71439_g != null) {
            /*SL:61*/if (v-2.getPacket() instanceof SPacketEntityVelocity) {
                final SPacketEntityVelocity sPacketEntityVelocity = /*EL:62*/(SPacketEntityVelocity)v-2.getPacket();
                /*SL:63*/if (sPacketEntityVelocity.func_149412_c() == Velocity.mc.field_71439_g.field_145783_c) {
                    /*SL:64*/if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                        /*SL:65*/v-2.setCanceled(true);
                        /*SL:66*/return;
                    }
                    final SPacketEntityVelocity sPacketEntityVelocity2;
                    final SPacketEntityVelocity a1 = /*EL:69*/sPacketEntityVelocity2 = sPacketEntityVelocity;
                    sPacketEntityVelocity2.field_149415_b *= (Integer)(Object)this.horizontal.getValue();
                    final SPacketEntityVelocity sPacketEntityVelocity3;
                    final SPacketEntityVelocity v1 = /*EL:71*/sPacketEntityVelocity3 = sPacketEntityVelocity;
                    sPacketEntityVelocity3.field_149416_c *= (Integer)(Object)this.vertical.getValue();
                    final SPacketEntityVelocity sPacketEntityVelocity4;
                    final SPacketEntityVelocity v2 = /*EL:73*/sPacketEntityVelocity4 = sPacketEntityVelocity;
                    sPacketEntityVelocity4.field_149414_d *= (Integer)(Object)this.horizontal.getValue();
                }
            }
            /*SL:76*/if (v-2.getPacket() instanceof SPacketEntityStatus && this.bobbers.getValue()) {
                final SPacketEntityStatus sPacketEntityStatus = /*EL:77*/(SPacketEntityStatus)v-2.getPacket();
                /*SL:78*/if (sPacketEntityStatus.func_149160_c() == 31) {
                    final Entity v3 = /*EL:79*/sPacketEntityStatus.func_149161_a((World)Velocity.mc.field_71441_e);
                    /*SL:80*/if (v3 instanceof EntityFishHook) {
                        final EntityFishHook v4 = /*EL:81*/(EntityFishHook)v3;
                        /*SL:82*/if (v4.field_146043_c == Velocity.mc.field_71439_g) {
                            /*SL:83*/v-2.setCanceled(true);
                        }
                    }
                }
            }
            /*SL:88*/if (this.explosions.getValue() && v-2.getPacket() instanceof SPacketExplosion) {
                /*SL:89*/if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                    /*SL:90*/v-2.setCanceled(true);
                    /*SL:91*/return;
                }
                final SPacketExplosion v5;
                final SPacketExplosion sPacketExplosion2;
                final SPacketExplosion sPacketExplosion = /*EL:95*/sPacketExplosion2 = (v5 = (SPacketExplosion)v-2.getPacket());
                sPacketExplosion2.field_149152_f *= this.horizontal.getValue();
                final SPacketExplosion sPacketExplosion3;
                final SPacketExplosion v6 = /*EL:97*/sPacketExplosion3 = v5;
                sPacketExplosion3.field_149153_g *= this.vertical.getValue();
                final SPacketExplosion sPacketExplosion4;
                final SPacketExplosion v7 = /*EL:99*/sPacketExplosion4 = v5;
                sPacketExplosion4.field_149159_h *= this.horizontal.getValue();
            }
        }
    }
    
    @SubscribeEvent
    public void onPush(final PushEvent a1) {
        /*SL:106*/if (a1.getStage() == 0 && this.noPush.getValue() && a1.entity.equals((Object)Velocity.mc.field_71439_g)) {
            /*SL:107*/if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                /*SL:108*/a1.setCanceled(true);
                /*SL:109*/return;
            }
            /*SL:111*/a1.x = -a1.x * this.horizontal.getValue();
            /*SL:112*/a1.y = -a1.y * this.vertical.getValue();
            /*SL:113*/a1.z = -a1.z * this.horizontal.getValue();
        }
        else/*SL:115*/ if (a1.getStage() == 1 && this.blocks.getValue()) {
            /*SL:116*/a1.setCanceled(true);
        }
        else/*SL:118*/ if (a1.getStage() == 2 && this.water.getValue() && Velocity.mc.field_71439_g != null && Velocity.mc.field_71439_g.equals((Object)a1.entity)) {
            /*SL:119*/a1.setCanceled(true);
        }
    }
    
    static {
        Velocity.INSTANCE = new Velocity();
    }
}
