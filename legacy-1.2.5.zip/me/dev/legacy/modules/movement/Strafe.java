package me.dev.legacy.modules.movement;

import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.modules.player.Freecam;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.event.events.move.MoveEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import java.math.RoundingMode;
import java.math.BigDecimal;
import java.util.Objects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Strafe extends Module
{
    private static Strafe INSTANCE;
    private final Setting<Integer> acceleration;
    private final Setting<Float> speedLimit;
    private int potionSpeed;
    private int stage;
    private double moveSpeed;
    private double lastDist;
    private int cooldownHops;
    private boolean waitForGround;
    private final Timer timer;
    private int hops;
    
    public Strafe() {
        super("Strafe", "AirControl etc.", Category.MOVEMENT, true, false, false);
        this.acceleration = (Setting<Integer>)this.register(new Setting("Speed", (T)1600, (T)1000, (T)2500));
        this.speedLimit = (Setting<Float>)this.register(new Setting("MaxSpeed", (T)60.0f, (T)20.0f, (T)60.0f));
        this.potionSpeed = 1500;
        this.stage = 1;
        this.cooldownHops = 0;
        this.waitForGround = false;
        this.timer = new Timer();
        this.hops = 0;
        Strafe.INSTANCE = this;
    }
    
    public static Strafe getInstance() {
        /*SL:48*/if (Strafe.INSTANCE == null) {
            Strafe.INSTANCE = /*EL:49*/new Strafe();
        }
        /*SL:51*/return Strafe.INSTANCE;
    }
    
    public static double getBaseMoveSpeed() {
        double n = /*EL:55*/0.272;
        /*SL:56*/if (Strafe.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            final int v1 = /*EL:57*/Objects.<PotionEffect>requireNonNull(Strafe.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            /*SL:58*/n *= 1.0 + 0.2 * v1;
        }
        /*SL:60*/return n;
    }
    
    public static double round(final double a1, final int a2) {
        /*SL:64*/if (a2 < 0) {
            /*SL:65*/throw new IllegalArgumentException();
        }
        final BigDecimal v1 = /*EL:67*/new BigDecimal(a1).setScale(a2, RoundingMode.HALF_UP);
        /*SL:68*/return v1.doubleValue();
    }
    
    @Override
    public void onEnable() {
        /*SL:73*/if (!Strafe.mc.field_71439_g.field_70122_E) {
            /*SL:74*/this.waitForGround = true;
        }
        /*SL:76*/this.hops = 0;
        /*SL:77*/this.timer.reset();
        /*SL:78*/this.moveSpeed = getBaseMoveSpeed();
    }
    
    @Override
    public void onDisable() {
        /*SL:83*/this.hops = 0;
        /*SL:84*/this.moveSpeed = 0.0;
        /*SL:85*/this.stage = 0;
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent a1) {
        /*SL:90*/if (a1.getStage() == 0) {
            /*SL:91*/this.lastDist = Math.sqrt((Strafe.mc.field_71439_g.field_70165_t - Strafe.mc.field_71439_g.field_70169_q) * (Strafe.mc.field_71439_g.field_70165_t - Strafe.mc.field_71439_g.field_70169_q) + (Strafe.mc.field_71439_g.field_70161_v - Strafe.mc.field_71439_g.field_70166_s) * (Strafe.mc.field_71439_g.field_70161_v - Strafe.mc.field_71439_g.field_70166_s));
        }
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent v-3) {
        /*SL:97*/if (v-3.getStage() != 0 || this.shouldReturn()) {
            /*SL:98*/return;
        }
        /*SL:100*/if (!Strafe.mc.field_71439_g.field_70122_E) {
            /*SL:101*/this.waitForGround = false;
        }
        float field_192832_b = Strafe.mc.field_71439_g.field_71158_b.field_192832_b;
        float field_78902_a = Strafe.mc.field_71439_g.field_71158_b.field_78902_a;
        float v0 = Strafe.mc.field_71439_g.field_70177_z;
        /*SL:106*/if (Strafe.mc.field_71439_g.field_70122_E && Legacy.speedManager.getSpeedKpH() < this.speedLimit.getValue()) {
            /*SL:107*/this.stage = 2;
        }
        /*SL:109*/if (round(Strafe.mc.field_71439_g.field_70163_u - (int)Strafe.mc.field_71439_g.field_70163_u, 3) == round(1.0, 3) && EntityUtil.isEntityMoving((Entity)Strafe.mc.field_71439_g)) {
            final EntityPlayerSP field_71439_g;
            final EntityPlayerSP a1 = /*EL:111*/field_71439_g = Strafe.mc.field_71439_g;
            field_71439_g.field_70181_x -= 0.0;
            /*SL:112*/v-3.setY(v-3.getY() - 0.2);
        }
        /*SL:114*/if (this.stage == 1 && EntityUtil.isMoving()) {
            /*SL:115*/this.stage = 2;
            /*SL:116*/this.moveSpeed = this.getMultiplier() * getBaseMoveSpeed() - 0.01;
        }
        else/*SL:118*/ if (this.stage == 2 && EntityUtil.isMoving()) {
            /*SL:119*/this.stage = 3;
            /*SL:120*/v-3.setY(Strafe.mc.field_71439_g.field_70181_x = 0.4);
            /*SL:121*/if (this.cooldownHops > 0) {
                /*SL:122*/--this.cooldownHops;
            }
            /*SL:124*/++this.hops;
            final double v = /*EL:125*/(this.acceleration.getValue() == 2149) ? 2.149802 : (this.acceleration.getValue() / 1000.0);
            /*SL:126*/this.moveSpeed *= v;
        }
        else/*SL:128*/ if (this.stage == 3) {
            /*SL:129*/this.stage = 4;
            final double v = /*EL:130*/0.66 * (this.lastDist - getBaseMoveSpeed());
            /*SL:131*/this.moveSpeed = this.lastDist - v;
        }
        else {
            /*SL:134*/if (Strafe.mc.field_71441_e.func_184144_a((Entity)Strafe.mc.field_71439_g, Strafe.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, Strafe.mc.field_71439_g.field_70181_x, 0.0)).size() > 0 || (Strafe.mc.field_71439_g.field_70124_G && this.stage > 0)) {
                /*SL:135*/this.stage = ((Strafe.mc.field_71439_g.field_191988_bg != 0.0f || Strafe.mc.field_71439_g.field_70702_br != 0.0f) ? 1 : 0);
            }
            /*SL:137*/this.moveSpeed = this.lastDist - this.lastDist / 200.0;
        }
        /*SL:139*/this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
        /*SL:140*/if (field_192832_b == 0.0f && field_78902_a == 0.0f) {
            /*SL:141*/v-3.setX(0.0);
            /*SL:142*/v-3.setZ(0.0);
            /*SL:143*/this.moveSpeed = 0.0;
        }
        else/*SL:145*/ if (field_192832_b != 0.0f) {
            /*SL:146*/if (field_78902_a >= 1.0f) {
                /*SL:147*/v0 += ((field_192832_b > 0.0f) ? -45.0f : 45.0f);
                /*SL:148*/field_78902_a = 0.0f;
            }
            else/*SL:150*/ if (field_78902_a <= -1.0f) {
                /*SL:151*/v0 += ((field_192832_b > 0.0f) ? 45.0f : -45.0f);
                /*SL:152*/field_78902_a = 0.0f;
            }
            /*SL:154*/if (field_192832_b > 0.0f) {
                /*SL:155*/field_192832_b = 1.0f;
            }
            else/*SL:157*/ if (field_192832_b < 0.0f) {
                /*SL:158*/field_192832_b = -1.0f;
            }
        }
        final double v = /*EL:161*/Math.cos(Math.toRadians(v0 + 90.0f));
        final double v2 = /*EL:162*/Math.sin(Math.toRadians(v0 + 90.0f));
        /*SL:163*/if (this.cooldownHops == 0) {
            /*SL:164*/v-3.setX(field_192832_b * this.moveSpeed * v + field_78902_a * this.moveSpeed * v2);
            /*SL:165*/v-3.setZ(field_192832_b * this.moveSpeed * v2 - field_78902_a * this.moveSpeed * v);
        }
        /*SL:167*/if (field_192832_b == 0.0f && field_78902_a == 0.0f) {
            /*SL:168*/this.timer.reset();
            /*SL:169*/v-3.setX(0.0);
            /*SL:170*/v-3.setZ(0.0);
        }
    }
    
    private float getMultiplier() {
        float v0 = /*EL:175*/500.0f;
        /*SL:176*/if (Strafe.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            final int v = /*EL:177*/Objects.<PotionEffect>requireNonNull(Strafe.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c() + 1;
            /*SL:178*/v0 = ((v >= 2) ? this.potionSpeed : ((float)this.potionSpeed));
        }
        /*SL:180*/return v0 / 100.0f;
    }
    
    private boolean shouldReturn() {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:184*/if (!ModuleManager.isModuleEnabled(Freecam.class)) {
            final ModuleManager moduleManager2 = Legacy.moduleManager;
            if (!ModuleManager.isModuleEnabled(PacketFly.class)) {
                return false;
            }
        }
        return true;
    }
}
