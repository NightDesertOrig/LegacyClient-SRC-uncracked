package me.dev.legacy.modules.movement;

import java.util.Objects;
import net.minecraft.potion.Potion;
import me.dev.legacy.modules.Module;

public class AntiLevitate extends Module
{
    public AntiLevitate() {
        super("AntiLevitate", "Removes levitation effect", Category.MOVEMENT, false, false, false);
    }
    
    @Override
    public void onUpdate() {
        /*SL:16*/if (AntiLevitate.mc.field_71439_g.func_70644_a((Potion)Objects.<Potion>requireNonNull(Potion.func_180142_b("levitation")))) {
            AntiLevitate.mc.field_71439_g.func_184596_c(/*EL:17*/Potion.func_180142_b("levitation"));
        }
    }
}
