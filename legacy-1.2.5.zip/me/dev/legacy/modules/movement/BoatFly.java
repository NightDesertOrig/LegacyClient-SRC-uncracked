package me.dev.legacy.modules.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.item.ItemBoat;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.client.CPacketInput;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.item.EntityBoat;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class BoatFly extends Module
{
    public Setting<Double> speed;
    public Setting<Double> verticalSpeed;
    public Setting<Boolean> placeBypass;
    public Setting<Boolean> bypass;
    public Setting<Boolean> noKick;
    public Setting<Boolean> packet;
    public Setting<Integer> packets;
    public Setting<Integer> interact;
    public static BoatFly INSTANCE;
    private EntityBoat target;
    private int teleportID;
    private int packetCounter;
    
    public BoatFly() {
        super("BoatFly", "/fly but boat", Category.MOVEMENT, true, false, false);
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)3.0, (T)1.0, (T)10.0));
        this.verticalSpeed = (Setting<Double>)this.register(new Setting("VerticalSpeed", (T)3.0, (T)1.0, (T)10.0));
        this.placeBypass = (Setting<Boolean>)this.register(new Setting("PlaceBypass", (T)true));
        this.bypass = (Setting<Boolean>)this.register(new Setting("Bypass", (T)true));
        this.noKick = (Setting<Boolean>)this.register(new Setting("No-Kick", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.packets = (Setting<Integer>)this.register(new Setting("Packets", (T)3, (T)1, (T)5, a1 -> this.packet.getValue()));
        this.interact = (Setting<Integer>)this.register(new Setting("Delay", (T)2, (T)1, (T)20));
        this.packetCounter = 0;
        BoatFly.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:41*/if (BoatFly.mc.field_71439_g == null) {
            /*SL:42*/return;
        }
        /*SL:44*/if (BoatFly.mc.field_71441_e == null || BoatFly.mc.field_71439_g.func_184187_bx() == null) {
            /*SL:45*/return;
        }
        /*SL:47*/if (BoatFly.mc.field_71439_g.func_184187_bx() instanceof EntityBoat) {
            /*SL:48*/this.target = (EntityBoat)BoatFly.mc.field_71439_g.field_184239_as;
        }
        BoatFly.mc.field_71439_g.func_184187_bx().func_189654_d(/*EL:50*/true);
        BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x = /*EL:51*/0.0;
        /*SL:52*/if (BoatFly.mc.field_71474_y.field_74314_A.func_151470_d()) {
            BoatFly.mc.field_71439_g.func_184187_bx().field_70122_E = /*EL:53*/false;
            BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x = /*EL:54*/this.verticalSpeed.getValue() / 10.0;
        }
        /*SL:56*/if (BoatFly.mc.field_71474_y.field_151444_V.func_151470_d()) {
            BoatFly.mc.field_71439_g.func_184187_bx().field_70122_E = /*EL:57*/false;
            BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x = /*EL:58*/-(this.verticalSpeed.getValue() / 10.0);
        }
        final double[] v1 = /*EL:60*/this.directionSpeed(this.speed.getValue() / 2.0);
        /*SL:61*/if (BoatFly.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || BoatFly.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
            BoatFly.mc.field_71439_g.func_184187_bx().field_70159_w = /*EL:62*/v1[0];
            BoatFly.mc.field_71439_g.func_184187_bx().field_70179_y = /*EL:63*/v1[1];
        }
        else {
            BoatFly.mc.field_71439_g.func_184187_bx().field_70159_w = /*EL:65*/0.0;
            BoatFly.mc.field_71439_g.func_184187_bx().field_70179_y = /*EL:66*/0.0;
        }
        /*SL:68*/if (this.noKick.getValue()) {
            /*SL:69*/if (BoatFly.mc.field_71474_y.field_74314_A.func_151470_d()) {
                /*SL:70*/if (BoatFly.mc.field_71439_g.field_70173_aa % 8 < 2) {
                    BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x = /*EL:71*/-0.03999999910593033;
                }
            }
            else/*SL:73*/ if (BoatFly.mc.field_71439_g.field_70173_aa % 8 < 4) {
                BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x = /*EL:74*/-0.07999999821186066;
            }
        }
        /*SL:77*/this.handlePackets(BoatFly.mc.field_71439_g.func_184187_bx().field_70159_w, BoatFly.mc.field_71439_g.func_184187_bx().field_70181_x, BoatFly.mc.field_71439_g.func_184187_bx().field_70179_y);
    }
    
    public void handlePackets(final double v2, final double v4, final double v6) {
        /*SL:81*/if (this.packet.getValue()) {
            Vec3d a2 = /*EL:82*/new Vec3d(v2, v4, v6);
            /*SL:83*/if (BoatFly.mc.field_71439_g.func_184187_bx() == null) {
                /*SL:84*/return;
            }
            /*SL:86*/a2 = BoatFly.mc.field_71439_g.func_184187_bx().func_174791_d().func_178787_e(a2);
            BoatFly.mc.field_71439_g.func_184187_bx().func_70107_b(/*EL:87*/a2.field_72450_a, a2.field_72448_b, a2.field_72449_c);
            BoatFly.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:88*/(Packet)new CPacketVehicleMove(BoatFly.mc.field_71439_g.func_184187_bx()));
            /*SL:89*/for (int a3 = 0; a3 < this.packets.getValue(); ++a3) {
                BoatFly.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:90*/(Packet)new CPacketConfirmTeleport(this.teleportID++));
            }
        }
    }
    
    private void NCPPacketTrick() {
        /*SL:96*/this.packetCounter = 0;
        BoatFly.mc.field_71439_g.func_184187_bx().func_184210_p();
        final Entity v1 = (Entity)BoatFly.mc.field_71441_e.field_72996_f.stream().filter(/*EL:98*/a1 -> a1 instanceof EntityBoat).min(Comparator.<? super T, Comparable>comparing(a1 -> BoatFly.mc.field_71439_g.func_70032_d(a1))).orElse(null);
        /*SL:99*/if (v1 != null) {
            BoatFly.mc.field_71442_b.func_187097_a((EntityPlayer)BoatFly.mc.field_71439_g, /*EL:100*/v1, EnumHand.MAIN_HAND);
        }
    }
    
    @SubscribeEvent
    public void onSendPacket(final PacketEvent.Send a1) {
        /*SL:107*/if (BoatFly.mc.field_71441_e != null && BoatFly.mc.field_71439_g != null && /*EL:108*/BoatFly.mc.field_71439_g.func_184187_bx() instanceof EntityBoat) {
            /*SL:109*/if (this.bypass.getValue() && a1.getPacket() instanceof CPacketInput && !BoatFly.mc.field_71474_y.field_74311_E.func_151470_d() && !BoatFly.mc.field_71439_g.func_184187_bx().field_70122_E) {
                /*SL:110*/++this.packetCounter;
                /*SL:111*/if (this.packetCounter == 3) {
                    /*SL:112*/this.NCPPacketTrick();
                }
            }
            /*SL:115*/if ((this.bypass.getValue() && a1.getPacket() instanceof SPacketPlayerPosLook) || a1.getPacket() instanceof SPacketMoveVehicle) {
                /*SL:116*/a1.setCanceled(true);
            }
        }
        /*SL:121*/if (a1.getPacket() instanceof CPacketVehicleMove && BoatFly.mc.field_71439_g.func_184218_aH() && BoatFly.mc.field_71439_g.field_70173_aa % this.interact.getValue() == 0) {
            BoatFly.mc.field_71442_b.func_187097_a((EntityPlayer)BoatFly.mc.field_71439_g, BoatFly.mc.field_71439_g.field_184239_as, EnumHand.OFF_HAND);
        }
        /*SL:124*/if ((a1.getPacket() instanceof CPacketPlayer.Rotation || a1.getPacket() instanceof CPacketInput) && BoatFly.mc.field_71439_g.func_184218_aH()) {
            /*SL:125*/a1.setCanceled(true);
        }
        /*SL:127*/if ((this.placeBypass.getValue() && a1.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && /*EL:128*/BoatFly.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBoat) || BoatFly.mc.field_71439_g.func_184592_cb().func_77973_b() instanceof ItemBoat) {
            /*SL:129*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onReceivePacket(final PacketEvent.Receive a1) {
        /*SL:135*/if (a1.getPacket() instanceof SPacketMoveVehicle && BoatFly.mc.field_71439_g.func_184218_aH()) {
            /*SL:136*/a1.setCanceled(true);
        }
        /*SL:138*/if (a1.getPacket() instanceof SPacketPlayerPosLook) {
            /*SL:139*/this.teleportID = ((SPacketPlayerPosLook)a1.getPacket()).field_186966_g;
        }
    }
    
    private double[] directionSpeed(final double a1) {
        float v1 = BoatFly.mc.field_71439_g.field_71158_b.field_192832_b;
        float v2 = BoatFly.mc.field_71439_g.field_71158_b.field_78902_a;
        float v3 = BoatFly.mc.field_71439_g.field_70126_B + (BoatFly.mc.field_71439_g.field_70177_z - BoatFly.mc.field_71439_g.field_70126_B) * BoatFly.mc.func_184121_ak();
        /*SL:147*/if (v1 != 0.0f) {
            /*SL:148*/if (v2 > 0.0f) {
                /*SL:149*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:150*/ if (v2 < 0.0f) {
                /*SL:151*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:153*/v2 = 0.0f;
            /*SL:154*/if (v1 > 0.0f) {
                /*SL:155*/v1 = 1.0f;
            }
            else/*SL:156*/ if (v1 < 0.0f) {
                /*SL:157*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:160*/Math.sin(Math.toRadians(v3 + 90.0f));
        final double v5 = /*EL:161*/Math.cos(Math.toRadians(v3 + 90.0f));
        final double v6 = /*EL:162*/v1 * a1 * v5 + v2 * a1 * v4;
        final double v7 = /*EL:163*/v1 * a1 * v4 - v2 * a1 * v5;
        /*SL:164*/return new double[] { v6, v7 };
    }
}
