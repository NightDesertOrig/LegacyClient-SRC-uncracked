package me.dev.legacy.modules.combat;

import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.init.Items;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class BetterXP extends Module
{
    Setting<Boolean> rotate;
    Setting<Integer> lookPitch;
    private int delay_count;
    int prvSlot;
    
    public BetterXP() {
        super("BetterXP", "uses exp with packets", Category.COMBAT, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.lookPitch = (Setting<Integer>)this.register(new Setting("LookPitch", (T)90, (T)0, (T)100, a1 -> this.rotate.getValue()));
    }
    
    @Override
    public void onEnable() {
        /*SL:24*/this.delay_count = 0;
    }
    
    @Override
    public void onUpdate() {
        /*SL:29*/if (BetterXP.mc.field_71462_r == null) {
            /*SL:30*/this.usedXp();
        }
    }
    
    private int findExpInHotbar() {
        int v0 = /*EL:35*/0;
        /*SL:36*/for (int v = 0; v < 9; ++v) {
            /*SL:37*/if (BetterXP.mc.field_71439_g.field_71071_by.func_70301_a(v).func_77973_b() == Items.field_151062_by) {
                /*SL:38*/v0 = v;
                /*SL:39*/break;
            }
        }
        /*SL:42*/return v0;
    }
    
    private void usedXp() {
        final int v1 = (int)BetterXP.mc.field_71439_g.field_70125_A;
        /*SL:47*/this.prvSlot = BetterXP.mc.field_71439_g.field_71071_by.field_70461_c;
        BetterXP.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:48*/(Packet)new CPacketHeldItemChange(this.findExpInHotbar()));
        /*SL:49*/if (this.rotate.getValue()) {
            BetterXP.mc.field_71439_g.field_70125_A = /*EL:50*/this.lookPitch.getValue();
            BetterXP.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:51*/(Packet)new CPacketPlayer.Rotation(BetterXP.mc.field_71439_g.field_70177_z, (float)this.lookPitch.getValue(), true));
        }
        BetterXP.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:52*/(Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
        /*SL:53*/if (this.rotate.getValue()) {
            BetterXP.mc.field_71439_g.field_70125_A = /*EL:54*/v1;
        }
        BetterXP.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:55*/this.prvSlot;
        BetterXP.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:56*/(Packet)new CPacketHeldItemChange(this.prvSlot));
    }
}
