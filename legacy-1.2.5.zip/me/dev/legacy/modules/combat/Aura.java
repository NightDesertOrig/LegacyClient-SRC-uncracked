package me.dev.legacy.modules.combat;

import java.util.Iterator;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.entity.EntityLivingBase;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.DamageUtil;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import net.minecraft.entity.Entity;
import me.dev.legacy.modules.Module;

public class Aura extends Module
{
    public static Entity target;
    private final Timer timer;
    public Setting<Float> range;
    public Setting<Boolean> delay;
    public Setting<Boolean> rotate;
    public Setting<Boolean> onlySharp;
    public Setting<Float> raytrace;
    public Setting<Boolean> players;
    public Setting<Boolean> mobs;
    public Setting<Boolean> animals;
    public Setting<Boolean> vehicles;
    public Setting<Boolean> projectiles;
    public Setting<Boolean> tps;
    public Setting<Boolean> packet;
    
    public Aura() {
        super("Aura", "Kills aura.", Category.COMBAT, true, false, false);
        this.timer = new Timer();
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)6.0f, (T)0.1f, (T)7.0f));
        this.delay = (Setting<Boolean>)this.register(new Setting("HitDelay", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.onlySharp = (Setting<Boolean>)this.register(new Setting("SwordOnly", (T)true));
        this.raytrace = (Setting<Float>)this.register(new Setting("Raytrace", (T)6.0f, (T)0.1f, (T)7.0f, "Wall Range."));
        this.players = (Setting<Boolean>)this.register(new Setting("Players", (T)true));
        this.mobs = (Setting<Boolean>)this.register(new Setting("Mobs", (T)false));
        this.animals = (Setting<Boolean>)this.register(new Setting("Animals", (T)false));
        this.vehicles = (Setting<Boolean>)this.register(new Setting("Entities", (T)false));
        this.projectiles = (Setting<Boolean>)this.register(new Setting("Projectiles", (T)false));
        this.tps = (Setting<Boolean>)this.register(new Setting("TpsSync", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
    }
    
    @Override
    public void onTick() {
        /*SL:40*/if (!this.rotate.getValue()) {
            /*SL:41*/this.doKillaura();
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerEvent(final UpdateWalkingPlayerEvent a1) {
        /*SL:46*/if (a1.getStage() == 0 && this.rotate.getValue()) {
            /*SL:47*/this.doKillaura();
        }
    }
    
    private void doKillaura() {
        /*SL:51*/if (this.onlySharp.getValue() && !EntityUtil.holdingWeapon((EntityPlayer)Aura.mc.field_71439_g)) {
            Aura.target = /*EL:52*/null;
            /*SL:53*/return;
        }
        final int v1 = /*EL:55*/this.delay.getValue() ? ((int)(DamageUtil.getCooldownByWeapon((EntityPlayer)Aura.mc.field_71439_g) * (this.tps.getValue() ? Legacy.serverManager.getTpsFactor() : 1.0f))) : 0;
        /*SL:56*/if (!this.timer.passedMs(v1)) {
            /*SL:57*/return;
        }
        Aura.target = /*EL:58*/this.getTarget();
        /*SL:59*/if (Aura.target == null) {
            /*SL:60*/return;
        }
        /*SL:61*/if (this.rotate.getValue()) {
            Legacy.rotationManager.lookAtEntity(Aura.target);
        }
        /*SL:63*/EntityUtil.attackEntity(Aura.target, this.packet.getValue(), true);
        /*SL:64*/this.timer.reset();
    }
    
    private Entity getTarget() {
        Entity entity = /*EL:68*/null;
        double a2 = /*EL:69*/this.range.getValue();
        double n = /*EL:70*/36.0;
        /*SL:71*/for (final Entity v1 : Aura.mc.field_71441_e.field_73010_i) {
            /*SL:72*/if ((this.players.getValue() && v1 instanceof EntityPlayer) || (this.animals.getValue() && EntityUtil.isPassive(v1)) || (this.mobs.getValue() && EntityUtil.isMobAggressive(v1)) || (this.vehicles.getValue() && EntityUtil.isVehicle(v1)) || (this.projectiles.getValue() && EntityUtil.isProjectile(v1))) {
                if (v1 instanceof EntityLivingBase && /*EL:73*/EntityUtil.isntValid(v1, a2)) {
                    /*SL:74*/continue;
                }
                /*SL:75*/if (!Aura.mc.field_71439_g.func_70685_l(v1) && !EntityUtil.canEntityFeetBeSeen(v1) && Aura.mc.field_71439_g.func_70068_e(v1) > MathUtil.square(this.raytrace.getValue())) {
                    /*SL:76*/continue;
                }
                /*SL:77*/if (entity == null) {
                    /*SL:78*/entity = v1;
                    /*SL:79*/a2 = Aura.mc.field_71439_g.func_70068_e(v1);
                    /*SL:80*/n = EntityUtil.getHealth(v1);
                }
                else {
                    /*SL:83*/if (v1 instanceof EntityPlayer && DamageUtil.isArmorLow((EntityPlayer)v1, 18)) {
                        /*SL:84*/entity = v1;
                        /*SL:85*/break;
                    }
                    /*SL:87*/if (Aura.mc.field_71439_g.func_70068_e(v1) < a2) {
                        /*SL:88*/entity = v1;
                        /*SL:89*/a2 = Aura.mc.field_71439_g.func_70068_e(v1);
                        /*SL:90*/n = EntityUtil.getHealth(v1);
                    }
                    /*SL:92*/if (EntityUtil.getHealth(v1) >= n) {
                        continue;
                    }
                    /*SL:93*/entity = v1;
                    /*SL:94*/a2 = Aura.mc.field_71439_g.func_70068_e(v1);
                    /*SL:95*/n = EntityUtil.getHealth(v1);
                }
            }
        }
        /*SL:98*/return entity;
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:102*/if (Aura.target instanceof EntityPlayer) {
            /*SL:103*/return Aura.target.func_70005_c_();
        }
        /*SL:104*/return null;
    }
}
