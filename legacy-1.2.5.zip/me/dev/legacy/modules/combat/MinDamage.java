package me.dev.legacy.modules.combat;

import com.google.common.eventbus.Subscribe;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class MinDamage extends Module
{
    private static MinDamage INSTANCE;
    private final Setting<Float> EnableDamage;
    private final Setting<Float> DisableDamage;
    
    public MinDamage() {
        super("MinDamage", "Set minimal damage for auto crystal.", Category.COMBAT, true, false, false);
        this.EnableDamage = (Setting<Float>)this.register(new Setting("EnableDamage", (T)4.0f, (T)1.0f, (T)36.0f));
        this.DisableDamage = (Setting<Float>)this.register(new Setting("DisableDamage", (T)4.0f, (T)1.0f, (T)36.0f));
        MinDamage.INSTANCE = this;
    }
    
    public static MinDamage getInstance() {
        /*SL:17*/return MinDamage.INSTANCE;
    }
    
    @Subscribe
    @Override
    public void onEnable() {
        /*SL:22*/AutoCrystal.getInstance().minDamage.setValue(this.EnableDamage.getValue());
    }
    
    @Subscribe
    @Override
    public void onDisable() {
        /*SL:27*/AutoCrystal.getInstance().minDamage.setValue(this.DisableDamage.getValue());
    }
    
    static {
        MinDamage.INSTANCE = new MinDamage();
    }
}
