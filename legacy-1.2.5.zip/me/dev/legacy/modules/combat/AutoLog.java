package me.dev.legacy.modules.combat;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoLog extends Module
{
    public final Setting<Boolean> packetKick;
    public final Setting<Boolean> fakeKick;
    public final Setting<Integer> Health;
    
    public AutoLog() {
        super("AutoLog", "Automatically logs on combat.", Category.COMBAT, true, false, false);
        this.packetKick = (Setting<Boolean>)this.register(new Setting("Packet Kick", (T)false));
        this.fakeKick = (Setting<Boolean>)this.register(new Setting("Fake Kick", (T)false));
        this.Health = (Setting<Integer>)this.register(new Setting("Health", (T)6, (T)1, (T)20));
    }
    
    @Override
    public void onTick() {
        /*SL:18*/if (AutoLog.mc.field_71439_g == null || AutoLog.mc.field_71441_e == null || AutoLog.mc.field_71439_g.field_71075_bZ.field_75098_d) {
            /*SL:19*/return;
        }
        final float v1 = AutoLog.mc.field_71439_g.func_110143_aJ();
        /*SL:24*/if (v1 <= this.Health.getValue() && v1 != 0.0f && !AutoLog.mc.field_71439_g.field_70128_L) {
            /*SL:25*/this.doLog();
            /*SL:26*/this.toggle();
        }
    }
    
    public void doLog() {
        /*SL:31*/if (this.packetKick.getValue()) {
            AutoLog.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:32*/(Packet)new CPacketPlayer.Position(AutoLog.mc.field_71439_g.field_70165_t, AutoLog.mc.field_71439_g.field_70163_u + 50.0, AutoLog.mc.field_71439_g.field_70161_v, false));
        }
        /*SL:35*/if (this.fakeKick.getValue()) {
            AutoLog.mc.field_71439_g.field_71174_a.func_147298_b().func_150718_a(/*EL:36*/(ITextComponent)new TextComponentString("Internal Exception: java.lang.NullPointerException"));
            /*SL:37*/return;
        }
        AutoLog.mc.field_71439_g.field_71174_a.func_147298_b().func_150718_a(/*EL:40*/(ITextComponent)new TextComponentString("Auto Log!"));
    }
}
