package me.dev.legacy.modules.combat;

import java.util.Iterator;
import net.minecraft.block.BlockAir;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.Legacy;
import java.util.List;
import java.util.Collections;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Comparator;
import net.minecraft.entity.player.EntityPlayer;
import java.util.ArrayList;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.PlayerUtil;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class SmartBurrow extends Module
{
    private static SmartBurrow INSTANCE;
    public Setting<Float> smartRange;
    public Setting<Boolean> onlyInHole;
    
    public SmartBurrow() {
        super("SmartBurrow", "Big smart", Category.COMBAT, true, false, false);
        this.smartRange = (Setting<Float>)this.register(new Setting("Smart Range", (T)2.5f, (T)1.0f, (T)10.0f));
        this.onlyInHole = (Setting<Boolean>)this.register(new Setting("Hole Only", (T)true));
        this.setInstance();
    }
    
    public static SmartBurrow getInstance() {
        /*SL:29*/if (SmartBurrow.INSTANCE == null) {
            SmartBurrow.INSTANCE = /*EL:30*/new SmartBurrow();
        }
        /*SL:33*/return SmartBurrow.INSTANCE;
    }
    
    private void setInstance() {
        SmartBurrow.INSTANCE = /*EL:37*/this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:41*/if (!this.onlyInHole.getValue() || PlayerUtil.isInHole((Entity)SmartBurrow.mc.field_71439_g)) {
            final ArrayList<Entity> list = (ArrayList<Entity>)SmartBurrow.mc.field_71441_e.field_72996_f.stream().filter(/*EL:42*/a1 -> a1 instanceof EntityPlayer && a1 != SmartBurrow.mc.field_71439_g).sorted(/*EL:44*/Comparator.<? super T, Comparable>comparing(a1 -> SmartBurrow.mc.field_71439_g.func_70032_d(a1))).collect(/*EL:46*/Collectors.<Object, ArrayList>toCollection(ArrayList::new));
            /*SL:47*/Collections.reverse(list);
            final Burrow burrow = (Burrow)Legacy.moduleManager.getModuleByName(/*EL:48*/"Burrow");
            final BlockPos blockPos = /*EL:49*/new BlockPos(Math.floor(SmartBurrow.mc.field_71439_g.func_174791_d().field_72450_a), Math.floor(SmartBurrow.mc.field_71439_g.func_174791_d().field_72448_b + 0.2), Math.floor(SmartBurrow.mc.field_71439_g.func_174791_d().field_72449_c));
            /*SL:50*/for (final Entity v : list) {
                /*SL:54*/if (v != SmartBurrow.mc.field_71439_g && SmartBurrow.mc.field_71439_g.func_70032_d(v) < this.smartRange.getValue() && !PlayerUtil.isInHole(v) && !burrow.isEnabled() && SmartBurrow.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() instanceof BlockAir) {
                    /*SL:55*/burrow.enable();
                    /*SL:56*/if (this.onlyInHole.getValue()) {
                        /*SL:57*/return;
                    }
                    getInstance().disable();
                }
            }
        }
    }
    
    static {
        SmartBurrow.INSTANCE = new SmartBurrow();
    }
}
