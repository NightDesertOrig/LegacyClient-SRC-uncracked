package me.dev.legacy.modules.combat;

import net.minecraft.util.math.Vec3d;
import java.util.Iterator;
import me.dev.legacy.api.util.MathUtil;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.entity.Entity;
import me.dev.legacy.Legacy;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBow;
import me.dev.legacy.modules.Module;

public class BowAim extends Module
{
    public BowAim() {
        super("BowAim", "BowAim", Category.COMBAT, true, false, false);
    }
    
    @Override
    public void onUpdate() {
        /*SL:19*/if (BowAim.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBow && BowAim.mc.field_71439_g.func_184587_cr() && BowAim.mc.field_71439_g.func_184612_cw() >= 3) {
            EntityPlayer a1 = /*EL:20*/null;
            float n = /*EL:21*/100.0f;
            /*SL:22*/for (final EntityPlayer v0 : BowAim.mc.field_71441_e.field_73010_i) {
                /*SL:23*/if (!(v0 instanceof EntityPlayerSP)) {
                    if (Legacy.friendManager.isFriend(v0.func_70005_c_())) {
                        continue;
                    }
                    final float v = /*EL:24*/v0.func_70032_d((Entity)BowAim.mc.field_71439_g);
                    /*SL:25*/if (v >= n) {
                        continue;
                    }
                    /*SL:26*/n = v;
                    /*SL:27*/a1 = v0;
                }
            }
            /*SL:30*/if (a1 != null) {
                final Vec3d interpolatedPos = /*EL:31*/EntityUtil.getInterpolatedPos((Entity)a1, BowAim.mc.func_184121_ak());
                final float[] v2 = /*EL:32*/MathUtil.calcAngle(EntityUtil.getInterpolatedPos((Entity)BowAim.mc.field_71439_g, BowAim.mc.func_184121_ak()), interpolatedPos);
                BowAim.mc.field_71439_g.field_70177_z = /*EL:34*/v2[0];
                BowAim.mc.field_71439_g.field_70125_A = /*EL:35*/v2[1];
            }
        }
    }
}
