package me.dev.legacy.modules.combat;

import net.minecraft.entity.EntityLivingBase;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import me.dev.legacy.Legacy;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.modules.Module;

public class AutoCity extends Module
{
    private boolean firstRun;
    private BlockPos mineTarget;
    private EntityPlayer closestTarget;
    Setting<Double> range;
    Setting<Boolean> announceUsage;
    
    public AutoCity() {
        super("AutoCity", "AutoCity", Category.COMBAT, true, false, false);
        this.range = (Setting<Double>)this.register(new Setting("Range", (T)5.0, (T)1.0, (T)6.0));
        this.announceUsage = (Setting<Boolean>)this.register(new Setting("Announce", (T)false));
    }
    
    @Override
    public void onEnable() {
        /*SL:38*/if (AutoCity.mc.field_71439_g == null) {
            /*SL:39*/this.toggle();
            /*SL:40*/return;
        }
        MinecraftForge.EVENT_BUS.register(/*EL:42*/(Object)this);
        /*SL:43*/this.firstRun = true;
    }
    
    @Override
    public void onDisable() {
        /*SL:47*/if (AutoCity.mc.field_71439_g == null) {
            /*SL:48*/return;
        }
        MinecraftForge.EVENT_BUS.unregister(/*EL:50*/(Object)this);
        /*SL:51*/Command.sendMessage(ChatFormatting.RED.toString() + " Disabled");
    }
    
    @Override
    public void onUpdate() {
        /*SL:57*/if (AutoCity.mc.field_71439_g == null) {
            /*SL:58*/return;
        }
        /*SL:60*/this.findClosestTarget();
        /*SL:61*/if (this.closestTarget == null) {
            /*SL:62*/if (this.firstRun) {
                /*SL:63*/this.firstRun = false;
                /*SL:64*/if (this.announceUsage.getValue()) {
                    /*SL:65*/Command.sendMessage(ChatFormatting.WHITE.toString() + "Enabled" + ChatFormatting.RESET.toString() + ", no one to city!");
                }
            }
            /*SL:68*/this.toggle();
            /*SL:69*/return;
        }
        /*SL:71*/if (this.firstRun && this.mineTarget != null) {
            /*SL:72*/this.firstRun = false;
            /*SL:73*/if (this.announceUsage.getValue()) {
                /*SL:74*/Command.sendMessage(" Trying to mine: " + ChatFormatting.AQUA.toString() + this.closestTarget.func_70005_c_());
            }
        }
        /*SL:77*/this.findCityBlock();
        /*SL:78*/if (this.mineTarget != null) {
            int field_70461_c = /*EL:79*/-1;
            /*SL:80*/for (int v0 = 0; v0 < 9; ++v0) {
                final ItemStack v = AutoCity.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:81*/v0);
                /*SL:82*/if (v != ItemStack.field_190927_a && v.func_77973_b() instanceof ItemPickaxe) {
                    /*SL:83*/field_70461_c = v0;
                    /*SL:84*/break;
                }
            }
            /*SL:87*/if (field_70461_c != -1) {
                AutoCity.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:88*/field_70461_c;
            }
            AutoCity.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            AutoCity.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:91*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.mineTarget, EnumFacing.UP));
            AutoCity.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:92*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.mineTarget, EnumFacing.UP));
            /*SL:93*/this.toggle();
        }
        else {
            /*SL:96*/Command.sendMessage(TextFormatting.BLUE + "] No city blocks to mine!");
            /*SL:97*/this.toggle();
        }
    }
    
    public BlockPos findCityBlock() {
        final Double n = /*EL:103*/this.range.getValue();
        final Vec3d v0 = /*EL:104*/this.closestTarget.func_174791_d();
        /*SL:105*/if (AutoCity.mc.field_71439_g.func_174791_d().func_72438_d(v0) <= n) {
            final BlockPos v = /*EL:106*/new BlockPos(v0.func_72441_c(1.0, 0.0, 0.0));
            final BlockPos v2 = /*EL:107*/new BlockPos(v0.func_72441_c(-1.0, 0.0, 0.0));
            final BlockPos v3 = /*EL:108*/new BlockPos(v0.func_72441_c(0.0, 0.0, 1.0));
            final BlockPos v4 = /*EL:109*/new BlockPos(v0.func_72441_c(0.0, 0.0, -1.0));
            /*SL:110*/if (this.canBreak(v)) {
                /*SL:111*/this.mineTarget = v;
            }
            /*SL:113*/if (!this.canBreak(v) && this.canBreak(v2)) {
                /*SL:114*/this.mineTarget = v2;
            }
            /*SL:116*/if (!this.canBreak(v) && !this.canBreak(v2) && this.canBreak(v3)) {
                /*SL:117*/this.mineTarget = v3;
            }
            /*SL:119*/if (!this.canBreak(v) && !this.canBreak(v2) && !this.canBreak(v3) && this.canBreak(v4)) {
                /*SL:120*/this.mineTarget = v4;
            }
            /*SL:122*/if ((!this.canBreak(v) && !this.canBreak(v2) && !this.canBreak(v3) && !this.canBreak(v4)) || AutoCity.mc.field_71439_g.func_174791_d().func_72438_d(v0) > n) {
                /*SL:123*/this.mineTarget = null;
            }
        }
        /*SL:126*/return this.mineTarget;
    }
    
    private boolean canBreak(final BlockPos a1) {
        final IBlockState v1 = AutoCity.mc.field_71441_e.func_180495_p(/*EL:130*/a1);
        final Block v2 = /*EL:131*/v1.func_177230_c();
        /*SL:132*/return v2.func_176195_g(v1, (World)AutoCity.mc.field_71441_e, a1) != -1.0f;
    }
    
    private void findClosestTarget() {
        final List<EntityPlayer> field_73010_i = (List<EntityPlayer>)AutoCity.mc.field_71441_e.field_73010_i;
        /*SL:137*/this.closestTarget = null;
        /*SL:138*/for (final EntityPlayer v1 : field_73010_i) {
            /*SL:139*/if (v1 == AutoCity.mc.field_71439_g) {
                /*SL:140*/continue;
            }
            /*SL:142*/if (Legacy.friendManager.isFriend(v1.func_70005_c_())) {
                /*SL:143*/continue;
            }
            /*SL:145*/if (!isLiving((Entity)v1)) {
                /*SL:146*/continue;
            }
            /*SL:148*/if (v1.func_110143_aJ() <= 0.0f) {
                /*SL:149*/continue;
            }
            /*SL:151*/if (this.closestTarget == null) {
                /*SL:152*/this.closestTarget = v1;
            }
            else {
                /*SL:155*/if (AutoCity.mc.field_71439_g.func_70032_d((Entity)v1) >= AutoCity.mc.field_71439_g.func_70032_d((Entity)this.closestTarget)) {
                    /*SL:156*/continue;
                }
                /*SL:158*/this.closestTarget = v1;
            }
        }
    }
    
    public static boolean isLiving(final Entity a1) {
        /*SL:164*/return a1 instanceof EntityLivingBase;
    }
}
