package me.dev.legacy.modules.combat;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumFacing;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.init.Items;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoBed extends Module
{
    boolean moving;
    Setting<Double> range;
    Setting<Boolean> rotate;
    Setting<Boolean> dimensionCheck;
    Setting<Boolean> refill;
    
    public AutoBed() {
        super("AutoBed", "Fucked (Future)", Category.COMBAT, true, false, false);
        this.moving = false;
        this.range = (Setting<Double>)this.register(new Setting("Range", (T)4.5, (T)0.0, (T)10.0));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.dimensionCheck = (Setting<Boolean>)this.register(new Setting("DimensionCheck", (T)true));
        this.refill = (Setting<Boolean>)this.register(new Setting("RefillBed", (T)true));
    }
    
    @Override
    public void onUpdate() {
        /*SL:34*/if (this.refill.getValue()) {
            int v0 = /*EL:36*/-1;
            /*SL:37*/for (int v = 0; v < 9; ++v) {
                /*SL:38*/if (AutoBed.mc.field_71439_g.field_71071_by.func_70301_a(v) == ItemStack.field_190927_a) {
                    /*SL:39*/v0 = v;
                    /*SL:40*/break;
                }
            }
            /*SL:44*/if (this.moving && v0 != -1) {
                AutoBed.mc.field_71442_b.func_187098_a(/*EL:45*/0, v0 + 36, 0, ClickType.PICKUP, (EntityPlayer)AutoBed.mc.field_71439_g);
                /*SL:46*/this.moving = false;
                /*SL:47*/v0 = -1;
            }
            /*SL:50*/if (v0 != -1 && !(AutoBed.mc.field_71462_r instanceof GuiContainer) && AutoBed.mc.field_71439_g.field_71071_by.func_70445_o().func_190926_b()) {
                int v = /*EL:52*/-1;
                /*SL:53*/for (int v2 = 0; v2 < 45; ++v2) {
                    /*SL:54*/if (AutoBed.mc.field_71439_g.field_71071_by.func_70301_a(v2).func_77973_b() == Items.field_151104_aV && v2 >= 9) {
                        /*SL:55*/v = v2;
                        /*SL:56*/break;
                    }
                }
                /*SL:60*/if (v != -1) {
                    AutoBed.mc.field_71442_b.func_187098_a(/*EL:61*/0, v, 0, ClickType.PICKUP, (EntityPlayer)AutoBed.mc.field_71439_g);
                    /*SL:62*/this.moving = true;
                }
            }
        }
        AutoBed.mc.field_71441_e.field_147482_g.stream().filter(/*EL:67*/a1 -> a1 instanceof TileEntityBed).filter(/*EL:68*/a1 -> AutoBed.mc.field_71439_g.func_70011_f((double)a1.func_174877_v().func_177958_n(), (double)a1.func_174877_v().func_177956_o(), (double)a1.func_174877_v().func_177952_p()) <= this.range.getValue()).sorted(/*EL:70*/Comparator.<? super T, Comparable>comparing(a1 -> AutoBed.mc.field_71439_g.func_70011_f((double)a1.func_174877_v().func_177958_n(), (double)a1.func_174877_v().func_177956_o(), (double)a1.func_174877_v().func_177952_p()))).forEach(a1 -> {
            if (!this.dimensionCheck.getValue() || AutoBed.mc.field_71439_g.field_71093_bK != 0) {
                if (this.rotate.getValue()) {
                    BlockUtil.faceVectorPacketInstant(new Vec3d((Vec3i)a1.func_174877_v().func_177963_a(0.5, 0.5, 0.5)));
                }
                AutoBed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(a1.func_174877_v(), EnumFacing.UP, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
        });
    }
}
