package me.dev.legacy.modules.combat;

import net.minecraft.block.BlockWeb;
import net.minecraft.block.BlockObsidian;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.Item;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.item.ItemSword;
import java.util.function.ToIntFunction;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.AbstractModule;
import org.lwjgl.input.Mouse;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHand;
import me.dev.legacy.api.event.events.block.ProcessRightClickBlockEvent;
import java.util.concurrent.ConcurrentLinkedQueue;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.api.util.InventoryUtil;
import java.util.Queue;
import me.dev.legacy.modules.Module;

public class Offhand extends Module
{
    private static Offhand instance;
    private final Queue<InventoryUtil.Task> taskList;
    private final Timer timer;
    private final Timer secondTimer;
    public Setting<Boolean> crystal;
    public Setting<Float> crystalHealth;
    public Setting<Float> crystalHoleHealth;
    public Setting<Boolean> gapple;
    public Setting<Boolean> armorCheck;
    public Setting<Boolean> crystalCheck;
    public Setting<Integer> actions;
    public Mode2 currentMode;
    public int totems;
    public int crystals;
    public int gapples;
    public int lastTotemSlot;
    public int lastGappleSlot;
    public int lastCrystalSlot;
    public int lastObbySlot;
    public int lastWebSlot;
    public boolean holdingCrystal;
    public boolean holdingTotem;
    public boolean holdingGapple;
    public boolean didSwitchThisTick;
    private boolean second;
    private boolean switchedForHealthReason;
    
    public Offhand() {
        super("Offhand", "Allows you to switch up your Offhand.", Category.COMBAT, true, false, false);
        this.taskList = new ConcurrentLinkedQueue<InventoryUtil.Task>();
        this.timer = new Timer();
        this.secondTimer = new Timer();
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystal", (T)true));
        this.crystalHealth = (Setting<Float>)this.register(new Setting("CrystalHP", (T)14.5f, (T)0.1f, (T)36.0f));
        this.crystalHoleHealth = (Setting<Float>)this.register(new Setting("CrystalHoleHP", (T)14.5f, (T)0.1f, (T)36.0f));
        this.gapple = (Setting<Boolean>)this.register(new Setting("Gapple", (T)true));
        this.armorCheck = (Setting<Boolean>)this.register(new Setting("ArmorCheck", (T)true));
        this.crystalCheck = (Setting<Boolean>)this.register(new Setting("CrystalCheck", (T)true));
        this.actions = (Setting<Integer>)this.register(new Setting("Packets", (T)4, (T)1, (T)4));
        this.currentMode = Mode2.TOTEMS;
        this.totems = 0;
        this.crystals = 0;
        this.gapples = 0;
        this.lastTotemSlot = -1;
        this.lastGappleSlot = -1;
        this.lastCrystalSlot = -1;
        this.lastObbySlot = -1;
        this.lastWebSlot = -1;
        this.holdingCrystal = false;
        this.holdingTotem = false;
        this.holdingGapple = false;
        this.didSwitchThisTick = false;
        this.second = false;
        this.switchedForHealthReason = false;
        Offhand.instance = this;
    }
    
    public static Offhand getInstance() {
        /*SL:68*/if (Offhand.instance == null) {
            Offhand.instance = /*EL:69*/new Offhand();
        }
        /*SL:71*/return Offhand.instance;
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final ProcessRightClickBlockEvent a1) {
        /*SL:76*/if (a1.hand == EnumHand.MAIN_HAND && a1.stack.func_77973_b() == Items.field_185158_cP && Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && Offhand.mc.field_71476_x != null && a1.pos == Offhand.mc.field_71476_x.func_178782_a()) {
            /*SL:77*/a1.setCanceled(true);
            Offhand.mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
            Offhand.mc.field_71442_b.func_187101_a((EntityPlayer)Offhand.mc.field_71439_g, (World)Offhand.mc.field_71441_e, EnumHand.OFF_HAND);
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:85*/if (this.timer.passedMs(50L)) {
            /*SL:86*/if (Offhand.mc.field_71439_g != null && Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && Offhand.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && Mouse.isButtonDown(1)) {
                Offhand.mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
                Offhand.mc.field_71474_y.field_74313_G.field_74513_e = /*EL:88*/Mouse.isButtonDown(1);
            }
        }
        else/*SL:90*/ if (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && Offhand.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) {
            Offhand.mc.field_71474_y.field_74313_G.field_74513_e = /*EL:91*/false;
        }
        /*SL:93*/if (AbstractModule.nullCheck()) {
            /*SL:94*/return;
        }
        /*SL:96*/this.doOffhand();
        /*SL:97*/if (this.secondTimer.passedMs(50L) && this.second) {
            /*SL:98*/this.second = false;
            /*SL:99*/this.timer.reset();
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v0) {
        /*SL:105*/if (!AbstractModule.fullNullCheck() && Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && Offhand.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && Offhand.mc.field_71474_y.field_74313_G.func_151470_d()) {
            /*SL:107*/if (v0.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                final CPacketPlayerTryUseItemOnBlock a1 = /*EL:108*/(CPacketPlayerTryUseItemOnBlock)v0.getPacket();
                /*SL:109*/if (a1.func_187022_c() == EnumHand.MAIN_HAND) {
                    /*SL:110*/if (this.timer.passedMs(50L)) {
                        Offhand.mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
                        Offhand.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:112*/(Packet)new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
                    }
                    /*SL:114*/v0.setCanceled(true);
                }
            }
            else {
                final CPacketPlayerTryUseItem v;
                /*SL:116*/if (v0.getPacket() instanceof CPacketPlayerTryUseItem && (v = (CPacketPlayerTryUseItem)v0.getPacket()).func_187028_a() == EnumHand.OFF_HAND && !this.timer.passedMs(50L)) {
                    /*SL:117*/v0.setCanceled(true);
                }
            }
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:124*/if (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            /*SL:125*/return "Crystal";
        }
        /*SL:127*/if (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            /*SL:128*/return "Totem";
        }
        /*SL:130*/if (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao) {
            /*SL:131*/return "Gapple";
        }
        /*SL:133*/return null;
    }
    
    public void doOffhand() {
        /*SL:137*/this.didSwitchThisTick = false;
        /*SL:138*/this.holdingCrystal = (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
        /*SL:139*/this.holdingTotem = (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY);
        /*SL:140*/this.holdingGapple = (Offhand.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao);
        /*SL:141*/this.totems = Offhand.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(a1 -> a1.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();
        /*SL:142*/if (this.holdingTotem) {
            /*SL:143*/this.totems += Offhand.mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(a1 -> a1.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();
        }
        /*SL:145*/this.crystals = Offhand.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(a1 -> a1.func_77973_b() == Items.field_185158_cP).mapToInt(ItemStack::func_190916_E).sum();
        /*SL:146*/if (this.holdingCrystal) {
            /*SL:147*/this.crystals += Offhand.mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(a1 -> a1.func_77973_b() == Items.field_185158_cP).mapToInt(ItemStack::func_190916_E).sum();
        }
        /*SL:149*/this.gapples = Offhand.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(a1 -> a1.func_77973_b() == Items.field_151153_ao).mapToInt(ItemStack::func_190916_E).sum();
        /*SL:150*/if (this.holdingGapple) {
            /*SL:151*/this.gapples += Offhand.mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(a1 -> a1.func_77973_b() == Items.field_151153_ao).mapToInt(ItemStack::func_190916_E).sum();
        }
        /*SL:153*/this.doSwitch();
    }
    
    public void doSwitch() {
        /*SL:157*/this.currentMode = Mode2.TOTEMS;
        /*SL:158*/if (this.gapple.getValue() && Offhand.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword && Offhand.mc.field_71474_y.field_74313_G.func_151470_d()) {
            /*SL:159*/this.currentMode = Mode2.GAPPLES;
        }
        else/*SL:160*/ if (this.currentMode != Mode2.CRYSTALS && this.crystal.getValue() && ((EntityUtil.isSafe((Entity)Offhand.mc.field_71439_g) && EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) > this.crystalHoleHealth.getValue()) || EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) > this.crystalHealth.getValue())) {
            /*SL:161*/this.currentMode = Mode2.CRYSTALS;
        }
        /*SL:163*/if (this.currentMode == Mode2.CRYSTALS && this.crystals == 0) {
            /*SL:164*/this.setMode(Mode2.TOTEMS);
        }
        /*SL:166*/if (this.currentMode == Mode2.CRYSTALS && ((!EntityUtil.isSafe((Entity)Offhand.mc.field_71439_g) && EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) <= this.crystalHealth.getValue()) || EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) <= this.crystalHoleHealth.getValue())) {
            /*SL:167*/if (this.currentMode == Mode2.CRYSTALS) {
                /*SL:168*/this.switchedForHealthReason = true;
            }
            /*SL:170*/this.setMode(Mode2.TOTEMS);
        }
        /*SL:172*/if (this.switchedForHealthReason && ((EntityUtil.isSafe((Entity)Offhand.mc.field_71439_g) && EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) > this.crystalHoleHealth.getValue()) || EntityUtil.getHealth((Entity)Offhand.mc.field_71439_g, true) > this.crystalHealth.getValue())) {
            /*SL:173*/this.setMode(Mode2.CRYSTALS);
            /*SL:174*/this.switchedForHealthReason = false;
        }
        /*SL:176*/if (this.currentMode == Mode2.CRYSTALS && this.armorCheck.getValue() && (Offhand.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_190931_a || Offhand.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() == Items.field_190931_a || Offhand.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() == Items.field_190931_a || Offhand.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() == Items.field_190931_a)) {
            /*SL:177*/this.setMode(Mode2.TOTEMS);
        }
        /*SL:179*/if (Offhand.mc.field_71462_r instanceof GuiContainer && !(Offhand.mc.field_71462_r instanceof GuiInventory)) {
            /*SL:180*/return;
        }
        final Item v0 = Offhand.mc.field_71439_g.func_184592_cb().func_77973_b();
        /*SL:183*/switch (this.currentMode) {
            case TOTEMS: {
                /*SL:185*/if (this.totems <= 0) {
                    break;
                }
                if (this.holdingTotem) {
                    break;
                }
                /*SL:186*/this.lastTotemSlot = InventoryUtil.findItemInventorySlot(Items.field_190929_cY, false);
                final int v = /*EL:187*/this.getLastSlot(v0, this.lastTotemSlot);
                /*SL:188*/this.putItemInOffhand(this.lastTotemSlot, v);
                /*SL:189*/break;
            }
            case GAPPLES: {
                /*SL:192*/if (this.gapples <= 0) {
                    break;
                }
                if (this.holdingGapple) {
                    break;
                }
                /*SL:193*/this.lastGappleSlot = InventoryUtil.findItemInventorySlot(Items.field_151153_ao, false);
                final int v = /*EL:194*/this.getLastSlot(v0, this.lastGappleSlot);
                /*SL:195*/this.putItemInOffhand(this.lastGappleSlot, v);
                /*SL:196*/break;
            }
            default: {
                /*SL:199*/if (this.crystals <= 0) {
                    break;
                }
                if (this.holdingCrystal) {
                    break;
                }
                /*SL:200*/this.lastCrystalSlot = InventoryUtil.findItemInventorySlot(Items.field_185158_cP, false);
                final int v = /*EL:201*/this.getLastSlot(v0, this.lastCrystalSlot);
                /*SL:202*/this.putItemInOffhand(this.lastCrystalSlot, v);
                break;
            }
        }
        /*SL:205*/for (int v = 0; v < this.actions.getValue(); ++v) {
            final InventoryUtil.Task v2 = /*EL:206*/this.taskList.poll();
            /*SL:207*/if (v2 != null) {
                /*SL:208*/v2.run();
                /*SL:209*/if (v2.isSwitching()) {
                    /*SL:210*/this.didSwitchThisTick = true;
                }
            }
        }
    }
    
    private boolean shouldTotem() {
        final boolean v1 = Offhand.mc.field_71439_g.func_110143_aJ() + Offhand.mc.field_71439_g.func_110139_bj() <= /*EL:215*/this.crystalHealth.getValue();
        final boolean v2 = /*EL:216*/!this.isCrystalsAABBEmpty();
        /*SL:217*/if (this.crystalCheck.getValue()) {
            /*SL:218*/return v1 || v2;
        }
        /*SL:219*/return v1;
    }
    
    private boolean isCrystalsAABBEmpty() {
        /*SL:223*/return this.isEmpty(Offhand.mc.field_71439_g.func_180425_c().func_177982_a(1, 0, 0)) && this.isEmpty(Offhand.mc.field_71439_g.func_180425_c().func_177982_a(/*EL:224*/-1, 0, 0)) && this.isEmpty(Offhand.mc.field_71439_g.func_180425_c().func_177982_a(/*EL:225*/0, 0, 1)) && this.isEmpty(Offhand.mc.field_71439_g.func_180425_c().func_177982_a(/*EL:226*/0, 0, -1)) && this.isEmpty(Offhand.mc.field_71439_g.func_180425_c());
    }
    
    private boolean isEmpty(final BlockPos a1) {
        final List<Entity> v1 = (List<Entity>)Offhand.mc.field_71441_e.func_72839_b(/*EL:231*/(Entity)null, new AxisAlignedBB(a1)).stream().filter(a1 -> a1 instanceof EntityEnderCrystal).collect(Collectors.<Object>toList());
        /*SL:232*/return v1.isEmpty();
    }
    
    private int getLastSlot(final Item a1, final int a2) {
        /*SL:236*/if (a1 == Items.field_185158_cP) {
            /*SL:237*/return this.lastCrystalSlot;
        }
        /*SL:239*/if (a1 == Items.field_151153_ao) {
            /*SL:240*/return this.lastGappleSlot;
        }
        /*SL:242*/if (a1 == Items.field_190929_cY) {
            /*SL:243*/return this.lastTotemSlot;
        }
        /*SL:245*/if (InventoryUtil.isBlock(a1, BlockObsidian.class)) {
            /*SL:246*/return this.lastObbySlot;
        }
        /*SL:248*/if (InventoryUtil.isBlock(a1, BlockWeb.class)) {
            /*SL:249*/return this.lastWebSlot;
        }
        /*SL:251*/if (a1 == Items.field_190931_a) {
            /*SL:252*/return -1;
        }
        /*SL:254*/return a2;
    }
    
    private void putItemInOffhand(final int a1, final int a2) {
        /*SL:258*/if (a1 != -1 && this.taskList.isEmpty()) {
            /*SL:259*/this.taskList.add(new InventoryUtil.Task(a1));
            /*SL:260*/this.taskList.add(new InventoryUtil.Task(45));
            /*SL:261*/this.taskList.add(new InventoryUtil.Task(a2));
            /*SL:262*/this.taskList.add(new InventoryUtil.Task());
        }
    }
    
    public void setMode(final Mode2 a1) {
        /*SL:267*/this.currentMode = ((this.currentMode == a1) ? Mode2.TOTEMS : a1);
    }
    
    public enum Mode2
    {
        TOTEMS, 
        GAPPLES, 
        CRYSTALS;
    }
}
