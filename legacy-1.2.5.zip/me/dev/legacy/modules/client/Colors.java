package me.dev.legacy.modules.client;

import me.dev.legacy.api.util.ColorUtil;
import java.awt.Color;
import me.dev.legacy.api.event.ClientEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.util.ColorHandler;
import me.dev.legacy.api.event.events.update.UpdateEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Colors extends Module
{
    private static Colors INSTANCE;
    public Setting<Boolean> rainbow;
    public Setting<rainbowMode> rainbowModeHud;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    public static Setting<Object> saturation;
    Setting<Integer> red;
    Setting<Integer> green;
    Setting<Integer> blue;
    Setting<Integer> alpha;
    int ticks;
    
    public Colors() {
        super("Colors", "Colors for sync.", Category.CLIENT, true, false, false);
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)true));
        this.rainbowModeHud = (Setting<rainbowMode>)this.register(new Setting("HRainbowMode", (T)rainbowMode.Static, a1 -> this.rainbow.getValue()));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", (T)200, (T)0, (T)600, a1 -> this.rainbow.getValue()));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", (T)255.0f, (T)1.0f, (T)255.0f, a1 -> this.rainbow.getValue()));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", (T)100.0f, (T)1.0f, (T)255.0f, a1 -> this.rainbow.getValue()));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.setInstance();
    }
    
    public static Colors getInstance() {
        /*SL:35*/if (Colors.INSTANCE == null) {
            Colors.INSTANCE = /*EL:36*/new Colors();
        }
        /*SL:38*/return Colors.INSTANCE;
    }
    
    private void setInstance() {
        Colors.INSTANCE = /*EL:42*/this;
    }
    
    @SubscribeEvent
    public void onUpdate(final UpdateEvent a1) {
        /*SL:64*/if (this.ticks++ < 10) {
            /*SL:65*/ColorHandler.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue());
        }
    }
    
    @SubscribeEvent
    public void onClientEvent(final ClientEvent a1) {
        /*SL:71*/if (a1.getProperty() == this.red || a1.getProperty() == this.green || a1.getProperty() == this.blue) {
            /*SL:72*/ColorHandler.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue());
        }
    }
    
    public int getCurrentColorHex() {
        /*SL:77*/if (this.rainbow.getValue()) {
            /*SL:78*/return Color.HSBtoRGB(this.rainbowHue.getValue(), (int)(Object)this.rainbowSaturation.getValue() / 255.0f, (int)(Object)this.rainbowBrightness.getValue() / 255.0f);
        }
        /*SL:80*/return ColorUtil.toARGB(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }
    
    static {
        Colors.INSTANCE = new Colors();
    }
    
    public enum rainbowModeArray
    {
        Static, 
        Up;
    }
    
    public enum rainbowMode
    {
        Static;
    }
}
