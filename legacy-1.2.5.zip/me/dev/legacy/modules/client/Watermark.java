package me.dev.legacy.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.api.util.RainbowUtil;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.api.util.Colour;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import me.dev.legacy.api.util.HudUtil;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Watermark extends Module
{
    private static Watermark INSTANCE;
    public Setting<Integer> waterMarkX;
    public Setting<Integer> waterMarkY;
    public Setting<Integer> waterMarkoffset;
    public Setting<Boolean> Fps;
    public Setting<Boolean> Tps;
    public Setting<Boolean> Time;
    public Setting<Boolean> Ping;
    String text;
    
    public Watermark() {
        super("Watermark", "CSGO watermark", Category.CLIENT, true, false, false);
        this.waterMarkX = (Setting<Integer>)this.register(new Setting("WatermarkPosX", (T)740, (T)0, (T)885));
        this.waterMarkY = (Setting<Integer>)this.register(new Setting("WatermarkPosY", (T)2, (T)0, (T)100));
        this.waterMarkoffset = (Setting<Integer>)this.register(new Setting("Offset", (T)1000, (T)0, (T)1000));
        this.Fps = (Setting<Boolean>)this.register(new Setting("Fps", (T)false));
        this.Tps = (Setting<Boolean>)this.register(new Setting("Tps", (T)false));
        this.Time = (Setting<Boolean>)this.register(new Setting("Time", (T)false));
        this.Ping = (Setting<Boolean>)this.register(new Setting("Ping", (T)false));
        this.text = "";
        this.setInstance();
    }
    
    public static Watermark getInstance() {
        /*SL:30*/if (Watermark.INSTANCE == null) {
            Watermark.INSTANCE = /*EL:31*/new Watermark();
        }
        /*SL:32*/return Watermark.INSTANCE;
    }
    
    private void setInstance() {
        Watermark.INSTANCE = /*EL:36*/this;
    }
    
    public int getHeight() {
        /*SL:42*/return HudUtil.getHudStringHeight(this.text);
    }
    
    public int getWidth() {
        /*SL:47*/return HudUtil.getHudStringWidth(this.text);
    }
    
    @Override
    public void onRender2D(final Render2DEvent a1) {
        final int v1 = /*EL:52*/5;
        final Colour v2 = /*EL:53*/new Colour(0, 0, 0, 255);
        final Colour v3 = /*EL:54*/new Colour(127, 127, 127, 255);
        /*SL:55*/RenderUtil.drawBorderedRect(this.waterMarkX.getValue() - v1, this.waterMarkY.getValue() - v1, this.waterMarkX.getValue() + /*EL:56*/v1 + this.getWidth(), this.waterMarkY.getValue() + v1 + this.getHeight() - 1, 1, v2.hashCode(), v3.hashCode(), false);
        /*SL:57*/RenderUtil.drawHLineG(this.waterMarkX.getValue() - v1, this.waterMarkY.getValue() - v1 + 1, this.waterMarkX.getValue() + /*EL:58*/v1 + this.getWidth() - 1 - (this.waterMarkX.getValue() - v1 - 1), RainbowUtil.getColour().hashCode(), RainbowUtil.getFurtherColour(Watermark.INSTANCE.waterMarkoffset.getValue()).hashCode());
        /*SL:59*/this.text = "legacy" + ChatFormatting.RESET + " | " + Watermark.mc.field_71439_g.func_70005_c_();
        /*SL:61*/if (getInstance().Fps.getValue()) {
            /*SL:62*/this.text = this.text + " |" + HudUtil.getFpsLine() + "Fps" + ChatFormatting.RESET;
        }
        /*SL:64*/if (getInstance().Tps.getValue()) {
            /*SL:65*/this.text = this.text + " |" + HudUtil.getTpsLine() + "Tps" + ChatFormatting.RESET;
        }
        /*SL:67*/if (getInstance().Ping.getValue()) {
            /*SL:68*/this.text = this.text + " |" + HudUtil.getPingLine() + "Ms" + ChatFormatting.RESET;
        }
        /*SL:70*/if (getInstance().Time.getValue()) {
            /*SL:71*/this.text = this.text + " | " + HudUtil.getAnaTimeLine() + ChatFormatting.RESET;
        }
        /*SL:74*/HudUtil.drawHudString(this.text, this.waterMarkX.getValue(), this.waterMarkY.getValue(), new Colour(255, 255, 255, 255).hashCode());
    }
    
    static {
        Watermark.INSTANCE = new Watermark();
    }
}
