package me.dev.legacy.modules.client;

import java.util.List;
import me.dev.legacy.api.util.HudUtil;
import me.dev.legacy.Legacy;
import net.minecraft.client.gui.ScaledResolution;
import me.dev.legacy.api.util.RainbowUtil;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.api.util.Colour;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import net.minecraft.client.Minecraft;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.ModuleManifest;
import me.dev.legacy.modules.Module;

@ModuleManifest(label = "CsArrsyList", category = Category.CLIENT)
public class ModulesList extends Module
{
    public Setting<Integer> arrayX;
    public Setting<Integer> arrayY;
    public Setting<Integer> arrayoffset;
    private static ModulesList INSTANCE;
    public static final Minecraft mc;
    int width;
    int height;
    
    public ModulesList() {
        super("ArrayList", "CSGO arraylist", Category.CLIENT, true, false, false);
        this.arrayX = (Setting<Integer>)this.register(new Setting("arraylistPosX", (T)740, (T)0, (T)885));
        this.arrayY = (Setting<Integer>)this.register(new Setting("arraylistPosY", (T)2, (T)0, (T)1000));
        this.arrayoffset = (Setting<Integer>)this.register(new Setting("arraylistOffSet", (T)2, (T)0, (T)1000));
        this.width = 0;
        this.height = 0;
        this.setInstance();
    }
    
    public static ModulesList getInstance() {
        /*SL:31*/if (ModulesList.INSTANCE == null) {
            ModulesList.INSTANCE = /*EL:32*/new ModulesList();
        }
        /*SL:33*/return ModulesList.INSTANCE;
    }
    
    private void setInstance() {
        ModulesList.INSTANCE = /*EL:37*/this;
    }
    
    public int getWidth() {
        /*SL:45*/return this.width;
    }
    
    public int getHeight() {
        /*SL:50*/return this.height;
    }
    
    @Override
    public void onRender2D(final Render2DEvent v-11) {
        final int n = /*EL:55*/5;
        final Colour colour = /*EL:56*/new Colour(0, 0, 0, 255);
        final Colour colour2 = /*EL:57*/new Colour(127, 127, 127, 255);
        /*SL:58*/RenderUtil.drawBorderedRect(this.arrayX.getValue() - n, this.arrayY.getValue() - n, this.arrayX.getValue() + /*EL:59*/n + this.getWidth(), this.arrayY.getValue() + this.getHeight() - 1, 1, colour.hashCode(), colour2.hashCode(), false);
        /*SL:60*/RenderUtil.drawHLineG(this.arrayX.getValue() - n, this.arrayY.getValue() - n, this.arrayX.getValue() + /*EL:61*/n + this.getWidth() - (this.arrayX.getValue() - n), RainbowUtil.getColour().hashCode(), RainbowUtil.getFurtherColour(this.arrayoffset.getValue()).hashCode());
        final ScaledResolution scaledResolution = /*EL:63*/new ScaledResolution(ModulesList.mc);
        boolean b = /*EL:64*/false;
        boolean b2 = /*EL:65*/false;
        /*SL:66*/if (this.arrayX.getValue() < scaledResolution.func_78328_b() / 2.0f) {
            /*SL:67*/b = true;
        }
        /*SL:69*/if (this.arrayX.getValue() < scaledResolution.func_78326_a() / 2.0f) {
            /*SL:70*/b2 = true;
        }
        final List<Module> enabledModules = Legacy.moduleManager.getEnabledModules();
        int width = /*EL:73*/0;
        int height = /*EL:74*/0;
        /*SL:75*/if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.ABC) {
            /*SL:76*/for (int i = 0; i < Legacy.moduleManager.sortedModulesABC.size(); ++i) {
                final String a1 = Legacy.moduleManager.sortedModulesABC.get(/*EL:77*/i);
                /*SL:79*/HudUtil.drawHudString(a1, this.arrayX.getValue(), this.arrayY.getValue() + height, new Colour(255, 255, 255, 255).hashCode());
                final int v1 = /*EL:80*/HudUtil.getHudStringWidth(a1);
                /*SL:81*/if (v1 > width) {
                    /*SL:82*/width = v1;
                }
                /*SL:85*/height += 11;
            }
            /*SL:87*/this.height = height;
            /*SL:88*/this.width = width;
        }
    }
    
    static {
        ModulesList.INSTANCE = new ModulesList();
        mc = Minecraft.func_71410_x();
    }
}
