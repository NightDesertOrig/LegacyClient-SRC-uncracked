package me.dev.legacy.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.client.network.NetworkPlayerInfo;
import me.dev.legacy.modules.Module;

public class TabFriends extends Module
{
    public static TabFriends INSTANCE;
    
    public TabFriends() {
        super("TabFriends", "TabModify", Category.CLIENT, true, false, false);
        TabFriends.INSTANCE = this;
    }
    
    public static String getPlayerName(final NetworkPlayerInfo a1) {
        final String v2;
        final String v1 = /*EL:19*/v2 = ((a1.func_178854_k() != null) ? a1.func_178854_k().func_150254_d() : ScorePlayerTeam.func_96667_a((Team)a1.func_178850_i(), a1.func_178845_a().getName()));
        /*SL:20*/return Legacy.friendManager.isFriend(v1) ? (ChatFormatting.BOLD + ChatFormatting.LIGHT_PURPLE.toString() + v1) : v1;
    }
}
