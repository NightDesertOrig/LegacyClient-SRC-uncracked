package me.dev.legacy.modules.client;

import java.awt.GraphicsEnvironment;
import me.dev.legacy.Legacy;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.impl.command.Command;
import me.dev.legacy.api.event.ClientEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Font extends Module
{
    private boolean reloadFont;
    public Setting<String> fontName;
    public Setting<Integer> fontSize;
    public Setting<Integer> fontStyle;
    public Setting<Boolean> antiAlias;
    public Setting<Boolean> fractionalMetrics;
    public Setting<Boolean> shadow;
    public Setting<Boolean> showFonts;
    public Setting<Boolean> full;
    private static Font INSTANCE;
    
    public Font() {
        super("CustomFont", "CustomFont for all of the clients text. Use the font command.", Category.CLIENT, true, false, false);
        this.reloadFont = false;
        this.fontName = (Setting<String>)this.register(new Setting("FontName", (T)"Arial", "Name of the font."));
        this.fontSize = (Setting<Integer>)this.register(new Setting("FontSize", (T)18, "Size of the font."));
        this.fontStyle = (Setting<Integer>)this.register(new Setting("FontStyle", (T)0, "Style of the font."));
        this.antiAlias = (Setting<Boolean>)this.register(new Setting("AntiAlias", (T)true, "Smoother font."));
        this.fractionalMetrics = (Setting<Boolean>)this.register(new Setting("Metrics", (T)true, "Thinner font."));
        this.shadow = (Setting<Boolean>)this.register(new Setting("Shadow", (T)true, "Less shadow offset font."));
        this.showFonts = (Setting<Boolean>)this.register(new Setting("Fonts", (T)false, "Shows all fonts."));
        this.full = (Setting<Boolean>)this.register(new Setting("Full", (T)false));
        this.setInstance();
    }
    
    private void setInstance() {
        Font.INSTANCE = /*EL:30*/this;
    }
    
    public static Font getInstance() {
        /*SL:34*/if (Font.INSTANCE == null) {
            Font.INSTANCE = /*EL:35*/new Font();
        }
        /*SL:37*/return Font.INSTANCE;
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent v2) {
        final Setting a1;
        /*SL:43*/if (v2.getStage() == 2 && (a1 = v2.getSetting()) != null && a1.getFeature().equals(this)) {
            /*SL:44*/if (a1.getName().equals("FontName") && !checkFont(a1.getPlannedValue().toString(), false)) {
                /*SL:45*/Command.sendMessage("�cThat font doesnt exist.");
                /*SL:46*/v2.setCanceled(true);
                /*SL:47*/return;
            }
            /*SL:49*/this.reloadFont = true;
        }
    }
    
    @Override
    public void onTick() {
        /*SL:55*/if (this.showFonts.getValue()) {
            checkFont(/*EL:56*/"Hello", true);
            /*SL:57*/Command.sendMessage("Current Font: " + this.fontName.getValue());
            /*SL:58*/this.showFonts.setValue(false);
        }
        /*SL:60*/if (this.reloadFont) {
            Legacy.textManager.init(/*EL:61*/false);
            /*SL:62*/this.reloadFont = false;
        }
    }
    
    public static boolean checkFont(final String a2, final boolean v1) {
        final String[] availableFontFamilyNames;
        final String[] v2 = /*EL:68*/availableFontFamilyNames = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (final String a3 : availableFontFamilyNames) {
            /*SL:69*/if (!v1 && a3.equals(a2)) {
                /*SL:70*/return true;
            }
            /*SL:72*/if (v1) {
                /*SL:73*/Command.sendMessage(a3);
            }
        }
        /*SL:75*/return false;
    }
    
    static {
        Font.INSTANCE = new Font();
    }
}
