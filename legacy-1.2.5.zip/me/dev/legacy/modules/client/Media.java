package me.dev.legacy.modules.client;

import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Media extends Module
{
    public final Setting<String> NameString;
    private static Media instance;
    
    public Media() {
        super("Media", "Changes name", Category.CLIENT, false, false, false);
        this.NameString = (Setting<String>)this.register(new Setting("Name", (T)"New Name Here..."));
        Media.instance = this;
    }
    
    @Override
    public void onEnable() {
        /*SL:19*/Command.sendMessage(ChatFormatting.GRAY + "Success! Name succesfully changed to " + ChatFormatting.GREEN + this.NameString.getValue());
    }
    
    public static Media getInstance() {
        /*SL:23*/if (Media.instance == null) {
            Media.instance = /*EL:24*/new Media();
        }
        /*SL:26*/return Media.instance;
    }
}
