package me.dev.legacy.modules;

import java.util.concurrent.TimeUnit;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.Util;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.Locale;
import me.dev.legacy.impl.gui.LegacyGui;
import org.lwjgl.input.Keyboard;
import java.util.Collection;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Comparator;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import java.util.function.Consumer;
import net.minecraftforge.common.MinecraftForge;
import java.util.Arrays;
import java.util.Iterator;
import me.dev.legacy.modules.movement.ElytraFlight;
import me.dev.legacy.modules.movement.BoatFly;
import me.dev.legacy.modules.movement.Phase;
import me.dev.legacy.modules.movement.Strafe;
import me.dev.legacy.modules.movement.PacketFly;
import me.dev.legacy.modules.movement.AntiLevitate;
import me.dev.legacy.modules.movement.HoleTP;
import me.dev.legacy.modules.movement.Anchor;
import me.dev.legacy.modules.movement.NoWeb;
import me.dev.legacy.modules.movement.Rubberband;
import me.dev.legacy.modules.movement.IceSpeed;
import me.dev.legacy.modules.movement.Speed;
import me.dev.legacy.modules.movement.Jesus;
import me.dev.legacy.modules.movement.Step;
import me.dev.legacy.modules.movement.Sprint;
import me.dev.legacy.modules.movement.Velocity;
import me.dev.legacy.modules.movement.ReverseStep;
import me.dev.legacy.modules.movement.NoSlow;
import me.dev.legacy.modules.movement.AntiVoid;
import me.dev.legacy.modules.misc.PortalBuilder;
import me.dev.legacy.modules.misc.AutoKit;
import me.dev.legacy.modules.misc.AutoBebra;
import me.dev.legacy.modules.misc.StashLogger;
import me.dev.legacy.modules.misc.NoHitBox;
import me.dev.legacy.modules.misc.BurrowAlert;
import me.dev.legacy.modules.misc.PearlNotify;
import me.dev.legacy.modules.misc.Dupe;
import me.dev.legacy.modules.player.XCarry;
import me.dev.legacy.modules.misc.PopCounter;
import me.dev.legacy.modules.misc.Tracker;
import me.dev.legacy.modules.misc.ShulkerViewer;
import me.dev.legacy.modules.misc.MCF;
import me.dev.legacy.modules.misc.BuildHeight;
import me.dev.legacy.modules.misc.Timestamps;
import me.dev.legacy.modules.player.Scaffold;
import me.dev.legacy.modules.player.Blink;
import me.dev.legacy.modules.player.FastBreak;
import me.dev.legacy.modules.player.Reach;
import me.dev.legacy.modules.player.MultiTask;
import me.dev.legacy.modules.player.TpsSync;
import me.dev.legacy.modules.player.LiquidInteract;
import me.dev.legacy.modules.player.MCP;
import me.dev.legacy.modules.player.FakePlayer;
import me.dev.legacy.modules.player.Replenish;
import me.dev.legacy.modules.player.FastPlace;
import me.dev.legacy.modules.player.Freecam;
import me.dev.legacy.modules.player.AntiHunger;
import me.dev.legacy.modules.combat.AutoCity;
import me.dev.legacy.modules.combat.SmartBurrow;
import me.dev.legacy.modules.combat.AntiCity;
import me.dev.legacy.modules.combat.AutoBed;
import me.dev.legacy.modules.combat.BowAim;
import me.dev.legacy.modules.combat.Surround;
import me.dev.legacy.modules.combat.AntiRegear;
import me.dev.legacy.modules.combat.AutoTrap;
import me.dev.legacy.modules.combat.Aura;
import me.dev.legacy.modules.combat.Quiver;
import me.dev.legacy.modules.combat.MinDamage;
import me.dev.legacy.modules.combat.AutoLog;
import me.dev.legacy.modules.combat.AutoCrystal;
import me.dev.legacy.modules.combat.Burrow;
import me.dev.legacy.modules.combat.AutoArmor;
import me.dev.legacy.modules.combat.HoleFiller;
import me.dev.legacy.modules.combat.AutoWeb;
import me.dev.legacy.modules.combat.Offhand;
import me.dev.legacy.modules.combat.Crits;
import me.dev.legacy.modules.combat.BetterXP;
import me.dev.legacy.modules.render.Nametags;
import me.dev.legacy.modules.render.SmallShield;
import me.dev.legacy.modules.render.PlayerChams;
import me.dev.legacy.modules.render.CrystalChams;
import me.dev.legacy.modules.render.Aspect;
import me.dev.legacy.modules.render.EntityHunger;
import me.dev.legacy.modules.render.ItemViewModel;
import me.dev.legacy.modules.render.Swing;
import me.dev.legacy.modules.render.HitMarkers;
import me.dev.legacy.modules.render.Tracers;
import me.dev.legacy.modules.render.HoleESP;
import me.dev.legacy.modules.render.Fullbright;
import me.dev.legacy.modules.render.ESP;
import me.dev.legacy.modules.render.SkyColor;
import me.dev.legacy.modules.render.NoRender;
import me.dev.legacy.modules.render.Trajectories;
import me.dev.legacy.modules.render.BlockHighlight;
import me.dev.legacy.modules.client.RPC;
import me.dev.legacy.modules.client.Components;
import me.dev.legacy.modules.client.TabFriends;
import me.dev.legacy.modules.client.Colors;
import me.dev.legacy.modules.client.Friends;
import me.dev.legacy.modules.client.ModulesList;
import me.dev.legacy.modules.client.Watermark;
import me.dev.legacy.modules.client.Media;
import me.dev.legacy.modules.client.HUD;
import me.dev.legacy.modules.client.ClickGui;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import me.dev.legacy.api.AbstractModule;

public class ModuleManager extends AbstractModule
{
    public ArrayList<Module> modules;
    public List<Module> sortedModules;
    public List<String> sortedModulesABC;
    public Animation animationThread;
    private static final LinkedHashMap<String, Module> modulesNameMap;
    private static final LinkedHashMap<Class<? extends Module>, Module> modulesClassMap;
    public static ArrayList<Module> nigger;
    
    public ModuleManager() {
        this.modules = new ArrayList<Module>();
        this.sortedModules = new ArrayList<Module>();
        this.sortedModulesABC = new ArrayList<String>();
    }
    
    public void init() {
        /*SL:38*/this.modules.add(new ClickGui());
        /*SL:39*/this.modules.add(new HUD());
        /*SL:40*/this.modules.add(new Media());
        /*SL:41*/this.modules.add(new Watermark());
        /*SL:42*/this.modules.add(new ModulesList());
        /*SL:43*/this.modules.add(new Friends());
        /*SL:44*/this.modules.add(new Colors());
        /*SL:45*/this.modules.add(new TabFriends());
        /*SL:46*/this.modules.add(new Components());
        /*SL:47*/this.modules.add(new RPC());
        /*SL:49*/this.modules.add(new BlockHighlight());
        /*SL:50*/this.modules.add(new Trajectories());
        /*SL:51*/this.modules.add(new NoRender());
        /*SL:52*/this.modules.add(new SkyColor());
        /*SL:53*/this.modules.add(new ESP());
        /*SL:54*/this.modules.add(new Fullbright());
        /*SL:55*/this.modules.add(new HoleESP());
        /*SL:56*/this.modules.add(new Tracers());
        /*SL:57*/this.modules.add(new HitMarkers());
        /*SL:58*/this.modules.add(new Swing());
        /*SL:59*/this.modules.add(new ItemViewModel());
        /*SL:60*/this.modules.add(new EntityHunger());
        /*SL:61*/this.modules.add(new Aspect());
        /*SL:62*/this.modules.add(new CrystalChams());
        /*SL:63*/this.modules.add(new PlayerChams());
        /*SL:64*/this.modules.add(new SmallShield());
        /*SL:65*/this.modules.add(new Nametags());
        /*SL:67*/this.modules.add(new BetterXP());
        /*SL:68*/this.modules.add(new Crits());
        /*SL:69*/this.modules.add(new Offhand());
        /*SL:70*/this.modules.add(new AutoWeb());
        /*SL:71*/this.modules.add(new HoleFiller());
        /*SL:72*/this.modules.add(new AutoArmor());
        /*SL:73*/this.modules.add(new Burrow());
        /*SL:74*/this.modules.add(new AutoCrystal());
        /*SL:75*/this.modules.add(new AutoLog());
        /*SL:76*/this.modules.add(new MinDamage());
        /*SL:77*/this.modules.add(new Quiver());
        /*SL:78*/this.modules.add(new Aura());
        /*SL:79*/this.modules.add(new AutoTrap());
        /*SL:80*/this.modules.add(new AntiRegear());
        /*SL:81*/this.modules.add(new Surround());
        /*SL:82*/this.modules.add(new BowAim());
        /*SL:83*/this.modules.add(new AutoBed());
        /*SL:84*/this.modules.add(new AntiCity());
        /*SL:85*/this.modules.add(new SmartBurrow());
        /*SL:86*/this.modules.add(new AutoCity());
        /*SL:88*/this.modules.add(new AntiHunger());
        /*SL:89*/this.modules.add(new Freecam());
        /*SL:90*/this.modules.add(new FastPlace());
        /*SL:91*/this.modules.add(new Replenish());
        /*SL:92*/this.modules.add(new FakePlayer());
        /*SL:93*/this.modules.add(new MCP());
        /*SL:94*/this.modules.add(new LiquidInteract());
        /*SL:95*/this.modules.add(new TpsSync());
        /*SL:96*/this.modules.add(new MultiTask());
        /*SL:97*/this.modules.add(new Reach());
        /*SL:98*/this.modules.add(new FastBreak());
        /*SL:99*/this.modules.add(new Blink());
        /*SL:100*/this.modules.add(new Scaffold());
        /*SL:102*/this.modules.add(new Timestamps());
        /*SL:103*/this.modules.add(new BuildHeight());
        /*SL:104*/this.modules.add(new MCF());
        /*SL:105*/this.modules.add(new ShulkerViewer());
        /*SL:106*/this.modules.add(new Tracker());
        /*SL:107*/this.modules.add(new PopCounter());
        /*SL:108*/this.modules.add(new XCarry());
        /*SL:109*/this.modules.add(new Dupe());
        /*SL:110*/this.modules.add(new PearlNotify());
        /*SL:111*/this.modules.add(new BurrowAlert());
        /*SL:112*/this.modules.add(new NoHitBox());
        /*SL:113*/this.modules.add(new StashLogger());
        /*SL:114*/this.modules.add(new AutoBebra());
        /*SL:115*/this.modules.add(new AutoKit());
        /*SL:116*/this.modules.add(new PortalBuilder());
        /*SL:118*/this.modules.add(new AntiVoid());
        /*SL:119*/this.modules.add(new NoSlow());
        /*SL:120*/this.modules.add(new ReverseStep());
        /*SL:121*/this.modules.add(new Velocity());
        /*SL:122*/this.modules.add(new Sprint());
        /*SL:123*/this.modules.add(new Step());
        /*SL:124*/this.modules.add(new Jesus());
        /*SL:125*/this.modules.add(new Speed());
        /*SL:126*/this.modules.add(new IceSpeed());
        /*SL:127*/this.modules.add(new Rubberband());
        /*SL:128*/this.modules.add(new NoWeb());
        /*SL:129*/this.modules.add(new Anchor());
        /*SL:130*/this.modules.add(new HoleTP());
        /*SL:131*/this.modules.add(new AntiLevitate());
        /*SL:132*/this.modules.add(new PacketFly());
        /*SL:133*/this.modules.add(new Strafe());
        /*SL:134*/this.modules.add(new Phase());
        /*SL:135*/this.modules.add(new BoatFly());
        /*SL:136*/this.modules.add(new ElytraFlight());
    }
    
    public Module getModuleByName(final String v2) {
        /*SL:140*/for (final Module a1 : this.modules) {
            /*SL:141*/if (!a1.getName().equalsIgnoreCase(v2)) {
                continue;
            }
            /*SL:142*/return a1;
        }
        /*SL:144*/return null;
    }
    
    public <T extends Module> T getModuleByClass(final Class<T> v2) {
        /*SL:148*/for (final Module a1 : this.modules) {
            /*SL:149*/if (!v2.isInstance(a1)) {
                continue;
            }
            /*SL:150*/return (T)a1;
        }
        /*SL:152*/return null;
    }
    
    public void enableModule(final Class<Module> a1) {
        final Module v1 = /*EL:157*/this.<Module>getModuleByClass(a1);
        /*SL:158*/if (v1 != null) {
            /*SL:159*/v1.enable();
        }
    }
    
    public void disableModule(final Class<Module> a1) {
        final Module v1 = /*EL:164*/this.<Module>getModuleByClass(a1);
        /*SL:165*/if (v1 != null) {
            /*SL:166*/v1.disable();
        }
    }
    
    public void enableModule(final String a1) {
        final Module v1 = /*EL:171*/this.getModuleByName(a1);
        /*SL:172*/if (v1 != null) {
            /*SL:173*/v1.enable();
        }
    }
    
    public void disableModule(final String a1) {
        final Module v1 = /*EL:178*/this.getModuleByName(a1);
        /*SL:179*/if (v1 != null) {
            /*SL:180*/v1.disable();
        }
    }
    
    public Module getModuleByDisplayName(final String v2) {
        /*SL:186*/for (final Module a1 : this.modules) {
            /*SL:187*/if (!a1.getDisplayName().equalsIgnoreCase(v2)) {
                continue;
            }
            /*SL:188*/return a1;
        }
        /*SL:190*/return null;
    }
    
    public ArrayList<Module> getEnabledModules() {
        final ArrayList<Module> list = /*EL:194*/new ArrayList<Module>();
        /*SL:195*/for (final Module v1 : this.modules) {
            /*SL:196*/if (!v1.isEnabled()) {
                continue;
            }
            /*SL:197*/list.add(v1);
        }
        /*SL:199*/return list;
    }
    
    public ArrayList<String> getEnabledModulesName() {
        final ArrayList<String> list = /*EL:203*/new ArrayList<String>();
        /*SL:204*/for (final Module v1 : this.modules) {
            /*SL:205*/if (v1.isEnabled()) {
                if (!v1.isDrawn()) {
                    continue;
                }
                /*SL:206*/list.add(v1.getFullArrayString());
            }
        }
        /*SL:208*/return list;
    }
    
    public ArrayList<Module> getModulesByCategory(final Module.Category a1) {
        final ArrayList<Module> v1 = /*EL:212*/new ArrayList<Module>();
        final ArrayList<Module> list;
        /*SL:213*/this.modules.forEach(a3 -> {
            if (a3.getCategory() == a1) {
                list.add(a3);
            }
            return;
        });
        /*SL:218*/return v1;
    }
    
    public List<Module.Category> getCategories() {
        /*SL:222*/return Arrays.<Module.Category>asList(Module.Category.values());
    }
    
    public void onLoad() {
        /*SL:226*/this.modules.stream().filter(Module::listening).forEach(MinecraftForge.EVENT_BUS::register);
        /*SL:227*/this.modules.forEach(Module::onLoad);
    }
    
    public void onUpdate() {
        /*SL:231*/this.modules.stream().filter(AbstractModule::isEnabled).forEach(Module::onUpdate);
    }
    
    public void onTick() {
        /*SL:235*/this.modules.stream().filter(AbstractModule::isEnabled).forEach(Module::onTick);
    }
    
    public void onRender2D(final Render2DEvent a1) {
        /*SL:239*/this.modules.stream().filter(AbstractModule::isEnabled).forEach(a2 -> a2.onRender2D(a1));
    }
    
    public void onRender3D(final Render3DEvent a1) {
        /*SL:243*/this.modules.stream().filter(AbstractModule::isEnabled).forEach(a2 -> a2.onRender3D(a1));
    }
    
    public <T extends Module> T getModuleT(final Class<T> a1) {
        /*SL:247*/return this.modules.stream().filter(a2 -> a2.getClass() == a1).<T>map(a1 -> a1).findFirst().orElse(null);
    }
    
    public void sortModules(final boolean a1) {
        /*SL:251*/this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.<? super Object, Comparable>comparing(a2 -> this.renderer.getStringWidth(a2.getFullArrayString()) * (a1 ? -1 : 1))).<List<Module>, ?>collect((Collector<? super Object, ?, List<Module>>)Collectors.<? super Object>toList());
    }
    
    public void sortModulesABC() {
        /*SL:255*/(this.sortedModulesABC = new ArrayList<String>(this.getEnabledModulesName())).sort(String.CASE_INSENSITIVE_ORDER);
    }
    
    public void onLogout() {
        /*SL:260*/this.modules.forEach(Module::onLogout);
    }
    
    public void onLogin() {
        /*SL:264*/this.modules.forEach(Module::onLogin);
    }
    
    public void onUnload() {
        /*SL:268*/this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
        /*SL:269*/this.modules.forEach(Module::onUnload);
    }
    
    public void onUnloadPost() {
        /*SL:273*/for (final Module v1 : this.modules) {
            /*SL:274*/v1.enabled.setValue(false);
        }
    }
    
    public void onKeyPressed(final int a1) {
        /*SL:279*/if (a1 == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.field_71462_r instanceof LegacyGui) {
            /*SL:280*/return;
        }
        /*SL:282*/this.modules.forEach(a2 -> {
            if (a2.getBind().getKey() == a1) {
                a2.toggle();
            }
        });
    }
    
    public static ArrayList<Module> getModules() {
        /*SL:355*/return ModuleManager.nigger;
    }
    
    public static boolean isModuleEnablednigger(final String a1) {
        final Module v1 = getModules().stream().filter(/*EL:359*/a2 -> a2.getName().equalsIgnoreCase(a1)).findFirst().orElse(null);
        /*SL:360*/return v1.isEnabled();
    }
    
    public static boolean isModuleEnablednigger(final Module a1) {
        /*SL:364*/return a1.isEnabled();
    }
    
    public static <T extends Module> T getModule(final Class<T> a1) {
        /*SL:369*/return (T)ModuleManager.modulesClassMap.get(a1);
    }
    
    public static Module getModule(final String a1) {
        /*SL:373*/if (a1 == null) {
            return null;
        }
        /*SL:374*/return ModuleManager.modulesNameMap.get(a1.toLowerCase(Locale.ROOT));
    }
    
    public static boolean isModuleEnabled(final Class<? extends Module> a1) {
        final Module v1 = /*EL:378*/ModuleManager.<Module>getModule(a1);
        /*SL:379*/return v1 != null && v1.isEnabled();
    }
    
    public static boolean isModuleEnabled(final String a1) {
        final Module v1 = getModule(/*EL:383*/a1);
        /*SL:384*/return v1 != null && v1.isEnabled();
    }
    
    static {
        modulesNameMap = new LinkedHashMap<String, Module>();
        modulesClassMap = new LinkedHashMap<Class<? extends Module>, Module>();
    }
    
    private class Animation extends Thread
    {
        public Module module;
        public float offset;
        public float vOffset;
        ScheduledExecutorService service;
        
        public Animation() {
            super("Animation");
            this.service = Executors.newSingleThreadScheduledExecutor();
        }
        
        @Override
        public void run() {
            /*SL:303*/if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.Length) {
                /*SL:304*/for (final Module v0 : ModuleManager.this.sortedModules) {
                    final String v = /*EL:305*/v0.getDisplayName() + ChatFormatting.GRAY + ((v0.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + v0.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    /*SL:306*/v0.offset = ModuleManager.this.renderer.getStringWidth(v) / HUD.getInstance().animationHorizontalTime.getValue();
                    /*SL:307*/v0.vOffset = ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue();
                    /*SL:308*/if (v0.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        /*SL:309*/if (v0.arrayListOffset <= v0.offset) {
                            continue;
                        }
                        if (Util.mc.field_71441_e == null) {
                            continue;
                        }
                        final Module module = /*EL:310*/v0;
                        module.arrayListOffset -= v0.offset;
                        /*SL:311*/v0.sliding = true;
                    }
                    else {
                        /*SL:314*/if (!v0.isDisabled()) {
                            continue;
                        }
                        if (HUD.getInstance().animationHorizontalTime.getValue() == 1) {
                            continue;
                        }
                        /*SL:315*/if (v0.arrayListOffset < ModuleManager.this.renderer.getStringWidth(v) && Util.mc.field_71441_e != null) {
                            final Module module2 = /*EL:316*/v0;
                            module2.arrayListOffset += v0.offset;
                            /*SL:317*/v0.sliding = true;
                        }
                        else {
                            /*SL:320*/v0.sliding = false;
                        }
                    }
                }
            }
            else {
                /*SL:323*/for (final String v2 : ModuleManager.this.sortedModulesABC) {
                    final Module v3 = Legacy.moduleManager.getModuleByName(/*EL:324*/v2);
                    final String v4 = /*EL:325*/v3.getDisplayName() + ChatFormatting.GRAY + ((v3.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + v3.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    /*SL:326*/v3.offset = ModuleManager.this.renderer.getStringWidth(v4) / HUD.getInstance().animationHorizontalTime.getValue();
                    /*SL:327*/v3.vOffset = ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue();
                    /*SL:328*/if (v3.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        /*SL:329*/if (v3.arrayListOffset <= v3.offset) {
                            continue;
                        }
                        if (Util.mc.field_71441_e == null) {
                            continue;
                        }
                        final Module module3 = /*EL:330*/v3;
                        module3.arrayListOffset -= v3.offset;
                        /*SL:331*/v3.sliding = true;
                    }
                    else {
                        /*SL:334*/if (!v3.isDisabled()) {
                            continue;
                        }
                        if (HUD.getInstance().animationHorizontalTime.getValue() == 1) {
                            continue;
                        }
                        /*SL:335*/if (v3.arrayListOffset < ModuleManager.this.renderer.getStringWidth(v4) && Util.mc.field_71441_e != null) {
                            final Module module4 = /*EL:336*/v3;
                            module4.arrayListOffset += v3.offset;
                            /*SL:337*/v3.sliding = true;
                        }
                        else {
                            /*SL:340*/v3.sliding = false;
                        }
                    }
                }
            }
        }
        
        @Override
        public void start() {
            System.out.println(/*EL:347*/"Starting animation thread.");
            /*SL:348*/this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
        }
    }
}
