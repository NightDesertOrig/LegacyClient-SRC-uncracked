package me.dev.legacy.modules.misc;

import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import java.util.Iterator;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.ArrayList;
import net.minecraft.entity.Entity;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import java.util.concurrent.ConcurrentHashMap;
import me.dev.legacy.modules.Module;

public class BurrowAlert extends Module
{
    private final ConcurrentHashMap<EntityPlayer, Integer> players;
    List<EntityPlayer> anti_spam;
    List<Entity> burrowedPlayers;
    
    public BurrowAlert() {
        super("BurrowAlert", "Burrow Alert", Category.MISC, true, false, false);
        this.players = new ConcurrentHashMap<EntityPlayer, Integer>();
        this.anti_spam = new ArrayList<EntityPlayer>();
        this.burrowedPlayers = new ArrayList<Entity>();
    }
    
    @Override
    public void onEnable() {
        /*SL:29*/this.players.clear();
        /*SL:30*/this.anti_spam.clear();
    }
    
    @Override
    public void onUpdate() {
        /*SL:35*/if (BurrowAlert.mc.field_71439_g == null || BurrowAlert.mc.field_71441_e == null) {
            /*SL:36*/return;
        }
        /*SL:38*/for (final Entity v1 : (List)BurrowAlert.mc.field_71441_e.field_72996_f.stream().filter(a1 -> a1 instanceof EntityPlayer).collect(Collectors.<Object>toList())) {
            /*SL:39*/if (!(v1 instanceof EntityPlayer)) {
                /*SL:40*/continue;
            }
            /*SL:42*/if (!this.burrowedPlayers.contains(v1) && this.isBurrowed(v1)) {
                /*SL:43*/this.burrowedPlayers.add(v1);
                /*SL:44*/Command.sendMessage(ChatFormatting.RED + v1.func_70005_c_() + " has just burrowed!");
            }
            else {
                /*SL:45*/if (!this.burrowedPlayers.contains(v1) || this.isBurrowed(v1)) {
                    continue;
                }
                /*SL:46*/this.burrowedPlayers.remove(v1);
                /*SL:47*/Command.sendMessage(ChatFormatting.GREEN + v1.func_70005_c_() + " is no longer burrowed!");
            }
        }
    }
    
    private boolean isBurrowed(final Entity a1) {
        final BlockPos v1 = /*EL:53*/new BlockPos(this.roundValueToCenter(a1.field_70165_t), a1.field_70163_u + 0.2, this.roundValueToCenter(a1.field_70161_v));
        /*SL:55*/return BurrowAlert.mc.field_71441_e.func_180495_p(v1).func_177230_c() == Blocks.field_150343_Z || BurrowAlert.mc.field_71441_e.func_180495_p(v1).func_177230_c() == Blocks.field_150477_bB;
    }
    
    private double roundValueToCenter(final double a1) {
        double v1 = /*EL:63*/Math.round(a1);
        /*SL:65*/if (v1 > a1) {
            /*SL:66*/v1 -= 0.5;
        }
        else/*SL:67*/ if (v1 <= a1) {
            /*SL:68*/v1 += 0.5;
        }
        /*SL:71*/return v1;
    }
}
