package me.dev.legacy.modules.misc;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.modules.Module;

public class BuildHeight extends Module
{
    public BuildHeight() {
        super("BuildHeight", "Allows you to place at build height", Category.MISC, true, false, false);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v2) {
        final CPacketPlayerTryUseItemOnBlock a1;
        /*SL:17*/if (v2.getStage() == 0 && v2.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && (a1 = (CPacketPlayerTryUseItemOnBlock)v2.getPacket()).func_187023_a().func_177956_o() >= 255 && a1.func_187024_b() == EnumFacing.UP) {
            /*SL:18*/a1.field_149579_d = EnumFacing.DOWN;
        }
    }
}
