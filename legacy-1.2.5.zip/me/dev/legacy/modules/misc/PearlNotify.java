package me.dev.legacy.modules.misc;

import java.util.Iterator;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.Entity;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import java.util.HashMap;
import me.dev.legacy.modules.Module;

public class PearlNotify extends Module
{
    private final HashMap<EntityPlayer, UUID> list;
    private Entity enderPearl;
    private boolean flag;
    
    public PearlNotify() {
        super("PearlResolver", "Notify pearl throws.", Category.MISC, true, false, false);
        this.list = new HashMap<EntityPlayer, UUID>();
    }
    
    @Override
    public void onEnable() {
        /*SL:26*/this.flag = true;
    }
    
    @Override
    public void onUpdate() {
        /*SL:31*/if (PearlNotify.mc.field_71441_e == null || PearlNotify.mc.field_71439_g == null) {
            /*SL:32*/return;
        }
        /*SL:34*/this.enderPearl = null;
        /*SL:35*/for (final Entity v1 : PearlNotify.mc.field_71441_e.field_72996_f) {
            /*SL:36*/if (v1 instanceof EntityEnderPearl) {
                /*SL:37*/this.enderPearl = v1;
                /*SL:38*/break;
            }
        }
        /*SL:41*/if (this.enderPearl == null) {
            /*SL:42*/this.flag = true;
            /*SL:43*/return;
        }
        EntityPlayer v2 = /*EL:45*/null;
        /*SL:46*/for (final EntityPlayer v3 : PearlNotify.mc.field_71441_e.field_73010_i) {
            /*SL:47*/if (v2 == null) {
                /*SL:48*/v2 = v3;
            }
            else {
                /*SL:50*/if (v2.func_70032_d(this.enderPearl) <= v3.func_70032_d(this.enderPearl)) {
                    /*SL:51*/continue;
                }
                /*SL:53*/v2 = v3;
            }
        }
        /*SL:56*/if (v2 == PearlNotify.mc.field_71439_g) {
            /*SL:57*/this.flag = false;
        }
        /*SL:59*/if (v2 != null && this.flag) {
            String v4 = /*EL:60*/this.enderPearl.func_174811_aO().toString();
            /*SL:61*/if (v4.equals("west")) {
                /*SL:62*/v4 = "east";
            }
            else/*SL:63*/ if (v4.equals("east")) {
                /*SL:64*/v4 = "west";
            }
            /*SL:66*/Command.sendMessage(Legacy.friendManager.isFriend(v2.func_70005_c_()) ? (ChatFormatting.WHITE + v2.func_70005_c_() + ChatFormatting.AQUA + " has just thrown a pearl heading " + v4 + "!") : (ChatFormatting.WHITE + v2.func_70005_c_() + ChatFormatting.AQUA + " has just thrown a pearl heading " + v4 + "!"));
            /*SL:67*/this.flag = false;
        }
    }
}
