package me.dev.legacy.modules.misc;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.event.DeathEvent;
import java.util.Objects;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.Entity;
import me.dev.legacy.impl.command.Command;
import me.dev.legacy.modules.client.HUD;
import me.dev.legacy.api.util.TextUtil;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.modules.Module;

public class Tracker extends Module
{
    private static Tracker instance;
    private EntityPlayer trackedPlayer;
    private int usedExp;
    private int usedStacks;
    
    public Tracker() {
        super("Tracker", "Tracks players in 1v1s.", Category.MISC, true, false, false);
        this.usedExp = 0;
        this.usedStacks = 0;
        Tracker.instance = this;
    }
    
    public static Tracker getInstance() {
        /*SL:28*/if (Tracker.instance == null) {
            Tracker.instance = /*EL:29*/new Tracker();
        }
        /*SL:31*/return Tracker.instance;
    }
    
    @Override
    public void onUpdate() {
        /*SL:36*/if (this.trackedPlayer == null) {
            /*SL:37*/this.trackedPlayer = EntityUtil.getClosestEnemy(1000.0);
        }
        else/*SL:38*/ if (this.usedStacks != this.usedExp / 64) {
            /*SL:39*/this.usedStacks = this.usedExp / 64;
            /*SL:40*/Command.sendMessage(TextUtil.coloredString(this.trackedPlayer.func_70005_c_() + " has used " + this.usedStacks + " stacks of XP!", HUD.getInstance().commandColor.getValue()));
        }
    }
    
    public void onSpawnEntity(final Entity a1) {
        /*SL:45*/if (a1 instanceof EntityExpBottle && Objects.equals(Tracker.mc.field_71441_e.func_72890_a(a1, 3.0), this.trackedPlayer)) {
            /*SL:46*/++this.usedExp;
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:52*/this.trackedPlayer = null;
        /*SL:53*/this.usedExp = 0;
        /*SL:54*/this.usedStacks = 0;
    }
    
    @SubscribeEvent
    public void onDeath(final DeathEvent a1) {
        /*SL:59*/if (a1.player.equals((Object)this.trackedPlayer)) {
            /*SL:60*/this.usedExp = 0;
            /*SL:61*/this.usedStacks = 0;
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:67*/if (this.trackedPlayer != null) {
            /*SL:68*/return this.trackedPlayer.func_70005_c_();
        }
        /*SL:70*/return null;
    }
}
