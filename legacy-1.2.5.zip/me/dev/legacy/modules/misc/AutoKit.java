package me.dev.legacy.modules.misc;

import me.dev.legacy.api.event.events.event.DeathEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketChatMessage;
import me.dev.legacy.impl.setting.Bind;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoKit extends Module
{
    public Setting<String> primaryKit;
    public Setting<String> secondaryKit;
    public Setting<Bind> swapBind;
    private boolean toggle;
    private boolean runThisLife;
    public static AutoKit INSTANCE;
    
    public AutoKit() {
        super("AutoKit", "Automatically does /kit <name>", Category.MISC, true, false, false);
        this.primaryKit = (Setting<String>)this.register(new Setting("Primary Kit", (T)"ffa"));
        this.secondaryKit = (Setting<String>)this.register(new Setting("Secondary Kit", (T)"duel"));
        this.swapBind = (Setting<Bind>)this.register(new Setting("SwapBind", (T)new Bind(-1)));
        this.toggle = false;
        this.runThisLife = false;
        this.setInstance();
    }
    
    public static AutoKit getInstance() {
        /*SL:26*/if (AutoKit.INSTANCE == null) {
            AutoKit.INSTANCE = /*EL:27*/new AutoKit();
        }
        /*SL:29*/return AutoKit.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        /*SL:33*/if (AutoKit.mc.field_71439_g.func_70089_S() && !this.runThisLife) {
            AutoKit.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:34*/(Packet)new CPacketChatMessage("/kit " + (this.toggle ? this.secondaryKit.getValue() : this.primaryKit.getValue())));
            /*SL:35*/this.runThisLife = true;
        }
    }
    
    @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
    public void onKeyInput(final InputEvent.KeyInputEvent a1) {
        /*SL:44*/if (Keyboard.getEventKeyState() && this.swapBind.getValue().getKey() == Keyboard.getEventKey()) {
            /*SL:45*/this.toggle = !this.toggle;
        }
    }
    
    @SubscribeEvent
    public void onEntityDeath(final DeathEvent a1) {
        /*SL:51*/if (a1.player == AutoKit.mc.field_71439_g) {
            /*SL:52*/this.runThisLife = false;
        }
    }
    
    private void setInstance() {
        AutoKit.INSTANCE = /*EL:57*/this;
    }
}
