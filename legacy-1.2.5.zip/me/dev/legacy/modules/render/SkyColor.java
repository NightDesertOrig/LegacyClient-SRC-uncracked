package me.dev.legacy.modules.render;

import java.awt.Color;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class SkyColor extends Module
{
    private Setting<Integer> red;
    private Setting<Integer> green;
    private Setting<Integer> blue;
    private Setting<Boolean> rainbow;
    private static SkyColor INSTANCE;
    
    public SkyColor() {
        super("SkyColor", "Changes the color of the fog", Category.RENDER, false, false, false);
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)true));
    }
    
    private void setInstance() {
        SkyColor.INSTANCE = /*EL:25*/this;
    }
    
    public static SkyColor getInstance() {
        /*SL:29*/if (SkyColor.INSTANCE == null) {
            SkyColor.INSTANCE = /*EL:30*/new SkyColor();
        }
        /*SL:31*/return SkyColor.INSTANCE;
    }
    
    @SubscribeEvent
    public void fogColors(final EntityViewRenderEvent.FogColors a1) {
        /*SL:36*/a1.setRed(this.red.getValue() / 255.0f);
        /*SL:37*/a1.setGreen(this.green.getValue() / 255.0f);
        /*SL:38*/a1.setBlue(this.blue.getValue() / 255.0f);
    }
    
    @SubscribeEvent
    public void fog_density(final EntityViewRenderEvent.FogDensity a1) {
        /*SL:43*/a1.setDensity(0.0f);
        /*SL:44*/a1.setCanceled(true);
    }
    
    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(/*EL:49*/(Object)this);
    }
    
    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(/*EL:54*/(Object)this);
    }
    
    @Override
    public void onUpdate() {
        /*SL:59*/if (this.rainbow.getValue()) {
            /*SL:60*/this.doRainbow();
        }
    }
    
    public void doRainbow() {
        final float[] v1 = /*EL:66*/{ /*EL:67*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:70*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:72*/this.red.setValue(v2 >> 16 & 0xFF);
        /*SL:73*/this.green.setValue(v2 >> 8 & 0xFF);
        /*SL:74*/this.blue.setValue(v2 & 0xFF);
    }
    
    static {
        SkyColor.INSTANCE = new SkyColor();
    }
}
