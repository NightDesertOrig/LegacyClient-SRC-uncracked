package me.dev.legacy.modules.render;

import net.minecraft.client.renderer.ItemRenderer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class SmallShield extends Module
{
    public Setting<Float> offhand;
    ItemRenderer itemRenderer;
    
    public SmallShield() {
        super("SmallShield", "Low Hands.", Category.RENDER, true, false, false);
        this.offhand = (Setting<Float>)this.register(new Setting("Height", (T)0.7f, (T)0.1f, (T)1.0f));
        this.itemRenderer = SmallShield.mc.field_71460_t.field_78516_c;
    }
    
    @Override
    public void onUpdate() {
        /*SL:18*/this.itemRenderer.field_187471_h = this.offhand.getValue();
    }
}
