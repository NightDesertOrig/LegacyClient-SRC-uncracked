package me.dev.legacy.modules.render;

import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumHand;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Swing extends Module
{
    private Setting<Hand> hand;
    
    public Swing() {
        super("Swing", "Changes the hand you swing with", Category.RENDER, false, false, false);
        this.hand = (Setting<Hand>)this.register(new Setting("Hand", (T)Hand.OFFHAND));
    }
    
    @Override
    public void onUpdate() {
        /*SL:15*/if (Swing.mc.field_71441_e == null) {
            /*SL:16*/return;
        }
        /*SL:17*/if (this.hand.getValue().equals(Hand.OFFHAND)) {
            Swing.mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
        }
        /*SL:20*/if (this.hand.getValue().equals(Hand.MAINHAND)) {
            Swing.mc.field_71439_g.field_184622_au = EnumHand.MAIN_HAND;
        }
        /*SL:24*/if (this.hand.getValue().equals(Hand.PACKETSWING) && Swing.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword && Swing.mc.field_71460_t.field_78516_c.field_187470_g >= 0.9) {
            Swing.mc.field_71460_t.field_78516_c.field_187469_f = /*EL:25*/1.0f;
            Swing.mc.field_71460_t.field_78516_c.field_187467_d = Swing.mc.field_71439_g.func_184614_ca();
        }
    }
    
    public enum Hand
    {
        OFFHAND, 
        MAINHAND, 
        PACKETSWING;
    }
}
