package me.dev.legacy.modules.render;

import com.google.common.base.Predicate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.Item;
import org.lwjgl.util.glu.Cylinder;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemBow;
import net.minecraft.util.EnumHand;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.modules.Module;

public class Trajectories extends Module
{
    public Trajectories() {
        super("Trajectories", "Draws trajectories.", Category.RENDER, false, false, false);
    }
    
    @Override
    public void onRender3D(final Render3DEvent v-36) {
        /*SL:27*/if (Trajectories.mc.field_71441_e != null && Trajectories.mc.field_71439_g != null && Trajectories.mc.func_175598_ae() != null) {
            final double n = Trajectories.mc.field_71439_g.field_70142_S + (Trajectories.mc.field_71439_g.field_70165_t - Trajectories.mc.field_71439_g.field_70142_S) * /*EL:28*/v-36.getPartialTicks();
            final double n2 = Trajectories.mc.field_71439_g.field_70137_T + (Trajectories.mc.field_71439_g.field_70163_u - Trajectories.mc.field_71439_g.field_70137_T) * /*EL:29*/v-36.getPartialTicks();
            final double n3 = Trajectories.mc.field_71439_g.field_70136_U + (Trajectories.mc.field_71439_g.field_70161_v - Trajectories.mc.field_71439_g.field_70136_U) * /*EL:30*/v-36.getPartialTicks();
            Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND);
            /*SL:32*/if (Trajectories.mc.field_71474_y.field_74320_O == 0 && (Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemBow || Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemFishingRod || Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemEnderPearl || Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemEgg || Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemSnowball || Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemExpBottle)) {
                /*SL:33*/GL11.glPushMatrix();
                final Item func_77973_b = Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b();
                double n4 = /*EL:35*/n - MathHelper.func_76134_b(Trajectories.mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * 0.16f;
                double n5 = /*EL:36*/n2 + Trajectories.mc.field_71439_g.func_70047_e() - 0.1000000014901161;
                double n6 = /*EL:37*/n3 - MathHelper.func_76126_a(Trajectories.mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * 0.16f;
                double n7 = /*EL:38*/-MathHelper.func_76126_a(Trajectories.mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * MathHelper.func_76134_b(Trajectories.mc.field_71439_g.field_70125_A / 180.0f * 3.1415927f) * ((func_77973_b instanceof ItemBow) ? 1.0 : 0.4);
                double n8 = /*EL:39*/-MathHelper.func_76126_a(Trajectories.mc.field_71439_g.field_70125_A / 180.0f * 3.1415927f) * ((func_77973_b instanceof ItemBow) ? 1.0 : 0.4);
                double n9 = /*EL:40*/MathHelper.func_76134_b(Trajectories.mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * MathHelper.func_76134_b(Trajectories.mc.field_71439_g.field_70125_A / 180.0f * 3.1415927f) * ((func_77973_b instanceof ItemBow) ? 1.0 : 0.4);
                final int n10 = /*EL:41*/72000 - Trajectories.mc.field_71439_g.func_184605_cv();
                float n11 = /*EL:42*/n10 / 20.0f;
                /*SL:43*/n11 = (n11 * n11 + n11 * 2.0f) / 3.0f;
                /*SL:44*/if (n11 > 1.0f) {
                    /*SL:45*/n11 = 1.0f;
                }
                final float func_76133_a = /*EL:47*/MathHelper.func_76133_a(n7 * n7 + n8 * n8 + n9 * n9);
                /*SL:48*/n7 /= func_76133_a;
                /*SL:49*/n8 /= func_76133_a;
                /*SL:50*/n9 /= func_76133_a;
                final float n12 = /*EL:51*/(func_77973_b instanceof ItemBow) ? (n11 * 2.0f) : ((func_77973_b instanceof ItemFishingRod) ? 1.25f : ((Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.9f : 1.0f));
                /*SL:52*/n7 *= n12 * ((func_77973_b instanceof ItemFishingRod) ? 0.75f : ((Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75f : 1.5f));
                /*SL:53*/n8 *= n12 * ((func_77973_b instanceof ItemFishingRod) ? 0.75f : ((Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75f : 1.5f));
                /*SL:54*/n9 *= n12 * ((func_77973_b instanceof ItemFishingRod) ? 0.75f : ((Trajectories.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75f : 1.5f));
                /*SL:55*/this.enableGL3D(2.0f);
                /*SL:56*/GlStateManager.func_179131_c(0.0f, 1.0f, 0.0f, 1.0f);
                /*SL:57*/GL11.glEnable(2848);
                final float n13 = /*EL:58*/(float)((func_77973_b instanceof ItemBow) ? 0.3 : 0.25);
                boolean b = /*EL:59*/false;
                Entity entity = /*EL:60*/null;
                RayTraceResult rayTraceResult = /*EL:61*/null;
                /*SL:62*/while (!b && n5 > 0.0) {
                    final Vec3d vec3d = /*EL:63*/new Vec3d(n4, n5, n6);
                    final Vec3d vec3d2 = /*EL:64*/new Vec3d(n4 + n7, n5 + n8, n6 + n9);
                    final RayTraceResult func_147447_a = Trajectories.mc.field_71441_e.func_147447_a(/*EL:65*/vec3d, vec3d2, false, true, false);
                    /*SL:66*/if (func_147447_a != null && func_147447_a.field_72313_a != RayTraceResult.Type.MISS) {
                        /*SL:67*/rayTraceResult = func_147447_a;
                        /*SL:68*/b = true;
                    }
                    final AxisAlignedBB axisAlignedBB = /*EL:70*/new AxisAlignedBB(n4 - n13, n5 - n13, n6 - n13, n4 + n13, n5 + n13, n6 + n13);
                    final List entitiesWithinAABB = /*EL:71*/this.getEntitiesWithinAABB(axisAlignedBB.func_72317_d(n7, n8, n9).func_72321_a(1.0, 1.0, 1.0));
                    /*SL:72*/for (final Object next : entitiesWithinAABB) {
                        final Entity entity2 = /*EL:73*/(Entity)next;
                        /*SL:74*/if (entity2.func_70067_L() && entity2 != Trajectories.mc.field_71439_g) {
                            final float a1 = /*EL:75*/0.3f;
                            final AxisAlignedBB v1 = /*EL:76*/entity2.func_174813_aQ().func_72321_a(0.30000001192092896, 0.30000001192092896, 0.30000001192092896);
                            final RayTraceResult v2 = /*EL:77*/v1.func_72327_a(vec3d, vec3d2);
                            /*SL:78*/if (v2 == null) {
                                /*SL:79*/continue;
                            }
                            /*SL:81*/b = true;
                            /*SL:82*/entity = entity2;
                            /*SL:83*/rayTraceResult = v2;
                        }
                    }
                    /*SL:86*/if (entity != null) {
                        /*SL:87*/GlStateManager.func_179131_c(1.0f, 0.0f, 0.0f, 1.0f);
                    }
                    /*SL:89*/n4 += n7;
                    /*SL:90*/n5 += n8;
                    /*SL:91*/n6 += n9;
                    final float n14 = /*EL:92*/0.99f;
                    /*SL:93*/n7 *= 0.9900000095367432;
                    /*SL:94*/n8 *= 0.9900000095367432;
                    /*SL:95*/n9 *= 0.9900000095367432;
                    /*SL:96*/n8 -= ((func_77973_b instanceof ItemBow) ? 0.05 : 0.03);
                    /*SL:97*/this.drawLine3D(n4 - n, n5 - n2, n6 - n3);
                }
                /*SL:99*/if (rayTraceResult != null && rayTraceResult.field_72313_a == RayTraceResult.Type.BLOCK) {
                    /*SL:100*/GlStateManager.func_179137_b(n4 - n, n5 - n2, n6 - n3);
                    final int func_176745_a = /*EL:101*/rayTraceResult.field_178784_b.func_176745_a();
                    /*SL:102*/if (func_176745_a == 2) {
                        /*SL:103*/GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
                    }
                    else/*SL:104*/ if (func_176745_a == 3) {
                        /*SL:105*/GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
                    }
                    else/*SL:106*/ if (func_176745_a == 4) {
                        /*SL:107*/GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
                    }
                    else/*SL:108*/ if (func_176745_a == 5) {
                        /*SL:109*/GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
                    }
                    final Cylinder cylinder = /*EL:111*/new Cylinder();
                    /*SL:112*/GlStateManager.func_179114_b(-90.0f, 1.0f, 0.0f, 0.0f);
                    /*SL:113*/cylinder.setDrawStyle(100011);
                    /*SL:114*/if (entity != null) {
                        /*SL:115*/GlStateManager.func_179131_c(0.0f, 0.0f, 0.0f, 1.0f);
                        /*SL:116*/GL11.glLineWidth(2.5f);
                        /*SL:117*/cylinder.draw(0.6f, 0.3f, 0.0f, 4, 1);
                        /*SL:118*/GL11.glLineWidth(0.1f);
                        /*SL:119*/GlStateManager.func_179131_c(1.0f, 0.0f, 0.0f, 1.0f);
                    }
                    /*SL:121*/cylinder.draw(0.6f, 0.3f, 0.0f, 4, 1);
                }
                /*SL:123*/this.disableGL3D();
                /*SL:124*/GL11.glPopMatrix();
            }
        }
    }
    
    public void enableGL3D(final float a1) {
        /*SL:130*/GL11.glDisable(3008);
        /*SL:131*/GL11.glEnable(3042);
        /*SL:132*/GL11.glBlendFunc(770, 771);
        /*SL:133*/GL11.glDisable(3553);
        /*SL:134*/GL11.glDisable(2929);
        /*SL:135*/GL11.glDepthMask(false);
        /*SL:136*/GL11.glEnable(2884);
        Trajectories.mc.field_71460_t.func_175072_h();
        /*SL:138*/GL11.glEnable(2848);
        /*SL:139*/GL11.glHint(3154, 4354);
        /*SL:140*/GL11.glHint(3155, 4354);
        /*SL:141*/GL11.glLineWidth(a1);
    }
    
    public void disableGL3D() {
        /*SL:145*/GL11.glEnable(3553);
        /*SL:146*/GL11.glEnable(2929);
        /*SL:147*/GL11.glDisable(3042);
        /*SL:148*/GL11.glEnable(3008);
        /*SL:149*/GL11.glDepthMask(true);
        /*SL:150*/GL11.glCullFace(1029);
        /*SL:151*/GL11.glDisable(2848);
        /*SL:152*/GL11.glHint(3154, 4352);
        /*SL:153*/GL11.glHint(3155, 4352);
    }
    
    public void drawLine3D(final double a1, final double a2, final double a3) {
        /*SL:157*/GL11.glVertex3d(a1, a2, a3);
    }
    
    private List getEntitiesWithinAABB(final AxisAlignedBB v-5) {
        final ArrayList list = /*EL:161*/new ArrayList();
        final int func_76128_c = /*EL:162*/MathHelper.func_76128_c((v-5.field_72340_a - 2.0) / 16.0);
        final int func_76128_c2 = /*EL:163*/MathHelper.func_76128_c((v-5.field_72336_d + 2.0) / 16.0);
        final int func_76128_c3 = /*EL:164*/MathHelper.func_76128_c((v-5.field_72339_c - 2.0) / 16.0);
        final int v0 = /*EL:165*/MathHelper.func_76128_c((v-5.field_72334_f + 2.0) / 16.0);
        /*SL:166*/for (int v = func_76128_c; v <= func_76128_c2; ++v) {
            /*SL:167*/for (int a1 = func_76128_c3; a1 <= v0; ++a1) {
                /*SL:168*/if (Trajectories.mc.field_71441_e.func_72863_F().func_186026_b(v, a1) != null) {
                    Trajectories.mc.field_71441_e.func_72964_e(/*EL:169*/v, a1).func_177414_a((Entity)Trajectories.mc.field_71439_g, v-5, (List)list, (Predicate)null);
                }
            }
        }
        /*SL:173*/return list;
    }
}
