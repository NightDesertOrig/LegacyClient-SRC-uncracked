package me.dev.legacy.modules.render;

import net.minecraft.util.math.Vec3d;
import java.util.Iterator;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityXPOrb;
import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.renderer.RenderGlobal;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class ESP extends Module
{
    private static ESP INSTANCE;
    private final Setting<Boolean> items;
    private final Setting<Boolean> xporbs;
    private final Setting<Boolean> xpbottles;
    private final Setting<Boolean> pearl;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    private final Setting<Integer> boxAlpha;
    private final Setting<Integer> alpha;
    
    public ESP() {
        super("ESP", "Renders a nice ESP.", Category.RENDER, false, false, false);
        this.items = (Setting<Boolean>)this.register(new Setting("Items", (T)false));
        this.xporbs = (Setting<Boolean>)this.register(new Setting("XpOrbs", (T)false));
        this.xpbottles = (Setting<Boolean>)this.register(new Setting("XpBottles", (T)false));
        this.pearl = (Setting<Boolean>)this.register(new Setting("Pearls", (T)false));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)120, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.setInstance();
    }
    
    public static ESP getInstance() {
        /*SL:39*/if (ESP.INSTANCE == null) {
            ESP.INSTANCE = /*EL:40*/new ESP();
        }
        /*SL:42*/return ESP.INSTANCE;
    }
    
    private void setInstance() {
        ESP.INSTANCE = /*EL:46*/this;
    }
    
    @Override
    public void onRender3D(final Render3DEvent v0) {
        /*SL:54*/if (this.items.getValue()) {
            int v = /*EL:55*/0;
            /*SL:56*/for (final Entity a1 : ESP.mc.field_71441_e.field_72996_f) {
                /*SL:57*/if (a1 instanceof EntityItem) {
                    if (ESP.mc.field_71439_g.func_70068_e(a1) >= 2500.0) {
                        continue;
                    }
                    final Vec3d v2 = /*EL:58*/EntityUtil.getInterpolatedRenderPos(a1, ESP.mc.func_184121_ak());
                    final AxisAlignedBB v3 = /*EL:59*/new AxisAlignedBB(a1.func_174813_aQ().field_72340_a - 0.05 - a1.field_70165_t + v2.field_72450_a, a1.func_174813_aQ().field_72338_b - 0.0 - a1.field_70163_u + v2.field_72448_b, a1.func_174813_aQ().field_72339_c - 0.05 - a1.field_70161_v + v2.field_72449_c, a1.func_174813_aQ().field_72336_d + 0.05 - a1.field_70165_t + v2.field_72450_a, a1.func_174813_aQ().field_72337_e + 0.1 - a1.field_70163_u + v2.field_72448_b, a1.func_174813_aQ().field_72334_f + 0.05 - a1.field_70161_v + v2.field_72449_c);
                    /*SL:60*/GlStateManager.func_179094_E();
                    /*SL:61*/GlStateManager.func_179147_l();
                    /*SL:62*/GlStateManager.func_179097_i();
                    /*SL:63*/GlStateManager.func_179120_a(770, 771, 0, 1);
                    /*SL:64*/GlStateManager.func_179090_x();
                    /*SL:65*/GlStateManager.func_179132_a(false);
                    /*SL:66*/GL11.glEnable(2848);
                    /*SL:67*/GL11.glHint(3154, 4354);
                    /*SL:68*/GL11.glLineWidth(1.0f);
                    /*SL:69*/RenderGlobal.func_189696_b(v3, this.red.getValue() / 255.0f, this.green.getValue() / 255.0f, this.blue.getValue() / 255.0f, this.boxAlpha.getValue() / 255.0f);
                    /*SL:70*/GL11.glDisable(2848);
                    /*SL:71*/GlStateManager.func_179132_a(true);
                    /*SL:72*/GlStateManager.func_179126_j();
                    /*SL:73*/GlStateManager.func_179098_w();
                    /*SL:74*/GlStateManager.func_179084_k();
                    /*SL:75*/GlStateManager.func_179121_F();
                    /*SL:76*/RenderUtil.drawBlockOutline(v3, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), 1.0f);
                    /*SL:77*/if (++v < 50) {
                        continue;
                    }
                    break;
                }
            }
        }
        /*SL:81*/if (this.xporbs.getValue()) {
            int v = /*EL:82*/0;
            /*SL:83*/for (final Entity v4 : ESP.mc.field_71441_e.field_72996_f) {
                /*SL:84*/if (v4 instanceof EntityXPOrb) {
                    if (ESP.mc.field_71439_g.func_70068_e(v4) >= 2500.0) {
                        continue;
                    }
                    final Vec3d v2 = /*EL:85*/EntityUtil.getInterpolatedRenderPos(v4, ESP.mc.func_184121_ak());
                    final AxisAlignedBB v3 = /*EL:86*/new AxisAlignedBB(v4.func_174813_aQ().field_72340_a - 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72338_b - 0.0 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72339_c - 0.05 - v4.field_70161_v + v2.field_72449_c, v4.func_174813_aQ().field_72336_d + 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72337_e + 0.1 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72334_f + 0.05 - v4.field_70161_v + v2.field_72449_c);
                    /*SL:87*/GlStateManager.func_179094_E();
                    /*SL:88*/GlStateManager.func_179147_l();
                    /*SL:89*/GlStateManager.func_179097_i();
                    /*SL:90*/GlStateManager.func_179120_a(770, 771, 0, 1);
                    /*SL:91*/GlStateManager.func_179090_x();
                    /*SL:92*/GlStateManager.func_179132_a(false);
                    /*SL:93*/GL11.glEnable(2848);
                    /*SL:94*/GL11.glHint(3154, 4354);
                    /*SL:95*/GL11.glLineWidth(1.0f);
                    /*SL:96*/RenderGlobal.func_189696_b(v3, this.red.getValue() / 255.0f, this.green.getValue() / 255.0f, this.blue.getValue() / 255.0f, this.boxAlpha.getValue() / 255.0f);
                    /*SL:97*/GL11.glDisable(2848);
                    /*SL:98*/GlStateManager.func_179132_a(true);
                    /*SL:99*/GlStateManager.func_179126_j();
                    /*SL:100*/GlStateManager.func_179098_w();
                    /*SL:101*/GlStateManager.func_179084_k();
                    /*SL:102*/GlStateManager.func_179121_F();
                    /*SL:103*/RenderUtil.drawBlockOutline(v3, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), 1.0f);
                    /*SL:104*/if (++v < 50) {
                        continue;
                    }
                    break;
                }
            }
        }
        /*SL:108*/if (this.pearl.getValue()) {
            int v = /*EL:109*/0;
            /*SL:110*/for (final Entity v4 : ESP.mc.field_71441_e.field_72996_f) {
                /*SL:111*/if (v4 instanceof EntityEnderPearl) {
                    if (ESP.mc.field_71439_g.func_70068_e(v4) >= 2500.0) {
                        continue;
                    }
                    final Vec3d v2 = /*EL:112*/EntityUtil.getInterpolatedRenderPos(v4, ESP.mc.func_184121_ak());
                    final AxisAlignedBB v3 = /*EL:113*/new AxisAlignedBB(v4.func_174813_aQ().field_72340_a - 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72338_b - 0.0 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72339_c - 0.05 - v4.field_70161_v + v2.field_72449_c, v4.func_174813_aQ().field_72336_d + 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72337_e + 0.1 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72334_f + 0.05 - v4.field_70161_v + v2.field_72449_c);
                    /*SL:114*/GlStateManager.func_179094_E();
                    /*SL:115*/GlStateManager.func_179147_l();
                    /*SL:116*/GlStateManager.func_179097_i();
                    /*SL:117*/GlStateManager.func_179120_a(770, 771, 0, 1);
                    /*SL:118*/GlStateManager.func_179090_x();
                    /*SL:119*/GlStateManager.func_179132_a(false);
                    /*SL:120*/GL11.glEnable(2848);
                    /*SL:121*/GL11.glHint(3154, 4354);
                    /*SL:122*/GL11.glLineWidth(1.0f);
                    /*SL:123*/RenderGlobal.func_189696_b(v3, this.red.getValue() / 255.0f, this.green.getValue() / 255.0f, this.blue.getValue() / 255.0f, this.boxAlpha.getValue() / 255.0f);
                    /*SL:124*/GL11.glDisable(2848);
                    /*SL:125*/GlStateManager.func_179132_a(true);
                    /*SL:126*/GlStateManager.func_179126_j();
                    /*SL:127*/GlStateManager.func_179098_w();
                    /*SL:128*/GlStateManager.func_179084_k();
                    /*SL:129*/GlStateManager.func_179121_F();
                    /*SL:130*/RenderUtil.drawBlockOutline(v3, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), 1.0f);
                    /*SL:131*/if (++v < 50) {
                        continue;
                    }
                    break;
                }
            }
        }
        /*SL:135*/if (this.xpbottles.getValue()) {
            int v = /*EL:136*/0;
            /*SL:137*/for (final Entity v4 : ESP.mc.field_71441_e.field_72996_f) {
                /*SL:138*/if (v4 instanceof EntityExpBottle) {
                    if (ESP.mc.field_71439_g.func_70068_e(v4) >= 2500.0) {
                        continue;
                    }
                    final Vec3d v2 = /*EL:139*/EntityUtil.getInterpolatedRenderPos(v4, ESP.mc.func_184121_ak());
                    final AxisAlignedBB v3 = /*EL:140*/new AxisAlignedBB(v4.func_174813_aQ().field_72340_a - 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72338_b - 0.0 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72339_c - 0.05 - v4.field_70161_v + v2.field_72449_c, v4.func_174813_aQ().field_72336_d + 0.05 - v4.field_70165_t + v2.field_72450_a, v4.func_174813_aQ().field_72337_e + 0.1 - v4.field_70163_u + v2.field_72448_b, v4.func_174813_aQ().field_72334_f + 0.05 - v4.field_70161_v + v2.field_72449_c);
                    /*SL:141*/GlStateManager.func_179094_E();
                    /*SL:142*/GlStateManager.func_179147_l();
                    /*SL:143*/GlStateManager.func_179097_i();
                    /*SL:144*/GlStateManager.func_179120_a(770, 771, 0, 1);
                    /*SL:145*/GlStateManager.func_179090_x();
                    /*SL:146*/GlStateManager.func_179132_a(false);
                    /*SL:147*/GL11.glEnable(2848);
                    /*SL:148*/GL11.glHint(3154, 4354);
                    /*SL:149*/GL11.glLineWidth(1.0f);
                    /*SL:150*/RenderGlobal.func_189696_b(v3, this.red.getValue() / 255.0f, this.green.getValue() / 255.0f, this.blue.getValue() / 255.0f, this.boxAlpha.getValue() / 255.0f);
                    /*SL:151*/GL11.glDisable(2848);
                    /*SL:152*/GlStateManager.func_179132_a(true);
                    /*SL:153*/GlStateManager.func_179126_j();
                    /*SL:154*/GlStateManager.func_179098_w();
                    /*SL:155*/GlStateManager.func_179084_k();
                    /*SL:156*/GlStateManager.func_179121_F();
                    /*SL:157*/RenderUtil.drawBlockOutline(v3, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), 1.0f);
                    /*SL:158*/if (++v < 50) {
                        /*SL:159*/continue;
                    }
                    break;
                }
            }
        }
    }
    
    static {
        ESP.INSTANCE = new ESP();
    }
}
