package me.dev.legacy.modules.render;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketEntityEffect;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Fullbright extends Module
{
    public Setting<Mode> mode;
    public Setting<Boolean> effects;
    private float previousSetting;
    
    public Fullbright() {
        super("Fullbright", "Makes your game brighter.", Category.RENDER, true, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.GAMMA));
        this.effects = (Setting<Boolean>)this.register(new Setting("Effects", (T)false));
        this.previousSetting = 1.0f;
    }
    
    @Override
    public void onEnable() {
        /*SL:26*/this.previousSetting = Fullbright.mc.field_71474_y.field_74333_Y;
    }
    
    @Override
    public void onUpdate() {
        /*SL:31*/if (this.mode.getValue() == Mode.GAMMA) {
            Fullbright.mc.field_71474_y.field_74333_Y = /*EL:32*/1000.0f;
        }
        /*SL:34*/if (this.mode.getValue() == Mode.POTION) {
            Fullbright.mc.field_71439_g.func_70690_d(/*EL:35*/new PotionEffect(MobEffects.field_76439_r, 5210));
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:41*/if (this.mode.getValue() == Mode.POTION) {
            Fullbright.mc.field_71439_g.func_184589_d(MobEffects.field_76439_r);
        }
        Fullbright.mc.field_71474_y.field_74333_Y = /*EL:44*/this.previousSetting;
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive v2) {
        /*SL:49*/if (v2.getStage() == 0 && v2.getPacket() instanceof SPacketEntityEffect && this.effects.getValue()) {
            final SPacketEntityEffect a1 = /*EL:50*/(SPacketEntityEffect)v2.getPacket();
            /*SL:51*/if (Fullbright.mc.field_71439_g != null && a1.func_149426_d() == Fullbright.mc.field_71439_g.func_145782_y() && (a1.func_149427_e() == 9 || a1.func_149427_e() == 15)) {
                /*SL:52*/v2.setCanceled(true);
            }
        }
    }
    
    public enum Mode
    {
        GAMMA, 
        POTION;
    }
}
