package me.dev.legacy.modules.render;

import java.awt.Color;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.Tessellator;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.nbt.NBTTagList;
import me.dev.legacy.api.util.DamageUtil;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.enchantment.Enchantment;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.ColorHolder;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;
import net.minecraft.init.Items;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemTool;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Nametags extends Module
{
    private static Nametags INSTANCE;
    private final Setting<Boolean> rect;
    private final Setting<Boolean> armor;
    private final Setting<Boolean> reversed;
    private final Setting<Boolean> health;
    private final Setting<Boolean> ping;
    private final Setting<Boolean> gamemode;
    private final Setting<Boolean> entityID;
    private final Setting<Boolean> heldStackName;
    private final Setting<Boolean> max;
    private final Setting<Boolean> maxText;
    private final Setting<Integer> Mred;
    private final Setting<Integer> Mgreen;
    private final Setting<Integer> Mblue;
    private final Setting<Float> size;
    private final Setting<Boolean> scaleing;
    private final Setting<Boolean> smartScale;
    private final Setting<Float> factor;
    private final Setting<Boolean> textcolor;
    private final Setting<Boolean> NCRainbow;
    private final Setting<Integer> NCred;
    private final Setting<Integer> NCgreen;
    private final Setting<Integer> NCblue;
    private final Setting<Boolean> outline;
    private final Setting<Boolean> ORainbow;
    private final Setting<Float> Owidth;
    private final Setting<Integer> Ored;
    private final Setting<Integer> Ogreen;
    private final Setting<Integer> Oblue;
    private final Setting<Boolean> friendcolor;
    private final Setting<Boolean> FCRainbow;
    private final Setting<Integer> FCred;
    private final Setting<Integer> FCgreen;
    private final Setting<Integer> FCblue;
    private final Setting<Boolean> FORainbow;
    private final Setting<Integer> FOred;
    private final Setting<Integer> FOgreen;
    private final Setting<Integer> FOblue;
    private final Setting<Boolean> sneakcolor;
    private final Setting<Boolean> sneak;
    private final Setting<Boolean> SCRainbow;
    private final Setting<Integer> SCred;
    private final Setting<Integer> SCgreen;
    private final Setting<Integer> SCblue;
    private final Setting<Boolean> SORainbow;
    private final Setting<Integer> SOred;
    private final Setting<Integer> SOgreen;
    private final Setting<Integer> SOblue;
    private final Setting<Boolean> invisiblescolor;
    private final Setting<Boolean> invisibles;
    private final Setting<Boolean> ICRainbow;
    private final Setting<Integer> ICred;
    private final Setting<Integer> ICgreen;
    private final Setting<Integer> ICblue;
    private final Setting<Boolean> IORainbow;
    private final Setting<Integer> IOred;
    private final Setting<Integer> IOgreen;
    private final Setting<Integer> IOblue;
    
    public Nametags() {
        super("Nametags", "Renders info about the player on a NameTag", Category.RENDER, false, false, false);
        this.rect = (Setting<Boolean>)this.register(new Setting("Rectangle", (T)true));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)true));
        this.reversed = (Setting<Boolean>)this.register(new Setting("ArmorReversed", (T)false, a1 -> this.armor.getValue()));
        this.health = (Setting<Boolean>)this.register(new Setting("Health", (T)true));
        this.ping = (Setting<Boolean>)this.register(new Setting("Ping", (T)true));
        this.gamemode = (Setting<Boolean>)this.register(new Setting("Gamemode", (T)false));
        this.entityID = (Setting<Boolean>)this.register(new Setting("EntityID", (T)false));
        this.heldStackName = (Setting<Boolean>)this.register(new Setting("StackName", (T)true));
        this.max = (Setting<Boolean>)this.register(new Setting("Max", (T)true));
        this.maxText = (Setting<Boolean>)this.register(new Setting("NoMaxText", (T)false, a1 -> this.max.getValue()));
        this.Mred = (Setting<Integer>)this.register(new Setting("Max-Red", (T)178, (T)0, (T)255, a1 -> this.max.getValue()));
        this.Mgreen = (Setting<Integer>)this.register(new Setting("Max-Green", (T)52, (T)0, (T)255, a1 -> this.max.getValue()));
        this.Mblue = (Setting<Integer>)this.register(new Setting("Max-Blue", (T)57, (T)0, (T)255, a1 -> this.max.getValue()));
        this.size = (Setting<Float>)this.register(new Setting("Size", (T)0.3f, (T)0.1f, (T)20.0f));
        this.scaleing = (Setting<Boolean>)this.register(new Setting("Scale", (T)false));
        this.smartScale = (Setting<Boolean>)this.register(new Setting("SmartScale", (T)false, a1 -> this.scaleing.getValue()));
        this.factor = (Setting<Float>)this.register(new Setting("Factor", (T)0.3f, (T)0.1f, (T)1.0f, a1 -> this.scaleing.getValue()));
        this.textcolor = (Setting<Boolean>)this.register(new Setting("TextColor", (T)true));
        this.NCRainbow = (Setting<Boolean>)this.register(new Setting("Text-Rainbow", (T)false, a1 -> this.textcolor.getValue()));
        this.NCred = (Setting<Integer>)this.register(new Setting("Text-Red", (T)255, (T)0, (T)255, a1 -> this.textcolor.getValue()));
        this.NCgreen = (Setting<Integer>)this.register(new Setting("Text-Green", (T)255, (T)0, (T)255, a1 -> this.textcolor.getValue()));
        this.NCblue = (Setting<Integer>)this.register(new Setting("Text-Blue", (T)255, (T)0, (T)255, a1 -> this.textcolor.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true));
        this.ORainbow = (Setting<Boolean>)this.register(new Setting("Outline-Rainbow", (T)false, a1 -> this.outline.getValue()));
        this.Owidth = (Setting<Float>)this.register(new Setting("Outline-Width", (T)1.3f, (T)0.0f, (T)5.0f, a1 -> this.outline.getValue()));
        this.Ored = (Setting<Integer>)this.register(new Setting("Outline-Red", (T)255, (T)0, (T)255, a1 -> this.outline.getValue()));
        this.Ogreen = (Setting<Integer>)this.register(new Setting("Outline-Green", (T)255, (T)0, (T)255, a1 -> this.outline.getValue()));
        this.Oblue = (Setting<Integer>)this.register(new Setting("Outline-Blue", (T)255, (T)0, (T)255, a1 -> this.outline.getValue()));
        this.friendcolor = (Setting<Boolean>)this.register(new Setting("FriendColor", (T)true));
        this.FCRainbow = (Setting<Boolean>)this.register(new Setting("Friend-Rainbow", (T)false, a1 -> this.friendcolor.getValue()));
        this.FCred = (Setting<Integer>)this.register(new Setting("Friend-Red", (T)0, (T)0, (T)255, a1 -> this.friendcolor.getValue()));
        this.FCgreen = (Setting<Integer>)this.register(new Setting("Friend-Green", (T)213, (T)0, (T)255, a1 -> this.friendcolor.getValue()));
        this.FCblue = (Setting<Integer>)this.register(new Setting("Friend-Blue", (T)255, (T)0, (T)255, a1 -> this.friendcolor.getValue()));
        this.FORainbow = (Setting<Boolean>)this.register(new Setting("FriendOutline-Rainbow", (T)false, a1 -> this.outline.getValue() && this.friendcolor.getValue()));
        this.FOred = (Setting<Integer>)this.register(new Setting("FriendOutline-Red", (T)0, (T)0, (T)255, a1 -> this.outline.getValue() && this.friendcolor.getValue()));
        this.FOgreen = (Setting<Integer>)this.register(new Setting("FriendOutline-Green", (T)213, (T)0, (T)255, a1 -> this.outline.getValue() && this.friendcolor.getValue()));
        this.FOblue = (Setting<Integer>)this.register(new Setting("FriendOutline-Blue", (T)255, (T)0, (T)255, a1 -> this.outline.getValue() && this.friendcolor.getValue()));
        this.sneakcolor = (Setting<Boolean>)this.register(new Setting("Sneak", (T)false));
        this.sneak = (Setting<Boolean>)this.register(new Setting("EnableSneak", (T)true, a1 -> this.sneakcolor.getValue()));
        this.SCRainbow = (Setting<Boolean>)this.register(new Setting("Sneak-Rainbow", (T)false, a1 -> this.sneakcolor.getValue()));
        this.SCred = (Setting<Integer>)this.register(new Setting("Sneak-Red", (T)245, (T)0, (T)255, a1 -> this.sneakcolor.getValue()));
        this.SCgreen = (Setting<Integer>)this.register(new Setting("Sneak-Green", (T)0, (T)0, (T)255, a1 -> this.sneakcolor.getValue()));
        this.SCblue = (Setting<Integer>)this.register(new Setting("Sneak-Blue", (T)122, (T)0, (T)255, a1 -> this.sneakcolor.getValue()));
        this.SORainbow = (Setting<Boolean>)this.register(new Setting("SneakOutline-Rainbow", (T)false, a1 -> this.outline.getValue() && this.sneakcolor.getValue()));
        this.SOred = (Setting<Integer>)this.register(new Setting("SneakOutline-Red", (T)245, (T)0, (T)255, a1 -> this.outline.getValue() && this.sneakcolor.getValue()));
        this.SOgreen = (Setting<Integer>)this.register(new Setting("SneakOutline-Green", (T)0, (T)0, (T)255, a1 -> this.outline.getValue() && this.sneakcolor.getValue()));
        this.SOblue = (Setting<Integer>)this.register(new Setting("SneakOutline-Blue", (T)122, (T)0, (T)255, a1 -> this.outline.getValue() && this.sneakcolor.getValue()));
        this.invisiblescolor = (Setting<Boolean>)this.register(new Setting("InvisiblesColor", (T)false));
        this.invisibles = (Setting<Boolean>)this.register(new Setting("EnableInvisibles", (T)true, a1 -> this.invisiblescolor.getValue()));
        this.ICRainbow = (Setting<Boolean>)this.register(new Setting("Invisible-Rainbow", (T)false, a1 -> this.invisiblescolor.getValue()));
        this.ICred = (Setting<Integer>)this.register(new Setting("Invisible-Red", (T)148, (T)0, (T)255, a1 -> this.invisiblescolor.getValue()));
        this.ICgreen = (Setting<Integer>)this.register(new Setting("Invisible-Green", (T)148, (T)0, (T)255, a1 -> this.invisiblescolor.getValue()));
        this.ICblue = (Setting<Integer>)this.register(new Setting("Invisible-Blue", (T)148, (T)0, (T)255, a1 -> this.invisiblescolor.getValue()));
        this.IORainbow = (Setting<Boolean>)this.register(new Setting("InvisibleOutline-Rainbow", (T)false, a1 -> this.outline.getValue() && this.invisiblescolor.getValue()));
        this.IOred = (Setting<Integer>)this.register(new Setting("InvisibleOutline-Red", (T)148, (T)0, (T)255, a1 -> this.outline.getValue() && this.invisiblescolor.getValue()));
        this.IOgreen = (Setting<Integer>)this.register(new Setting("InvisibleOutline-Green", (T)148, (T)0, (T)255, a1 -> this.outline.getValue() && this.invisiblescolor.getValue()));
        this.IOblue = (Setting<Integer>)this.register(new Setting("InvisibleOutline-Blue", (T)148, (T)0, (T)255, a1 -> this.outline.getValue() && this.invisiblescolor.getValue()));
    }
    
    public static Nametags getInstance() {
        /*SL:38*/if (Nametags.INSTANCE == null) {
            Nametags.INSTANCE = /*EL:39*/new Nametags();
        }
        /*SL:41*/return Nametags.INSTANCE;
    }
    
    @Override
    public void onRender3D(final Render3DEvent v-4) {
        /*SL:111*/for (final EntityPlayer v-5 : Nametags.mc.field_71441_e.field_73010_i) {
            /*SL:112*/if (v-5 != null && !v-5.equals((Object)Nametags.mc.field_71439_g) && v-5.func_70089_S() && (!v-5.func_82150_aj() || this.invisibles.getValue())) {
                final double a1 = /*EL:113*/this.interpolate(v-5.field_70142_S, v-5.field_70165_t, v-4.getPartialTicks()) - Nametags.mc.func_175598_ae().field_78725_b;
                final double v1 = /*EL:114*/this.interpolate(v-5.field_70137_T, v-5.field_70163_u, v-4.getPartialTicks()) - Nametags.mc.func_175598_ae().field_78726_c;
                final double v2 = /*EL:115*/this.interpolate(v-5.field_70136_U, v-5.field_70161_v, v-4.getPartialTicks()) - Nametags.mc.func_175598_ae().field_78723_d;
                /*SL:116*/this.renderNameTag(v-5, a1, v1, v2, v-4.getPartialTicks());
            }
        }
    }
    
    private void renderNameTag(final EntityPlayer v-26, final double v-25, final double v-23, final double v-21, final float v-19) {
        final double n = /*EL:123*/v-23 + (v-26.func_70093_af() ? 0.5 : 0.7);
        final Entity func_175606_aa = Nametags.mc.func_175606_aa();
        /*SL:125*/assert func_175606_aa != null;
        final double field_70165_t = /*EL:126*/func_175606_aa.field_70165_t;
        final double field_70163_u = /*EL:127*/func_175606_aa.field_70163_u;
        final double field_70161_v = /*EL:128*/func_175606_aa.field_70161_v;
        /*SL:129*/func_175606_aa.field_70165_t = this.interpolate(func_175606_aa.field_70169_q, func_175606_aa.field_70165_t, v-19);
        /*SL:130*/func_175606_aa.field_70163_u = this.interpolate(func_175606_aa.field_70167_r, func_175606_aa.field_70163_u, v-19);
        /*SL:131*/func_175606_aa.field_70161_v = this.interpolate(func_175606_aa.field_70166_s, func_175606_aa.field_70161_v, v-19);
        final String displayTag = /*EL:133*/this.getDisplayTag(v-26);
        final double func_70011_f = /*EL:134*/func_175606_aa.func_70011_f(v-25 + Nametags.mc.func_175598_ae().field_78730_l, v-23 + Nametags.mc.func_175598_ae().field_78731_m, v-21 + Nametags.mc.func_175598_ae().field_78728_n);
        final int n2 = /*EL:135*/this.renderer.getStringWidth(displayTag) / 2;
        double n3 = /*EL:136*/(0.0018 + this.size.getValue() * (func_70011_f * this.factor.getValue())) / 1000.0;
        /*SL:138*/if (func_70011_f <= 8.0 && this.smartScale.getValue()) {
            /*SL:139*/n3 = 0.0245;
        }
        /*SL:142*/if (!this.scaleing.getValue()) {
            /*SL:143*/n3 = this.size.getValue() / 100.0;
        }
        /*SL:146*/GlStateManager.func_179094_E();
        /*SL:147*/RenderHelper.func_74519_b();
        /*SL:148*/GlStateManager.func_179088_q();
        /*SL:149*/GlStateManager.func_179136_a(1.0f, -1500000.0f);
        /*SL:150*/GlStateManager.func_179140_f();
        /*SL:151*/GlStateManager.func_179109_b((float)v-25, (float)n + 1.4f, (float)v-21);
        /*SL:152*/GlStateManager.func_179114_b(-Nametags.mc.func_175598_ae().field_78735_i, 0.0f, 1.0f, 0.0f);
        /*SL:153*/GlStateManager.func_179114_b(Nametags.mc.func_175598_ae().field_78732_j, (Nametags.mc.field_71474_y.field_74320_O == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        /*SL:154*/GlStateManager.func_179139_a(-n3, -n3, n3);
        /*SL:155*/GlStateManager.func_179097_i();
        /*SL:156*/GlStateManager.func_179147_l();
        /*SL:157*/GlStateManager.func_179147_l();
        /*SL:158*/if (this.rect.getValue()) {
            /*SL:159*/this.drawRect(-n2 - 2, -(Nametags.mc.field_71466_p.field_78288_b + 1), n2 + 2.0f, 1.5f, 1426063360);
        }
        /*SL:161*/if (this.outline.getValue()) {
            /*SL:162*/this.drawOutlineRect(-n2 - 2, -(Nametags.mc.field_71466_p.field_78288_b + 1), n2 + 2.0f, 1.5f, this.getOutlineColor(v-26));
        }
        /*SL:164*/GlStateManager.func_179084_k();
        final ItemStack func_77946_l = /*EL:165*/v-26.func_184614_ca().func_77946_l();
        /*SL:166*/if (func_77946_l.func_77962_s() && (func_77946_l.func_77973_b() instanceof ItemTool || func_77946_l.func_77973_b() instanceof ItemArmor)) {
            /*SL:167*/func_77946_l.field_77994_a = 1;
        }
        /*SL:170*/if (this.heldStackName.getValue() && !func_77946_l.field_190928_g && func_77946_l.func_77973_b() != Items.field_190931_a) {
            final String a1 = /*EL:171*/func_77946_l.func_82833_r();
            final int a2 = /*EL:172*/this.renderer.getStringWidth(a1) / 2;
            /*SL:173*/GL11.glPushMatrix();
            /*SL:174*/GL11.glScalef(0.75f, 0.75f, 0.0f);
            /*SL:175*/this.renderer.drawStringWithShadow(a1, -a2, -(this.getBiggestArmorTag(v-26) + 20.0f), -1);
            /*SL:176*/GL11.glScalef(1.5f, 1.5f, 1.0f);
            /*SL:177*/GL11.glPopMatrix();
        }
        /*SL:180*/if (this.armor.getValue()) {
            /*SL:181*/GlStateManager.func_179094_E();
            int n4 = /*EL:182*/-6;
            int n5 = /*EL:183*/0;
            /*SL:184*/for (final ItemStack a3 : v-26.field_71071_by.field_70460_b) {
                /*SL:185*/if (a3 != null) {
                    /*SL:186*/n4 -= 8;
                    /*SL:187*/if (a3.func_77973_b() == Items.field_190931_a) {
                        continue;
                    }
                    ++n5;
                }
            }
            /*SL:191*/n4 -= 8;
            final ItemStack v0 = /*EL:192*/v-26.func_184592_cb().func_77946_l();
            /*SL:193*/if (v0.func_77962_s() && (v0.func_77973_b() instanceof ItemTool || v0.func_77973_b() instanceof ItemArmor)) {
                /*SL:194*/v0.field_77994_a = 1;
            }
            /*SL:197*/this.renderItemStack(v0, n4, -26);
            /*SL:198*/n4 += 16;
            /*SL:200*/if (this.reversed.getValue()) {
                /*SL:201*/for (int v = 0; v <= 3; ++v) {
                    final ItemStack a4 = /*EL:202*/(ItemStack)v-26.field_71071_by.field_70460_b.get(v);
                    /*SL:203*/if (a4 != null && a4.func_77973_b() != Items.field_190931_a) {
                        final ItemStack a5 = /*EL:204*/a4.func_77946_l();
                        /*SL:206*/this.renderItemStack(a4, n4, -26);
                        /*SL:207*/n4 += 16;
                    }
                }
            }
            else {
                /*SL:211*/for (int v = 3; v >= 0; --v) {
                    final ItemStack v2 = /*EL:212*/(ItemStack)v-26.field_71071_by.field_70460_b.get(v);
                    /*SL:213*/if (v2 != null && v2.func_77973_b() != Items.field_190931_a) {
                        final ItemStack v3 = /*EL:214*/v2.func_77946_l();
                        /*SL:216*/this.renderItemStack(v2, n4, -26);
                        /*SL:217*/n4 += 16;
                    }
                }
            }
            /*SL:222*/this.renderItemStack(func_77946_l, n4, -26);
            /*SL:224*/GlStateManager.func_179121_F();
        }
        /*SL:227*/this.renderer.drawStringWithShadow(displayTag, -n2, -(this.renderer.getFontHeight() - 1), this.getDisplayColor(v-26));
        /*SL:229*/func_175606_aa.field_70165_t = field_70165_t;
        /*SL:230*/func_175606_aa.field_70163_u = field_70163_u;
        /*SL:231*/func_175606_aa.field_70161_v = field_70161_v;
        /*SL:232*/GlStateManager.func_179126_j();
        /*SL:233*/GlStateManager.func_179084_k();
        /*SL:234*/GlStateManager.func_179113_r();
        /*SL:235*/GlStateManager.func_179136_a(1.0f, 1500000.0f);
        /*SL:236*/GlStateManager.func_179121_F();
    }
    
    private int getDisplayColor(final EntityPlayer a1) {
        int v1 = /*EL:240*/ColorHolder.toHex(this.NCred.getValue(), this.NCgreen.getValue(), this.NCblue.getValue());
        /*SL:241*/if (Legacy.friendManager.isFriend(a1)) {
            /*SL:242*/return ColorHolder.toHex(this.FCred.getValue(), this.FCgreen.getValue(), this.FCblue.getValue());
        }
        /*SL:243*/if (a1.func_82150_aj() && this.invisibles.getValue()) {
            /*SL:244*/v1 = ColorHolder.toHex(this.ICred.getValue(), this.ICgreen.getValue(), this.ICblue.getValue());
        }
        else/*SL:245*/ if (a1.func_70093_af() && this.sneak.getValue()) {
            /*SL:246*/v1 = ColorHolder.toHex(this.SCred.getValue(), this.SCgreen.getValue(), this.SCblue.getValue());
        }
        /*SL:248*/return v1;
    }
    
    private int getOutlineColor(final EntityPlayer a1) {
        int v1 = /*EL:252*/ColorHolder.toHex(this.Ored.getValue(), this.Ogreen.getValue(), this.Oblue.getValue());
        /*SL:253*/if (Legacy.friendManager.isFriend(a1)) {
            /*SL:254*/v1 = ColorHolder.toHex(this.FOred.getValue(), this.FOgreen.getValue(), this.FOblue.getValue());
        }
        else/*SL:255*/ if (a1.func_82150_aj() && this.invisibles.getValue()) {
            /*SL:256*/v1 = ColorHolder.toHex(this.IOred.getValue(), this.IOgreen.getValue(), this.IOblue.getValue());
        }
        else/*SL:257*/ if (a1.func_70093_af() && this.sneak.getValue()) {
            /*SL:258*/v1 = ColorHolder.toHex(this.SOred.getValue(), this.SOgreen.getValue(), this.SOblue.getValue());
        }
        /*SL:260*/return v1;
    }
    
    private void renderItemStack(final ItemStack a1, final int a2, final int a3) {
        /*SL:264*/GlStateManager.func_179094_E();
        /*SL:265*/GlStateManager.func_179132_a(true);
        /*SL:266*/GlStateManager.func_179086_m(256);
        /*SL:268*/RenderHelper.func_74519_b();
        Nametags.mc.func_175599_af().field_77023_b = /*EL:269*/-150.0f;
        /*SL:270*/GlStateManager.func_179118_c();
        /*SL:271*/GlStateManager.func_179126_j();
        /*SL:272*/GlStateManager.func_179129_p();
        Nametags.mc.func_175599_af().func_180450_b(/*EL:274*/a1, a2, a3);
        Nametags.mc.func_175599_af().func_175030_a(Nametags.mc.field_71466_p, /*EL:275*/a1, a2, a3);
        Nametags.mc.func_175599_af().field_77023_b = /*EL:277*/0.0f;
        /*SL:278*/RenderHelper.func_74518_a();
        /*SL:280*/GlStateManager.func_179089_o();
        /*SL:281*/GlStateManager.func_179141_d();
        /*SL:283*/GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
        /*SL:284*/GlStateManager.func_179097_i();
        /*SL:285*/this.renderEnchantmentText(a1, a2, a3);
        /*SL:286*/GlStateManager.func_179126_j();
        /*SL:287*/GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
        /*SL:288*/GlStateManager.func_179121_F();
    }
    
    private void renderEnchantmentText(final ItemStack v-8, final int v-7, final int v-6) {
        int n = /*EL:292*/v-6 - 8;
        /*SL:295*/if (v-8.func_77973_b() == Items.field_151153_ao && v-8.func_77962_s()) {
            /*SL:296*/this.renderer.drawStringWithShadow("god", v-7 * 2, n, -3977919);
            /*SL:297*/n -= 8;
        }
        final NBTTagList func_77986_q = /*EL:300*/v-8.func_77986_q();
        /*SL:301*/if (func_77986_q.func_74745_c() > 2 && this.max.getValue()) {
            /*SL:302*/if (this.maxText.getValue()) {
                /*SL:303*/this.renderer.drawStringWithShadow("", v-7 * 2, n, ColorHolder.toHex(this.Mred.getValue(), this.Mgreen.getValue(), this.Mblue.getValue()));
                /*SL:304*/n -= 8;
            }
            else {
                /*SL:306*/this.renderer.drawStringWithShadow("max", v-7 * 2, n, ColorHolder.toHex(this.Mred.getValue(), this.Mgreen.getValue(), this.Mblue.getValue()));
                /*SL:307*/n -= 8;
            }
        }
        else {
            /*SL:310*/for (int i = 0; i < func_77986_q.func_74745_c(); ++i) {
                short a2 = /*EL:311*/func_77986_q.func_150305_b(i).func_74765_d("id");
                /*SL:312*/a2 = func_77986_q.func_150305_b(i).func_74765_d("lvl");
                final Enchantment v1 = /*EL:313*/Enchantment.func_185262_c((int)a2);
                /*SL:314*/if (v1 != null) {
                    String a3 = /*EL:315*/v1.func_190936_d() ? (TextFormatting.RED + v1.func_77316_c((int)a2).substring(/*EL:317*/11).substring(0, 1).toLowerCase()) : v1.func_77316_c((int)a2).substring(/*EL:318*/0, 1).toLowerCase();
                    /*SL:319*/a3 += a2;
                    /*SL:320*/this.renderer.drawStringWithShadow(a3, v-7 * 2, n, -1);
                    /*SL:321*/n -= 8;
                }
            }
        }
        /*SL:326*/if (DamageUtil.hasDurability(v-8)) {
            final int i = /*EL:327*/DamageUtil.getRoundedDamage(v-8);
            String s;
            /*SL:329*/if (i >= 60) {
                /*SL:330*/s = "�a";
            }
            else/*SL:331*/ if (i >= 25) {
                /*SL:332*/s = "�e";
            }
            else {
                /*SL:334*/s = "�c";
            }
            /*SL:336*/this.renderer.drawStringWithShadow(s + i + "%", v-7 * 2, n, -1);
        }
    }
    
    private float getBiggestArmorTag(final EntityPlayer v-8) {
        float n = /*EL:341*/0.0f;
        boolean b = /*EL:342*/false;
        /*SL:343*/for (final ItemStack func_77946_l : v-8.field_71071_by.field_70460_b) {
            float n2 = /*EL:344*/0.0f;
            /*SL:345*/if (func_77946_l != null) {
                final NBTTagList list = /*EL:346*/func_77946_l.func_77986_q();
                /*SL:347*/for (int i = 0; i < list.func_74745_c(); ++i) {
                    final short a1 = /*EL:348*/list.func_150305_b(i).func_74765_d("id");
                    final Enchantment v1 = /*EL:349*/Enchantment.func_185262_c((int)a1);
                    /*SL:350*/if (v1 != null) {
                        /*SL:351*/n2 += 8.0f;
                        /*SL:352*/b = true;
                    }
                }
            }
            /*SL:356*/if (n2 > n) {
                n = n2;
            }
        }
        final ItemStack func_77946_l2 = /*EL:358*/v-8.func_184614_ca().func_77946_l();
        /*SL:359*/if (func_77946_l2.func_77962_s()) {
            float n3 = /*EL:360*/0.0f;
            final NBTTagList func_77986_q = /*EL:361*/func_77946_l2.func_77986_q();
            /*SL:362*/for (int j = 0; j < func_77986_q.func_74745_c(); ++j) {
                final short func_74765_d = /*EL:363*/func_77986_q.func_150305_b(j).func_74765_d("id");
                final Enchantment v2 = /*EL:364*/Enchantment.func_185262_c((int)func_74765_d);
                /*SL:365*/if (v2 != null) {
                    /*SL:366*/n3 += 8.0f;
                    /*SL:367*/b = true;
                }
            }
            /*SL:370*/if (n3 > n) {
                n = n3;
            }
        }
        ItemStack func_77946_l = /*EL:372*/v-8.func_184592_cb().func_77946_l();
        /*SL:373*/if (func_77946_l.func_77962_s()) {
            float n2 = /*EL:374*/0.0f;
            final NBTTagList list = /*EL:375*/func_77946_l.func_77986_q();
            /*SL:376*/for (int i = 0; i < list.func_74745_c(); ++i) {
                final short v3 = /*EL:377*/list.func_150305_b(i).func_74765_d("id");
                final Enchantment v1 = /*EL:378*/Enchantment.func_185262_c((int)v3);
                /*SL:379*/if (v1 != null) {
                    /*SL:380*/n2 += 8.0f;
                    /*SL:381*/b = true;
                }
            }
            /*SL:384*/if (n2 > n) {
                n = n2;
            }
        }
        /*SL:386*/return (b ? 0 : 20) + n;
    }
    
    private String getDisplayTag(final EntityPlayer v-2) {
        String s = /*EL:390*/v-2.func_145748_c_().func_150254_d();
        /*SL:391*/if (s.contains(Nametags.mc.func_110432_I().func_111285_a())) {
            /*SL:392*/s = "You";
        }
        /*SL:395*/if (!this.health.getValue()) {
            /*SL:396*/return s;
        }
        final float v0 = /*EL:399*/EntityUtil.getHealth((Entity)v-2);
        String v = null;
        /*SL:402*/if (v0 > 18.0f) {
            final String a1 = /*EL:403*/"�a";
        }
        else/*SL:404*/ if (v0 > 16.0f) {
            /*SL:405*/v = "�2";
        }
        else/*SL:406*/ if (v0 > 12.0f) {
            /*SL:407*/v = "�e";
        }
        else/*SL:408*/ if (v0 > 8.0f) {
            /*SL:409*/v = "�c";
        }
        else/*SL:410*/ if (v0 > 5.0f) {
            /*SL:411*/v = "�4";
        }
        else {
            /*SL:413*/v = "�4";
        }
        String v2 = /*EL:416*/"";
        /*SL:417*/if (this.ping.getValue()) {
            try {
                final int v3 = /*EL:419*/Objects.<NetHandlerPlayClient>requireNonNull(Nametags.mc.func_147114_u()).func_175102_a(v-2.func_110124_au()).func_178853_c();
                /*SL:420*/v2 = v2 + v3 + "ms ";
            }
            catch (Exception ex) {}
        }
        String v4 = /*EL:424*/"";
        /*SL:425*/if (this.entityID.getValue()) {
            /*SL:426*/v4 = v4 + "ID: " + v-2.func_145782_y() + " ";
        }
        String v5 = /*EL:429*/"";
        /*SL:430*/if (this.gamemode.getValue()) {
            /*SL:431*/if (v-2.func_184812_l_()) {
                /*SL:432*/v5 += "[C] ";
            }
            else/*SL:433*/ if (v-2.func_175149_v() || v-2.func_82150_aj()) {
                /*SL:434*/v5 += "[I] ";
            }
            else {
                /*SL:436*/v5 += "[S] ";
            }
        }
        /*SL:440*/if (Math.floor(v0) == v0) {
            /*SL:441*/s = s + v + " " + ((v0 > 0.0f) ? ((int)Math.floor(v0)) : "dead");
        }
        else {
            /*SL:443*/s = s + v + " " + ((v0 > 0.0f) ? ((int)v0) : "dead");
        }
        /*SL:445*/return " " + v2 + v4 + v5 + s + " ";
    }
    
    private double interpolate(final double a1, final double a2, final float a3) {
        /*SL:449*/return a1 + (a2 - a1) * a3;
    }
    
    public void drawOutlineRect(final float a1, final float a2, final float a3, final float a4, final int a5) {
        final float v1 = /*EL:453*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:454*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:455*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:456*/(a5 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:457*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:458*/v5.func_178180_c();
        /*SL:459*/GlStateManager.func_179147_l();
        /*SL:460*/GlStateManager.func_179090_x();
        /*SL:461*/GlStateManager.func_187441_d((float)this.Owidth.getValue());
        /*SL:462*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:463*/v6.func_181668_a(2, DefaultVertexFormats.field_181706_f);
        /*SL:464*/v6.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:465*/v6.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:466*/v6.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:467*/v6.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:468*/v5.func_78381_a();
        /*SL:469*/GlStateManager.func_179098_w();
        /*SL:470*/GlStateManager.func_179084_k();
    }
    
    public void drawRect(final float a1, final float a2, final float a3, final float a4, final int a5) {
        final float v1 = /*EL:474*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:475*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:476*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:477*/(a5 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:478*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:479*/v5.func_178180_c();
        /*SL:480*/GlStateManager.func_179147_l();
        /*SL:481*/GlStateManager.func_179090_x();
        /*SL:482*/GlStateManager.func_187441_d((float)this.Owidth.getValue());
        /*SL:483*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:484*/v6.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:485*/v6.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:486*/v6.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:487*/v6.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:488*/v6.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:489*/v5.func_78381_a();
        /*SL:490*/GlStateManager.func_179098_w();
        /*SL:491*/GlStateManager.func_179084_k();
    }
    
    @Override
    public void onUpdate() {
        /*SL:496*/if (this.outline.getValue().equals(false)) {
            /*SL:497*/this.rect.setValue(true);
        }
        else/*SL:498*/ if (this.rect.getValue().equals(false)) {
            /*SL:499*/this.outline.setValue(true);
        }
        /*SL:501*/if (this.ORainbow.getValue()) {
            /*SL:502*/this.OutlineRainbow();
        }
        /*SL:504*/if (this.NCRainbow.getValue()) {
            /*SL:505*/this.TextRainbow();
        }
        /*SL:507*/if (this.FCRainbow.getValue()) {
            /*SL:508*/this.FriendRainbow();
        }
        /*SL:510*/if (this.SCRainbow.getValue()) {
            /*SL:511*/this.SneakColorRainbow();
        }
        /*SL:513*/if (this.ICRainbow.getValue()) {
            /*SL:514*/this.InvisibleRainbow();
        }
        /*SL:516*/if (this.FORainbow.getValue()) {
            /*SL:517*/this.FriendOutlineRainbow();
        }
        /*SL:519*/if (this.IORainbow.getValue()) {
            /*SL:520*/this.InvisibleOutlineRainbow();
        }
        /*SL:522*/if (this.SORainbow.getValue()) {
            /*SL:523*/this.SneakOutlineRainbow();
        }
    }
    
    public void OutlineRainbow() {
        final float[] v1 = /*EL:530*/{ /*EL:531*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:534*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:536*/this.Ored.setValue(v2 >> 16 & 0xFF);
        /*SL:537*/this.Ogreen.setValue(v2 >> 8 & 0xFF);
        /*SL:538*/this.Oblue.setValue(v2 & 0xFF);
    }
    
    public void TextRainbow() {
        final float[] v1 = /*EL:542*/{ /*EL:543*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:546*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:548*/this.NCred.setValue(v2 >> 16 & 0xFF);
        /*SL:549*/this.NCgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:550*/this.NCblue.setValue(v2 & 0xFF);
    }
    
    public void FriendRainbow() {
        final float[] v1 = /*EL:554*/{ /*EL:555*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:558*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:560*/this.FCred.setValue(v2 >> 16 & 0xFF);
        /*SL:561*/this.FCgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:562*/this.FCblue.setValue(v2 & 0xFF);
    }
    
    public void SneakColorRainbow() {
        final float[] v1 = /*EL:566*/{ /*EL:567*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:570*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:572*/this.SCred.setValue(v2 >> 16 & 0xFF);
        /*SL:573*/this.SCgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:574*/this.SCblue.setValue(v2 & 0xFF);
    }
    
    public void InvisibleRainbow() {
        final float[] v1 = /*EL:578*/{ /*EL:579*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:582*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:584*/this.ICred.setValue(v2 >> 16 & 0xFF);
        /*SL:585*/this.ICgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:586*/this.ICblue.setValue(v2 & 0xFF);
    }
    
    public void InvisibleOutlineRainbow() {
        final float[] v1 = /*EL:590*/{ /*EL:591*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:594*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:596*/this.IOred.setValue(v2 >> 16 & 0xFF);
        /*SL:597*/this.IOgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:598*/this.IOblue.setValue(v2 & 0xFF);
    }
    
    public void FriendOutlineRainbow() {
        final float[] v1 = /*EL:602*/{ /*EL:603*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:606*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:608*/this.FOred.setValue(v2 >> 16 & 0xFF);
        /*SL:609*/this.FOgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:610*/this.FOblue.setValue(v2 & 0xFF);
    }
    
    public void SneakOutlineRainbow() {
        final float[] v1 = /*EL:614*/{ /*EL:615*/System.currentTimeMillis() % 11520L / 11520.0f };
        final int v2 = /*EL:618*/Color.HSBtoRGB(v1[0], 0.8f, 0.8f);
        /*SL:620*/this.SOred.setValue(v2 >> 16 & 0xFF);
        /*SL:621*/this.SOgreen.setValue(v2 >> 8 & 0xFF);
        /*SL:622*/this.SOblue.setValue(v2 & 0xFF);
    }
    
    static {
        Nametags.INSTANCE = new Nametags();
    }
}
