package me.dev.legacy.modules.render;

import org.lwjgl.opengl.GL11;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBase;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class PlayerChams extends Module
{
    public static PlayerChams INSTANCE;
    Setting<Sets> page;
    public final Setting<Boolean> chams;
    public final Setting<Boolean> wireframe;
    public final Setting<Float> scale;
    public final Setting<Float> lineWidth;
    public final Setting<Integer> alpha;
    public final Setting<Integer> visibleRed;
    public final Setting<Integer> visibleGreen;
    public final Setting<Integer> visibleBlue;
    public final Setting<Integer> invisibleRed;
    public final Setting<Integer> invisibleGreen;
    public final Setting<Integer> invisibleBlue;
    
    public PlayerChams() {
        super("PlayerChams", "draws chams", Category.RENDER, true, false, false);
        this.page = (Setting<Sets>)this.register(new Setting("Page", (T)Sets.OTHER));
        this.chams = (Setting<Boolean>)this.register(new Setting("Chams", (T)false, a1 -> this.page.getValue() == Sets.OTHER));
        this.wireframe = (Setting<Boolean>)this.register(new Setting("Wireframe", (T)false, a1 -> this.page.getValue() == Sets.OTHER));
        this.scale = (Setting<Float>)this.register(new Setting("Scale", (T)1.0f, (T)0.1f, (T)1.1f, a1 -> this.page.getValue() == Sets.OTHER));
        this.lineWidth = (Setting<Float>)this.register(new Setting("Linewidth", (T)1.0f, (T)0.1f, (T)3.0f, a1 -> this.page.getValue() == Sets.OTHER));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)100, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.visibleRed = (Setting<Integer>)this.register(new Setting("Visible Red", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.visibleGreen = (Setting<Integer>)this.register(new Setting("Visible Green", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.visibleBlue = (Setting<Integer>)this.register(new Setting("Visible Blue", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.invisibleRed = (Setting<Integer>)this.register(new Setting("Invisible Red", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.invisibleGreen = (Setting<Integer>)this.register(new Setting("Invisible Green", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        this.invisibleBlue = (Setting<Integer>)this.register(new Setting("Invisible Blue", (T)255, (T)0, (T)255, a1 -> this.page.getValue() == Sets.COLOR));
        PlayerChams.INSTANCE = this;
    }
    
    public final void onRenderModel(final ModelBase a1, final Entity a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8) {
        /*SL:41*/if (a2 instanceof EntityPlayer) {
            /*SL:42*/return;
        }
        /*SL:44*/GL11.glPushAttrib(1048575);
        /*SL:45*/GL11.glPolygonMode(1032, 6913);
        /*SL:46*/GL11.glDisable(3553);
        /*SL:47*/GL11.glDisable(2896);
        /*SL:48*/GL11.glDisable(2929);
        /*SL:49*/GL11.glColorMaterial(1032, 5634);
        /*SL:50*/GL11.glEnable(2848);
        /*SL:51*/GL11.glEnable(3042);
        /*SL:52*/GL11.glBlendFunc(770, 771);
        /*SL:53*/GL11.glLineWidth((float)this.lineWidth.getValue());
        /*SL:54*/GL11.glDepthMask(false);
        /*SL:55*/GL11.glColor4d((double)(PlayerChams.INSTANCE.invisibleRed.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.invisibleGreen.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.invisibleBlue.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.alpha.getValue() / 255.0f));
        /*SL:56*/a1.func_78088_a(a2, a3, a4, a5, a6, a7, a8);
        /*SL:57*/GL11.glEnable(2929);
        /*SL:58*/GL11.glDepthMask(true);
        /*SL:59*/GL11.glColor4d((double)(PlayerChams.INSTANCE.visibleRed.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.visibleGreen.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.visibleBlue.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.alpha.getValue() / 255.0f));
        /*SL:60*/a1.func_78088_a(a2, a3, a4, a5, a6, a7, a8);
        /*SL:61*/GL11.glEnable(3042);
        /*SL:62*/GL11.glPopAttrib();
    }
    
    public enum Sets
    {
        COLOR, 
        OTHER;
    }
}
