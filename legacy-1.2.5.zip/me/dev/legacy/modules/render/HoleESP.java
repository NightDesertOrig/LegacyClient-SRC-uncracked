package me.dev.legacy.modules.render;

import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class HoleESP extends Module
{
    public Setting<Boolean> renderOwn;
    public Setting<Boolean> fov;
    public Setting<Boolean> rainbow;
    private final Setting<Integer> range;
    private final Setting<Integer> rangeY;
    public Setting<Boolean> box;
    public Setting<Boolean> gradientBox;
    public Setting<Boolean> invertGradientBox;
    public Setting<Boolean> outline;
    public Setting<Boolean> gradientOutline;
    public Setting<Boolean> invertGradientOutline;
    public Setting<Double> height;
    private Setting<Integer> red;
    private Setting<Integer> green;
    private Setting<Integer> blue;
    private Setting<Integer> alpha;
    private Setting<Integer> boxAlpha;
    private Setting<Float> lineWidth;
    public Setting<Boolean> safeColor;
    private Setting<Integer> safeRed;
    private Setting<Integer> safeGreen;
    private Setting<Integer> safeBlue;
    private Setting<Integer> safeAlpha;
    public Setting<Boolean> customOutline;
    private Setting<Integer> cRed;
    private Setting<Integer> cGreen;
    private Setting<Integer> cBlue;
    private Setting<Integer> cAlpha;
    private Setting<Integer> safecRed;
    private Setting<Integer> safecGreen;
    private Setting<Integer> safecBlue;
    private Setting<Integer> safecAlpha;
    private static HoleESP INSTANCE;
    private int currentAlpha;
    
    public HoleESP() {
        super("HoleESP", "Shows safe spots.", Category.RENDER, false, false, false);
        this.renderOwn = (Setting<Boolean>)this.register(new Setting("RenderOwn", (T)true));
        this.fov = (Setting<Boolean>)this.register(new Setting("InFov", (T)true));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)false));
        this.range = (Setting<Integer>)this.register(new Setting("RangeX", (T)0, (T)0, (T)10));
        this.rangeY = (Setting<Integer>)this.register(new Setting("RangeY", (T)0, (T)0, (T)10));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)true));
        this.gradientBox = (Setting<Boolean>)this.register(new Setting("Gradient", (T)false, a1 -> this.box.getValue()));
        this.invertGradientBox = (Setting<Boolean>)this.register(new Setting("ReverseGradient", (T)false, a1 -> this.gradientBox.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true));
        this.gradientOutline = (Setting<Boolean>)this.register(new Setting("GradientOutline", (T)false, a1 -> this.outline.getValue()));
        this.invertGradientOutline = (Setting<Boolean>)this.register(new Setting("ReverseOutline", (T)false, a1 -> this.gradientOutline.getValue()));
        this.height = (Setting<Double>)this.register(new Setting("Height", (T)0.0, (T)(-2.0), (T)2.0));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)0, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)0, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)125, (T)0, (T)255, a1 -> this.box.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.0f, (T)0.1f, (T)5.0f, a1 -> this.outline.getValue()));
        this.safeColor = (Setting<Boolean>)this.register(new Setting("BedrockColor", (T)false));
        this.safeRed = (Setting<Integer>)this.register(new Setting("BedrockRed", (T)0, (T)0, (T)255, a1 -> this.safeColor.getValue()));
        this.safeGreen = (Setting<Integer>)this.register(new Setting("BedrockGreen", (T)255, (T)0, (T)255, a1 -> this.safeColor.getValue()));
        this.safeBlue = (Setting<Integer>)this.register(new Setting("BedrockBlue", (T)0, (T)0, (T)255, a1 -> this.safeColor.getValue()));
        this.safeAlpha = (Setting<Integer>)this.register(new Setting("BedrockAlpha", (T)255, (T)0, (T)255, a1 -> this.safeColor.getValue()));
        this.customOutline = (Setting<Boolean>)this.register(new Setting("CustomLine", (T)false, a1 -> this.outline.getValue()));
        this.cRed = (Setting<Integer>)this.register(new Setting("OL-Red", (T)0, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue()));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OL-Green", (T)0, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue()));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OL-Blue", (T)255, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue()));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OL-Alpha", (T)255, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue()));
        this.safecRed = (Setting<Integer>)this.register(new Setting("OL-SafeRed", (T)0, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue() && this.safeColor.getValue()));
        this.safecGreen = (Setting<Integer>)this.register(new Setting("OL-SafeGreen", (T)255, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue() && this.safeColor.getValue()));
        this.safecBlue = (Setting<Integer>)this.register(new Setting("OL-SafeBlue", (T)0, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue() && this.safeColor.getValue()));
        this.safecAlpha = (Setting<Integer>)this.register(new Setting("OL-SafeAlpha", (T)255, (T)0, (T)255, a1 -> this.customOutline.getValue() && this.outline.getValue() && this.safeColor.getValue()));
        this.currentAlpha = 0;
        this.setInstance();
    }
    
    private void setInstance() {
        HoleESP.INSTANCE = /*EL:58*/this;
    }
    
    public static HoleESP getInstance() {
        /*SL:62*/if (HoleESP.INSTANCE == null) {
            HoleESP.INSTANCE = /*EL:63*/new HoleESP();
        }
        /*SL:65*/return HoleESP.INSTANCE;
    }
    
    @Override
    public void onRender3D(final Render3DEvent v-3) {
        assert HoleESP.mc.field_175622_Z != /*EL:70*/null;
        final Vec3i vec3i = /*EL:71*/new Vec3i(HoleESP.mc.field_175622_Z.field_70165_t, HoleESP.mc.field_175622_Z.field_70163_u, HoleESP.mc.field_175622_Z.field_70161_v);
        /*SL:72*/for (int i = vec3i.func_177958_n() - this.range.getValue(); i < vec3i.func_177958_n() + this.range.getValue(); ++i) {
            /*SL:73*/for (int v0 = vec3i.func_177952_p() - this.range.getValue(); v0 < vec3i.func_177952_p() + this.range.getValue(); ++v0) {
                /*SL:74*/for (int v = vec3i.func_177956_o() + this.rangeY.getValue(); v > vec3i.func_177956_o() - this.rangeY.getValue(); --v) {
                    final BlockPos a1 = /*EL:75*/new BlockPos(i, v, v0);
                    /*SL:76*/if (HoleESP.mc.field_71441_e.func_180495_p(a1).func_177230_c().equals(Blocks.field_150350_a) && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a) && (!a1.equals((Object)new BlockPos(HoleESP.mc.field_71439_g.field_70165_t, HoleESP.mc.field_71439_g.field_70163_u, HoleESP.mc.field_71439_g.field_70161_v)) || this.renderOwn.getValue())) {
                        if (BlockUtil.isPosInFov(a1) || !this.fov.getValue()) {
                            /*SL:78*/if (HoleESP.mc.field_71441_e.func_180495_p(a1.func_177978_c()).func_177230_c() == Blocks.field_150357_h && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177974_f()).func_177230_c() == Blocks.field_150357_h && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177976_e()).func_177230_c() == Blocks.field_150357_h && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177968_d()).func_177230_c() == Blocks.field_150357_h && HoleESP.mc.field_71441_e.func_180495_p(a1.func_177977_b()).func_177230_c() == Blocks.field_150357_h) {
                                /*SL:79*/RenderUtil.drawBoxESP(a1, ((boolean)this.rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.safeRed.getValue(), this.safeGreen.getValue(), this.safeBlue.getValue(), this.safeAlpha.getValue()), this.customOutline.getValue(), new Color(this.safecRed.getValue(), this.safecGreen.getValue(), this.safecBlue.getValue(), this.safecAlpha.getValue()), this.lineWidth.getValue(), this.outline.getValue(), this.box.getValue(), this.boxAlpha.getValue(), true, this.height.getValue(), this.gradientBox.getValue(), this.gradientOutline.getValue(), this.invertGradientBox.getValue(), this.invertGradientOutline.getValue(), this.currentAlpha);
                            }
                            else/*SL:82*/ if (BlockUtil.isBlockUnSafe(HoleESP.mc.field_71441_e.func_180495_p(a1.func_177977_b()).func_177230_c()) && BlockUtil.isBlockUnSafe(HoleESP.mc.field_71441_e.func_180495_p(a1.func_177974_f()).func_177230_c()) && BlockUtil.isBlockUnSafe(HoleESP.mc.field_71441_e.func_180495_p(a1.func_177976_e()).func_177230_c()) && BlockUtil.isBlockUnSafe(HoleESP.mc.field_71441_e.func_180495_p(a1.func_177968_d()).func_177230_c())) {
                                if (BlockUtil.isBlockUnSafe(HoleESP.mc.field_71441_e.func_180495_p(a1.func_177978_c()).func_177230_c())) {
                                    /*SL:84*/RenderUtil.drawBoxESP(a1, ((boolean)this.rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.customOutline.getValue(), new Color(this.cRed.getValue(), this.cGreen.getValue(), this.cBlue.getValue(), this.cAlpha.getValue()), this.lineWidth.getValue(), this.outline.getValue(), this.box.getValue(), this.boxAlpha.getValue(), true, this.height.getValue(), this.gradientBox.getValue(), this.gradientOutline.getValue(), this.invertGradientBox.getValue(), this.invertGradientOutline.getValue(), this.currentAlpha);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    static {
        HoleESP.INSTANCE = new HoleESP();
    }
}
