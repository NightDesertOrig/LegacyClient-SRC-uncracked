package me.dev.legacy.api.manager;

import java.util.Iterator;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.Enemy;
import io.netty.util.internal.ConcurrentSet;

public class Enemies extends RotationManager
{
    private static ConcurrentSet<Enemy> enemies;
    
    public static void addEnemy(final String a1) {
        Enemies.enemies.add(/*EL:10*/(Object)new Enemy(a1));
    }
    
    public static void delEnemy(final String a1) {
        Enemies.enemies.remove((Object)getEnemyByName(/*EL:13*/a1));
    }
    
    public static Enemy getEnemyByName(final String v1) {
        /*SL:16*/for (final Enemy a1 : Enemies.enemies) {
            /*SL:17*/if (Legacy.enemy.username.equalsIgnoreCase(v1)) {
                /*SL:18*/return a1;
            }
        }
        /*SL:21*/return null;
    }
    
    public static ConcurrentSet<Enemy> getEnemies() {
        /*SL:24*/return Enemies.enemies;
    }
    
    public static boolean isEnemy(final String a1) {
        /*SL:27*/return Enemies.enemies.stream().anyMatch(a2 -> a2.username.equalsIgnoreCase(a1));
    }
    
    static {
        Enemies.enemies = (ConcurrentSet<Enemy>)new ConcurrentSet();
    }
}
