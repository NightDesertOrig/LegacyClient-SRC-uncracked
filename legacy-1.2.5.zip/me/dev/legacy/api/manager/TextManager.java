package me.dev.legacy.api.manager;

import net.minecraft.util.math.MathHelper;
import me.dev.legacy.api.util.MathUtil;
import java.awt.Color;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.Legacy;
import java.awt.Font;
import me.dev.legacy.impl.gui.font.CustomFont;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.api.AbstractModule;

public class TextManager extends AbstractModule
{
    private final Timer idleTimer;
    public int scaledWidth;
    public int scaledHeight;
    public int scaleFactor;
    private CustomFont customFont;
    private boolean idling;
    
    public TextManager() {
        this.idleTimer = new Timer();
        this.customFont = new CustomFont(new Font("Verdana", 0, 17), true, false);
        this.updateResolution();
    }
    
    public void init(final boolean a1) {
        final me.dev.legacy.modules.client.Font v1 = Legacy.moduleManager.<me.dev.legacy.modules.client.Font>getModuleByClass(/*EL:28*/me.dev.legacy.modules.client.Font.class);
        try {
            /*SL:30*/this.setFontRenderer(new Font(v1.fontName.getValue(), v1.fontStyle.getValue(), v1.fontSize.getValue()), v1.antiAlias.getValue(), v1.fractionalMetrics.getValue());
        }
        catch (Exception ex) {}
    }
    
    public void drawStringWithShadow(final String a1, final float a2, final float a3, final int a4) {
        /*SL:37*/this.drawString(a1, a2, a3, a4, true);
    }
    
    public float drawString(final String a1, final float a2, final float a3, final int a4, final boolean a5) {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:41*/if (ModuleManager.isModuleEnabled(me.dev.legacy.modules.client.Font.getInstance().getName())) {
            /*SL:42*/if (a5) {
                /*SL:43*/this.customFont.drawStringWithShadow(a1, a2, a3, a4);
            }
            else {
                /*SL:45*/this.customFont.drawString(a1, a2, a3, a4);
            }
            /*SL:47*/return a2;
        }
        TextManager.mc.field_71466_p.func_175065_a(/*EL:49*/a1, a2, a3, a4, a5);
        /*SL:50*/return a2;
    }
    
    public void drawRainbowString(final String a6, final float v1, final float v2, final int v3, final float v4, final boolean v5) {
        Color v6 = /*EL:53*/new Color(v3);
        final float v7 = /*EL:54*/1.0f / v4;
        final String[] v8 = /*EL:55*/a6.split("�.");
        float v9 = /*EL:56*/Color.RGBtoHSB(v6.getRed(), v6.getGreen(), v6.getBlue(), null)[0];
        final float v10 = /*EL:57*/Color.RGBtoHSB(v6.getRed(), v6.getGreen(), v6.getBlue(), null)[1];
        final float v11 = /*EL:58*/Color.RGBtoHSB(v6.getRed(), v6.getGreen(), v6.getBlue(), null)[2];
        int v12 = /*EL:59*/0;
        boolean v13 = /*EL:60*/true;
        boolean v14 = /*EL:61*/false;
        /*SL:62*/for (int a7 = 0; a7 < a6.length(); ++a7) {
            final char a8 = /*EL:63*/a6.charAt(a7);
            final char a9 = /*EL:64*/a6.charAt(MathUtil.clamp(a7 + 1, 0, a6.length() - 1));
            /*SL:65*/if ((String.valueOf(a8) + a9).equals("�r")) {
                /*SL:66*/v13 = false;
            }
            else/*SL:67*/ if ((String.valueOf(a8) + a9).equals("�+")) {
                /*SL:68*/v13 = true;
            }
            /*SL:70*/if (v14) {
                /*SL:71*/v14 = false;
            }
            else {
                /*SL:74*/if ((String.valueOf(a8) + a9).equals("�r")) {
                    final String a10 = /*EL:75*/a6.substring(a7);
                    /*SL:76*/this.drawString(a10, v1 + v12, v2, Color.WHITE.getRGB(), v5);
                    /*SL:77*/break;
                }
                /*SL:79*/this.drawString(String.valueOf(a8).equals("�") ? "" : String.valueOf(a8), v1 + v12, v2, v13 ? v6.getRGB() : Color.WHITE.getRGB(), v5);
                /*SL:80*/if (String.valueOf(a8).equals("�")) {
                    /*SL:81*/v14 = true;
                }
                /*SL:83*/v12 += this.getStringWidth(String.valueOf(a8));
                /*SL:84*/if (!String.valueOf(a8).equals(" ")) {
                    /*SL:85*/v6 = new Color(Color.HSBtoRGB(v9, v10, v11));
                    /*SL:86*/v9 += v7;
                }
            }
        }
    }
    
    public int getStringWidth(final String a1) {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:91*/if (ModuleManager.isModuleEnabled(me.dev.legacy.modules.client.Font.getInstance().getName())) {
            /*SL:92*/return this.customFont.getStringWidth(a1);
        }
        /*SL:94*/return TextManager.mc.field_71466_p.func_78256_a(a1);
    }
    
    public int getFontHeight() {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:98*/if (ModuleManager.isModuleEnabled(me.dev.legacy.modules.client.Font.getInstance().getName())) {
            final String v1 = /*EL:99*/"A";
            /*SL:100*/return this.customFont.getStringHeight(v1);
        }
        /*SL:102*/return TextManager.mc.field_71466_p.field_78288_b;
    }
    
    public void setFontRenderer(final Font a1, final boolean a2, final boolean a3) {
        /*SL:106*/this.customFont = new CustomFont(a1, a2, a3);
    }
    
    public Font getCurrentFont() {
        /*SL:110*/return this.customFont.getFont();
    }
    
    public void updateResolution() {
        /*SL:114*/this.scaledWidth = TextManager.mc.field_71443_c;
        /*SL:115*/this.scaledHeight = TextManager.mc.field_71440_d;
        /*SL:116*/this.scaleFactor = 1;
        final boolean v1 = TextManager.mc.func_152349_b();
        int v2 = TextManager.mc.field_71474_y.field_74335_Z;
        /*SL:119*/if (v2 == 0) {
            /*SL:120*/v2 = 1000;
        }
        /*SL:122*/while (this.scaleFactor < v2 && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
            /*SL:123*/++this.scaleFactor;
        }
        /*SL:125*/if (v1 && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
            /*SL:126*/--this.scaleFactor;
        }
        final double v3 = /*EL:128*/this.scaledWidth / this.scaleFactor;
        final double v4 = /*EL:129*/this.scaledHeight / this.scaleFactor;
        /*SL:130*/this.scaledWidth = MathHelper.func_76143_f(v3);
        /*SL:131*/this.scaledHeight = MathHelper.func_76143_f(v4);
    }
    
    public String getIdleSign() {
        /*SL:135*/if (this.idleTimer.passedMs(500L)) {
            /*SL:136*/this.idling = !this.idling;
            /*SL:137*/this.idleTimer.reset();
        }
        /*SL:139*/if (this.idling) {
            /*SL:140*/return "_";
        }
        /*SL:142*/return "";
    }
}
