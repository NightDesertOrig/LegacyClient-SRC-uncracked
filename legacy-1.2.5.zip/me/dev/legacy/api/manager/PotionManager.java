package me.dev.legacy.api.manager;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.potion.Potion;
import java.util.Iterator;
import net.minecraft.client.resources.I18n;
import java.util.ArrayList;
import net.minecraft.potion.PotionEffect;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import me.dev.legacy.api.AbstractModule;

public class PotionManager extends AbstractModule
{
    private final Map<EntityPlayer, PotionList> potions;
    
    public PotionManager() {
        this.potions = new ConcurrentHashMap<EntityPlayer, PotionList>();
    }
    
    public List<PotionEffect> getOwnPotions() {
        /*SL:20*/return this.getPlayerPotions((EntityPlayer)PotionManager.mc.field_71439_g);
    }
    
    public List<PotionEffect> getPlayerPotions(final EntityPlayer a1) {
        final PotionList v1 = /*EL:24*/this.potions.get(a1);
        List<PotionEffect> v2 = /*EL:25*/new ArrayList<PotionEffect>();
        /*SL:26*/if (v1 != null) {
            /*SL:27*/v2 = v1.getEffects();
        }
        /*SL:29*/return v2;
    }
    
    public PotionEffect[] getImportantPotions(final EntityPlayer v-2) {
        final PotionEffect[] array = /*EL:33*/new PotionEffect[3];
        /*SL:34*/for (final PotionEffect v1 : this.getPlayerPotions(v-2)) {
            final Potion a1 = /*EL:35*/v1.func_188419_a();
            final String lowerCase = /*EL:36*/I18n.func_135052_a(a1.func_76393_a(), new Object[0]).toLowerCase();
            switch (lowerCase) {
                case "strength": {
                    /*SL:38*/array[0] = v1;
                }
                case "weakness": {
                    /*SL:41*/array[1] = v1;
                }
                case "speed": {
                    /*SL:44*/array[2] = v1;
                    continue;
                }
            }
        }
        /*SL:48*/return array;
    }
    
    public String getPotionString(final PotionEffect a1) {
        final Potion v1 = /*EL:52*/a1.func_188419_a();
        /*SL:53*/return I18n.func_135052_a(v1.func_76393_a(), new Object[0]) + " " + (a1.func_76458_c() + 1) + " " + ChatFormatting.WHITE + Potion.func_188410_a(a1, 1.0f);
    }
    
    public String getColoredPotionString(final PotionEffect a1) {
        /*SL:57*/return this.getPotionString(a1);
    }
    
    public static class PotionList
    {
        private final List<PotionEffect> effects;
        
        public PotionList() {
            this.effects = new ArrayList<PotionEffect>();
        }
        
        public void addEffect(final PotionEffect a1) {
            /*SL:64*/if (a1 != null) {
                /*SL:65*/this.effects.add(a1);
            }
        }
        
        public List<PotionEffect> getEffects() {
            /*SL:70*/return this.effects;
        }
    }
}
