package me.dev.legacy.api.manager;

import me.dev.legacy.impl.gui.components.Component;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.api.util.ColorUtil;
import java.awt.Color;

public class ColorManager
{
    private float red;
    private float green;
    private float blue;
    private float alpha;
    private Color color;
    
    public ColorManager() {
        this.red = 1.0f;
        this.green = 1.0f;
        this.blue = 1.0f;
        this.alpha = 1.0f;
        this.color = new Color(this.red, this.green, this.blue, this.alpha);
    }
    
    public Color getColor() {
        /*SL:17*/return this.color;
    }
    
    public void setColor(final Color a1) {
        /*SL:21*/this.color = a1;
    }
    
    public int getColorAsInt() {
        /*SL:25*/return ColorUtil.toRGBA(this.color);
    }
    
    public int getColorAsIntFullAlpha() {
        /*SL:29*/return ColorUtil.toRGBA(new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), 255));
    }
    
    public int getColorWithAlpha(final int a1) {
        /*SL:33*/if (ClickGui.getInstance().rainbow.getValue()) {
            /*SL:34*/return ColorUtil.rainbow(Component.counter1[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB();
        }
        /*SL:36*/return ColorUtil.toRGBA(new Color(this.red, this.green, this.blue, a1 / 255.0f));
    }
    
    public void setColor(final float a1, final float a2, final float a3, final float a4) {
        /*SL:40*/this.red = a1;
        /*SL:41*/this.green = a2;
        /*SL:42*/this.blue = a3;
        /*SL:43*/this.alpha = a4;
        /*SL:44*/this.updateColor();
    }
    
    public void updateColor() {
        /*SL:48*/this.setColor(new Color(this.red, this.green, this.blue, this.alpha));
    }
    
    public void setColor(final int a1, final int a2, final int a3, final int a4) {
        /*SL:52*/this.red = a1 / 255.0f;
        /*SL:53*/this.green = a2 / 255.0f;
        /*SL:54*/this.blue = a3 / 255.0f;
        /*SL:55*/this.alpha = a4 / 255.0f;
        /*SL:56*/this.updateColor();
    }
    
    public void setRed(final float a1) {
        /*SL:60*/this.red = a1;
        /*SL:61*/this.updateColor();
    }
    
    public void setGreen(final float a1) {
        /*SL:65*/this.green = a1;
        /*SL:66*/this.updateColor();
    }
    
    public void setBlue(final float a1) {
        /*SL:70*/this.blue = a1;
        /*SL:71*/this.updateColor();
    }
    
    public void setAlpha(final float a1) {
        /*SL:75*/this.alpha = a1;
        /*SL:76*/this.updateColor();
    }
}
