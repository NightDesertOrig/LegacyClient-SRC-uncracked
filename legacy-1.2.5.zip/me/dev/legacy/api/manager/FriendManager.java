package me.dev.legacy.api.manager;

import java.util.UUID;
import me.dev.legacy.api.util.PlayerUtil;
import java.util.function.Predicate;
import java.util.Objects;
import me.dev.legacy.impl.setting.Setting;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import java.util.ArrayList;
import java.util.List;
import me.dev.legacy.api.AbstractModule;

public class FriendManager extends AbstractModule
{
    private List<Friend> friends;
    
    public FriendManager() {
        super("Friends");
        this.friends = new ArrayList<Friend>();
    }
    
    public boolean isFriend(final String a1) {
        /*SL:22*/this.cleanFriends();
        /*SL:23*/return this.friends.stream().anyMatch(a2 -> a2.username.equalsIgnoreCase(a1));
    }
    
    public boolean isFriend(final EntityPlayer a1) {
        /*SL:27*/return this.isFriend(a1.func_70005_c_());
    }
    
    public void addFriend(final String a1) {
        final Friend v1 = /*EL:31*/this.getFriendByName(a1);
        /*SL:32*/if (v1 != null) {
            /*SL:33*/this.friends.add(v1);
        }
        /*SL:35*/this.cleanFriends();
    }
    
    public void removeFriend(final String v2) {
        /*SL:39*/this.cleanFriends();
        /*SL:40*/for (final Friend a1 : this.friends) {
            /*SL:41*/if (!a1.getUsername().equalsIgnoreCase(v2)) {
                continue;
            }
            /*SL:42*/this.friends.remove(a1);
            break;
        }
    }
    
    public void onLoad() {
        /*SL:48*/this.friends = new ArrayList<Friend>();
        /*SL:49*/this.clearSettings();
    }
    
    public void saveFriends() {
        /*SL:53*/this.clearSettings();
        /*SL:54*/this.cleanFriends();
        /*SL:55*/for (final Friend v1 : this.friends) {
            /*SL:56*/this.register(new Setting(v1.getUuid().toString(), (T)v1.getUsername()));
        }
    }
    
    public void cleanFriends() {
        /*SL:61*/this.friends.stream().filter(Objects::nonNull).filter(a1 -> a1.getUsername() != null);
    }
    
    public List<Friend> getFriends() {
        /*SL:65*/this.cleanFriends();
        /*SL:66*/return this.friends;
    }
    
    public Friend getFriendByName(final String v2) {
        final UUID v3 = /*EL:70*/PlayerUtil.getUUIDFromName(v2);
        /*SL:71*/if (v3 != null) {
            final Friend a1 = /*EL:72*/new Friend(v2, v3);
            /*SL:73*/return a1;
        }
        /*SL:75*/return null;
    }
    
    public void addFriend(final Friend a1) {
        /*SL:79*/this.friends.add(a1);
    }
    
    public static class Friend
    {
        private final String username;
        private final UUID uuid;
        
        public Friend(final String a1, final UUID a2) {
            this.username = a1;
            this.uuid = a2;
        }
        
        public String getUsername() {
            /*SL:92*/return this.username;
        }
        
        public UUID getUuid() {
            /*SL:96*/return this.uuid;
        }
    }
}
