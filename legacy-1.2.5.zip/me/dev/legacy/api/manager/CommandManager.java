package me.dev.legacy.api.manager;

import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.LinkedList;
import me.dev.legacy.impl.command.commands.ReloadSoundCommand;
import me.dev.legacy.impl.command.commands.UnloadCommand;
import me.dev.legacy.impl.command.commands.ReloadCommand;
import me.dev.legacy.impl.command.commands.HelpCommand;
import me.dev.legacy.impl.command.commands.FriendCommand;
import me.dev.legacy.impl.command.commands.ConfigCommand;
import me.dev.legacy.impl.command.commands.PrefixCommand;
import me.dev.legacy.impl.command.commands.ModuleCommand;
import me.dev.legacy.impl.command.commands.BindCommand;
import me.dev.legacy.impl.command.Command;
import java.util.ArrayList;
import me.dev.legacy.api.AbstractModule;

public class CommandManager extends AbstractModule
{
    private final ArrayList<Command> commands;
    private String clientMessage;
    private String prefix;
    
    public CommandManager() {
        super("Command");
        this.commands = new ArrayList<Command>();
        this.clientMessage = "[Legacy]";
        this.prefix = "-";
        this.commands.add(new BindCommand());
        this.commands.add(new ModuleCommand());
        this.commands.add(new PrefixCommand());
        this.commands.add(new ConfigCommand());
        this.commands.add(new FriendCommand());
        this.commands.add(new HelpCommand());
        this.commands.add(new ReloadCommand());
        this.commands.add(new UnloadCommand());
        this.commands.add(new ReloadSoundCommand());
    }
    
    public static String[] removeElement(final String[] a2, final int v1) {
        final LinkedList<String> v2 = /*EL:31*/new LinkedList<String>();
        /*SL:32*/for (int a3 = 0; a3 < a2.length; ++a3) {
            /*SL:33*/if (a3 != v1) {
                /*SL:34*/v2.add(a2[a3]);
            }
        }
        /*SL:36*/return v2.<String>toArray(a2);
    }
    
    private static String strip(final String a1, final String a2) {
        /*SL:40*/if (a1.startsWith(a2) && a1.endsWith(a2)) {
            /*SL:41*/return a1.substring(a2.length(), a1.length() - a2.length());
        }
        /*SL:43*/return a1;
    }
    
    public void executeCommand(final String v-4) {
        final String[] split = /*EL:47*/v-4.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        final String substring = /*EL:48*/split[0].substring(1);
        final String[] removeElement = removeElement(/*EL:49*/split, 0);
        /*SL:50*/for (int a1 = 0; a1 < removeElement.length; ++a1) {
            /*SL:51*/if (removeElement[a1] != null) {
                /*SL:52*/removeElement[a1] = strip(removeElement[a1], "\"");
            }
        }
        /*SL:54*/for (final Command v1 : this.commands) {
            /*SL:55*/if (!v1.getName().equalsIgnoreCase(substring)) {
                continue;
            }
            /*SL:56*/v1.execute(split);
            /*SL:57*/return;
        }
        /*SL:59*/Command.sendMessage(ChatFormatting.GRAY + "Command not found, type 'help' for the commands list.");
    }
    
    public Command getCommandByName(final String v2) {
        /*SL:63*/for (final Command a1 : this.commands) {
            /*SL:64*/if (!a1.getName().equals(v2)) {
                continue;
            }
            /*SL:65*/return a1;
        }
        /*SL:67*/return null;
    }
    
    public ArrayList<Command> getCommands() {
        /*SL:71*/return this.commands;
    }
    
    public String getClientMessage() {
        /*SL:75*/return this.clientMessage;
    }
    
    public void setClientMessage(final String a1) {
        /*SL:79*/this.clientMessage = a1;
    }
    
    public String getPrefix() {
        /*SL:83*/return this.prefix;
    }
    
    public void setPrefix(final String a1) {
        /*SL:87*/this.prefix = a1;
    }
}
