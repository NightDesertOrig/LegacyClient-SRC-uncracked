package me.dev.legacy.api.manager;

import java.util.function.BiFunction;
import java.util.Iterator;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import me.dev.legacy.api.AbstractModule;

public class TotemPopManager extends AbstractModule
{
    private Map<EntityPlayer, Integer> poplist;
    private Set<EntityPlayer> toAnnounce;
    
    public TotemPopManager() {
        this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
        this.toAnnounce = new HashSet<EntityPlayer>();
    }
    
    public void onUpdate() {
        /*SL:17*/for (final EntityPlayer entityPlayer : this.toAnnounce) {
            /*SL:18*/if (entityPlayer == null) {
                continue;
            }
            int n = /*EL:19*/0;
            /*SL:20*/for (final char v1 : entityPlayer.func_70005_c_().toCharArray()) {
                /*SL:21*/n += v1;
                /*SL:22*/n *= 10;
            }
            /*SL:24*/this.toAnnounce.remove(entityPlayer);
            break;
        }
    }
    
    public void onLogout() {
    }
    
    public void init() {
    }
    
    public void onTotemPop(final EntityPlayer a1) {
        /*SL:38*/this.popTotem(a1);
        /*SL:39*/if (!a1.equals((Object)TotemPopManager.mc.field_71439_g)) {
            /*SL:40*/this.toAnnounce.add(a1);
        }
    }
    
    public void onDeath(final EntityPlayer v2) {
        int v3 = /*EL:46*/0;
        /*SL:47*/for (final char a1 : v2.func_70005_c_().toCharArray()) {
            /*SL:48*/v3 += a1;
            /*SL:49*/v3 *= 10;
        }
        /*SL:51*/this.toAnnounce.remove(v2);
    }
    
    public void onLogout(final EntityPlayer a1, final boolean a2) {
        /*SL:55*/if (a2) {
            /*SL:56*/this.resetPops(a1);
        }
    }
    
    public void onOwnLogout(final boolean a1) {
        /*SL:61*/if (a1) {
            /*SL:62*/this.clearList();
        }
    }
    
    public void clearList() {
        /*SL:67*/this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
    }
    
    public void resetPops(final EntityPlayer a1) {
        /*SL:71*/this.setTotemPops(a1, 0);
    }
    
    public void popTotem(final EntityPlayer a1) {
        /*SL:75*/this.poplist.merge(a1, 1, Integer::sum);
    }
    
    public void setTotemPops(final EntityPlayer a1, final int a2) {
        /*SL:79*/this.poplist.put(a1, a2);
    }
    
    public int getTotemPops(final EntityPlayer a1) {
        final Integer v1 = /*EL:83*/this.poplist.get(a1);
        /*SL:84*/if (v1 == null) {
            /*SL:85*/return 0;
        }
        /*SL:87*/return v1;
    }
    
    public String getTotemPopString(final EntityPlayer a1) {
        /*SL:91*/return "�f" + ((this.getTotemPops(a1) <= 0) ? "" : ("-" + this.getTotemPops(a1) + " "));
    }
}
