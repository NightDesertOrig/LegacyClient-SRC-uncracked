package me.dev.legacy.api.manager;

import net.minecraft.block.Block;
import java.util.Iterator;
import net.minecraft.util.math.Vec3i;
import net.minecraft.init.Blocks;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.entity.player.EntityPlayer;
import me.dev.legacy.api.util.EntityUtil;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.api.AbstractModule;

public class HoleManager extends AbstractModule
{
    private static final BlockPos[] surroundOffset;
    private final List<BlockPos> midSafety;
    private List<BlockPos> holes;
    
    public HoleManager() {
        this.midSafety = new ArrayList<BlockPos>();
        this.holes = new ArrayList<BlockPos>();
    }
    
    public void update() {
        /*SL:21*/if (!AbstractModule.fullNullCheck()) {
            /*SL:22*/this.holes = this.calcHoles();
        }
    }
    
    public List<BlockPos> getHoles() {
        /*SL:27*/return this.holes;
    }
    
    public List<BlockPos> getMidSafety() {
        /*SL:31*/return this.midSafety;
    }
    
    public List<BlockPos> getSortedHoles() {
        /*SL:35*/this.holes.sort(Comparator.<? super BlockPos>comparingDouble(a1 -> HoleManager.mc.field_71439_g.func_174818_b(a1)));
        /*SL:36*/return this.getHoles();
    }
    
    public List<BlockPos> calcHoles() {
        final ArrayList<BlockPos> list = /*EL:40*/new ArrayList<BlockPos>();
        /*SL:41*/this.midSafety.clear();
        final List<BlockPos> sphere = /*EL:42*/BlockUtil.getSphere(EntityUtil.getPlayerPos((EntityPlayer)HoleManager.mc.field_71439_g), 6.0f, 6, false, true, 0);
        /*SL:43*/for (final BlockPos blockPos : sphere) {
            /*SL:44*/if (HoleManager.mc.field_71441_e.func_180495_p(blockPos).func_177230_c().equals(Blocks.field_150350_a) && HoleManager.mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                if (!HoleManager.mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                    /*SL:45*/continue;
                }
                boolean b = /*EL:46*/true;
                boolean b2 = /*EL:47*/true;
                /*SL:48*/for (final BlockPos v0 : HoleManager.surroundOffset) {
                    final Block v = HoleManager.mc.field_71441_e.func_180495_p(/*EL:49*/blockPos.func_177971_a((Vec3i)v0)).func_177230_c();
                    /*SL:50*/if (BlockUtil.isBlockUnSolid(v)) {
                        /*SL:51*/b2 = false;
                    }
                    /*SL:53*/if (v != Blocks.field_150357_h && v != Blocks.field_150343_Z && v != Blocks.field_150477_bB) {
                        if (v != Blocks.field_150467_bQ) {
                            /*SL:55*/b = false;
                        }
                    }
                }
                /*SL:57*/if (b) {
                    /*SL:58*/list.add(blockPos);
                }
                /*SL:60*/if (!b2) {
                    continue;
                }
                /*SL:61*/this.midSafety.add(blockPos);
            }
        }
        /*SL:63*/return list;
    }
    
    public boolean isSafe(final BlockPos v-4) {
        boolean b = /*EL:67*/true;
        /*SL:68*/for (final BlockPos v1 : HoleManager.surroundOffset) {
            final Block a1 = HoleManager.mc.field_71441_e.func_180495_p(/*EL:69*/v-4.func_177971_a((Vec3i)v1)).func_177230_c();
            /*SL:70*/if (a1 != Blocks.field_150357_h) {
                /*SL:71*/b = false;
                /*SL:72*/break;
            }
        }
        /*SL:74*/return b;
    }
    
    static {
        surroundOffset = BlockUtil.toBlockPos(EntityUtil.getOffsets(0, true));
    }
}
