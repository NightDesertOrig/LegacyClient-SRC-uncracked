package me.dev.legacy.api.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EventStage extends Event
{
    private int stage;
    
    public EventStage() {
    }
    
    public EventStage(final int a1) {
        this.stage = a1;
    }
    
    public int getStage() {
        /*SL:17*/return this.stage;
    }
    
    public void setStage(final int a1) {
        /*SL:21*/this.stage = a1;
    }
}
