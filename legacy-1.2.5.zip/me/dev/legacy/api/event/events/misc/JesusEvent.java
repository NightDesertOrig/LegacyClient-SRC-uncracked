package me.dev.legacy.api.event.events.misc;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class JesusEvent extends EventStage
{
    private BlockPos pos;
    private AxisAlignedBB boundingBox;
    
    public JesusEvent(final int a1, final BlockPos a2) {
        super(a1);
        this.pos = a2;
    }
    
    public void setBoundingBox(final AxisAlignedBB a1) {
        /*SL:20*/this.boundingBox = a1;
    }
    
    public void setPos(final BlockPos a1) {
        /*SL:24*/this.pos = a1;
    }
    
    public BlockPos getPos() {
        /*SL:28*/return this.pos;
    }
    
    public AxisAlignedBB getBoundingBox() {
        /*SL:32*/return this.boundingBox;
    }
}
