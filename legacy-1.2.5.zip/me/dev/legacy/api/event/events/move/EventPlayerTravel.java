package me.dev.legacy.api.event.events.move;

import me.dev.legacy.api.event.events.MinecraftEvent;

public class EventPlayerTravel extends MinecraftEvent
{
    public float Strafe;
    public float Vertical;
    public float Forward;
    
    public EventPlayerTravel(final float a1, final float a2, final float a3) {
        this.Strafe = a1;
        this.Vertical = a2;
        this.Forward = a3;
    }
}
