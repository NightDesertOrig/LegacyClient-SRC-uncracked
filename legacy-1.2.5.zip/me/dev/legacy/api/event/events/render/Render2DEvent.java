package me.dev.legacy.api.event.events.render;

import net.minecraft.client.gui.ScaledResolution;
import me.dev.legacy.api.event.EventStage;

public class Render2DEvent extends EventStage
{
    public float partialTicks;
    public ScaledResolution scaledResolution;
    
    public Render2DEvent(final float a1, final ScaledResolution a2) {
        this.partialTicks = a1;
        this.scaledResolution = a2;
    }
    
    public void setPartialTicks(final float a1) {
        /*SL:17*/this.partialTicks = a1;
    }
    
    public void setScaledResolution(final ScaledResolution a1) {
        /*SL:21*/this.scaledResolution = a1;
    }
    
    public double getScreenWidth() {
        /*SL:25*/return this.scaledResolution.func_78327_c();
    }
    
    public double getScreenHeight() {
        /*SL:29*/return this.scaledResolution.func_78324_d();
    }
}
