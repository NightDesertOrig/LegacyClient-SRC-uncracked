package me.dev.legacy.api.event.events.render;

import me.dev.legacy.api.event.EventStage;

public class PerspectiveEvent extends EventStage
{
    private float aspect;
    
    public PerspectiveEvent(final float a1) {
        this.aspect = a1;
    }
    
    public float getAspect() {
        /*SL:13*/return this.aspect;
    }
    
    public void setAspect(final float a1) {
        /*SL:17*/this.aspect = a1;
    }
}
