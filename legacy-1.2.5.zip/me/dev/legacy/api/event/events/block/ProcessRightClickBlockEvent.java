package me.dev.legacy.api.event.events.block;

import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class ProcessRightClickBlockEvent extends EventStage
{
    public BlockPos pos;
    public EnumHand hand;
    public ItemStack stack;
    
    public ProcessRightClickBlockEvent(final BlockPos a1, final EnumHand a2, final ItemStack a3) {
        this.pos = a1;
        this.hand = a2;
        this.stack = a3;
    }
}
