package me.dev.legacy.api.event.events.block;

import net.minecraft.util.math.BlockPos;
import me.dev.legacy.api.event.EventStage;

public class BlockDestructionEvent extends EventStage
{
    BlockPos nigger;
    
    public BlockDestructionEvent(BlockPos a1) {
        a1 = a1;
    }
    
    public BlockPos getBlockPos() {
        /*SL:14*/return this.nigger;
    }
}
