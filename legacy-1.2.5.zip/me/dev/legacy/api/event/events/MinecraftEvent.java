package me.dev.legacy.api.event.events;

import me.dev.legacy.api.util.Wrapper;
import me.zero.alpine.fork.event.type.Cancellable;

public class MinecraftEvent extends Cancellable
{
    private Era era;
    private final float partialTicks;
    
    public MinecraftEvent() {
        this.era = Era.PRE;
        this.partialTicks = Wrapper.GetMC().func_184121_ak();
    }
    
    public MinecraftEvent(final Era a1) {
        this.era = Era.PRE;
        this.partialTicks = Wrapper.GetMC().func_184121_ak();
        this.era = a1;
    }
    
    public Era getEra() {
        /*SL:24*/return this.era;
    }
    
    public float getPartialTicks() {
        /*SL:29*/return this.partialTicks;
    }
    
    public enum Era
    {
        PRE, 
        PERI, 
        POST;
    }
}
