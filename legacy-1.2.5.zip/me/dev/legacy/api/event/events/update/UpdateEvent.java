package me.dev.legacy.api.event.events.update;

import me.dev.legacy.api.event.EventStage;

public class UpdateEvent extends EventStage
{
    private final int stage;
    
    public UpdateEvent(final int a1) {
        this.stage = a1;
    }
    
    @Override
    public final int getStage() {
        /*SL:14*/return this.stage;
    }
}
