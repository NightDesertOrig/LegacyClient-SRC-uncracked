package me.dev.legacy.api.event.events.other;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraft.network.Packet;
import me.dev.legacy.api.event.EventStage;

public class PacketEvent extends EventStage
{
    private final Packet<?> packet;
    
    public PacketEvent(final int a1, final Packet<?> a2) {
        super(a1);
        this.packet = a2;
    }
    
    public <T extends Object> T getPacket() {
        /*SL:17*/return (T)this.packet;
    }
    
    @Cancelable
    public static class Send extends PacketEvent
    {
        public Send(final int a1, final Packet<?> a2) {
            super(a1, a2);
        }
    }
    
    @Cancelable
    public static class Receive extends PacketEvent
    {
        public Receive(final int a1, final Packet<?> a2) {
            super(a1, a2);
        }
    }
}
