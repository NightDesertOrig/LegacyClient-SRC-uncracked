package me.dev.legacy.api.event.events.other;

import net.minecraft.network.Packet;
import me.dev.legacy.api.event.events.MinecraftEvent;

public class EventNetworkPacketEvent extends MinecraftEvent
{
    public Packet m_Packet;
    
    public EventNetworkPacketEvent(final me.dev.legacy.api.event.events.other.Packet a1) {
        this.m_Packet = (Packet)a1;
    }
    
    public Packet GetPacket() {
        /*SL:17*/return this.m_Packet;
    }
    
    public Packet getPacket() {
        /*SL:22*/return this.m_Packet;
    }
}
