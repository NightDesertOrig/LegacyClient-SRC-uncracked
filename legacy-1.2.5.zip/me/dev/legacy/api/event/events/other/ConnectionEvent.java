package me.dev.legacy.api.event.events.other;

import net.minecraft.entity.player.EntityPlayer;
import java.util.UUID;
import me.dev.legacy.api.event.EventStage;

public class ConnectionEvent extends EventStage
{
    private final UUID uuid;
    private final EntityPlayer entity;
    private final String name;
    
    public ConnectionEvent(final int a1, final UUID a2, final String a3) {
        super(a1);
        this.uuid = a2;
        this.name = a3;
        this.entity = null;
    }
    
    public ConnectionEvent(final int a1, final EntityPlayer a2, final UUID a3, final String a4) {
        super(a1);
        this.entity = a2;
        this.uuid = a3;
        this.name = a4;
    }
    
    public String getName() {
        /*SL:29*/return this.name;
    }
    
    public UUID getUuid() {
        /*SL:33*/return this.uuid;
    }
    
    public EntityPlayer getEntity() {
        /*SL:37*/return this.entity;
    }
}
