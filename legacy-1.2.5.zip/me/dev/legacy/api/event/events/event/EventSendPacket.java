package me.dev.legacy.api.event.events.event;

import me.dev.legacy.api.event.events.other.Packet;

public final class EventSendPacket extends EventCancellable
{
    private Packet packet;
    
    public EventSendPacket(final EventStage a1, final Packet a2) {
        super(a1);
        this.packet = a2;
    }
    
    public Packet getPacket() {
        /*SL:15*/return this.packet;
    }
    
    public void setPacket(final Packet a1) {
        /*SL:19*/this.packet = a1;
    }
}
