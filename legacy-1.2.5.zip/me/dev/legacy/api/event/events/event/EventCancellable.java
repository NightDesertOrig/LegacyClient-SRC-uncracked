package me.dev.legacy.api.event.events.event;

public class EventCancellable extends EventStageable
{
    private boolean canceled;
    
    public EventCancellable() {
    }
    
    public EventCancellable(final EventStage a1) {
        super(a1);
    }
    
    public EventCancellable(final EventStage a1, final boolean a2) {
        super(a1);
        this.canceled = a2;
    }
    
    public boolean isCanceled() {
        /*SL:20*/return this.canceled;
    }
    
    public void setCanceled(final boolean a1) {
        /*SL:24*/this.canceled = a1;
    }
}
