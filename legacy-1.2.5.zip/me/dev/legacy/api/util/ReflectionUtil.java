package me.dev.legacy.api.util;

import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.AccessibleObject;
import java.util.Objects;

public class ReflectionUtil
{
    public static <F, T extends F> void copyOf(final F a2, final T a3, final boolean v1) throws NoSuchFieldException, IllegalAccessException {
        /*SL:11*/Objects.<F>requireNonNull(a2);
        /*SL:12*/Objects.<T>requireNonNull(a3);
        final Class<?> v2 = /*EL:13*/a2.getClass();
        /*SL:14*/for (final Field a4 : v2.getDeclaredFields()) {
            makePublic(/*EL:15*/a4);
            /*SL:16*/if (!isStatic(a4)) {
                if (!v1 || !isFinal(a4)) {
                    makeMutable(/*EL:17*/a4);
                    /*SL:18*/a4.set(a3, a4.get(a2));
                }
            }
        }
    }
    
    public static <F, T extends F> void copyOf(final F a1, final T a2) throws NoSuchFieldException, IllegalAccessException {
        /*SL:23*/ReflectionUtil.<F, T>copyOf(a1, a2, false);
    }
    
    public static boolean isStatic(final Member a1) {
        /*SL:27*/return (a1.getModifiers() & 0x8) != 0x0;
    }
    
    public static boolean isFinal(final Member a1) {
        /*SL:31*/return (a1.getModifiers() & 0x10) != 0x0;
    }
    
    public static void makeAccessible(final AccessibleObject a1, final boolean a2) {
        /*SL:35*/Objects.<AccessibleObject>requireNonNull(a1);
        /*SL:36*/a1.setAccessible(a2);
    }
    
    public static void makePublic(final AccessibleObject a1) {
        makeAccessible(/*EL:40*/a1, true);
    }
    
    public static void makePrivate(final AccessibleObject a1) {
        makeAccessible(/*EL:44*/a1, false);
    }
    
    public static void makeMutable(final Member a1) throws NoSuchFieldException, IllegalAccessException {
        /*SL:48*/Objects.<Member>requireNonNull(a1);
        final Field v1 = /*EL:49*/Field.class.getDeclaredField("modifiers");
        makePublic(/*EL:50*/v1);
        /*SL:51*/v1.setInt(a1, a1.getModifiers() & 0xFFFFFFEF);
    }
    
    public static void makeImmutable(final Member a1) throws NoSuchFieldException, IllegalAccessException {
        /*SL:55*/Objects.<Member>requireNonNull(a1);
        final Field v1 = /*EL:56*/Field.class.getDeclaredField("modifiers");
        makePublic(/*EL:57*/v1);
        /*SL:58*/v1.setInt(a1, a1.getModifiers() & 0x10);
    }
}
