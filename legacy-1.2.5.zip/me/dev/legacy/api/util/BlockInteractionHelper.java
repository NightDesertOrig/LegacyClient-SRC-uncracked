package me.dev.legacy.api.util;

import java.util.Arrays;
import net.minecraft.init.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.entity.projectile.EntityEgg;
import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.block.Block;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.client.Minecraft;
import java.util.List;

public class BlockInteractionHelper
{
    public static final List blackList;
    public static final List shulkerList;
    private static final Minecraft mc;
    
    public static boolean hotbarSlotCheckEmpty(final ItemStack a1) {
        /*SL:32*/return a1 != ItemStack.field_190927_a;
    }
    
    public static boolean blockCheckNonBlock(final ItemStack a1) {
        /*SL:36*/return a1.func_77973_b() instanceof ItemBlock;
    }
    
    public static void rotate(final float a1, final float a2) {
        /*SL:40*/Minecraft.func_71410_x().field_71439_g.field_70177_z = a1;
        /*SL:41*/Minecraft.func_71410_x().field_71439_g.field_70125_A = a2;
    }
    
    public static void rotate(final double[] a1) {
        /*SL:45*/Minecraft.func_71410_x().field_71439_g.field_70177_z = (float)a1[0];
        /*SL:46*/Minecraft.func_71410_x().field_71439_g.field_70125_A = (float)a1[1];
    }
    
    public static double[] calculateLookAt(final double a1, final double a2, final double a3, final EntityPlayer a4) {
        double v1 = /*EL:50*/a4.field_70165_t - a1;
        double v2 = /*EL:51*/a4.field_70163_u - a2;
        double v3 = /*EL:52*/a4.field_70161_v - a3;
        final double v4 = /*EL:53*/Math.sqrt(v1 * v1 + v2 * v2 + v3 * v3);
        /*SL:54*/v1 /= v4;
        /*SL:55*/v2 /= v4;
        /*SL:56*/v3 /= v4;
        double v5 = /*EL:57*/Math.asin(v2);
        double v6 = /*EL:58*/Math.atan2(v3, v1);
        /*SL:59*/v5 = v5 * 180.0 / 3.141592653589793;
        /*SL:60*/v6 = v6 * 180.0 / 3.141592653589793;
        /*SL:61*/v6 += 90.0;
        /*SL:62*/return new double[] { v6, v5 };
    }
    
    public static void lookAtBlock(final BlockPos a1) {
        rotate(calculateLookAt(/*EL:66*/a1.func_177958_n(), a1.func_177956_o(), a1.func_177952_p(), (EntityPlayer)Minecraft.func_71410_x().field_71439_g));
    }
    
    public static void placeBlockScaffold(final BlockPos v-5) {
        final Vec3d vec3d = /*EL:70*/new Vec3d(Wrapper.getPlayer().field_70165_t, Wrapper.getPlayer().field_70163_u + Wrapper.getPlayer().func_70047_e(), Wrapper.getPlayer().field_70161_v);
        /*SL:71*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:72*/v-5.func_177972_a(v0);
            final EnumFacing v2 = /*EL:73*/v0.func_176734_d();
            /*SL:74*/if (canBeClicked(v)) {
                final Vec3d a1 = /*EL:75*/new Vec3d((Vec3i)v).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v2.func_176730_m()).func_178789_a(0.5f));
                /*SL:76*/if (vec3d.func_72436_e(a1) <= 18.0625) {
                    faceVectorPacketInstant(/*EL:77*/a1);
                    processRightClickBlock(/*EL:78*/v, v2, a1);
                    /*SL:79*/Wrapper.getPlayer().func_184609_a(EnumHand.MAIN_HAND);
                    BlockInteractionHelper.mc.field_71467_ac = /*EL:80*/4;
                    /*SL:81*/return;
                }
            }
        }
    }
    
    private static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:89*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:90*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:91*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:92*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:93*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:94*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:95*/return new float[] { Wrapper.getPlayer().field_70177_z + MathHelper.func_76142_g(v6 - Wrapper.getPlayer().field_70177_z), Wrapper.getPlayer().field_70125_A + MathHelper.func_76142_g(v7 - Wrapper.getPlayer().field_70125_A) };
    }
    
    private static Vec3d getEyesPos() {
        /*SL:99*/return new Vec3d(Wrapper.getPlayer().field_70165_t, Wrapper.getPlayer().field_70163_u + Wrapper.getPlayer().func_70047_e(), Wrapper.getPlayer().field_70161_v);
    }
    
    public static void faceVectorPacketInstant(final Vec3d a1) {
        final float[] v1 = getLegitRotations(/*EL:103*/a1);
        /*SL:104*/Wrapper.getPlayer().field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(v1[0], v1[1], Wrapper.getPlayer().field_70122_E));
    }
    
    private static void processRightClickBlock(final BlockPos a1, final EnumFacing a2, final Vec3d a3) {
        getPlayerController().func_187099_a(/*EL:108*/Wrapper.getPlayer(), BlockInteractionHelper.mc.field_71441_e, a1, a2, a3, EnumHand.MAIN_HAND);
    }
    
    public static boolean canBeClicked(final BlockPos a1) {
        /*SL:112*/return getBlock(a1).func_176209_a(getState(a1), false);
    }
    
    private static Block getBlock(final BlockPos a1) {
        /*SL:116*/return getState(a1).func_177230_c();
    }
    
    private static PlayerControllerMP getPlayerController() {
        /*SL:120*/return Minecraft.func_71410_x().field_71442_b;
    }
    
    private static IBlockState getState(final BlockPos a1) {
        /*SL:124*/return Wrapper.getWorld().func_180495_p(a1);
    }
    
    public static boolean checkForNeighbours(final BlockPos v-3) {
        /*SL:128*/if (!hasNeighbour(v-3)) {
            /*SL:129*/for (final EnumFacing v1 : EnumFacing.values()) {
                final BlockPos a1 = /*EL:130*/v-3.func_177972_a(v1);
                /*SL:131*/if (hasNeighbour(a1)) {
                    /*SL:132*/return true;
                }
            }
            /*SL:135*/return false;
        }
        /*SL:137*/return true;
    }
    
    public static List<BlockPos> getSphere(final BlockPos a6, final float v1, final int v2, final boolean v3, final boolean v4, final int v5) {
        final List<BlockPos> v6 = /*EL:141*/new ArrayList<BlockPos>();
        final int v7 = /*EL:142*/a6.func_177958_n();
        final int v8 = /*EL:143*/a6.func_177956_o();
        final int v9 = /*EL:144*/a6.func_177952_p();
        /*SL:145*/for (int a7 = v7 - (int)v1; a7 <= v7 + v1; ++a7) {
            /*SL:146*/for (int a8 = v9 - (int)v1; a8 <= v9 + v1; ++a8) {
                /*SL:147*/for (int a9 = v4 ? (v8 - (int)v1) : v8; a9 < (v4 ? (v8 + v1) : (v8 + v2)); ++a9) {
                    final double a10 = /*EL:148*/(v7 - a7) * (v7 - a7) + (v9 - a8) * (v9 - a8) + (v4 ? ((v8 - a9) * (v8 - a9)) : 0);
                    /*SL:149*/if (a10 < v1 * v1 && (!v3 || a10 >= (v1 - 1.0f) * (v1 - 1.0f))) {
                        final BlockPos a11 = /*EL:150*/new BlockPos(a7, a9 + v5, a8);
                        /*SL:151*/v6.add(a11);
                    }
                }
            }
        }
        /*SL:156*/return v6;
    }
    
    public static List<BlockPos> getCircle(final BlockPos v1, final int v2, final float v3, final boolean v4) {
        final List<BlockPos> v5 = /*EL:160*/new ArrayList<BlockPos>();
        final int v6 = /*EL:161*/v1.func_177958_n();
        final int v7 = /*EL:162*/v1.func_177952_p();
        /*SL:163*/for (BlockPos a4 = (BlockPos)(v6 - (int)v3); a4 <= v6 + v3; ++a4) {
            /*SL:164*/for (int a2 = v7 - (int)v3; a2 <= v7 + v3; ++a2) {
                final double a3 = /*EL:165*/(v6 - a4) * (v6 - a4) + (v7 - a2) * (v7 - a2);
                /*SL:166*/if (a3 < v3 * v3 && (!v4 || a3 >= (v3 - 1.0f) * (v3 - 1.0f))) {
                    /*SL:167*/a4 = new BlockPos(a4, v2, a2);
                    /*SL:168*/v5.add(a4);
                }
            }
        }
        /*SL:172*/return v5;
    }
    
    private static boolean hasNeighbour(final BlockPos v-3) {
        /*SL:176*/for (final EnumFacing v1 : EnumFacing.values()) {
            final BlockPos a1 = /*EL:177*/v-3.func_177972_a(v1);
            /*SL:178*/if (!Wrapper.getWorld().func_180495_p(a1).func_185904_a().func_76222_j()) {
                /*SL:179*/return true;
            }
        }
        /*SL:182*/return false;
    }
    
    public static EnumFacing getPlaceableSide(final BlockPos v-4) {
        /*SL:186*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:187*/v-4.func_177972_a(v0);
            /*SL:188*/if (BlockInteractionHelper.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(BlockInteractionHelper.mc.field_71441_e.func_180495_p(v), false)) {
                final IBlockState a1 = BlockInteractionHelper.mc.field_71441_e.func_180495_p(/*EL:189*/v);
                /*SL:190*/if (!a1.func_185904_a().func_76222_j()) {
                    /*SL:191*/return v0;
                }
            }
        }
        /*SL:195*/return null;
    }
    
    public static float[] getDirectionToBlock(final int a1, final int a2, final int a3, final EnumFacing a4) {
        final EntityEgg v1 = /*EL:199*/new EntityEgg((World)BlockInteractionHelper.mc.field_71441_e);
        /*SL:200*/v1.field_70165_t = a1 + 0.5;
        /*SL:201*/v1.field_70163_u = a2 + 0.5;
        /*SL:202*/v1.field_70161_v = a3 + 0.5;
        final EntityEgg entityEgg;
        final EntityEgg v2 = /*EL:204*/entityEgg = v1;
        entityEgg.field_70165_t += a4.func_176730_m().func_177958_n() * 0.25;
        final EntityEgg entityEgg2;
        final EntityEgg v3 = /*EL:206*/entityEgg2 = v1;
        entityEgg2.field_70163_u += a4.func_176730_m().func_177956_o() * 0.25;
        final EntityEgg entityEgg3;
        final EntityEgg v4 = /*EL:208*/entityEgg3 = v1;
        entityEgg3.field_70161_v += a4.func_176730_m().func_177952_p() * 0.25;
        /*SL:209*/return getDirectionToEntity((Entity)v1);
    }
    
    private static float[] getDirectionToEntity(final Entity a1) {
        /*SL:213*/return new float[] { getYaw(a1) + BlockInteractionHelper.mc.field_71439_g.field_70177_z, getPitch(a1) + BlockInteractionHelper.mc.field_71439_g.field_70125_A };
    }
    
    public static float[] getRotationNeededForBlock(final EntityPlayer a1, final BlockPos a2) {
        final double v1 = /*EL:217*/a2.func_177958_n() - a1.field_70165_t;
        final double v2 = /*EL:218*/a2.func_177956_o() + 0.5 - (a1.field_70163_u + a1.func_70047_e());
        final double v3 = /*EL:219*/a2.func_177952_p() - a1.field_70161_v;
        final double v4 = /*EL:220*/Math.sqrt(v1 * v1 + v3 * v3);
        final float v5 = /*EL:221*/(float)(Math.atan2(v3, v1) * 180.0 / 3.141592653589793) - 90.0f;
        final float v6 = /*EL:222*/(float)(-(Math.atan2(v2, v4) * 180.0 / 3.141592653589793));
        /*SL:223*/return new float[] { v5, v6 };
    }
    
    public static float getYaw(final Entity v-4) {
        final double n = /*EL:227*/v-4.field_70165_t - BlockInteractionHelper.mc.field_71439_g.field_70165_t;
        final double n2 = /*EL:228*/v-4.field_70161_v - BlockInteractionHelper.mc.field_71439_g.field_70161_v;
        double v1 = 0.0;
        /*SL:230*/if (n2 < 0.0 && n < 0.0) {
            final double a1 = /*EL:231*/90.0 + Math.toDegrees(Math.atan(n2 / n));
        }
        else/*SL:233*/ if (n2 < 0.0 && n > 0.0) {
            /*SL:234*/v1 = -90.0 + Math.toDegrees(Math.atan(n2 / n));
        }
        else {
            /*SL:237*/v1 = Math.toDegrees(-Math.atan(n / n2));
        }
        /*SL:239*/return MathHelper.func_76142_g(-(BlockInteractionHelper.mc.field_71439_g.field_70177_z - (float)v1));
    }
    
    private static float wrapAngleTo180(float a1) {
        /*SL:243*/for (a1 %= 360.0f; a1 >= 180.0f; a1 -= 360.0f) {}
        /*SL:244*/while (a1 < -180.0f) {
            /*SL:245*/a1 += 360.0f;
        }
        /*SL:247*/return a1;
    }
    
    public static float getPitch(final Entity a1) {
        final double v1 = /*EL:251*/a1.field_70165_t - BlockInteractionHelper.mc.field_71439_g.field_70165_t;
        final double v2 = /*EL:252*/a1.field_70161_v - BlockInteractionHelper.mc.field_71439_g.field_70161_v;
        final double v3 = /*EL:253*/a1.field_70163_u - 1.6 + a1.func_70047_e() - BlockInteractionHelper.mc.field_71439_g.field_70163_u;
        final double v4 = /*EL:254*/MathHelper.func_76133_a(v1 * v1 + v2 * v2);
        final double v5 = /*EL:255*/-Math.toDegrees(Math.atan(v3 / v4));
        /*SL:256*/return -MathHelper.func_76142_g(BlockInteractionHelper.mc.field_71439_g.field_70125_A - (float)v5);
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        mc = Minecraft.func_71410_x();
    }
}
