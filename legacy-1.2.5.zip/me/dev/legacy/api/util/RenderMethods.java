package me.dev.legacy.api.util;

import java.awt.Rectangle;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.Minecraft;
import java.nio.ByteBuffer;
import java.awt.Color;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public class RenderMethods
{
    public static void drawGradientRect(final float a1, final float a2, final float a3, final float a4, final int a5, final int a6) {
        enableGL2D();
        /*SL:18*/GL11.glShadeModel(7425);
        /*SL:19*/GL11.glBegin(7);
        glColor(/*EL:20*/a5);
        /*SL:21*/GL11.glVertex2f(a1, a4);
        /*SL:22*/GL11.glVertex2f(a3, a4);
        glColor(/*EL:23*/a6);
        /*SL:24*/GL11.glVertex2f(a3, a2);
        /*SL:25*/GL11.glVertex2f(a1, a2);
        /*SL:26*/GL11.glEnd();
        /*SL:27*/GL11.glShadeModel(7424);
        disableGL2D();
    }
    
    public static void drawBorderedRect(float a1, float a2, float a3, float a4, final int a5, final int a6) {
        enableGL2D();
        /*SL:33*/a1 *= 2.0f;
        /*SL:34*/a3 *= 2.0f;
        /*SL:35*/a2 *= 2.0f;
        /*SL:36*/a4 *= 2.0f;
        /*SL:37*/GL11.glScalef(0.5f, 0.5f, 0.5f);
        drawVLine(/*EL:38*/a1, a2, a4 - 1.0f, a6);
        drawVLine(/*EL:39*/a3 - 1.0f, a2, a4, a6);
        drawHLine(/*EL:40*/a1, a3 - 1.0f, a2, a6);
        drawHLine(/*EL:41*/a1, a3 - 2.0f, a4 - 1.0f, a6);
        drawRect(/*EL:42*/a1 + 1.0f, a2 + 1.0f, a3 - 1.0f, a4 - 1.0f, a5);
        /*SL:43*/GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
    }
    
    public static void drawOutlinedBox(final AxisAlignedBB a1) {
        /*SL:48*/if (a1 == null) {
            /*SL:49*/return;
        }
        /*SL:50*/GL11.glBegin(3);
        /*SL:51*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:52*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:53*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:54*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:55*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:56*/GL11.glEnd();
        /*SL:57*/GL11.glBegin(3);
        /*SL:58*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:59*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:60*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:61*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:62*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:63*/GL11.glEnd();
        /*SL:64*/GL11.glBegin(1);
        /*SL:65*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:66*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:67*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:68*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:69*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:70*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:71*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:72*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:73*/GL11.glEnd();
    }
    
    public static void drawBorderedRectReliant(final float a1, final float a2, final float a3, final float a4, final float a5, final int a6, final int a7) {
        enableGL2D();
        drawRect(/*EL:78*/a1, a2, a3, a4, a6);
        glColor(/*EL:79*/a7);
        /*SL:80*/GL11.glEnable(3042);
        /*SL:81*/GL11.glDisable(3553);
        /*SL:82*/GL11.glBlendFunc(770, 771);
        /*SL:83*/GL11.glLineWidth(a5);
        /*SL:84*/GL11.glBegin(3);
        /*SL:85*/GL11.glVertex2f(a1, a2);
        /*SL:86*/GL11.glVertex2f(a1, a4);
        /*SL:87*/GL11.glVertex2f(a3, a4);
        /*SL:88*/GL11.glVertex2f(a3, a2);
        /*SL:89*/GL11.glVertex2f(a1, a2);
        /*SL:90*/GL11.glEnd();
        /*SL:91*/GL11.glEnable(3553);
        /*SL:92*/GL11.glDisable(3042);
        disableGL2D();
    }
    
    public static void drawStrip(final int v-11, final int v-10, final float v-9, final double v-8, final float v-6, final float v-5, final int v-4) {
        final float n = /*EL:97*/(v-4 >> 24 & 0xFF) / 255.0f;
        final float n2 = /*EL:98*/(v-4 >> 16 & 0xFF) / 255.0f;
        final float n3 = /*EL:99*/(v-4 >> 8 & 0xFF) / 255.0f;
        final float v0 = /*EL:100*/(v-4 & 0xFF) / 255.0f;
        /*SL:101*/GL11.glPushMatrix();
        /*SL:102*/GL11.glTranslated((double)v-11, (double)v-10, 0.0);
        /*SL:103*/GL11.glColor4f(n2, n3, v0, n);
        /*SL:104*/GL11.glLineWidth(v-9);
        /*SL:105*/if (v-8 > 0.0) {
            /*SL:106*/GL11.glBegin(3);
            /*SL:107*/for (float a4 = 0; a4 < v-8; ++a4) {
                final float a2 = /*EL:108*/(float)(a4 * v-8 * 3.141592653589793 / v-6);
                final float a3 = /*EL:109*/(float)(Math.cos(a2) * v-5);
                /*SL:110*/a4 = (float)(Math.sin(a2) * v-5);
                /*SL:111*/GL11.glVertex2f(a3, a4);
            }
            /*SL:113*/GL11.glEnd();
        }
        /*SL:115*/if (v-8 < 0.0) {
            /*SL:116*/GL11.glBegin(3);
            /*SL:117*/for (byte v = 0; v > v-8; --v) {
                final float a5 = /*EL:118*/(float)(v * v-8 * 3.141592653589793 / v-6);
                final float a6 = /*EL:119*/(float)(Math.cos(a5) * -v-5);
                final float a7 = /*EL:120*/(float)(Math.sin(a5) * -v-5);
                /*SL:121*/GL11.glVertex2f(a6, a7);
            }
            /*SL:123*/GL11.glEnd();
        }
        disableGL2D();
        /*SL:126*/GL11.glDisable(3479);
        /*SL:127*/GL11.glPopMatrix();
    }
    
    public static void enableGL3D() {
        /*SL:131*/GL11.glDisable(3008);
        /*SL:132*/GL11.glEnable(3042);
        /*SL:133*/GL11.glBlendFunc(770, 771);
        /*SL:134*/GL11.glDisable(3553);
        /*SL:135*/GL11.glDisable(2929);
        /*SL:136*/GL11.glDepthMask(false);
        /*SL:137*/GL11.glEnable(2884);
        /*SL:138*/GL11.glEnable(2848);
        /*SL:139*/GL11.glHint(3154, 4353);
        /*SL:140*/GL11.glDisable(2896);
    }
    
    public static void drawBorderedRect(final float a1, final float a2, final float a3, final float a4, final float a5, final int a6, final int a7) {
        enableGL2D();
        glColor(/*EL:145*/a6);
        drawRect(/*EL:146*/a1 + a5, a2 + a5, a3 - a5, a4 - a5);
        glColor(/*EL:147*/a7);
        drawRect(/*EL:148*/a1 + a5, a2, a3 - a5, a2 + a5);
        drawRect(/*EL:149*/a1, a2, a1 + a5, a4);
        drawRect(/*EL:150*/a3 - a5, a2, a3, a4);
        drawRect(/*EL:151*/a1 + a5, a4 - a5, a3 - a5, a4);
        disableGL2D();
    }
    
    public static void glColor(final Color a1) {
        /*SL:156*/GL11.glColor4f(a1.getRed() / 255.0f, a1.getGreen() / 255.0f, a1.getBlue() / 255.0f, a1.getAlpha() / 255.0f);
    }
    
    public static void disableGL2D() {
        /*SL:160*/GL11.glEnable(3553);
        /*SL:161*/GL11.glDisable(3042);
        /*SL:162*/GL11.glEnable(2929);
        /*SL:163*/GL11.glDisable(2848);
        /*SL:164*/GL11.glHint(3154, 4352);
        /*SL:165*/GL11.glHint(3155, 4352);
    }
    
    public static void drawBox(final AxisAlignedBB a1) {
        /*SL:169*/if (a1 == null) {
            /*SL:170*/return;
        }
        /*SL:171*/GL11.glBegin(7);
        /*SL:172*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:173*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:174*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:175*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:176*/GL11.glEnd();
        /*SL:177*/GL11.glBegin(7);
        /*SL:178*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:179*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:180*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:181*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:182*/GL11.glEnd();
        /*SL:183*/GL11.glBegin(7);
        /*SL:184*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:185*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:186*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:187*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:188*/GL11.glEnd();
        /*SL:189*/GL11.glBegin(7);
        /*SL:190*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:191*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:192*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:193*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:194*/GL11.glEnd();
        /*SL:195*/GL11.glBegin(7);
        /*SL:196*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:197*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:198*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:199*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:200*/GL11.glEnd();
        /*SL:201*/GL11.glBegin(7);
        /*SL:202*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:203*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:204*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:205*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:206*/GL11.glEnd();
        /*SL:207*/GL11.glBegin(7);
        /*SL:208*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:209*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:210*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:211*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:212*/GL11.glEnd();
        /*SL:213*/GL11.glBegin(7);
        /*SL:214*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:215*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:216*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:217*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:218*/GL11.glEnd();
        /*SL:219*/GL11.glBegin(7);
        /*SL:220*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:221*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:222*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:223*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:224*/GL11.glEnd();
        /*SL:225*/GL11.glBegin(7);
        /*SL:226*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:227*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:228*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:229*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:230*/GL11.glEnd();
        /*SL:231*/GL11.glBegin(7);
        /*SL:232*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:233*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:234*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:235*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:236*/GL11.glEnd();
        /*SL:237*/GL11.glBegin(7);
        /*SL:238*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:239*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:240*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:241*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:242*/GL11.glEnd();
    }
    
    public static void drawGradientBorderedRectReliant(final float a1, final float a2, final float a3, final float a4, final float a5, final int a6, final int a7, final int a8) {
        enableGL2D();
        drawGradientRect(/*EL:247*/a1, a2, a3, a4, a8, a7);
        glColor(/*EL:248*/a6);
        /*SL:249*/GL11.glEnable(3042);
        /*SL:250*/GL11.glDisable(3553);
        /*SL:251*/GL11.glBlendFunc(770, 771);
        /*SL:252*/GL11.glLineWidth(a5);
        /*SL:253*/GL11.glBegin(3);
        /*SL:254*/GL11.glVertex2f(a1, a2);
        /*SL:255*/GL11.glVertex2f(a1, a4);
        /*SL:256*/GL11.glVertex2f(a3, a4);
        /*SL:257*/GL11.glVertex2f(a3, a2);
        /*SL:258*/GL11.glVertex2f(a1, a2);
        /*SL:259*/GL11.glEnd();
        /*SL:260*/GL11.glEnable(3553);
        /*SL:261*/GL11.glDisable(3042);
        disableGL2D();
    }
    
    public static int applyTexture(final int a1, final int a2, final int a3, final ByteBuffer a4, final boolean a5, final boolean a6) {
        /*SL:266*/GL11.glBindTexture(3553, a1);
        /*SL:267*/GL11.glTexParameteri(3553, 10241, a5 ? 9729 : 9728);
        /*SL:268*/GL11.glTexParameteri(3553, 10240, a5 ? 9729 : 9728);
        /*SL:269*/GL11.glTexParameteri(3553, 10242, a6 ? 10497 : 10496);
        /*SL:270*/GL11.glTexParameteri(3553, 10243, a6 ? 10497 : 10496);
        /*SL:271*/GL11.glPixelStorei(3317, 1);
        /*SL:272*/GL11.glTexImage2D(3553, 0, 32856, a2, a3, 0, 6408, 5121, a4);
        /*SL:273*/return a1;
    }
    
    public static void disableGL3D() {
        /*SL:277*/GL11.glEnable(2896);
        /*SL:278*/GL11.glDisable(2848);
        /*SL:279*/GL11.glEnable(3553);
        /*SL:280*/GL11.glEnable(2929);
        /*SL:281*/GL11.glDisable(3042);
        /*SL:282*/GL11.glEnable(3008);
        /*SL:283*/GL11.glDepthMask(true);
        /*SL:284*/GL11.glCullFace(1029);
    }
    
    public static void enableGL3D(final float a1) {
        /*SL:288*/GL11.glDisable(3008);
        /*SL:289*/GL11.glEnable(3042);
        /*SL:290*/GL11.glBlendFunc(770, 771);
        /*SL:291*/GL11.glDisable(3553);
        /*SL:292*/GL11.glDisable(2929);
        /*SL:293*/GL11.glDepthMask(false);
        /*SL:294*/GL11.glEnable(2884);
        /*SL:295*/Minecraft.func_71410_x().field_71460_t.func_180436_i();
        /*SL:296*/GL11.glEnable(2848);
        /*SL:297*/GL11.glHint(3154, 4354);
        /*SL:298*/GL11.glHint(3155, 4354);
        /*SL:299*/GL11.glLineWidth(a1);
    }
    
    public static void drawRoundedRect(float a1, float a2, float a3, float a4, final int a5, final int a6) {
        enableGL2D();
        /*SL:304*/a1 *= 2.0f;
        /*SL:305*/a2 *= 2.0f;
        /*SL:306*/a3 *= 2.0f;
        /*SL:307*/a4 *= 2.0f;
        /*SL:308*/GL11.glScalef(0.5f, 0.5f, 0.5f);
        drawVLine(/*EL:309*/a1, a2 + 1.0f, a4 - 2.0f, a5);
        drawVLine(/*EL:310*/a3 - 1.0f, a2 + 1.0f, a4 - 2.0f, a5);
        drawHLine(/*EL:311*/a1 + 2.0f, a3 - 3.0f, a2, a5);
        drawHLine(/*EL:312*/a1 + 2.0f, a3 - 3.0f, a4 - 1.0f, a5);
        drawHLine(/*EL:313*/a1 + 1.0f, a1 + 1.0f, a2 + 1.0f, a5);
        drawHLine(/*EL:314*/a3 - 2.0f, a3 - 2.0f, a2 + 1.0f, a5);
        drawHLine(/*EL:315*/a3 - 2.0f, a3 - 2.0f, a4 - 2.0f, a5);
        drawHLine(/*EL:316*/a1 + 1.0f, a1 + 1.0f, a4 - 2.0f, a5);
        drawRect(/*EL:317*/a1 + 1.0f, a2 + 1.0f, a3 - 1.0f, a4 - 1.0f, a6);
        /*SL:318*/GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
    }
    
    public static double getDiff(final double a1, final double a2, final float a3, final double a4) {
        /*SL:323*/return a1 + (a2 - a1) * a3 - a4;
    }
    
    public static void drawRect(final float a1, final float a2, final float a3, final float a4) {
        /*SL:327*/GL11.glBegin(7);
        /*SL:328*/GL11.glVertex2f(a1, a4);
        /*SL:329*/GL11.glVertex2f(a3, a4);
        /*SL:330*/GL11.glVertex2f(a3, a2);
        /*SL:331*/GL11.glVertex2f(a1, a2);
        /*SL:332*/GL11.glEnd();
    }
    
    public static void renderCrosses(final AxisAlignedBB a1) {
        /*SL:336*/GL11.glBegin(1);
        /*SL:337*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:338*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:339*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:340*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:341*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:342*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:343*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:344*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:345*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:346*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:347*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:348*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:349*/GL11.glEnd();
    }
    
    public static void glColor(final int a1) {
        final float v1 = /*EL:353*/(a1 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:354*/(a1 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:355*/(a1 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:356*/(a1 & 0xFF) / 255.0f;
        /*SL:357*/GL11.glColor4f(v2, v3, v4, v1);
    }
    
    public static void drawHLine(float a2, float a3, final float a4, final int v1) {
        /*SL:361*/if (a3 < a2) {
            final float a5 = /*EL:362*/a2;
            /*SL:363*/a2 = a3;
            /*SL:364*/a3 = a5;
        }
        drawRect(/*EL:366*/a2, a4, a3 + 1.0f, a4 + 1.0f, v1);
    }
    
    public static void drawLine(final float a1, final float a2, final float a3, final float a4, final float a5) {
        /*SL:370*/GL11.glDisable(3553);
        /*SL:371*/GL11.glLineWidth(a5);
        /*SL:372*/GL11.glBegin(1);
        /*SL:373*/GL11.glVertex2f(a1, a2);
        /*SL:374*/GL11.glVertex2f(a3, a4);
        /*SL:375*/GL11.glEnd();
        /*SL:376*/GL11.glEnable(3553);
    }
    
    public static void drawRect(final float a1, final float a2, final float a3, final float a4, final int a5) {
        enableGL2D();
        glColor(/*EL:381*/a5);
        drawRect(/*EL:382*/a1, a2, a3, a4);
        disableGL2D();
    }
    
    public static void drawGradientHRect(final float a1, final float a2, final float a3, final float a4, final int a5, final int a6) {
        enableGL2D();
        /*SL:388*/GL11.glShadeModel(7425);
        /*SL:389*/GL11.glBegin(7);
        glColor(/*EL:390*/a5);
        /*SL:391*/GL11.glVertex2f(a1, a2);
        /*SL:392*/GL11.glVertex2f(a1, a4);
        glColor(/*EL:393*/a6);
        /*SL:394*/GL11.glVertex2f(a3, a4);
        /*SL:395*/GL11.glVertex2f(a3, a2);
        /*SL:396*/GL11.glEnd();
        /*SL:397*/GL11.glShadeModel(7424);
        disableGL2D();
    }
    
    public static void rectangle(double a3, double a4, double a5, double v1, final int v3) {
        /*SL:402*/if (a3 < a5) {
            final double a6 = /*EL:403*/a3;
            /*SL:404*/a3 = a5;
            /*SL:405*/a5 = a6;
        }
        /*SL:407*/if (a4 < v1) {
            final double a7 = /*EL:408*/a4;
            /*SL:409*/a4 = v1;
            /*SL:410*/v1 = a7;
        }
        final float v4 = /*EL:412*/(v3 >> 24 & 0xFF) / 255.0f;
        final float v5 = /*EL:413*/(v3 >> 16 & 0xFF) / 255.0f;
        final float v6 = /*EL:414*/(v3 >> 8 & 0xFF) / 255.0f;
        final float v7 = /*EL:415*/(v3 & 0xFF) / 255.0f;
        final Tessellator v8 = /*EL:416*/Tessellator.func_178181_a();
        final BufferBuilder v9 = /*EL:417*/v8.func_178180_c();
        /*SL:418*/GlStateManager.func_179147_l();
        /*SL:419*/GlStateManager.func_179140_f();
        /*SL:420*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:421*/GlStateManager.func_179131_c(v5, v6, v7, v4);
        /*SL:422*/v9.func_181668_a(7, DefaultVertexFormats.field_181710_j);
        /*SL:423*/v9.func_181662_b(a3, v1, 0.0);
        /*SL:424*/v9.func_181662_b(a5, v1, 0.0);
        /*SL:425*/v9.func_181662_b(a5, a4, 0.0);
        /*SL:426*/v9.func_181662_b(a3, a4, 0.0);
        /*SL:427*/v8.func_78381_a();
        /*SL:428*/GlStateManager.func_179145_e();
        /*SL:429*/GlStateManager.func_179084_k();
    }
    
    public static void enableGL2D() {
        /*SL:433*/GL11.glDisable(2929);
        /*SL:434*/GL11.glEnable(3042);
        /*SL:435*/GL11.glDisable(3553);
        /*SL:436*/GL11.glBlendFunc(770, 771);
        /*SL:437*/GL11.glDepthMask(true);
        /*SL:438*/GL11.glEnable(2848);
        /*SL:439*/GL11.glHint(3154, 4354);
        /*SL:440*/GL11.glHint(3155, 4354);
    }
    
    public static void drawFullCircle(int a4, int v1, double v2, final int v4) {
        /*SL:444*/v2 *= 2.0;
        /*SL:445*/a4 *= 2;
        /*SL:446*/v1 *= 2;
        final float v5 = /*EL:447*/(v4 >> 24 & 0xFF) / 255.0f;
        final float v6 = /*EL:448*/(v4 >> 16 & 0xFF) / 255.0f;
        final float v7 = /*EL:449*/(v4 >> 8 & 0xFF) / 255.0f;
        final float v8 = /*EL:450*/(v4 & 0xFF) / 255.0f;
        enableGL2D();
        /*SL:452*/GL11.glScalef(0.5f, 0.5f, 0.5f);
        /*SL:453*/GL11.glColor4f(v6, v7, v8, v5);
        /*SL:454*/GL11.glBegin(6);
        /*SL:455*/for (byte a5 = 0; a5 <= 360; ++a5) {
            final double a6 = /*EL:456*/Math.sin(a5 * 3.141592653589793 / 180.0) * v2;
            final double a7 = /*EL:457*/Math.cos(a5 * 3.141592653589793 / 180.0) * v2;
            /*SL:458*/GL11.glVertex2d(a4 + a6, v1 + a7);
        }
        /*SL:460*/GL11.glEnd();
        /*SL:461*/GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
    }
    
    public static void drawTriangle(final int a1, final int a2, final int a3, final int a4, final int a5) {
        /*SL:466*/GL11.glEnable(3042);
        /*SL:467*/GL11.glDisable(3553);
        /*SL:468*/GL11.glBlendFunc(770, 771);
        final float v1 = /*EL:469*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:470*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:471*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:472*/(a5 & 0xFF) / 255.0f;
        /*SL:473*/GL11.glColor4f(v2, v3, v4, v1);
        /*SL:474*/GL11.glEnable(2848);
        /*SL:475*/GL11.glHint(3154, 4354);
        /*SL:476*/GL11.glLineWidth(1.0f);
        /*SL:477*/GL11.glShadeModel(7425);
        /*SL:478*/switch (a3) {
            case 0: {
                /*SL:480*/GL11.glBegin(2);
                /*SL:481*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
                /*SL:482*/GL11.glVertex2d((double)(a1 + a4), (double)(a2 - a4));
                /*SL:483*/GL11.glVertex2d((double)(a1 - a4), (double)(a2 - a4));
                /*SL:484*/GL11.glEnd();
                /*SL:485*/GL11.glBegin(4);
                /*SL:486*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
                /*SL:487*/GL11.glVertex2d((double)(a1 + a4), (double)(a2 - a4));
                /*SL:488*/GL11.glVertex2d((double)(a1 - a4), (double)(a2 - a4));
                /*SL:489*/GL11.glEnd();
                /*SL:490*/break;
            }
            case 1: {
                /*SL:492*/GL11.glBegin(2);
                /*SL:493*/GL11.glVertex2d((double)a1, (double)a2);
                /*SL:494*/GL11.glVertex2d((double)a1, (double)(a2 + a4 / 2));
                /*SL:495*/GL11.glVertex2d((double)(a1 + a4 + a4 / 2), (double)a2);
                /*SL:496*/GL11.glEnd();
                /*SL:497*/GL11.glBegin(4);
                /*SL:498*/GL11.glVertex2d((double)a1, (double)a2);
                /*SL:499*/GL11.glVertex2d((double)a1, (double)(a2 + a4 / 2));
                /*SL:500*/GL11.glVertex2d((double)(a1 + a4 + a4 / 2), (double)a2);
                /*SL:501*/GL11.glEnd();
                /*SL:502*/break;
            }
            case 3: {
                /*SL:504*/GL11.glBegin(2);
                /*SL:505*/GL11.glVertex2d((double)a1, (double)a2);
                /*SL:506*/GL11.glVertex2d(a1 + a4 * 1.25, (double)(a2 - a4 / 2));
                /*SL:507*/GL11.glVertex2d(a1 + a4 * 1.25, (double)(a2 + a4 / 2));
                /*SL:508*/GL11.glEnd();
                /*SL:509*/GL11.glBegin(4);
                /*SL:510*/GL11.glVertex2d(a1 + a4 * 1.25, (double)(a2 - a4 / 2));
                /*SL:511*/GL11.glVertex2d((double)a1, (double)a2);
                /*SL:512*/GL11.glVertex2d(a1 + a4 * 1.25, (double)(a2 + a4 / 2));
                /*SL:513*/GL11.glEnd();
                break;
            }
        }
        /*SL:516*/GL11.glDisable(2848);
        /*SL:517*/GL11.glEnable(3553);
        /*SL:518*/GL11.glDisable(3042);
    }
    
    public static void drawGradientRect(final double a1, final double a2, final double a3, final double a4, final int a5, final int a6) {
        /*SL:522*/GL11.glEnable(3042);
        /*SL:523*/GL11.glDisable(3553);
        /*SL:524*/GL11.glBlendFunc(770, 771);
        /*SL:525*/GL11.glEnable(2848);
        /*SL:526*/GL11.glShadeModel(7425);
        /*SL:527*/GL11.glPushMatrix();
        /*SL:528*/GL11.glBegin(7);
        glColor(/*EL:529*/a5);
        /*SL:530*/GL11.glVertex2d(a3, a2);
        /*SL:531*/GL11.glVertex2d(a1, a2);
        glColor(/*EL:532*/a6);
        /*SL:533*/GL11.glVertex2d(a1, a4);
        /*SL:534*/GL11.glVertex2d(a3, a4);
        /*SL:535*/GL11.glEnd();
        /*SL:536*/GL11.glPopMatrix();
        /*SL:537*/GL11.glEnable(3553);
        /*SL:538*/GL11.glDisable(3042);
        /*SL:539*/GL11.glDisable(2848);
        /*SL:540*/GL11.glShadeModel(7424);
    }
    
    public static Color rainbow(final long a1, final float a2) {
        final float v1 = /*EL:544*/(System.nanoTime() + a1) / 1.0E10f % 1.0f;
        final long v2 = /*EL:545*/Long.parseLong(Integer.toHexString(Color.HSBtoRGB(v1, 1.0f, 1.0f)), 16);
        final Color v3 = /*EL:546*/new Color((int)v2);
        /*SL:547*/return new Color(v3.getRed() / 255.0f * a2, v3.getGreen() / 255.0f * a2, v3.getBlue() / 255.0f * a2, v3.getAlpha() / 255.0f);
    }
    
    public static void drawRect(final float a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8) {
        enableGL2D();
        /*SL:552*/GL11.glColor4f(a5, a6, a7, a8);
        drawRect(/*EL:553*/a1, a2, a3, a4);
        disableGL2D();
    }
    
    public static void glColor(final float a1, final int a2, final int a3, final int a4) {
        final float v1 = /*EL:558*/0.003921569f * a2;
        final float v2 = /*EL:559*/0.003921569f * a3;
        final float v3 = /*EL:560*/0.003921569f * a4;
        /*SL:561*/GL11.glColor4f(v1, v2, v3, a1);
    }
    
    public static void drawRect(final Rectangle a1, final int a2) {
        drawRect(/*EL:565*/a1.x, a1.y, a1.x + a1.width, a1.y + a1.height, a2);
    }
    
    public static Color blend(final Color a1, final Color a2, final float a3) {
        final float v1 = /*EL:569*/1.0f - a3;
        final float[] v2 = /*EL:570*/new float[3];
        final float[] v3 = /*EL:571*/new float[3];
        /*SL:572*/a1.getColorComponents(v2);
        /*SL:573*/a2.getColorComponents(v3);
        /*SL:574*/return new Color(v2[0] * a3 + v3[0] * v1, v2[1] * a3 + v3[1] * v1, v2[2] * a3 + v3[2] * v1);
    }
    
    public static void drawHLine(float a2, float a3, final float a4, final int a5, final int v1) {
        /*SL:578*/if (a3 < a2) {
            final float a6 = /*EL:579*/a2;
            /*SL:580*/a2 = a3;
            /*SL:581*/a3 = a6;
        }
        drawGradientRect(/*EL:583*/a2, a4, a3 + 1.0f, a4 + 1.0f, a5, v1);
    }
    
    public static void drawBorderedRect(final Rectangle a1, final float a2, final int a3, final int a4) {
        final float v1 = /*EL:587*/a1.x;
        final float v2 = /*EL:588*/a1.y;
        final float v3 = /*EL:589*/a1.x + a1.width;
        final float v4 = /*EL:590*/a1.y + a1.height;
        enableGL2D();
        glColor(/*EL:592*/a3);
        drawRect(/*EL:593*/v1 + a2, v2 + a2, v3 - a2, v4 - a2);
        glColor(/*EL:594*/a4);
        drawRect(/*EL:595*/v1 + 1.0f, v2, v3 - 1.0f, v2 + a2);
        drawRect(/*EL:596*/v1, v2, v1 + a2, v4);
        drawRect(/*EL:597*/v3 - a2, v2, v3, v4);
        drawRect(/*EL:598*/v1 + 1.0f, v4 - a2, v3 - 1.0f, v4);
        disableGL2D();
    }
    
    public static void drawGradientBorderedRect(final double a1, final double a2, final double a3, final double a4, final float a5, final int a6, final int a7, final int a8) {
        enableGL2D();
        /*SL:604*/GL11.glPushMatrix();
        glColor(/*EL:605*/a6);
        /*SL:606*/GL11.glLineWidth(1.0f);
        /*SL:607*/GL11.glBegin(1);
        /*SL:608*/GL11.glVertex2d(a1, a2);
        /*SL:609*/GL11.glVertex2d(a1, a4);
        /*SL:610*/GL11.glVertex2d(a3, a4);
        /*SL:611*/GL11.glVertex2d(a3, a2);
        /*SL:612*/GL11.glVertex2d(a1, a2);
        /*SL:613*/GL11.glVertex2d(a3, a2);
        /*SL:614*/GL11.glVertex2d(a1, a4);
        /*SL:615*/GL11.glVertex2d(a3, a4);
        /*SL:616*/GL11.glEnd();
        /*SL:617*/GL11.glPopMatrix();
        drawGradientRect(/*EL:618*/a1, a2, a3, a4, a7, a8);
        disableGL2D();
    }
    
    public static void drawCircle(float a3, float a4, float a5, final int v1, final int v2) {
        /*SL:623*/a5 *= 2.0f;
        /*SL:624*/a3 *= 2.0f;
        /*SL:625*/a4 *= 2.0f;
        final float v3 = /*EL:626*/(v2 >> 24 & 0xFF) / 255.0f;
        final float v4 = /*EL:627*/(v2 >> 16 & 0xFF) / 255.0f;
        final float v5 = /*EL:628*/(v2 >> 8 & 0xFF) / 255.0f;
        final float v6 = /*EL:629*/(v2 & 0xFF) / 255.0f;
        final float v7 = /*EL:630*/(float)(6.2831852 / v1);
        final float v8 = /*EL:631*/(float)Math.cos(v7);
        final float v9 = /*EL:632*/(float)Math.sin(v7);
        float v10 = /*EL:633*/a5;
        float v11 = /*EL:634*/0.0f;
        enableGL2D();
        /*SL:636*/GL11.glScalef(0.5f, 0.5f, 0.5f);
        /*SL:637*/GL11.glColor4f(v4, v5, v6, v3);
        /*SL:638*/GL11.glBegin(2);
        /*SL:639*/for (byte a6 = 0; a6 < v1; ++a6) {
            /*SL:640*/GL11.glVertex2f(v10 + a3, v11 + a4);
            final float a7 = /*EL:641*/v10;
            /*SL:642*/v10 = v8 * v10 - v9 * v11;
            /*SL:643*/v11 = v9 * a7 + v8 * v11;
        }
        /*SL:645*/GL11.glEnd();
        /*SL:646*/GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
    }
    
    public static void drawVLine(final float a2, float a3, float a4, final int v1) {
        /*SL:651*/if (a4 < a3) {
            final float a5 = /*EL:652*/a3;
            /*SL:653*/a3 = a4;
            /*SL:654*/a4 = a5;
        }
        drawRect(/*EL:656*/a2, a3 + 1.0f, a2 + 1.0f, a4, v1);
    }
}
