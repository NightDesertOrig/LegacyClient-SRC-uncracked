package me.dev.legacy.api.util;

import java.util.Arrays;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Block;
import java.util.List;

public class HoleFillUtil
{
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    private static final Minecraft mc;
    private static Entity player;
    public static FMLCommonHandler fmlHandler;
    
    public static void placeBlockScaffold(final BlockPos v-5) {
        final Vec3d vec3d = /*EL:30*/new Vec3d(HoleFillUtil.player.field_70165_t, HoleFillUtil.player.field_70163_u + HoleFillUtil.player.func_70047_e(), HoleFillUtil.player.field_70161_v);
        /*SL:31*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:32*/v-5.func_177972_a(v0);
            final EnumFacing v2 = /*EL:33*/v0.func_176734_d();
            /*SL:34*/if (canBeClicked(v)) {
                final Vec3d a1 = /*EL:35*/new Vec3d((Vec3i)v).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v2.func_176730_m()).func_186678_a(0.5));
                /*SL:36*/if (vec3d.func_72436_e(a1) <= 18.0625) {
                    faceVectorPacketInstant(/*EL:37*/a1);
                    processRightClickBlock(/*EL:38*/v, v2, a1);
                    HoleFillUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    HoleFillUtil.mc.field_71467_ac = /*EL:40*/4;
                    /*SL:41*/return;
                }
            }
        }
    }
    
    private static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:49*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:50*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:51*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:52*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:53*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:54*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:55*/return new float[] { HoleFillUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(v6 - HoleFillUtil.mc.field_71439_g.field_70177_z), HoleFillUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(v7 - HoleFillUtil.mc.field_71439_g.field_70125_A) };
    }
    
    private static Vec3d getEyesPos() {
        /*SL:59*/return new Vec3d(HoleFillUtil.mc.field_71439_g.field_70165_t, HoleFillUtil.mc.field_71439_g.field_70163_u + HoleFillUtil.mc.field_71439_g.func_70047_e(), HoleFillUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static void faceVectorPacketInstant(final Vec3d a1) {
        final float[] v1 = getLegitRotations(/*EL:63*/a1);
        HoleFillUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:64*/(Packet)new CPacketPlayer.Rotation(v1[0], v1[1], HoleFillUtil.mc.field_71439_g.field_70122_E));
    }
    
    static void processRightClickBlock(final BlockPos a1, final EnumFacing a2, final Vec3d a3) {
        getPlayerController().func_187099_a(HoleFillUtil.mc.field_71439_g, HoleFillUtil.mc.field_71441_e, /*EL:68*/a1, a2, a3, EnumHand.MAIN_HAND);
    }
    
    public static boolean canBeClicked(final BlockPos a1) {
        /*SL:72*/return getBlock(a1).func_176209_a(getState(a1), false);
    }
    
    private static Block getBlock(final BlockPos a1) {
        /*SL:76*/return getState(a1).func_177230_c();
    }
    
    private static PlayerControllerMP getPlayerController() {
        /*SL:80*/return Minecraft.func_71410_x().field_71442_b;
    }
    
    private static IBlockState getState(final BlockPos a1) {
        /*SL:84*/return HoleFillUtil.mc.field_71441_e.func_180495_p(a1);
    }
    
    public static boolean checkForNeighbours(final BlockPos v-3) {
        /*SL:88*/if (!hasNeighbour(v-3)) {
            /*SL:89*/for (final EnumFacing v1 : EnumFacing.values()) {
                final BlockPos a1 = /*EL:90*/v-3.func_177972_a(v1);
                /*SL:91*/if (hasNeighbour(a1)) {
                    /*SL:92*/return true;
                }
            }
            /*SL:95*/return false;
        }
        /*SL:97*/return true;
    }
    
    public static EnumFacing getPlaceableSide(final BlockPos v-4) {
        /*SL:101*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:102*/v-4.func_177972_a(v0);
            /*SL:103*/if (HoleFillUtil.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(HoleFillUtil.mc.field_71441_e.func_180495_p(v), false)) {
                final IBlockState a1 = HoleFillUtil.mc.field_71441_e.func_180495_p(/*EL:104*/v);
                /*SL:105*/if (!a1.func_185904_a().func_76222_j()) {
                    /*SL:106*/return v0;
                }
            }
        }
        /*SL:110*/return null;
    }
    
    public static boolean hasNeighbour(final BlockPos v-3) {
        /*SL:114*/for (final EnumFacing v1 : EnumFacing.values()) {
            final BlockPos a1 = /*EL:115*/v-3.func_177972_a(v1);
            /*SL:116*/if (!HoleFillUtil.mc.field_71441_e.func_180495_p(a1).func_185904_a().func_76222_j()) {
                /*SL:117*/return true;
            }
        }
        /*SL:120*/return false;
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        mc = Minecraft.func_71410_x();
        HoleFillUtil.player = (Entity)HoleFillUtil.mc.field_71439_g;
        HoleFillUtil.fmlHandler = FMLCommonHandler.instance();
    }
}
