package me.dev.legacy.api.util;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Title
{
    int ticks;
    int bruh;
    int breakTimer;
    String bruh1;
    boolean qwerty;
    
    public Title() {
        this.ticks = 0;
        this.bruh = 0;
        this.breakTimer = 0;
        this.bruh1 = "Legacy | v1.2.5";
        this.qwerty = false;
    }
    
    @SubscribeEvent
    public void onTick(final TickEvent.ClientTickEvent a1) {
        /*SL:16*/++this.ticks;
        /*SL:17*/if (this.ticks % 17 == 0) {
            /*SL:19*/Display.setTitle(this.bruh1.substring(0, this.bruh1.length() - this.bruh));
            /*SL:20*/if ((this.bruh == this.bruh1.length() && this.breakTimer != 0) || (this.bruh == 0 && this.breakTimer != 0)) {
                /*SL:21*/++this.breakTimer;
                /*SL:22*/return;
            }
            /*SL:23*/this.breakTimer = 0;
            /*SL:24*/if (this.bruh == this.bruh1.length()) {
                this.qwerty = true;
            }
            /*SL:25*/if (this.qwerty) {
                --this.bruh;
            }
            else {
                /*SL:26*/++this.bruh;
            }
            /*SL:27*/if (this.bruh == 0) {
                this.qwerty = false;
            }
        }
    }
}
