package me.dev.legacy.api.util;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Comparator;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import net.minecraft.client.Minecraft;
import java.math.RoundingMode;
import java.math.BigDecimal;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import java.util.Random;

public class MathUtil implements Util
{
    private static final Random random;
    
    public static int getRandom(final int a1, final int a2) {
        /*SL:20*/return a1 + MathUtil.random.nextInt(a2 - a1 + 1);
    }
    
    public static double getRandom(final double a1, final double a2) {
        /*SL:24*/return MathHelper.func_151237_a(a1 + MathUtil.random.nextDouble() * a2, a1, a2);
    }
    
    public static float getRandom(final float a1, final float a2) {
        /*SL:28*/return MathHelper.func_76131_a(a1 + MathUtil.random.nextFloat() * a2, a1, a2);
    }
    
    public static int clamp(final int a1, final int a2, final int a3) {
        /*SL:32*/return (a1 < a2) ? a2 : Math.min(a1, a3);
    }
    
    public static float clamp(final float a1, final float a2, final float a3) {
        /*SL:36*/return (a1 < a2) ? a2 : Math.min(a1, a3);
    }
    
    public static double clamp(final double a1, final double a2, final double a3) {
        /*SL:40*/return (a1 < a2) ? a2 : Math.min(a1, a3);
    }
    
    public static float sin(final float a1) {
        /*SL:44*/return MathHelper.func_76126_a(a1);
    }
    
    public static float cos(final float a1) {
        /*SL:48*/return MathHelper.func_76134_b(a1);
    }
    
    public static float wrapDegrees(final float a1) {
        /*SL:52*/return MathHelper.func_76142_g(a1);
    }
    
    public static double wrapDegrees(final double a1) {
        /*SL:56*/return MathHelper.func_76138_g(a1);
    }
    
    public static Vec3d roundVec(final Vec3d a1, final int a2) {
        /*SL:60*/return new Vec3d(round(a1.field_72450_a, a2), round(a1.field_72448_b, a2), round(a1.field_72449_c, a2));
    }
    
    public static double square(final double a1) {
        /*SL:64*/return a1 * a1;
    }
    
    public static double round(final double a1, final int a2) {
        /*SL:68*/if (a2 < 0) {
            /*SL:69*/throw new IllegalArgumentException();
        }
        BigDecimal v1 = /*EL:71*/BigDecimal.valueOf(a1);
        /*SL:72*/v1 = v1.setScale(a2, RoundingMode.FLOOR);
        /*SL:73*/return v1.doubleValue();
    }
    
    public static float wrap(final float a1) {
        float v1 = /*EL:77*/a1 % 360.0f;
        /*SL:78*/if (v1 >= 180.0f) {
            /*SL:79*/v1 -= 360.0f;
        }
        /*SL:81*/if (v1 < -180.0f) {
            /*SL:82*/v1 += 360.0f;
        }
        /*SL:84*/return v1;
    }
    
    public static double[] directionSpeedNoForward(final double a1) {
        final Minecraft v1 = /*EL:88*/Minecraft.func_71410_x();
        float v2 = /*EL:89*/1.0f;
        /*SL:91*/if (v1.field_71474_y.field_74370_x.func_151468_f() || v1.field_71474_y.field_74366_z.func_151468_f() || v1.field_71474_y.field_74368_y.func_151468_f() || v1.field_71474_y.field_74351_w.func_151468_f()) {
            /*SL:92*/v2 = v1.field_71439_g.field_71158_b.field_192832_b;
        }
        float v3 = /*EL:94*/v1.field_71439_g.field_71158_b.field_78902_a;
        float v4 = /*EL:95*/v1.field_71439_g.field_70126_B + (v1.field_71439_g.field_70177_z - v1.field_71439_g.field_70126_B) * v1.func_184121_ak();
        /*SL:98*/if (v2 != 0.0f) {
            /*SL:99*/if (v3 > 0.0f) {
                /*SL:100*/v4 += ((v2 > 0.0f) ? -45 : 45);
            }
            else/*SL:101*/ if (v3 < 0.0f) {
                /*SL:102*/v4 += ((v2 > 0.0f) ? 45 : -45);
            }
            /*SL:104*/v3 = 0.0f;
            /*SL:107*/if (v2 > 0.0f) {
                /*SL:108*/v2 = 1.0f;
            }
            else/*SL:109*/ if (v2 < 0.0f) {
                /*SL:110*/v2 = -1.0f;
            }
        }
        final double v5 = /*EL:113*/Math.sin(Math.toRadians(v4 + 90.0f));
        final double v6 = /*EL:114*/Math.cos(Math.toRadians(v4 + 90.0f));
        final double v7 = /*EL:115*/v2 * a1 * v6 + v3 * a1 * v5;
        final double v8 = /*EL:116*/v2 * a1 * v5 - v3 * a1 * v6;
        /*SL:117*/return new double[] { v7, v8 };
    }
    
    public static Vec3d direction(final float a1) {
        /*SL:122*/return new Vec3d(Math.cos(degToRad(a1 + 90.0f)), 0.0, Math.sin(degToRad(a1 + 90.0f)));
    }
    
    public static Vec3d calculateLine(final Vec3d a1, final Vec3d a2, final double a3) {
        final double v1 = /*EL:125*/Math.sqrt(multiply(a2.field_72450_a - a1.field_72450_a) + multiply(a2.field_72448_b - a1.field_72448_b) + multiply(a2.field_72449_c - a1.field_72449_c));
        final double v2 = /*EL:126*/(a2.field_72450_a - a1.field_72450_a) / v1;
        final double v3 = /*EL:127*/(a2.field_72448_b - a1.field_72448_b) / v1;
        final double v4 = /*EL:128*/(a2.field_72449_c - a1.field_72449_c) / v1;
        final double v5 = /*EL:129*/a1.field_72450_a + v2 * a3;
        final double v6 = /*EL:130*/a1.field_72448_b + v3 * a3;
        final double v7 = /*EL:131*/a1.field_72449_c + v4 * a3;
        /*SL:132*/return new Vec3d(v5, v6, v7);
    }
    
    public static float round(final float a1, final int a2) {
        /*SL:136*/if (a2 < 0) {
            /*SL:137*/throw new IllegalArgumentException();
        }
        BigDecimal v1 = /*EL:139*/BigDecimal.valueOf(a1);
        /*SL:140*/v1 = v1.setScale(a2, RoundingMode.FLOOR);
        /*SL:141*/return v1.floatValue();
    }
    
    public static <K, V extends java.lang.Object> Map<K, V> sortByValue(final Map<K, V> a2, final boolean v1) {
        final LinkedList<Map.Entry<K, V>> v2 = /*EL:145*/new LinkedList<Map.Entry<K, V>>(a2.entrySet());
        /*SL:146*/if (v1) {
            /*SL:147*/v2.sort((Comparator<? super Object>)Map.Entry.<Object, Object>comparingByValue(Comparator.<? super Object>reverseOrder()));
        }
        else {
            /*SL:149*/v2.sort((Comparator<? super Object>)Map.Entry.<Object, Comparable>comparingByValue());
        }
        final LinkedHashMap v3 = /*EL:151*/new LinkedHashMap();
        /*SL:152*/for (final Map.Entry a3 : v2) {
            /*SL:153*/v3.put(a3.getKey(), a3.getValue());
        }
        /*SL:155*/return (Map<K, V>)v3;
    }
    
    public static String getTimeOfDay() {
        final Calendar v1 = /*EL:159*/Calendar.getInstance();
        final int v2 = /*EL:160*/v1.get(11);
        /*SL:161*/if (v2 < 12) {
            /*SL:162*/return "Good Morning ";
        }
        /*SL:164*/if (v2 < 16) {
            /*SL:165*/return "Good Afternoon ";
        }
        /*SL:167*/if (v2 < 21) {
            /*SL:168*/return "Good Evening ";
        }
        /*SL:170*/return "Good Night ";
    }
    
    public static double radToDeg(final double a1) {
        /*SL:174*/return a1 * 57.295780181884766;
    }
    
    public static double degToRad(final double a1) {
        /*SL:178*/return a1 * 0.01745329238474369;
    }
    
    public static double getIncremental(final double a1, final double a2) {
        final double v1 = /*EL:182*/1.0 / a2;
        /*SL:183*/return Math.round(a1 * v1) / v1;
    }
    
    public static double[] directionSpeed(final double a1) {
        float v1 = MathUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float v2 = MathUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float v3 = MathUtil.mc.field_71439_g.field_70126_B + (MathUtil.mc.field_71439_g.field_70177_z - MathUtil.mc.field_71439_g.field_70126_B) * MathUtil.mc.func_184121_ak();
        /*SL:190*/if (v1 != 0.0f) {
            /*SL:191*/if (v2 > 0.0f) {
                /*SL:192*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:193*/ if (v2 < 0.0f) {
                /*SL:194*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:196*/v2 = 0.0f;
            /*SL:197*/if (v1 > 0.0f) {
                /*SL:198*/v1 = 1.0f;
            }
            else/*SL:199*/ if (v1 < 0.0f) {
                /*SL:200*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:203*/Math.sin(Math.toRadians(v3 + 90.0f));
        final double v5 = /*EL:204*/Math.cos(Math.toRadians(v3 + 90.0f));
        final double v6 = /*EL:205*/v1 * a1 * v5 + v2 * a1 * v4;
        final double v7 = /*EL:206*/v1 * a1 * v4 - v2 * a1 * v5;
        /*SL:207*/return new double[] { v6, v7 };
    }
    
    public static float[] calcAngleNoY(final Vec3d a1, final Vec3d a2) {
        final double v1 = /*EL:210*/a2.field_72450_a - a1.field_72450_a;
        final double v2 = /*EL:211*/a2.field_72449_c - a1.field_72449_c;
        /*SL:212*/return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(v2, v1)) - 90.0) };
    }
    
    public static double multiply(final double a1) {
        /*SL:215*/return a1 * a1;
    }
    
    public static Vec3d extrapolatePlayerPosition(final EntityPlayer a1, final int a2) {
        final Vec3d v1 = /*EL:219*/new Vec3d(a1.field_70142_S, a1.field_70137_T, a1.field_70136_U);
        final Vec3d v2 = /*EL:220*/new Vec3d(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v);
        final double v3 = multiply(/*EL:221*/a1.field_70159_w) + multiply(a1.field_70181_x) + multiply(a1.field_70179_y);
        final Vec3d v4 = calculateLine(/*EL:222*/v1, v2, v3 * a2);
        /*SL:223*/return new Vec3d(v4.field_72450_a, a1.field_70163_u, v4.field_72449_c);
    }
    
    public static List<Vec3d> getBlockBlocks(final Entity a1) {
        final ArrayList<Vec3d> v1 = /*EL:227*/new ArrayList<Vec3d>();
        final AxisAlignedBB v2 = /*EL:228*/a1.func_174813_aQ();
        final double v3 = /*EL:229*/a1.field_70163_u;
        final double v4 = round(/*EL:230*/v2.field_72340_a, 0);
        final double v5 = round(/*EL:231*/v2.field_72339_c, 0);
        final double v6 = round(/*EL:232*/v2.field_72336_d, 0);
        final double v7 = round(/*EL:233*/v2.field_72334_f, 0);
        /*SL:234*/if (v4 != v6) {
            /*SL:235*/v1.add(new Vec3d(v4, v3, v5));
            /*SL:236*/v1.add(new Vec3d(v6, v3, v5));
            /*SL:237*/if (v5 != v7) {
                /*SL:238*/v1.add(new Vec3d(v4, v3, v7));
                /*SL:239*/v1.add(new Vec3d(v6, v3, v7));
                /*SL:240*/return v1;
            }
        }
        else/*SL:242*/ if (v5 != v7) {
            /*SL:243*/v1.add(new Vec3d(v4, v3, v5));
            /*SL:244*/v1.add(new Vec3d(v4, v3, v7));
            /*SL:245*/return v1;
        }
        /*SL:247*/v1.add(a1.func_174791_d());
        /*SL:248*/return v1;
    }
    
    public static boolean areVec3dsAligned(final Vec3d a1, final Vec3d a2) {
        /*SL:252*/return areVec3dsAlignedRetarded(a1, a2);
    }
    
    public static boolean areVec3dsAlignedRetarded(final Vec3d a1, final Vec3d a2) {
        final BlockPos v1 = /*EL:256*/new BlockPos(a1);
        final BlockPos v2 = /*EL:257*/new BlockPos(a2.field_72450_a, a1.field_72448_b, a2.field_72449_c);
        /*SL:258*/return v1.equals((Object)v2);
    }
    
    public static float[] calcAngle(final Vec3d a1, final Vec3d a2) {
        final double v1 = /*EL:262*/a2.field_72450_a - a1.field_72450_a;
        final double v2 = /*EL:263*/(a2.field_72448_b - a1.field_72448_b) * -1.0;
        final double v3 = /*EL:264*/a2.field_72449_c - a1.field_72449_c;
        final double v4 = /*EL:265*/MathHelper.func_76133_a(v1 * v1 + v3 * v3);
        /*SL:266*/return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(v3, v1)) - 90.0), (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(v2, v4))) };
    }
    
    static {
        random = new Random();
    }
}
