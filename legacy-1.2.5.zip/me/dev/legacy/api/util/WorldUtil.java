package me.dev.legacy.api.util;

import net.minecraft.world.World;
import java.util.Iterator;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.MinecraftInstance;

public class WorldUtil implements MinecraftInstance
{
    public static void placeBlock(final BlockPos v-5) {
        /*SL:20*/for (final EnumFacing enumFacing : EnumFacing.values()) {
            /*SL:21*/if (!WorldUtil.mc.field_71441_e.func_180495_p(v-5.func_177972_a(enumFacing)).func_177230_c().equals(Blocks.field_150350_a) && !isIntercepted(v-5)) {
                final Vec3d a1 = /*EL:22*/new Vec3d(v-5.func_177958_n() + 0.5 + enumFacing.func_82601_c() * 0.5, v-5.func_177956_o() + 0.5 + enumFacing.func_96559_d() * 0.5, v-5.func_177952_p() + 0.5 + enumFacing.func_82599_e() * 0.5);
                final float[] v1 = /*EL:23*/{ WorldUtil.mc.field_71439_g.field_70177_z, WorldUtil.mc.field_71439_g.field_70125_A };
                WorldUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:24*/(Packet)new CPacketPlayer.Rotation((float)Math.toDegrees(Math.atan2(a1.field_72449_c - WorldUtil.mc.field_71439_g.field_70161_v, a1.field_72450_a - WorldUtil.mc.field_71439_g.field_70165_t)) - 90.0f, (float)(-Math.toDegrees(Math.atan2(a1.field_72448_b - (WorldUtil.mc.field_71439_g.field_70163_u + WorldUtil.mc.field_71439_g.func_70047_e()), Math.sqrt((a1.field_72450_a - WorldUtil.mc.field_71439_g.field_70165_t) * (a1.field_72450_a - WorldUtil.mc.field_71439_g.field_70165_t) + (a1.field_72449_c - WorldUtil.mc.field_71439_g.field_70161_v) * (a1.field_72449_c - WorldUtil.mc.field_71439_g.field_70161_v))))), WorldUtil.mc.field_71439_g.field_70122_E));
                WorldUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:25*/(Packet)new CPacketEntityAction((Entity)WorldUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                WorldUtil.mc.field_71442_b.func_187099_a(WorldUtil.mc.field_71439_g, WorldUtil.mc.field_71441_e, /*EL:26*/v-5.func_177972_a(enumFacing), enumFacing.func_176734_d(), new Vec3d((Vec3i)v-5), EnumHand.MAIN_HAND);
                WorldUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                WorldUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:28*/(Packet)new CPacketEntityAction((Entity)WorldUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                WorldUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:29*/(Packet)new CPacketPlayer.Rotation(v1[0], v1[1], WorldUtil.mc.field_71439_g.field_70122_E));
                /*SL:30*/return;
            }
        }
    }
    
    public static void placeBlock(final BlockPos a1, final int a2) {
        /*SL:36*/if (a2 == -1) {
            /*SL:37*/return;
        }
        final int v1 = WorldUtil.mc.field_71439_g.field_71071_by.field_70461_c;
        WorldUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:40*/a2;
        placeBlock(/*EL:41*/a1);
        WorldUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:42*/v1;
    }
    
    public static boolean isIntercepted(final BlockPos v1) {
        /*SL:46*/for (final Entity a1 : WorldUtil.mc.field_71441_e.field_72996_f) {
            /*SL:47*/if (new AxisAlignedBB(v1).func_72326_a(a1.func_174813_aQ())) {
                /*SL:48*/return true;
            }
        }
        /*SL:51*/return false;
    }
    
    public static BlockPos GetLocalPlayerPosFloored() {
        /*SL:55*/return new BlockPos(Math.floor(WorldUtil.mc.field_71439_g.field_70165_t), Math.floor(WorldUtil.mc.field_71439_g.field_70163_u), Math.floor(WorldUtil.mc.field_71439_g.field_70161_v));
    }
    
    public static boolean canBreak(final BlockPos a1) {
        /*SL:59*/return WorldUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c().func_176195_g(WorldUtil.mc.field_71441_e.func_180495_p(a1), (World)WorldUtil.mc.field_71441_e, a1) != -1.0f;
    }
}
