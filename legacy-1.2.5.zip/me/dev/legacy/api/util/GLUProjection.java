package me.dev.legacy.api.util;

import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.BufferUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

public final class GLUProjection
{
    private static GLUProjection instance;
    private IntBuffer viewport;
    private FloatBuffer modelview;
    private FloatBuffer projection;
    private FloatBuffer coords;
    private Vector3D frustumPos;
    private Vector3D[] frustum;
    private Vector3D[] invFrustum;
    private Vector3D viewVec;
    private double displayWidth;
    private double displayHeight;
    private double widthScale;
    private double heightScale;
    private double bra;
    private double bla;
    private double tra;
    private double tla;
    private Line tb;
    private Line bb;
    private Line lb;
    private Line rb;
    private float fovY;
    private float fovX;
    private Vector3D lookVec;
    
    private GLUProjection() {
        this.coords = BufferUtils.createFloatBuffer(3);
    }
    
    public static GLUProjection getInstance() {
        /*SL:39*/if (GLUProjection.instance == null) {
            GLUProjection.instance = /*EL:40*/new GLUProjection();
        }
        /*SL:42*/return GLUProjection.instance;
    }
    
    public void updateMatrices(final IntBuffer a1, final FloatBuffer a2, final FloatBuffer a3, final double a4, final double a5) {
        /*SL:47*/this.viewport = a1;
        /*SL:48*/this.modelview = a2;
        /*SL:49*/this.projection = a3;
        /*SL:50*/this.widthScale = a4;
        /*SL:51*/this.heightScale = a5;
        final float v1 = /*EL:52*/this.fovY = (float)Math.toDegrees(Math.atan(1.0 / this.projection.get(5)) * 2.0);
        /*SL:53*/this.displayWidth = this.viewport.get(2);
        /*SL:54*/this.displayHeight = this.viewport.get(3);
        /*SL:55*/this.fovX = (float)Math.toDegrees(2.0 * Math.atan(this.displayWidth / this.displayHeight * Math.tan(Math.toRadians(this.fovY) / 2.0)));
        final Vector3D v2 = /*EL:56*/new Vector3D(this.modelview.get(0), this.modelview.get(1), this.modelview.get(2));
        final Vector3D v3 = /*EL:57*/new Vector3D(this.modelview.get(4), this.modelview.get(5), this.modelview.get(6));
        final Vector3D v4 = /*EL:58*/new Vector3D(this.modelview.get(8), this.modelview.get(9), this.modelview.get(10));
        final Vector3D v5 = /*EL:59*/new Vector3D(0.0, 1.0, 0.0);
        final Vector3D v6 = /*EL:60*/new Vector3D(1.0, 0.0, 0.0);
        double v7 = /*EL:61*/Math.toDegrees(Math.atan2(v6.cross(v2).length(), v6.dot(v2))) + 180.0;
        /*SL:62*/if (v4.x < 0.0) {
            /*SL:63*/v7 = 360.0 - v7;
        }
        double v8 = /*EL:65*/0.0;
        /*SL:66*/v8 = (((-v4.y > 0.0 && v7 >= 90.0 && v7 < 270.0) || (v4.y > 0.0 && (v7 < 90.0 || v7 >= 270.0))) ? Math.toDegrees(Math.atan2(v5.cross(v3).length(), v5.dot(v3))) : (-Math.toDegrees(Math.atan2(v5.cross(v3).length(), v5.dot(v3)))));
        /*SL:67*/this.lookVec = this.getRotationVector(v7, v8);
        final Matrix4f v9 = /*EL:68*/new Matrix4f();
        /*SL:69*/v9.load(this.modelview.asReadOnlyBuffer());
        /*SL:70*/v9.invert();
        /*SL:71*/this.frustumPos = new Vector3D(v9.m30, v9.m31, v9.m32);
        /*SL:72*/this.frustum = this.getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, v7, v8, v1, 1.0, this.displayWidth / this.displayHeight);
        /*SL:73*/this.invFrustum = this.getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, v7 - 180.0, -v8, v1, 1.0, this.displayWidth / this.displayHeight);
        /*SL:74*/this.viewVec = this.getRotationVector(v7, v8).normalized();
        /*SL:75*/this.bra = Math.toDegrees(Math.acos(this.displayHeight * a5 / Math.sqrt(this.displayWidth * a4 * this.displayWidth * a4 + this.displayHeight * a5 * this.displayHeight * a5)));
        /*SL:76*/this.bla = 360.0 - this.bra;
        /*SL:77*/this.tra = this.bla - 180.0;
        /*SL:78*/this.tla = this.bra + 180.0;
        /*SL:79*/this.rb = new Line(this.displayWidth * this.widthScale, 0.0, 0.0, 0.0, 1.0, 0.0);
        /*SL:80*/this.tb = new Line(0.0, 0.0, 0.0, 1.0, 0.0, 0.0);
        /*SL:81*/this.lb = new Line(0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
        /*SL:82*/this.bb = new Line(0.0, this.displayHeight * this.heightScale, 0.0, 1.0, 0.0, 0.0);
    }
    
    public Projection project(final double v-23, final double v-21, final double v-19, final ClampMode v-17, final boolean v-16) {
        /*SL:91*/if (this.viewport == null || this.modelview == null || this.projection == null) {
            return new Projection(0.0, 0.0, Projection.Type.FAIL);
        }
        final Vector3D vector3D = /*EL:92*/new Vector3D(v-23, v-21, v-19);
        final boolean[] doFrustumCheck = /*EL:93*/this.doFrustumCheck(this.frustum, this.frustumPos, v-23, v-21, v-19);
        final boolean b2;
        final boolean b = /*EL:94*/b2 = (doFrustumCheck[0] || doFrustumCheck[1] || doFrustumCheck[2] || doFrustumCheck[3]);
        /*SL:95*/if (b) {
            final boolean b3 = /*EL:97*/vector3D.sub(this.frustumPos).dot(this.viewVec) <= 0.0;
            final boolean[] doFrustumCheck2 = /*EL:98*/this.doFrustumCheck(this.invFrustum, this.frustumPos, v-23, v-21, v-19);
            final boolean b5;
            final boolean b4 = /*EL:99*/b5 = (doFrustumCheck2[0] || doFrustumCheck2[1] || doFrustumCheck2[2] || doFrustumCheck2[3]);
            /*SL:100*/if ((v-16 && !b4) || (b4 && v-17 != ClampMode.NONE)) {
                /*SL:101*/if ((v-16 && !b4) || (v-17 == ClampMode.DIRECT && b4)) {
                    double a1 = /*EL:102*/0.0;
                    double a2 = /*EL:103*/0.0;
                    /*SL:104*/if (!GLU.gluProject((float)v-23, (float)v-21, (float)v-19, this.modelview, this.projection, this.viewport, this.coords)) {
                        return new Projection(0.0, 0.0, Projection.Type.FAIL);
                    }
                    /*SL:105*/if (b3) {
                        /*SL:106*/a1 = this.displayWidth * this.widthScale - this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0;
                        /*SL:107*/a2 = this.displayHeight * this.heightScale - (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0;
                    }
                    else {
                        /*SL:109*/a1 = this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0;
                        /*SL:110*/a2 = (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0;
                    }
                    final Vector3D a3 = /*EL:112*/new Vector3D(a1, a2, 0.0).snormalize();
                    /*SL:113*/a1 = a3.x;
                    /*SL:114*/a2 = a3.y;
                    final Line a4 = /*EL:115*/new Line(this.displayWidth * this.widthScale / 2.0, this.displayHeight * this.heightScale / 2.0, 0.0, a1, a2, 0.0);
                    double a5 = /*EL:116*/Math.toDegrees(Math.acos(a3.y / Math.sqrt(a3.x * a3.x + a3.y * a3.y)));
                    /*SL:117*/if (a1 < 0.0) {
                        /*SL:118*/a5 = 360.0 - a5;
                    }
                    Vector3D v1 = /*EL:120*/new Vector3D(0.0, 0.0, 0.0);
                    /*SL:121*/v1 = ((a5 >= this.bra && a5 < this.tra) ? this.rb.intersect(a4) : ((a5 >= this.tra && a5 < this.tla) ? this.tb.intersect(a4) : ((a5 >= this.tla && a5 < this.bla) ? this.lb.intersect(a4) : this.bb.intersect(a4))));
                    /*SL:122*/return new Projection(v1.x, v1.y, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
                }
                else {
                    /*SL:124*/if (v-17 != ClampMode.ORTHOGONAL || !b4) {
                        return new Projection(0.0, 0.0, Projection.Type.FAIL);
                    }
                    /*SL:125*/if (!GLU.gluProject((float)v-23, (float)v-21, (float)v-19, this.modelview, this.projection, this.viewport, this.coords)) {
                        return new Projection(0.0, 0.0, Projection.Type.FAIL);
                    }
                    double a6 = /*EL:126*/this.coords.get(0) * this.widthScale;
                    double a7 = /*EL:127*/(this.displayHeight - this.coords.get(1)) * this.heightScale;
                    /*SL:128*/if (b3) {
                        /*SL:129*/a6 = this.displayWidth * this.widthScale - a6;
                        /*SL:130*/a7 = this.displayHeight * this.heightScale - a7;
                    }
                    /*SL:132*/if (a6 < 0.0) {
                        /*SL:133*/a6 = 0.0;
                    }
                    else/*SL:134*/ if (a6 > this.displayWidth * this.widthScale) {
                        /*SL:135*/a6 = this.displayWidth * this.widthScale;
                    }
                    /*SL:137*/if (a7 < 0.0) {
                        /*SL:138*/a7 = 0.0;
                        /*SL:139*/return new Projection(a6, a7, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
                    }
                    /*SL:141*/if (a7 <= this.displayHeight * this.heightScale) {
                        return new Projection(a6, a7, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
                    }
                    /*SL:142*/a7 = this.displayHeight * this.heightScale;
                    /*SL:144*/return new Projection(a6, a7, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
                }
            }
            else {
                /*SL:146*/if (!GLU.gluProject((float)v-23, (float)v-21, (float)v-19, this.modelview, this.projection, this.viewport, this.coords)) {
                    return new Projection(0.0, 0.0, Projection.Type.FAIL);
                }
                double a6 = /*EL:147*/this.coords.get(0) * this.widthScale;
                double a7 = /*EL:148*/(this.displayHeight - this.coords.get(1)) * this.heightScale;
                /*SL:149*/if (!b3) {
                    return new Projection(a6, a7, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
                }
                /*SL:150*/a6 = this.displayWidth * this.widthScale - a6;
                /*SL:151*/a7 = this.displayHeight * this.heightScale - a7;
                /*SL:152*/return new Projection(a6, a7, b4 ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
            }
        }
        else {
            /*SL:154*/if (!GLU.gluProject((float)v-23, (float)v-21, (float)v-19, this.modelview, this.projection, this.viewport, this.coords)) {
                return new Projection(0.0, 0.0, Projection.Type.FAIL);
            }
            final double a8 = /*EL:155*/this.coords.get(0) * this.widthScale;
            final double a9 = /*EL:156*/(this.displayHeight - this.coords.get(1)) * this.heightScale;
            /*SL:157*/return new Projection(a8, a9, Projection.Type.INSIDE);
        }
    }
    
    public boolean[] doFrustumCheck(final Vector3D[] a1, final Vector3D a2, final double a3, final double a4, final double a5) {
        final Vector3D v1 = /*EL:161*/new Vector3D(a3, a4, a5);
        final boolean v2 = /*EL:162*/this.crossPlane(new Vector3D[] { a2, a1[3], a1[0] }, v1);
        final boolean v3 = /*EL:163*/this.crossPlane(new Vector3D[] { a2, a1[0], a1[1] }, v1);
        final boolean v4 = /*EL:164*/this.crossPlane(new Vector3D[] { a2, a1[1], a1[2] }, v1);
        final boolean v5 = /*EL:165*/this.crossPlane(new Vector3D[] { a2, a1[2], a1[3] }, v1);
        /*SL:166*/return new boolean[] { v2, v3, v4, v5 };
    }
    
    public boolean crossPlane(final Vector3D[] a1, final Vector3D a2) {
        final Vector3D v1 = /*EL:170*/new Vector3D(0.0, 0.0, 0.0);
        final Vector3D v2 = /*EL:171*/a1[1].sub(a1[0]);
        final Vector3D v3 = /*EL:172*/a1[2].sub(a1[0]);
        final Vector3D v4 = /*EL:173*/v2.cross(v3).snormalize();
        final double v5 = /*EL:174*/v1.sub(v4).dot(a1[2]);
        final double v6 = /*EL:175*/v4.dot(a2) + v5;
        /*SL:176*/return v6 >= 0.0;
    }
    
    public Vector3D[] getFrustum(final double a1, final double a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8) {
        final double v1 = /*EL:180*/2.0 * Math.tan(Math.toRadians(a6 / 2.0)) * a7;
        final double v2 = /*EL:181*/v1 * a8;
        final Vector3D v3 = /*EL:182*/this.getRotationVector(a4, a5).snormalize();
        final Vector3D v4 = /*EL:183*/this.getRotationVector(a4, a5 - 90.0).snormalize();
        final Vector3D v5 = /*EL:184*/this.getRotationVector(a4 + 90.0, 0.0).snormalize();
        final Vector3D v6 = /*EL:185*/new Vector3D(a1, a2, a3);
        final Vector3D v7 = /*EL:186*/v3.add(v6);
        final Vector3D v8 = /*EL:187*/new Vector3D(v7.x * a7, v7.y * a7, v7.z * a7);
        final Vector3D v9 = /*EL:188*/new Vector3D(v8.x + v4.x * v1 / 2.0 - v5.x * v2 / 2.0, v8.y + v4.y * v1 / 2.0 - v5.y * v2 / 2.0, v8.z + v4.z * v1 / 2.0 - v5.z * v2 / 2.0);
        final Vector3D v10 = /*EL:189*/new Vector3D(v8.x - v4.x * v1 / 2.0 - v5.x * v2 / 2.0, v8.y - v4.y * v1 / 2.0 - v5.y * v2 / 2.0, v8.z - v4.z * v1 / 2.0 - v5.z * v2 / 2.0);
        final Vector3D v11 = /*EL:190*/new Vector3D(v8.x + v4.x * v1 / 2.0 + v5.x * v2 / 2.0, v8.y + v4.y * v1 / 2.0 + v5.y * v2 / 2.0, v8.z + v4.z * v1 / 2.0 + v5.z * v2 / 2.0);
        final Vector3D v12 = /*EL:191*/new Vector3D(v8.x - v4.x * v1 / 2.0 + v5.x * v2 / 2.0, v8.y - v4.y * v1 / 2.0 + v5.y * v2 / 2.0, v8.z - v4.z * v1 / 2.0 + v5.z * v2 / 2.0);
        /*SL:192*/return new Vector3D[] { v9, v10, v12, v11 };
    }
    
    public Vector3D[] getFrustum() {
        /*SL:196*/return this.frustum;
    }
    
    public float getFovX() {
        /*SL:200*/return this.fovX;
    }
    
    public float getFovY() {
        /*SL:204*/return this.fovY;
    }
    
    public Vector3D getLookVector() {
        /*SL:208*/return this.lookVec;
    }
    
    public Vector3D getRotationVector(final double a1, final double a2) {
        final double v1 = /*EL:212*/Math.cos(-a1 * 0.01745329238474369 - 3.141592653589793);
        final double v2 = /*EL:213*/Math.sin(-a1 * 0.01745329238474369 - 3.141592653589793);
        final double v3 = /*EL:214*/-Math.cos(-a2 * 0.01745329238474369);
        final double v4 = /*EL:215*/Math.sin(-a2 * 0.01745329238474369);
        /*SL:216*/return new Vector3D(v2 * v3, v4, v1 * v3);
    }
    
    public enum ClampMode
    {
        ORTHOGONAL, 
        DIRECT, 
        NONE;
    }
    
    public static class Projection
    {
        private final double x;
        private final double y;
        private final Type t;
        
        public Projection(final double a1, final double a2, final Type a3) {
            this.x = a1;
            this.y = a2;
            this.t = a3;
        }
        
        public double getX() {
            /*SL:238*/return this.x;
        }
        
        public double getY() {
            /*SL:242*/return this.y;
        }
        
        public Type getType() {
            /*SL:246*/return this.t;
        }
        
        public boolean isType(final Type a1) {
            /*SL:250*/return this.t == a1;
        }
        
        public enum Type
        {
            INSIDE, 
            OUTSIDE, 
            INVERTED, 
            FAIL;
        }
    }
    
    public static class Vector3D
    {
        public double x;
        public double y;
        public double z;
        
        public Vector3D(final double a1, final double a2, final double a3) {
            this.x = a1;
            this.y = a2;
            this.z = a3;
        }
        
        public Vector3D add(final Vector3D a1) {
            /*SL:274*/return new Vector3D(this.x + a1.x, this.y + a1.y, this.z + a1.z);
        }
        
        public Vector3D add(final double a1, final double a2, final double a3) {
            /*SL:278*/return new Vector3D(this.x + a1, this.y + a2, this.z + a3);
        }
        
        public Vector3D sub(final Vector3D a1) {
            /*SL:282*/return new Vector3D(this.x - a1.x, this.y - a1.y, this.z - a1.z);
        }
        
        public Vector3D sub(final double a1, final double a2, final double a3) {
            /*SL:286*/return new Vector3D(this.x - a1, this.y - a2, this.z - a3);
        }
        
        public Vector3D normalized() {
            final double v1 = /*EL:290*/Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
            /*SL:291*/return new Vector3D(this.x / v1, this.y / v1, this.z / v1);
        }
        
        public double dot(final Vector3D a1) {
            /*SL:295*/return this.x * a1.x + this.y * a1.y + this.z * a1.z;
        }
        
        public Vector3D cross(final Vector3D a1) {
            /*SL:299*/return new Vector3D(this.y * a1.z - this.z * a1.y, this.z * a1.x - this.x * a1.z, this.x * a1.y - this.y * a1.x);
        }
        
        public Vector3D mul(final double a1) {
            /*SL:303*/return new Vector3D(this.x * a1, this.y * a1, this.z * a1);
        }
        
        public Vector3D div(final double a1) {
            /*SL:307*/return new Vector3D(this.x / a1, this.y / a1, this.z / a1);
        }
        
        public double length() {
            /*SL:311*/return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        }
        
        public Vector3D sadd(final Vector3D a1) {
            /*SL:315*/this.x += a1.x;
            /*SL:316*/this.y += a1.y;
            /*SL:317*/this.z += a1.z;
            /*SL:318*/return this;
        }
        
        public Vector3D sadd(final double a1, final double a2, final double a3) {
            /*SL:322*/this.x += a1;
            /*SL:323*/this.y += a2;
            /*SL:324*/this.z += a3;
            /*SL:325*/return this;
        }
        
        public Vector3D ssub(final Vector3D a1) {
            /*SL:329*/this.x -= a1.x;
            /*SL:330*/this.y -= a1.y;
            /*SL:331*/this.z -= a1.z;
            /*SL:332*/return this;
        }
        
        public Vector3D ssub(final double a1, final double a2, final double a3) {
            /*SL:336*/this.x -= a1;
            /*SL:337*/this.y -= a2;
            /*SL:338*/this.z -= a3;
            /*SL:339*/return this;
        }
        
        public Vector3D snormalize() {
            final double v1 = /*EL:343*/Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
            /*SL:344*/this.x /= v1;
            /*SL:345*/this.y /= v1;
            /*SL:346*/this.z /= v1;
            /*SL:347*/return this;
        }
        
        public Vector3D scross(final Vector3D a1) {
            /*SL:351*/this.x = this.y * a1.z - this.z * a1.y;
            /*SL:352*/this.y = this.z * a1.x - this.x * a1.z;
            /*SL:353*/this.z = this.x * a1.y - this.y * a1.x;
            /*SL:354*/return this;
        }
        
        public Vector3D smul(final double a1) {
            /*SL:358*/this.x *= a1;
            /*SL:359*/this.y *= a1;
            /*SL:360*/this.z *= a1;
            /*SL:361*/return this;
        }
        
        public Vector3D sdiv(final double a1) {
            /*SL:365*/this.x /= a1;
            /*SL:366*/this.y /= a1;
            /*SL:367*/this.z /= a1;
            /*SL:368*/return this;
        }
        
        @Override
        public String toString() {
            /*SL:372*/return "(X: " + this.x + " Y: " + this.y + " Z: " + this.z + ")";
        }
    }
    
    public static class Line
    {
        public Vector3D sourcePoint;
        public Vector3D direction;
        
        public Line(final double a1, final double a2, final double a3, final double a4, final double a5, final double a6) {
            this.sourcePoint = new Vector3D(0.0, 0.0, 0.0);
            this.direction = new Vector3D(0.0, 0.0, 0.0);
            this.sourcePoint.x = a1;
            this.sourcePoint.y = a2;
            this.sourcePoint.z = a3;
            this.direction.x = a4;
            this.direction.y = a5;
            this.direction.z = a6;
        }
        
        public Vector3D intersect(final Line a1) {
            final double v1 = /*EL:390*/this.sourcePoint.x;
            final double v2 = /*EL:391*/this.direction.x;
            final double v3 = /*EL:392*/a1.sourcePoint.x;
            final double v4 = /*EL:393*/a1.direction.x;
            final double v5 = /*EL:394*/this.sourcePoint.y;
            final double v6 = /*EL:395*/this.direction.y;
            final double v7 = /*EL:396*/a1.sourcePoint.y;
            final double v8 = /*EL:397*/a1.direction.y;
            final double v9 = /*EL:398*/-(v1 * v8 - v3 * v8 - v4 * (v5 - v7));
            final double v10 = /*EL:399*/v2 * v8 - v4 * v6;
            /*SL:400*/if (v10 == 0.0) {
                /*SL:401*/return this.intersectXZ(a1);
            }
            final double v11 = /*EL:403*/v9 / v10;
            final Vector3D v12 = /*EL:404*/new Vector3D(0.0, 0.0, 0.0);
            /*SL:405*/v12.x = this.sourcePoint.x + this.direction.x * v11;
            /*SL:406*/v12.y = this.sourcePoint.y + this.direction.y * v11;
            /*SL:407*/v12.z = this.sourcePoint.z + this.direction.z * v11;
            /*SL:408*/return v12;
        }
        
        private Vector3D intersectXZ(final Line a1) {
            final double v1 = /*EL:412*/this.sourcePoint.x;
            final double v2 = /*EL:413*/this.direction.x;
            final double v3 = /*EL:414*/a1.sourcePoint.x;
            final double v4 = /*EL:415*/a1.direction.x;
            final double v5 = /*EL:416*/this.sourcePoint.z;
            final double v6 = /*EL:417*/this.direction.z;
            final double v7 = /*EL:418*/a1.sourcePoint.z;
            final double v8 = /*EL:419*/a1.direction.z;
            final double v9 = /*EL:420*/-(v1 * v8 - v3 * v8 - v4 * (v5 - v7));
            final double v10 = /*EL:421*/v2 * v8 - v4 * v6;
            /*SL:422*/if (v10 == 0.0) {
                /*SL:423*/return this.intersectYZ(a1);
            }
            final double v11 = /*EL:425*/v9 / v10;
            final Vector3D v12 = /*EL:426*/new Vector3D(0.0, 0.0, 0.0);
            /*SL:427*/v12.x = this.sourcePoint.x + this.direction.x * v11;
            /*SL:428*/v12.y = this.sourcePoint.y + this.direction.y * v11;
            /*SL:429*/v12.z = this.sourcePoint.z + this.direction.z * v11;
            /*SL:430*/return v12;
        }
        
        private Vector3D intersectYZ(final Line a1) {
            final double v1 = /*EL:434*/this.sourcePoint.y;
            final double v2 = /*EL:435*/this.direction.y;
            final double v3 = /*EL:436*/a1.sourcePoint.y;
            final double v4 = /*EL:437*/a1.direction.y;
            final double v5 = /*EL:438*/this.sourcePoint.z;
            final double v6 = /*EL:439*/this.direction.z;
            final double v7 = /*EL:440*/a1.sourcePoint.z;
            final double v8 = /*EL:441*/a1.direction.z;
            final double v9 = /*EL:442*/-(v1 * v8 - v3 * v8 - v4 * (v5 - v7));
            final double v10 = /*EL:443*/v2 * v8 - v4 * v6;
            /*SL:444*/if (v10 == 0.0) {
                /*SL:445*/return null;
            }
            final double v11 = /*EL:447*/v9 / v10;
            final Vector3D v12 = /*EL:448*/new Vector3D(0.0, 0.0, 0.0);
            /*SL:449*/v12.x = this.sourcePoint.x + this.direction.x * v11;
            /*SL:450*/v12.y = this.sourcePoint.y + this.direction.y * v11;
            /*SL:451*/v12.z = this.sourcePoint.z + this.direction.z * v11;
            /*SL:452*/return v12;
        }
        
        public Vector3D intersectPlane(final Vector3D a1, final Vector3D a2) {
            final Vector3D v1 = /*EL:456*/new Vector3D(this.sourcePoint.x, this.sourcePoint.y, this.sourcePoint.z);
            final double v2 = /*EL:457*/a1.sub(this.sourcePoint).dot(a2) / this.direction.dot(a2);
            /*SL:458*/v1.sadd(this.direction.mul(v2));
            /*SL:459*/if (this.direction.dot(a2) == 0.0) {
                /*SL:460*/return null;
            }
            /*SL:462*/return v1;
        }
    }
}
