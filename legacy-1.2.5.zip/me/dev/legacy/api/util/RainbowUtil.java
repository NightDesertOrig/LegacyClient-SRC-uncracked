package me.dev.legacy.api.util;

import java.awt.Color;

public class RainbowUtil
{
    public static Color getColour() {
        /*SL:8*/return Colour.fromHSB(System.currentTimeMillis() % 11520L / 11520.0f, 1.0f, 1.0f);
    }
    
    public static Color getFurtherColour(final int a1) {
        /*SL:12*/return Colour.fromHSB((System.currentTimeMillis() + a1) % 11520L / 11520.0f, 1.0f, 1.0f);
    }
}
