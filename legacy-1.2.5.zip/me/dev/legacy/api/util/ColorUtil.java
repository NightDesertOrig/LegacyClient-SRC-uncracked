package me.dev.legacy.api.util;

import me.dev.legacy.modules.client.ClickGui;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class ColorUtil
{
    public ColorUtil(final int a1, final int a2, final int a3, final int a4) {
    }
    
    public static void color(final int a1) {
        /*SL:15*/GL11.glColor4f((a1 >> 16 & 0xFF) / 255.0f, (a1 >> 8 & 0xFF) / 255.0f, (a1 & 0xFF) / 255.0f, (a1 >> 24 & 0xFF) / 255.0f);
    }
    
    public static int shadeColour(final int a1, final int a2) {
        final int v1 = /*EL:18*/((a1 & 0xFF0000) >> 16) * (100 + a2) / 100;
        final int v2 = /*EL:19*/((a1 & 0xFF00) >> 8) * (100 + a2) / 100;
        final int v3 = /*EL:20*/(a1 & 0xFF) * (100 + a2) / 100;
        /*SL:21*/return new Color(v1, v2, v3).hashCode();
    }
    
    public static int getRainbow(final int a1, final float a2) {
        final float v1 = /*EL:25*/System.currentTimeMillis() % a1;
        /*SL:26*/return Color.getHSBColor(v1 / a1, a2, 1.0f).getRGB();
    }
    
    public static int getRainbow(final int a1, final int a2, final float a3) {
        final float v1 = /*EL:30*/System.currentTimeMillis() % a1 + a2 * 15L;
        /*SL:31*/return Color.getHSBColor(v1 / a1, a3, 1.0f).getRGB();
    }
    
    public static int toRGBA(final int a1, final int a2, final int a3) {
        /*SL:35*/return toRGBA(a1, a2, a3, 255);
    }
    
    public static int toRGBA(final int a1, final int a2, final int a3, final int a4) {
        /*SL:39*/return (a1 << 16) + (a2 << 8) + a3 + (a4 << 24);
    }
    
    public static int toARGB(final int a1, final int a2, final int a3, final int a4) {
        /*SL:43*/return new Color(a1, a2, a3, a4).getRGB();
    }
    
    public static int toRGBA(final float a1, final float a2, final float a3, final float a4) {
        /*SL:47*/return toRGBA((int)(a1 * 255.0f), (int)(a2 * 255.0f), (int)(a3 * 255.0f), (int)(a4 * 255.0f));
    }
    
    public static Color rainbow(final int a1) {
        double v1 = /*EL:51*/Math.ceil((System.currentTimeMillis() + a1) / 20.0);
        /*SL:52*/return Color.getHSBColor((float)((v1 %= 360.0) / 360.0), ClickGui.getInstance().rainbowSaturation.getValue() / 255.0f, ClickGui.getInstance().rainbowBrightness.getValue() / 255.0f);
    }
    
    public static int toRGBA(final float[] a1) {
        /*SL:56*/if (a1.length != 4) {
            /*SL:57*/throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        /*SL:59*/return toRGBA(a1[0], a1[1], a1[2], a1[3]);
    }
    
    public static int toRGBA(final double[] a1) {
        /*SL:63*/if (a1.length != 4) {
            /*SL:64*/throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        /*SL:66*/return toRGBA((float)a1[0], (float)a1[1], (float)a1[2], (float)a1[3]);
    }
    
    public static int toRGBA(final Color a1) {
        /*SL:84*/return toRGBA(a1.getRed(), a1.getGreen(), a1.getBlue(), a1.getAlpha());
    }
    
    public static class Colors
    {
        public static final int WHITE;
        public static final int BLACK;
        public static final int RED;
        public static final int GREEN;
        public static final int BLUE;
        public static final int ORANGE;
        public static final int PURPLE;
        public static final int GRAY;
        public static final int DARK_RED;
        public static final int YELLOW;
        public static final int RAINBOW = Integer.MIN_VALUE;
        
        static {
            WHITE = ColorUtil.toRGBA(255, 255, 255, 255);
            BLACK = ColorUtil.toRGBA(0, 0, 0, 255);
            RED = ColorUtil.toRGBA(255, 0, 0, 255);
            GREEN = ColorUtil.toRGBA(0, 255, 0, 255);
            BLUE = ColorUtil.toRGBA(0, 0, 255, 255);
            ORANGE = ColorUtil.toRGBA(255, 128, 0, 255);
            PURPLE = ColorUtil.toRGBA(163, 73, 163, 255);
            GRAY = ColorUtil.toRGBA(127, 127, 127, 255);
            DARK_RED = ColorUtil.toRGBA(64, 0, 0, 255);
            YELLOW = ColorUtil.toRGBA(255, 255, 0, 255);
        }
    }
    
    public static class ColorName
    {
        public int r;
        public int g;
        public int b;
        public String name;
        
        public ColorName(final String a1, final int a2, final int a3, final int a4) {
            this.r = a2;
            this.g = a3;
            this.b = a4;
            this.name = a1;
        }
        
        public int computeMSE(final int a1, final int a2, final int a3) {
            /*SL:101*/return ((a1 - this.r) * (a1 - this.r) + (a2 - this.g) * (a2 - this.g) + (a3 - this.b) * (a3 - this.b)) / 3;
        }
        
        public int getR() {
            /*SL:105*/return this.r;
        }
        
        public int getG() {
            /*SL:109*/return this.g;
        }
        
        public int getB() {
            /*SL:113*/return this.b;
        }
        
        public String getName() {
            /*SL:117*/return this.name;
        }
    }
}
