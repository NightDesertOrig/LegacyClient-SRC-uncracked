package me.dev.legacy.api.util;

public enum Stage
{
    PRE, 
    POST;
}
