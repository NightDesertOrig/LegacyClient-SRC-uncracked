package me.dev.legacy.api.util;

import java.util.Arrays;
import net.minecraft.block.material.Material;
import net.minecraft.world.World;
import net.minecraft.network.play.client.CPacketAnimation;
import java.util.function.Predicate;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;
import net.minecraft.network.play.client.CPacketEntityAction;
import java.util.concurrent.atomic.AtomicBoolean;
import com.google.common.util.concurrent.AtomicDouble;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockAir;
import net.minecraft.util.math.RayTraceResult;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.block.BlockSlab;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.Vec3d;
import java.util.Collection;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Block;
import java.util.List;

public class BlockUtil implements Util
{
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    public static final List<Block> unSafeBlocks;
    public static List<Block> unSolidBlocks;
    public static List<Block> emptyBlocks;
    
    public static List<BlockPos> getBlockSphere(final float a1, final Class a2) {
        final NonNullList v1 = /*EL:41*/NonNullList.func_191196_a();
        /*SL:42*/v1.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)BlockUtil.mc.field_71439_g), a1, (int)a1, false, true, 0).stream().filter(a2 -> a2.isInstance(BlockUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c())).<List<? super Object>, ?>collect((Collector<? super Object, ?, List<? super Object>>)Collectors.<Object>toList()));
        /*SL:43*/return (List<BlockPos>)v1;
    }
    
    public static void placeBlockScaffold(final BlockPos v-6) {
        final Vec3d vec3d = /*EL:46*/new Vec3d(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u + BlockUtil.mc.field_71439_g.func_70047_e(), BlockUtil.mc.field_71439_g.field_70161_v);
        /*SL:47*/for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos a1 = /*EL:48*/v-6.func_177972_a(enumFacing);
            final EnumFacing v1 = /*EL:49*/enumFacing.func_176734_d();
            final Vec3d v2;
            /*SL:51*/if (canBeClicked(a1) && vec3d.func_72436_e(v2 = new Vec3d((Vec3i)a1).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v1.func_176730_m()).func_186678_a(0.5))) <= 18.0625) {
                /*SL:52*/HoleFillUtil.faceVectorPacketInstant(v2);
                /*SL:53*/HoleFillUtil.processRightClickBlock(a1, v1, v2);
                BlockUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                BlockUtil.mc.field_71467_ac = /*EL:55*/4;
                /*SL:56*/return;
            }
        }
    }
    
    public static double getNearestBlockBelow() {
        /*SL:62*/for (double v1 = BlockUtil.mc.field_71439_g.field_70163_u; v1 > 0.0; v1 -= 0.001) {
            if (/*EL:63*/!(BlockUtil.mc.field_71441_e.func_180495_p(new BlockPos(BlockUtil.mc.field_71439_g.field_70165_t, v1, BlockUtil.mc.field_71439_g.field_70161_v)).func_177230_c() instanceof BlockSlab) && BlockUtil.mc.field_71441_e.func_180495_p(new BlockPos(BlockUtil.mc.field_71439_g.field_70165_t, v1, BlockUtil.mc.field_71439_g.field_70161_v)).func_177230_c().func_176223_P().func_185890_d((IBlockAccess)BlockUtil.mc.field_71441_e, new BlockPos(0, 0, 0)) != null) {
                /*SL:64*/return v1;
            }
        }
        /*SL:66*/return -1.0;
    }
    
    public static void faceVectorPacketInstant(final Vec3d a1) {
        final float[] v1 = /*EL:70*/RotationUtil.getLegitRotations(a1);
        /*SL:71*/Wrapper.getPlayer().field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(v1[0], v1[1], Wrapper.getPlayer().field_70122_E));
    }
    
    public static boolean isInHole() {
        final BlockPos v1 = /*EL:75*/new BlockPos(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u, BlockUtil.mc.field_71439_g.field_70161_v);
        final IBlockState v2 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:76*/v1);
        /*SL:77*/return isBlockValid(v2, v1);
    }
    
    public static boolean isBlockValid(final IBlockState a1, final BlockPos a2) {
        /*SL:90*/return a1.func_177230_c() == Blocks.field_150350_a && BlockUtil.mc.field_71439_g.func_174818_b(a2) >= 1.0 && BlockUtil.mc.field_71441_e.func_180495_p(a2.func_177984_a()).func_177230_c() == Blocks.field_150350_a && BlockUtil.mc.field_71441_e.func_180495_p(a2.func_177981_b(2)).func_177230_c() == Blocks.field_150350_a && (isBedrockHole(/*EL:93*/a2) || isObbyHole(a2) || isBothHole(a2) || isElseHole(a2));
    }
    
    public static boolean isObbyHole(final BlockPos v-3) {
        /*SL:97*/for (final BlockPos v1 : getTouchingBlocks(v-3)) {
            final IBlockState a1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:98*/v1);
            /*SL:99*/if (a1.func_177230_c() == Blocks.field_150350_a || a1.func_177230_c() != Blocks.field_150343_Z) {
                /*SL:100*/return false;
            }
        }
        /*SL:102*/return true;
    }
    
    public static boolean isBedrockHole(final BlockPos v-3) {
        /*SL:106*/for (final BlockPos v1 : getTouchingBlocks(v-3)) {
            final IBlockState a1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:107*/v1);
            /*SL:108*/if (a1.func_177230_c() == Blocks.field_150350_a || a1.func_177230_c() != Blocks.field_150357_h) {
                /*SL:109*/return false;
            }
        }
        /*SL:111*/return true;
    }
    
    public static boolean isBothHole(final BlockPos v-3) {
        /*SL:115*/for (final BlockPos v1 : getTouchingBlocks(v-3)) {
            final IBlockState a1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:116*/v1);
            if (/*EL:117*/a1.func_177230_c() == Blocks.field_150350_a || (a1.func_177230_c() != Blocks.field_150357_h && a1.func_177230_c() != Blocks.field_150343_Z)) {
                /*SL:118*/return false;
            }
        }
        /*SL:120*/return true;
    }
    
    public static boolean isElseHole(final BlockPos v-3) {
        /*SL:124*/for (final BlockPos v1 : getTouchingBlocks(v-3)) {
            final IBlockState a1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:125*/v1);
            /*SL:126*/if (a1.func_177230_c() == Blocks.field_150350_a || !a1.func_185913_b()) {
                /*SL:127*/return false;
            }
        }
        /*SL:129*/return true;
    }
    
    public static BlockPos[] getTouchingBlocks(final BlockPos a1) {
        /*SL:133*/return new BlockPos[] { a1.func_177978_c(), a1.func_177968_d(), a1.func_177974_f(), a1.func_177976_e(), a1.func_177977_b() };
    }
    
    public static boolean canPlaceCrystal(final BlockPos a1, final boolean a2) {
        final Chunk v1 = BlockUtil.mc.field_71441_e.func_175726_f(/*EL:137*/a1);
        final Block v2 = /*EL:138*/v1.func_177435_g(a1).func_177230_c();
        /*SL:139*/if (v2 != Blocks.field_150357_h && v2 != Blocks.field_150343_Z) {
            /*SL:140*/return false;
        }
        final BlockPos v3 = /*EL:142*/a1.func_177967_a(EnumFacing.UP, 1);
        /*SL:143*/return v1.func_177435_g(v3).func_177230_c() == Blocks.field_150350_a && v1.func_177435_g(a1.func_177967_a(EnumFacing.UP, 2)).func_177230_c() == Blocks.field_150350_a && BlockUtil.mc.field_71441_e.func_175647_a(/*EL:146*/(Class)Entity.class, new AxisAlignedBB((double)v3.func_177958_n(), (double)v3.func_177956_o(), (double)v3.func_177952_p(), (double)(v3.func_177958_n() + 1), (double)(v3.func_177956_o() + (a2 ? 2 : 1)), (double)(v3.func_177952_p() + 1)), a1 -> !(a1 instanceof EntityEnderCrystal)).isEmpty();
    }
    
    public static boolean isBlockEmpty(final BlockPos v-1) {
        try {
            /*SL:153*/if (BlockUtil.emptyBlocks.contains(BlockUtil.mc.field_71441_e.func_180495_p(v-1).func_177230_c())) {
                final AxisAlignedBB a1 = /*EL:154*/new AxisAlignedBB(v-1);
                /*SL:155*/for (final Entity v2 : BlockUtil.mc.field_71441_e.field_72996_f) {
                    /*SL:165*/if (v2 instanceof EntityLivingBase && a1.func_72326_a(v2.func_174813_aQ())) {
                        return /*EL:169*/false;
                    }
                }
                return true;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static boolean canPlaceBlock(final BlockPos v0) {
        /*SL:174*/if (isBlockEmpty(v0)) {
            final EnumFacing[] values;
            final EnumFacing[] v = /*EL:177*/values = EnumFacing.values();
            for (final EnumFacing a1 : values) {
                /*SL:178*/if (!BlockUtil.emptyBlocks.contains(BlockUtil.mc.field_71441_e.func_180495_p(v0.func_177972_a(a1)).func_177230_c()) && BlockUtil.mc.field_71439_g.func_174824_e(BlockUtil.mc.func_184121_ak()).func_72438_d(new Vec3d(v0.func_177958_n() + 0.5 + a1.func_82601_c() * 0.5, v0.func_177956_o() + 0.5 + a1.func_96559_d() * 0.5, v0.func_177952_p() + 0.5 + a1.func_82599_e() * 0.5)) <= 4.25) {
                    /*SL:179*/return true;
                }
            }
        }
        /*SL:184*/return false;
    }
    
    public static List<EnumFacing> getPossibleSides(final BlockPos v-6) {
        final ArrayList<EnumFacing> list = /*EL:188*/new ArrayList<EnumFacing>();
        /*SL:189*/for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos v1 = /*EL:191*/v-6.func_177972_a(enumFacing);
            /*SL:192*/if (BlockUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c().func_176209_a(BlockUtil.mc.field_71441_e.func_180495_p(v1), false)) {
                final IBlockState a1;
                if (!(a1 = BlockUtil.mc.field_71441_e.func_180495_p(v1)).func_185904_a().func_76222_j()) {
                    /*SL:194*/list.add(enumFacing);
                }
            }
        }
        /*SL:196*/return list;
    }
    
    public static EnumFacing getFirstFacing(final BlockPos v1) {
        final Iterator<EnumFacing> v2 = getPossibleSides(/*EL:200*/v1).iterator();
        /*SL:201*/if (v2.hasNext()) {
            final EnumFacing a1 = /*EL:202*/v2.next();
            /*SL:203*/return a1;
        }
        /*SL:205*/return null;
    }
    
    public static EnumFacing getRayTraceFacing(final BlockPos a1) {
        final RayTraceResult v1 = BlockUtil.mc.field_71441_e.func_72933_a(/*EL:209*/new Vec3d(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u + BlockUtil.mc.field_71439_g.func_70047_e(), BlockUtil.mc.field_71439_g.field_70161_v), new Vec3d(a1.func_177958_n() + 0.5, a1.func_177958_n() - 0.5, a1.func_177958_n() + 0.5));
        /*SL:210*/if (v1 == null || v1.field_178784_b == null) {
            /*SL:211*/return EnumFacing.UP;
        }
        /*SL:213*/return v1.field_178784_b;
    }
    
    public static int isPositionPlaceable(final BlockPos a1, final boolean a2) {
        /*SL:217*/return isPositionPlaceable(a1, a2, true);
    }
    
    public static int isPositionPlaceable(final BlockPos a3, final boolean v1, final boolean v2) {
        final Block v3 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:221*/a3).func_177230_c();
        /*SL:222*/if (!(v3 instanceof BlockAir) && !(v3 instanceof BlockLiquid) && !(v3 instanceof BlockTallGrass) && !(v3 instanceof BlockFire) && !(v3 instanceof BlockDeadBush) && !(v3 instanceof BlockSnow)) {
            /*SL:223*/return 0;
        }
        /*SL:225*/if (!rayTracePlaceCheck(a3, v1, 0.0f)) {
            /*SL:226*/return -1;
        }
        /*SL:228*/if (v2) {
            /*SL:229*/for (final Entity a4 : BlockUtil.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(a3))) {
                /*SL:230*/if (!(a4 instanceof EntityItem)) {
                    if (a4 instanceof EntityXPOrb) {
                        continue;
                    }
                    /*SL:231*/return 1;
                }
            }
        }
        /*SL:234*/for (final EnumFacing a5 : getPossibleSides(a3)) {
            /*SL:235*/if (!canBeClicked(a3.func_177972_a(a5))) {
                continue;
            }
            /*SL:236*/return 3;
        }
        /*SL:238*/return 2;
    }
    
    public static void rightClickBlock(final BlockPos a4, final Vec3d a5, final EnumHand v1, final EnumFacing v2, final boolean v3) {
        /*SL:242*/if (v3) {
            final float a6 = /*EL:243*/(float)(a5.field_72450_a - a4.func_177958_n());
            final float a7 = /*EL:244*/(float)(a5.field_72448_b - a4.func_177956_o());
            final float a8 = /*EL:245*/(float)(a5.field_72449_c - a4.func_177952_p());
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:246*/(Packet)new CPacketPlayerTryUseItemOnBlock(a4, v2, v1, a6, a7, a8));
        }
        else {
            BlockUtil.mc.field_71442_b.func_187099_a(BlockUtil.mc.field_71439_g, BlockUtil.mc.field_71441_e, /*EL:248*/a4, v2, a5, v1);
        }
        BlockUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        BlockUtil.mc.field_71467_ac = /*EL:251*/4;
    }
    
    public static void rightClickBlockLegit(final BlockPos a5, final float a6, final boolean a7, final EnumHand v1, final AtomicDouble v2, final AtomicDouble v3, final AtomicBoolean v4) {
        final Vec3d v5 = /*EL:255*/RotationUtil.getEyesPos();
        final Vec3d v6 = /*EL:256*/new Vec3d((Vec3i)a5).func_72441_c(0.5, 0.5, 0.5);
        final double v7 = /*EL:257*/v5.func_72436_e(v6);
        /*SL:258*/for (final EnumFacing a8 : EnumFacing.values()) {
            final Vec3d a9 = /*EL:259*/v6.func_178787_e(new Vec3d(a8.func_176730_m()).func_186678_a(0.5));
            final double a10 = /*EL:260*/v5.func_72436_e(a9);
            if (/*EL:261*/a10 <= MathUtil.square(a6) && a10 < v7 && BlockUtil.mc.field_71441_e.func_147447_a(v5, a9, false, true, false) == null) {
                /*SL:263*/if (a7) {
                    final float[] a11 = /*EL:264*/RotationUtil.getLegitRotations(a9);
                    /*SL:265*/v2.set(a11[0]);
                    /*SL:266*/v3.set(a11[1]);
                    /*SL:267*/v4.set(true);
                }
                BlockUtil.mc.field_71442_b.func_187099_a(BlockUtil.mc.field_71439_g, BlockUtil.mc.field_71441_e, /*EL:269*/a5, a8, a9, v1);
                BlockUtil.mc.field_71439_g.func_184609_a(/*EL:270*/v1);
                BlockUtil.mc.field_71467_ac = /*EL:271*/4;
                /*SL:272*/break;
            }
        }
    }
    
    public static boolean placeBlock(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4, final boolean a5) {
        boolean v1 = /*EL:277*/false;
        final EnumFacing v2 = getFirstFacing(/*EL:278*/a1);
        /*SL:279*/if (v2 == null) {
            /*SL:280*/return a5;
        }
        final BlockPos v3 = /*EL:282*/a1.func_177972_a(v2);
        final EnumFacing v4 = /*EL:283*/v2.func_176734_d();
        final Vec3d v5 = /*EL:284*/new Vec3d((Vec3i)v3).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v4.func_176730_m()).func_186678_a(0.5));
        final Block v6 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:285*/v3).func_177230_c();
        /*SL:286*/if (!BlockUtil.mc.field_71439_g.func_70093_af() && (BlockUtil.blackList.contains(v6) || BlockUtil.shulkerList.contains(v6))) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:287*/(Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            BlockUtil.mc.field_71439_g.func_70095_a(/*EL:288*/true);
            /*SL:289*/v1 = true;
        }
        /*SL:291*/if (a3) {
            /*SL:292*/RotationUtil.faceVector(v5, true);
        }
        rightClickBlock(/*EL:294*/v3, v5, a2, v4, a4);
        BlockUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        BlockUtil.mc.field_71467_ac = /*EL:296*/4;
        /*SL:297*/return v1 || a5;
    }
    
    public static boolean placeBlockSmartRotate(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4, final boolean a5) {
        boolean v1 = /*EL:301*/false;
        final EnumFacing v2 = getFirstFacing(/*EL:302*/a1);
        /*SL:303*/Command.sendMessage(v2.toString());
        /*SL:304*/if (v2 == null) {
            /*SL:305*/return a5;
        }
        final BlockPos v3 = /*EL:307*/a1.func_177972_a(v2);
        final EnumFacing v4 = /*EL:308*/v2.func_176734_d();
        final Vec3d v5 = /*EL:309*/new Vec3d((Vec3i)v3).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v4.func_176730_m()).func_186678_a(0.5));
        final Block v6 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:310*/v3).func_177230_c();
        /*SL:311*/if (!BlockUtil.mc.field_71439_g.func_70093_af() && (BlockUtil.blackList.contains(v6) || BlockUtil.shulkerList.contains(v6))) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:312*/(Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            /*SL:313*/v1 = true;
        }
        /*SL:315*/if (a3) {
            Legacy.rotationManager.lookAtVec3d(/*EL:316*/v5);
        }
        rightClickBlock(/*EL:318*/v3, v5, a2, v4, a4);
        BlockUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        BlockUtil.mc.field_71467_ac = /*EL:320*/4;
        /*SL:321*/return v1 || a5;
    }
    
    public static void placeBlockStopSneaking(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4, final boolean a5) {
        final boolean v1 = placeBlockSmartRotate(/*EL:325*/a1, a2, a3, a4, a5);
        /*SL:326*/if (!a5 && v1) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:327*/(Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
    }
    
    public static Vec3d[] getHelpingBlocks(final Vec3d a1) {
        /*SL:332*/return new Vec3d[] { new Vec3d(a1.field_72450_a, a1.field_72448_b - 1.0, a1.field_72449_c), new Vec3d((a1.field_72450_a != 0.0) ? (a1.field_72450_a * 2.0) : a1.field_72450_a, a1.field_72448_b, (a1.field_72450_a != 0.0) ? a1.field_72449_c : (a1.field_72449_c * 2.0)), new Vec3d((a1.field_72450_a == 0.0) ? (a1.field_72450_a + 1.0) : a1.field_72450_a, a1.field_72448_b, (a1.field_72450_a == 0.0) ? a1.field_72449_c : (a1.field_72449_c + 1.0)), new Vec3d((a1.field_72450_a == 0.0) ? (a1.field_72450_a - 1.0) : a1.field_72450_a, a1.field_72448_b, (a1.field_72450_a == 0.0) ? a1.field_72449_c : (a1.field_72449_c - 1.0)), new Vec3d(a1.field_72450_a, a1.field_72448_b + 1.0, a1.field_72449_c) };
    }
    
    public static List<BlockPos> possiblePlacePositions(final float a1) {
        final NonNullList v1 = /*EL:336*/NonNullList.func_191196_a();
        /*SL:337*/v1.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)BlockUtil.mc.field_71439_g), a1, (int)a1, false, true, 0).stream().filter((Predicate<? super Object>)BlockUtil::canPlaceCrystal).<List<? super Object>, ?>collect((Collector<? super Object, ?, List<? super Object>>)Collectors.<Object>toList()));
        /*SL:338*/return (List<BlockPos>)v1;
    }
    
    public static List<BlockPos> getSphere(final BlockPos v1, final float v2, final int v3, final boolean v4, final boolean v5, final int v6) {
        final ArrayList<BlockPos> v7 = /*EL:342*/new ArrayList<BlockPos>();
        final int v8 = /*EL:343*/v1.func_177958_n();
        final int v9 = /*EL:344*/v1.func_177956_o();
        final int v10 = /*EL:345*/v1.func_177952_p();
        /*SL:347*/for (int v11 = v8 - (int)v2; v11 <= v8 + v2; /*SL:364*/++v11) {
            for (BlockPos a6 = (BlockPos)(v10 - (int)v2); a6 <= v10 + v2; ++a6) {
                int a2 = v5 ? (v9 - (int)v2) : v9;
                while (true) {
                    final float a3 = a2;
                    final float a4 = v5 ? (v9 + v2) : (v9 + v3);
                    if (a3 >= a4) {
                        break;
                    }
                    final double a5 = (v8 - v11) * (v8 - v11) + (v10 - a6) * (v10 - a6) + (v5 ? ((v9 - a2) * (v9 - a2)) : 0);
                    if (a5 < v2 * v2 && (!v4 || a5 >= (v2 - 1.0f) * (v2 - 1.0f))) {
                        a6 = new BlockPos(v11, a2 + v6, a6);
                        v7.add(a6);
                    }
                    ++a2;
                }
            }
        }
        /*SL:366*/return v7;
    }
    
    public static boolean canPlaceCrystal(final BlockPos v1) {
        final BlockPos v2 = /*EL:370*/v1.func_177982_a(0, 1, 0);
        final BlockPos v3 = /*EL:371*/v1.func_177982_a(0, 2, 0);
        try {
            /*SL:373*/return (BlockUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() == Blocks.field_150357_h || BlockUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() == Blocks.field_150343_Z) && BlockUtil.mc.field_71441_e.func_180495_p(v2).func_177230_c() == Blocks.field_150350_a && BlockUtil.mc.field_71441_e.func_180495_p(v3).func_177230_c() == Blocks.field_150350_a && BlockUtil.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(v2)).isEmpty() && BlockUtil.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(v3)).isEmpty();
        }
        catch (Exception a1) {
            /*SL:375*/return false;
        }
    }
    
    public static List<BlockPos> possiblePlacePositions(final float a1, final boolean a2, final boolean a3) {
        final NonNullList v1 = /*EL:380*/NonNullList.func_191196_a();
        /*SL:381*/v1.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)BlockUtil.mc.field_71439_g), a1, (int)a1, false, true, 0).stream().filter(a3 -> canPlaceCrystal(a3, a2, a3)).<List<? super Object>, ?>collect((Collector<? super Object, ?, List<? super Object>>)Collectors.<Object>toList()));
        /*SL:382*/return (List<BlockPos>)v1;
    }
    
    public static boolean canPlaceCrystal(final BlockPos v1, final boolean v2, final boolean v3) {
        final BlockPos v4 = /*EL:386*/v1.func_177982_a(0, 1, 0);
        final BlockPos v5 = /*EL:387*/v1.func_177982_a(0, 2, 0);
        try {
            /*SL:389*/if (BlockUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() != Blocks.field_150357_h && BlockUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() != Blocks.field_150343_Z) {
                /*SL:390*/return false;
            }
            /*SL:392*/if ((!v3 && BlockUtil.mc.field_71441_e.func_180495_p(v5).func_177230_c() != Blocks.field_150350_a) || BlockUtil.mc.field_71441_e.func_180495_p(v4).func_177230_c() != Blocks.field_150350_a) {
                /*SL:393*/return false;
            }
            /*SL:395*/for (final Entity a1 : BlockUtil.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(v4))) {
                /*SL:396*/if (!a1.field_70128_L) {
                    if (v2 && a1 instanceof EntityEnderCrystal) {
                        continue;
                    }
                    /*SL:397*/return false;
                }
            }
            /*SL:399*/if (!v3) {
                /*SL:400*/for (final Entity a2 : BlockUtil.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(v5))) {
                    /*SL:401*/if (!a2.field_70128_L) {
                        if (v2 && a2 instanceof EntityEnderCrystal) {
                            continue;
                        }
                        /*SL:402*/return false;
                    }
                }
            }
        }
        catch (Exception a3) {
            /*SL:406*/return false;
        }
        /*SL:408*/return true;
    }
    
    public static boolean canBeClicked(final BlockPos a1) {
        /*SL:412*/return getBlock(a1).func_176209_a(getState(a1), false);
    }
    
    private static Block getBlock(final BlockPos a1) {
        /*SL:416*/return getState(a1).func_177230_c();
    }
    
    private static IBlockState getState(final BlockPos a1) {
        /*SL:420*/return BlockUtil.mc.field_71441_e.func_180495_p(a1);
    }
    
    public static boolean isBlockAboveEntitySolid(final Entity v1) {
        /*SL:424*/if (v1 != null) {
            final BlockPos a1 = /*EL:425*/new BlockPos(v1.field_70165_t, v1.field_70163_u + 2.0, v1.field_70161_v);
            /*SL:426*/return isBlockSolid(a1);
        }
        /*SL:428*/return false;
    }
    
    public static void debugPos(final String a1, final BlockPos a2) {
        /*SL:432*/Command.sendMessage(a1 + a2.func_177958_n() + "x, " + a2.func_177956_o() + "y, " + a2.func_177952_p() + "z");
    }
    
    public static void placeCrystalOnBlock(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4) {
        final RayTraceResult v1 = BlockUtil.mc.field_71441_e.func_72933_a(/*EL:436*/new Vec3d(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u + BlockUtil.mc.field_71439_g.func_70047_e(), BlockUtil.mc.field_71439_g.field_70161_v), new Vec3d(a1.func_177958_n() + 0.5, a1.func_177956_o() - 0.5, a1.func_177952_p() + 0.5));
        final EnumFacing v2 = /*EL:437*/(v1 == null || v1.field_178784_b == null) ? EnumFacing.UP : v1.field_178784_b;
        BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:438*/(Packet)new CPacketPlayerTryUseItemOnBlock(a1, v2, a2, 0.0f, 0.0f, 0.0f));
        /*SL:439*/if (a3) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:440*/(Packet)new CPacketAnimation(a4 ? a2 : EnumHand.MAIN_HAND));
        }
    }
    
    public static BlockPos[] toBlockPos(final Vec3d[] v1) {
        final BlockPos[] v2 = /*EL:446*/new BlockPos[v1.length];
        /*SL:447*/for (int a1 = 0; a1 < v1.length; ++a1) {
            /*SL:448*/v2[a1] = new BlockPos(v1[a1]);
        }
        /*SL:450*/return v2;
    }
    
    public static Vec3d posToVec3d(final BlockPos a1) {
        /*SL:454*/return new Vec3d((Vec3i)a1);
    }
    
    public static BlockPos vec3dToPos(final Vec3d a1) {
        /*SL:458*/return new BlockPos(a1);
    }
    
    public static Boolean isPosInFov(final BlockPos a1) {
        final int v1 = /*EL:462*/RotationUtil.getDirection4D();
        /*SL:463*/if (v1 == 0 && a1.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c < 0.0) {
            /*SL:464*/return false;
        }
        /*SL:466*/if (v1 == 1 && a1.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a > 0.0) {
            /*SL:467*/return false;
        }
        /*SL:469*/if (v1 == 2 && a1.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c > 0.0) {
            /*SL:470*/return false;
        }
        /*SL:472*/return v1 != 3 || a1.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a >= 0.0;
    }
    
    public static boolean isBlockBelowEntitySolid(final Entity v1) {
        /*SL:476*/if (v1 != null) {
            final BlockPos a1 = /*EL:477*/new BlockPos(v1.field_70165_t, v1.field_70163_u - 1.0, v1.field_70161_v);
            /*SL:478*/return isBlockSolid(a1);
        }
        /*SL:480*/return false;
    }
    
    public static boolean isBlockSolid(final BlockPos a1) {
        /*SL:484*/return !isBlockUnSolid(a1);
    }
    
    public static boolean isBlockUnSolid(final BlockPos a1) {
        /*SL:488*/return isBlockUnSolid(BlockUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c());
    }
    
    public static boolean isBlockUnSolid(final Block a1) {
        /*SL:492*/return BlockUtil.unSolidBlocks.contains(a1);
    }
    
    public static boolean isBlockUnSafe(final Block a1) {
        /*SL:496*/return BlockUtil.unSafeBlocks.contains(a1);
    }
    
    public static Vec3d[] convertVec3ds(final Vec3d a2, final Vec3d[] v1) {
        final Vec3d[] v2 = /*EL:500*/new Vec3d[v1.length];
        /*SL:501*/for (int a3 = 0; a3 < v1.length; ++a3) {
            /*SL:502*/v2[a3] = a2.func_178787_e(v1[a3]);
        }
        /*SL:504*/return v2;
    }
    
    public static Vec3d[] convertVec3ds(final EntityPlayer a1, final Vec3d[] a2) {
        /*SL:508*/return convertVec3ds(a1.func_174791_d(), a2);
    }
    
    public static boolean canBreak(final BlockPos a1) {
        final IBlockState v1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:512*/a1);
        final Block v2 = /*EL:513*/v1.func_177230_c();
        /*SL:514*/return v2.func_176195_g(v1, (World)BlockUtil.mc.field_71441_e, a1) != -1.0f;
    }
    
    public static boolean isValidBlock(final BlockPos a1) {
        final Block v1 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:518*/a1).func_177230_c();
        /*SL:519*/return !(v1 instanceof BlockLiquid) && v1.func_149688_o((IBlockState)null) != Material.field_151579_a;
    }
    
    public static boolean isScaffoldPos(final BlockPos a1) {
        /*SL:523*/return BlockUtil.mc.field_71441_e.func_175623_d(a1) || BlockUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() == Blocks.field_150431_aC || BlockUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() == Blocks.field_150329_H || BlockUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() instanceof BlockLiquid;
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos a1, final boolean a2, final float a3) {
        /*SL:527*/return !a2 || BlockUtil.mc.field_71441_e.func_147447_a(new Vec3d(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u + BlockUtil.mc.field_71439_g.func_70047_e(), BlockUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)a1.func_177958_n(), (double)(a1.func_177956_o() + a3), (double)a1.func_177952_p()), false, true, false) == null;
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos a1, final boolean a2) {
        /*SL:531*/return rayTracePlaceCheck(a1, a2, 1.0f);
    }
    
    public static List<BlockPos> getSphere(final float v-6) {
        final List<BlockPos> list = /*EL:535*/new ArrayList<BlockPos>();
        final BlockPos blockPos = /*EL:536*/new BlockPos(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u, BlockUtil.mc.field_71439_g.field_70161_v);
        final int func_177958_n = /*EL:537*/blockPos.func_177958_n();
        final int func_177956_o = /*EL:538*/blockPos.func_177956_o();
        final int func_177952_p = /*EL:539*/blockPos.func_177952_p();
        /*SL:540*/for (int v0 = func_177958_n - (int)v-6; v0 <= func_177958_n + v-6; ++v0) {
            /*SL:541*/for (int v = func_177952_p - (int)v-6; v <= func_177952_p + v-6; ++v) {
                /*SL:542*/for (int a1 = func_177956_o - (int)v-6; a1 < func_177956_o + v-6; ++a1) {
                    /*SL:543*/if ((func_177958_n - v0) * (func_177958_n - v0) + (func_177952_p - v) * (func_177952_p - v) + (func_177956_o - a1) * (func_177956_o - a1) < v-6 * v-6) {
                        /*SL:544*/list.add(new BlockPos(v0, a1, v));
                    }
                }
            }
        }
        /*SL:549*/return list;
    }
    
    public static List<BlockPos> getSphereRealth(final float v-8, final boolean v-7) {
        final List<BlockPos> list = /*EL:553*/new ArrayList<BlockPos>();
        final BlockPos blockPos = /*EL:554*/new BlockPos(BlockUtil.mc.field_71439_g.func_174791_d());
        final int func_177958_n = /*EL:555*/blockPos.func_177958_n();
        final int func_177956_o = /*EL:556*/blockPos.func_177956_o();
        final int func_177952_p = /*EL:557*/blockPos.func_177952_p();
        final int n = /*EL:558*/(int)v-8;
        /*SL:559*/for (int v0 = func_177958_n - n; v0 <= func_177958_n + v-8; ++v0) {
            /*SL:560*/for (int v = func_177952_p - n; v <= func_177952_p + v-8; ++v) {
                /*SL:561*/for (BlockPos a2 = (BlockPos)(func_177956_o - n); a2 < func_177956_o + v-8; ++a2) {
                    /*SL:562*/if ((func_177958_n - v0) * (func_177958_n - v0) + (func_177952_p - v) * (func_177952_p - v) + (func_177956_o - a2) * (func_177956_o - a2) < v-8 * v-8) {
                        /*SL:563*/a2 = new BlockPos(v0, a2, v);
                        /*SL:564*/if (!v-7 || BlockUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c() != Blocks.field_150350_a) {
                            /*SL:565*/list.add(a2);
                        }
                    }
                }
            }
        }
        /*SL:571*/return list;
    }
    
    public static List<Vec3d> getOffsetList(final int a1, final boolean a2) {
        final List<Vec3d> v1 = /*EL:575*/new ArrayList<Vec3d>(5);
        /*SL:576*/v1.add(new Vec3d(-1.0, (double)a1, 0.0));
        /*SL:577*/v1.add(new Vec3d(1.0, (double)a1, 0.0));
        /*SL:578*/v1.add(new Vec3d(0.0, (double)a1, -1.0));
        /*SL:579*/v1.add(new Vec3d(0.0, (double)a1, 1.0));
        /*SL:581*/if (a2) {
            /*SL:582*/v1.add(new Vec3d(0.0, (double)(a1 - 1), 0.0));
        }
        /*SL:585*/return v1;
    }
    
    public static Vec3d[] getOffsets(final int a1, final boolean a2) {
        final List<Vec3d> v1 = getOffsetList(/*EL:589*/a1, a2);
        final Vec3d[] v2 = /*EL:590*/new Vec3d[v1.size()];
        /*SL:591*/return v1.<Vec3d>toArray(v2);
    }
    
    public static boolean isSafe(final Entity a1, final int a2, final boolean a3) {
        /*SL:595*/return getUnsafeBlocks(a1, a2, a3).size() == 0;
    }
    
    public static List<Vec3d> getUnsafeBlocks(final Entity a1, final int a2, final boolean a3) {
        /*SL:599*/return getUnsafeBlocksFromVec3d(a1.func_174791_d(), a2, a3);
    }
    
    public static List<Vec3d> getUnsafeBlocksFromVec3d(final Vec3d a3, final int v1, final boolean v2) {
        final List<Vec3d> v3 = /*EL:603*/new ArrayList<Vec3d>(5);
        /*SL:604*/for (final Vec3d a4 : getOffsets(v1, v2)) {
            final Block a5 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:605*/new BlockPos(a3).func_177963_a(a4.field_72450_a, a4.field_72448_b, a4.field_72449_c)).func_177230_c();
            /*SL:606*/if (a5 instanceof BlockAir || a5 instanceof BlockLiquid || a5 instanceof BlockTallGrass || a5 instanceof BlockFire || a5 instanceof BlockDeadBush || a5 instanceof BlockSnow) {
                /*SL:607*/v3.add(a4);
            }
        }
        /*SL:610*/return v3;
    }
    
    public static Vec3d[] getUnsafeBlockArray(final Entity a1, final int a2, final boolean a3) {
        final List<Vec3d> v1 = getUnsafeBlocks(/*EL:614*/a1, a2, a3);
        final Vec3d[] v2 = /*EL:615*/new Vec3d[v1.size()];
        /*SL:616*/return v1.<Vec3d>toArray(v2);
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos a1) {
        /*SL:620*/return rayTracePlaceCheck(a1, true);
    }
    
    public static void placeCrystalOnBlock(final BlockPos a1, final EnumHand a2, final boolean a3) {
        final RayTraceResult v1 = BlockUtil.mc.field_71441_e.func_72933_a(/*EL:624*/new Vec3d(BlockUtil.mc.field_71439_g.field_70165_t, BlockUtil.mc.field_71439_g.field_70163_u + BlockUtil.mc.field_71439_g.func_70047_e(), BlockUtil.mc.field_71439_g.field_70161_v), new Vec3d(a1.func_177958_n() + 0.5, a1.func_177956_o() - 0.5, a1.func_177952_p() + 0.5));
        final EnumFacing v2 = /*EL:625*/(v1 == null || v1.field_178784_b == null) ? EnumFacing.UP : v1.field_178784_b;
        BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:626*/(Packet)new CPacketPlayerTryUseItemOnBlock(a1, v2, a2, 0.0f, 0.0f, 0.0f));
        /*SL:627*/if (a3) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:628*/(Packet)new CPacketAnimation(a2));
        }
    }
    
    public static void placeBlock(final BlockPos v-4) {
        /*SL:633*/for (final EnumFacing v0 : EnumFacing.field_82609_l) {
            final BlockPos v = /*EL:634*/v-4.func_177972_a(v0);
            final IBlockState v2 = BlockUtil.mc.field_71441_e.func_180495_p(/*EL:635*/v);
            /*SL:636*/if (v2.func_177230_c().func_176209_a(v2, false)) {
                final boolean a1 = /*EL:637*/!PlayerUtil.isShifting() && v2.func_177230_c().func_180639_a((World)BlockUtil.mc.field_71441_e, v-4, BlockUtil.mc.field_71441_e.func_180495_p(v-4), (EntityPlayer)BlockUtil.mc.field_71439_g, EnumHand.MAIN_HAND, v0, 0.5f, 0.5f, 0.5f);
                /*SL:638*/if (a1) {
                    BlockUtil.mc.func_147114_u().func_147297_a(/*EL:639*/(Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                }
                BlockUtil.mc.func_147114_u().func_147297_a(/*EL:641*/(Packet)new CPacketPlayerTryUseItemOnBlock(v, v0.func_176734_d(), EnumHand.MAIN_HAND, 0.5f, 0.5f, 0.5f));
                BlockUtil.mc.func_147114_u().func_147297_a(/*EL:642*/(Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
                /*SL:643*/if (a1) {
                    BlockUtil.mc.func_147114_u().func_147297_a(/*EL:644*/(Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                }
            }
        }
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        unSafeBlocks = Arrays.<Block>asList(Blocks.field_150343_Z, Blocks.field_150357_h, Blocks.field_150477_bB, Blocks.field_150467_bQ);
        BlockUtil.unSolidBlocks = Arrays.<Block>asList(Blocks.field_150356_k, Blocks.field_150457_bL, Blocks.field_150433_aE, Blocks.field_150404_cg, Blocks.field_185764_cQ, Blocks.field_150465_bP, Blocks.field_150457_bL, Blocks.field_150473_bD, Blocks.field_150479_bC, Blocks.field_150471_bO, Blocks.field_150442_at, Blocks.field_150430_aB, Blocks.field_150468_ap, Blocks.field_150441_bU, Blocks.field_150455_bV, Blocks.field_150413_aR, Blocks.field_150416_aS, Blocks.field_150437_az, Blocks.field_150429_aA, Blocks.field_150488_af, Blocks.field_150350_a, Blocks.field_150427_aO, Blocks.field_150384_bq, Blocks.field_150355_j, Blocks.field_150358_i, Blocks.field_150353_l, Blocks.field_150356_k, Blocks.field_150345_g, Blocks.field_150328_O, Blocks.field_150327_N, Blocks.field_150338_P, Blocks.field_150337_Q, Blocks.field_150464_aj, Blocks.field_150459_bM, Blocks.field_150469_bN, Blocks.field_185773_cZ, Blocks.field_150436_aH, Blocks.field_150393_bb, Blocks.field_150394_bc, Blocks.field_150392_bi, Blocks.field_150388_bm, Blocks.field_150375_by, Blocks.field_185766_cS, Blocks.field_185765_cR, Blocks.field_150329_H, Blocks.field_150330_I, Blocks.field_150395_bd, Blocks.field_150480_ab, Blocks.field_150448_aq, Blocks.field_150408_cc, Blocks.field_150319_E, Blocks.field_150318_D, Blocks.field_150478_aa);
        BlockUtil.emptyBlocks = Arrays.<Block>asList(Blocks.field_150350_a, Blocks.field_150356_k, Blocks.field_150353_l, Blocks.field_150358_i, Blocks.field_150355_j, Blocks.field_150395_bd, Blocks.field_150431_aC, Blocks.field_150329_H, Blocks.field_150480_ab);
    }
}
