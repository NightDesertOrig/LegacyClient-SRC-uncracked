package me.dev.legacy.api.util;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.EXTFramebufferObject;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.glu.GLU;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.util.math.Vec2f;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import org.lwjgl.util.glu.Disk;
import org.lwjgl.util.glu.Sphere;
import net.minecraft.world.IBlockAccess;
import me.dev.legacy.Legacy;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.RenderGlobal;
import java.util.Objects;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import java.awt.Color;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.BufferBuilder;
import java.nio.IntBuffer;
import java.nio.FloatBuffer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.RenderItem;

public class RenderUtil implements Util
{
    public static RenderItem itemRender;
    public static ICamera camera;
    private static final Frustum frustrum;
    private static boolean depth;
    private static boolean texture;
    private static boolean clean;
    private static boolean bind;
    private static boolean override;
    private static final FloatBuffer screenCoords;
    private static final IntBuffer viewport;
    private static final FloatBuffer modelView;
    private static final FloatBuffer projection;
    private static final BufferBuilder bufferbuilder;
    private static final Tessellator tessellator;
    
    public static void updateModelViewProjectionMatrix() {
        /*SL:64*/GL11.glGetFloat(2982, RenderUtil.modelView);
        /*SL:65*/GL11.glGetFloat(2983, RenderUtil.projection);
        /*SL:66*/GL11.glGetInteger(2978, RenderUtil.viewport);
        final ScaledResolution v1 = /*EL:67*/new ScaledResolution(Minecraft.func_71410_x());
    }
    
    public static void drawSidewaysGradientRect(final int a1, final int a2, final int a3, final int a4, final int a5, final int a6) {
        final float v1 = /*EL:70*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:71*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:72*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:73*/(a5 & 0xFF) / 255.0f;
        final float v5 = /*EL:74*/(a6 >> 24 & 0xFF) / 255.0f;
        final float v6 = /*EL:75*/(a6 >> 16 & 0xFF) / 255.0f;
        final float v7 = /*EL:76*/(a6 >> 8 & 0xFF) / 255.0f;
        final float v8 = /*EL:77*/(a6 & 0xFF) / 255.0f;
        /*SL:78*/GlStateManager.func_179090_x();
        /*SL:79*/GlStateManager.func_179147_l();
        /*SL:80*/GlStateManager.func_179118_c();
        /*SL:81*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        /*SL:82*/GlStateManager.func_179103_j(7425);
        final Tessellator v9 = /*EL:83*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:84*/v9.func_178180_c();
        /*SL:85*/v10.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:86*/v10.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:87*/v10.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:88*/v10.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:89*/v10.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:90*/v9.func_78381_a();
        /*SL:91*/GlStateManager.func_179103_j(7424);
        /*SL:92*/GlStateManager.func_179084_k();
        /*SL:93*/GlStateManager.func_179141_d();
        /*SL:94*/GlStateManager.func_179098_w();
    }
    
    public static void drawHLineG(final int a1, final int a2, final int a3, final int a4, final int a5) {
        drawSidewaysGradientRect(/*EL:97*/a1, a2, a1 + a3, a2 + 1, a4, a5);
    }
    
    public static void drawGradientSideways(final double a1, final double a2, final double a3, final double a4, final int a5, final int a6) {
        final float v1 = /*EL:101*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:102*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:103*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:104*/(a5 & 0xFF) / 255.0f;
        final float v5 = /*EL:105*/(a6 >> 24 & 0xFF) / 255.0f;
        final float v6 = /*EL:106*/(a6 >> 16 & 0xFF) / 255.0f;
        final float v7 = /*EL:107*/(a6 >> 8 & 0xFF) / 255.0f;
        final float v8 = /*EL:108*/(a6 & 0xFF) / 255.0f;
        /*SL:109*/GL11.glEnable(3042);
        /*SL:110*/GL11.glDisable(3553);
        /*SL:111*/GL11.glBlendFunc(770, 771);
        /*SL:112*/GL11.glEnable(2848);
        /*SL:113*/GL11.glShadeModel(7425);
        /*SL:114*/GL11.glPushMatrix();
        /*SL:115*/GL11.glBegin(7);
        /*SL:116*/GL11.glColor4f(v2, v3, v4, v1);
        /*SL:117*/GL11.glVertex2d(a1, a2);
        /*SL:118*/GL11.glVertex2d(a1, a4);
        /*SL:119*/GL11.glColor4f(v6, v7, v8, v5);
        /*SL:120*/GL11.glVertex2d(a3, a4);
        /*SL:121*/GL11.glVertex2d(a3, a2);
        /*SL:122*/GL11.glEnd();
        /*SL:123*/GL11.glPopMatrix();
        /*SL:124*/GL11.glEnable(3553);
        /*SL:125*/GL11.glDisable(3042);
        /*SL:126*/GL11.glDisable(2848);
        /*SL:127*/GL11.glShadeModel(7424);
    }
    
    public static void drawTriangleOutline(final float a1, final float a2, final float a3, final float a4, final float a5, final float a6, final int a7) {
        final boolean v1 = /*EL:130*/GL11.glIsEnabled(3042);
        /*SL:131*/GL11.glEnable(3042);
        /*SL:132*/GL11.glDisable(3553);
        /*SL:133*/GL11.glBlendFunc(770, 771);
        /*SL:134*/GL11.glEnable(2848);
        /*SL:135*/GL11.glPushMatrix();
        /*SL:136*/GL11.glLineWidth(a6);
        hexColor(/*EL:137*/a7);
        /*SL:138*/GL11.glBegin(2);
        /*SL:139*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:140*/GL11.glVertex2d((double)(a1 - a3 / a4), (double)(a2 - a3));
        /*SL:141*/GL11.glVertex2d((double)a1, (double)(a2 - a3 / a5));
        /*SL:142*/GL11.glVertex2d((double)(a1 + a3 / a4), (double)(a2 - a3));
        /*SL:143*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:144*/GL11.glEnd();
        /*SL:145*/GL11.glPopMatrix();
        /*SL:146*/GL11.glEnable(3553);
        /*SL:147*/if (!v1) {
            /*SL:148*/GL11.glDisable(3042);
        }
        /*SL:150*/GL11.glDisable(2848);
    }
    
    public static void drawRectangleCorrectly(final int a1, final int a2, final int a3, final int a4, final int a5) {
        /*SL:154*/GL11.glLineWidth(1.0f);
        /*SL:155*/Gui.func_73734_a(a1, a2, a1 + a3, a2 + a4, a5);
    }
    
    public static AxisAlignedBB interpolateAxis(final AxisAlignedBB a1) {
        /*SL:159*/return new AxisAlignedBB(a1.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, a1.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, a1.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, a1.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, a1.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, a1.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
    }
    
    public static void drawTexturedRect(final int a1, final int a2, final int a3, final int a4, final int a5, final int a6, final int a7) {
        final Tessellator v1 = /*EL:163*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:164*/v1.func_178180_c();
        /*SL:165*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:166*/v2.func_181662_b((double)(a1 + 0), (double)(a2 + a6), (double)a7).func_187315_a((double)((a3 + 0) * 0.00390625f), (double)((a4 + a6) * 0.00390625f)).func_181675_d();
        /*SL:167*/v2.func_181662_b((double)(a1 + a5), (double)(a2 + a6), (double)a7).func_187315_a((double)((a3 + a5) * 0.00390625f), (double)((a4 + a6) * 0.00390625f)).func_181675_d();
        /*SL:168*/v2.func_181662_b((double)(a1 + a5), (double)(a2 + 0), (double)a7).func_187315_a((double)((a3 + a5) * 0.00390625f), (double)((a4 + 0) * 0.00390625f)).func_181675_d();
        /*SL:169*/v2.func_181662_b((double)(a1 + 0), (double)(a2 + 0), (double)a7).func_187315_a((double)((a3 + 0) * 0.00390625f), (double)((a4 + 0) * 0.00390625f)).func_181675_d();
        /*SL:170*/v1.func_78381_a();
    }
    
    public static void drawOpenGradientBox(final BlockPos a2, final Color a3, final Color a4, final double v1) {
        /*SL:174*/for (final EnumFacing a5 : EnumFacing.values()) {
            /*SL:175*/if (a5 != EnumFacing.UP) {
                drawGradientPlane(/*EL:176*/a2, a5, a3, a4, v1);
            }
        }
    }
    
    public static void drawClosedGradientBox(final BlockPos a2, final Color a3, final Color a4, final double v1) {
        /*SL:182*/for (final EnumFacing a5 : EnumFacing.values()) {
            drawGradientPlane(/*EL:183*/a2, a5, a3, a4, v1);
        }
    }
    
    public static void drawTricolorGradientBox(final BlockPos a3, final Color a4, final Color v1, final Color v2) {
        /*SL:188*/for (final EnumFacing a5 : EnumFacing.values()) {
            /*SL:189*/if (a5 != EnumFacing.UP) {
                drawGradientPlane(/*EL:190*/a3, a5, a4, v1, true, false);
            }
        }
        /*SL:193*/for (final EnumFacing a6 : EnumFacing.values()) {
            /*SL:194*/if (a6 != EnumFacing.DOWN) {
                drawGradientPlane(/*EL:195*/a3, a6, v1, v2, true, true);
            }
        }
    }
    
    public static void drawGradientPlane(final BlockPos a1, final EnumFacing a2, final Color a3, final Color a4, final boolean a5, final boolean a6) {
        final Tessellator v1 = /*EL:201*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:202*/v1.func_178180_c();
        final IBlockState v3 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:203*/a1);
        final Vec3d v4 = /*EL:204*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        final AxisAlignedBB v5 = /*EL:205*/v3.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v4.field_72450_a, -v4.field_72448_b, -v4.field_72449_c);
        final float v6 = /*EL:206*/a3.getRed() / 255.0f;
        final float v7 = /*EL:207*/a3.getGreen() / 255.0f;
        final float v8 = /*EL:208*/a3.getBlue() / 255.0f;
        final float v9 = /*EL:209*/a3.getAlpha() / 255.0f;
        final float v10 = /*EL:210*/a4.getRed() / 255.0f;
        final float v11 = /*EL:211*/a4.getGreen() / 255.0f;
        final float v12 = /*EL:212*/a4.getBlue() / 255.0f;
        final float v13 = /*EL:213*/a4.getAlpha() / 255.0f;
        double v14 = /*EL:214*/0.0;
        double v15 = /*EL:215*/0.0;
        double v16 = /*EL:216*/0.0;
        double v17 = /*EL:217*/0.0;
        double v18 = /*EL:218*/0.0;
        double v19 = /*EL:219*/0.0;
        /*SL:220*/if (a2 == EnumFacing.DOWN) {
            /*SL:221*/v14 = v5.field_72340_a;
            /*SL:222*/v17 = v5.field_72336_d;
            /*SL:223*/v15 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:224*/v18 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:225*/v16 = v5.field_72339_c;
            /*SL:226*/v19 = v5.field_72334_f;
        }
        else/*SL:228*/ if (a2 == EnumFacing.UP) {
            /*SL:229*/v14 = v5.field_72340_a;
            /*SL:230*/v17 = v5.field_72336_d;
            /*SL:231*/v15 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:232*/v18 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:233*/v16 = v5.field_72339_c;
            /*SL:234*/v19 = v5.field_72334_f;
        }
        else/*SL:236*/ if (a2 == EnumFacing.EAST) {
            /*SL:237*/v14 = v5.field_72336_d;
            /*SL:238*/v17 = v5.field_72336_d;
            /*SL:239*/v15 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:240*/v18 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:241*/v16 = v5.field_72339_c;
            /*SL:242*/v19 = v5.field_72334_f;
        }
        else/*SL:244*/ if (a2 == EnumFacing.WEST) {
            /*SL:245*/v14 = v5.field_72340_a;
            /*SL:246*/v17 = v5.field_72340_a;
            /*SL:247*/v15 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:248*/v18 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:249*/v16 = v5.field_72339_c;
            /*SL:250*/v19 = v5.field_72334_f;
        }
        else/*SL:252*/ if (a2 == EnumFacing.SOUTH) {
            /*SL:253*/v14 = v5.field_72340_a;
            /*SL:254*/v17 = v5.field_72336_d;
            /*SL:255*/v15 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:256*/v18 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:257*/v16 = v5.field_72334_f;
            /*SL:258*/v19 = v5.field_72334_f;
        }
        else/*SL:260*/ if (a2 == EnumFacing.NORTH) {
            /*SL:261*/v14 = v5.field_72340_a;
            /*SL:262*/v17 = v5.field_72336_d;
            /*SL:263*/v15 = v5.field_72338_b + (a6 ? 0.5 : 0.0);
            /*SL:264*/v18 = v5.field_72337_e / (a5 ? 2 : 1);
            /*SL:265*/v16 = v5.field_72339_c;
            /*SL:266*/v19 = v5.field_72339_c;
        }
        /*SL:268*/GlStateManager.func_179094_E();
        /*SL:269*/GlStateManager.func_179097_i();
        /*SL:270*/GlStateManager.func_179090_x();
        /*SL:271*/GlStateManager.func_179147_l();
        /*SL:272*/GlStateManager.func_179118_c();
        /*SL:273*/GlStateManager.func_179132_a(false);
        /*SL:274*/v2.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        /*SL:275*/if (a2 == EnumFacing.EAST || a2 == EnumFacing.WEST || a2 == EnumFacing.NORTH || a2 == EnumFacing.SOUTH) {
            /*SL:276*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:277*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:278*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:279*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:280*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:281*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:282*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:283*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:284*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:285*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:286*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:287*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:288*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:289*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:290*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:291*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:292*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:293*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:294*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:295*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:296*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:297*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:298*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:299*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:300*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:301*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:302*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:303*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:304*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:305*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
        }
        else/*SL:307*/ if (a2 == EnumFacing.UP) {
            /*SL:308*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:309*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:310*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:311*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:312*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:313*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:314*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:315*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:316*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:317*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:318*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:319*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:320*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:321*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:322*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:323*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:324*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:325*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:326*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:327*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:328*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:329*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:330*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:331*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:332*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:333*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:334*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:335*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:336*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:337*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
        }
        else/*SL:339*/ if (a2 == EnumFacing.DOWN) {
            /*SL:340*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:341*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:342*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:343*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:344*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:345*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:346*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:347*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:348*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:349*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:350*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:351*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:352*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:353*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:354*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:355*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:356*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:357*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:358*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:359*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:360*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:361*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:362*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:363*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:364*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:365*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:366*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:367*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:368*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:369*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
        }
        /*SL:371*/v1.func_78381_a();
        /*SL:372*/GlStateManager.func_179132_a(true);
        /*SL:373*/GlStateManager.func_179084_k();
        /*SL:374*/GlStateManager.func_179141_d();
        /*SL:375*/GlStateManager.func_179098_w();
        /*SL:376*/GlStateManager.func_179126_j();
        /*SL:377*/GlStateManager.func_179121_F();
    }
    
    public static void drawGradientPlane(final BlockPos a1, final EnumFacing a2, final Color a3, final Color a4, final double a5) {
        final Tessellator v1 = /*EL:381*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:382*/v1.func_178180_c();
        final IBlockState v3 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:383*/a1);
        final Vec3d v4 = /*EL:384*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        final AxisAlignedBB v5 = /*EL:385*/v3.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v4.field_72450_a, -v4.field_72448_b, -v4.field_72449_c).func_72321_a(0.0, a5, 0.0);
        final float v6 = /*EL:386*/a3.getRed() / 255.0f;
        final float v7 = /*EL:387*/a3.getGreen() / 255.0f;
        final float v8 = /*EL:388*/a3.getBlue() / 255.0f;
        final float v9 = /*EL:389*/a3.getAlpha() / 255.0f;
        final float v10 = /*EL:390*/a4.getRed() / 255.0f;
        final float v11 = /*EL:391*/a4.getGreen() / 255.0f;
        final float v12 = /*EL:392*/a4.getBlue() / 255.0f;
        final float v13 = /*EL:393*/a4.getAlpha() / 255.0f;
        double v14 = /*EL:394*/0.0;
        double v15 = /*EL:395*/0.0;
        double v16 = /*EL:396*/0.0;
        double v17 = /*EL:397*/0.0;
        double v18 = /*EL:398*/0.0;
        double v19 = /*EL:399*/0.0;
        /*SL:400*/if (a2 == EnumFacing.DOWN) {
            /*SL:401*/v14 = v5.field_72340_a;
            /*SL:402*/v17 = v5.field_72336_d;
            /*SL:403*/v15 = v5.field_72338_b;
            /*SL:404*/v18 = v5.field_72338_b;
            /*SL:405*/v16 = v5.field_72339_c;
            /*SL:406*/v19 = v5.field_72334_f;
        }
        else/*SL:408*/ if (a2 == EnumFacing.UP) {
            /*SL:409*/v14 = v5.field_72340_a;
            /*SL:410*/v17 = v5.field_72336_d;
            /*SL:411*/v15 = v5.field_72337_e;
            /*SL:412*/v18 = v5.field_72337_e;
            /*SL:413*/v16 = v5.field_72339_c;
            /*SL:414*/v19 = v5.field_72334_f;
        }
        else/*SL:416*/ if (a2 == EnumFacing.EAST) {
            /*SL:417*/v14 = v5.field_72336_d;
            /*SL:418*/v17 = v5.field_72336_d;
            /*SL:419*/v15 = v5.field_72338_b;
            /*SL:420*/v18 = v5.field_72337_e;
            /*SL:421*/v16 = v5.field_72339_c;
            /*SL:422*/v19 = v5.field_72334_f;
        }
        else/*SL:424*/ if (a2 == EnumFacing.WEST) {
            /*SL:425*/v14 = v5.field_72340_a;
            /*SL:426*/v17 = v5.field_72340_a;
            /*SL:427*/v15 = v5.field_72338_b;
            /*SL:428*/v18 = v5.field_72337_e;
            /*SL:429*/v16 = v5.field_72339_c;
            /*SL:430*/v19 = v5.field_72334_f;
        }
        else/*SL:432*/ if (a2 == EnumFacing.SOUTH) {
            /*SL:433*/v14 = v5.field_72340_a;
            /*SL:434*/v17 = v5.field_72336_d;
            /*SL:435*/v15 = v5.field_72338_b;
            /*SL:436*/v18 = v5.field_72337_e;
            /*SL:437*/v16 = v5.field_72334_f;
            /*SL:438*/v19 = v5.field_72334_f;
        }
        else/*SL:440*/ if (a2 == EnumFacing.NORTH) {
            /*SL:441*/v14 = v5.field_72340_a;
            /*SL:442*/v17 = v5.field_72336_d;
            /*SL:443*/v15 = v5.field_72338_b;
            /*SL:444*/v18 = v5.field_72337_e;
            /*SL:445*/v16 = v5.field_72339_c;
            /*SL:446*/v19 = v5.field_72339_c;
        }
        /*SL:448*/GlStateManager.func_179094_E();
        /*SL:449*/GlStateManager.func_179097_i();
        /*SL:450*/GlStateManager.func_179090_x();
        /*SL:451*/GlStateManager.func_179147_l();
        /*SL:452*/GlStateManager.func_179118_c();
        /*SL:453*/GlStateManager.func_179132_a(false);
        /*SL:454*/v2.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        /*SL:455*/if (a2 == EnumFacing.EAST || a2 == EnumFacing.WEST || a2 == EnumFacing.NORTH || a2 == EnumFacing.SOUTH) {
            /*SL:456*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:457*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:458*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:459*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:460*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:461*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:462*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:463*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:464*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:465*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:466*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:467*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:468*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:469*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:470*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:471*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:472*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:473*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:474*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:475*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:476*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:477*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:478*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:479*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:480*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:481*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:482*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:483*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:484*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:485*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
        }
        else/*SL:487*/ if (a2 == EnumFacing.UP) {
            /*SL:488*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:489*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:490*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:491*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:492*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:493*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:494*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:495*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:496*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:497*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:498*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:499*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:500*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:501*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:502*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:503*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:504*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:505*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:506*/v2.func_181662_b(v14, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:507*/v2.func_181662_b(v17, v15, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:508*/v2.func_181662_b(v14, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:509*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:510*/v2.func_181662_b(v17, v15, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:511*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:512*/v2.func_181662_b(v14, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:513*/v2.func_181662_b(v14, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:514*/v2.func_181662_b(v17, v18, v16).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:515*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:516*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
            /*SL:517*/v2.func_181662_b(v17, v18, v19).func_181666_a(v10, v11, v12, v13).func_181675_d();
        }
        else/*SL:519*/ if (a2 == EnumFacing.DOWN) {
            /*SL:520*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:521*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:522*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:523*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:524*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:525*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:526*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:527*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:528*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:529*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:530*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:531*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:532*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:533*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:534*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:535*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:536*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:537*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:538*/v2.func_181662_b(v14, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:539*/v2.func_181662_b(v17, v15, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:540*/v2.func_181662_b(v14, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:541*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:542*/v2.func_181662_b(v17, v15, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:543*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:544*/v2.func_181662_b(v14, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:545*/v2.func_181662_b(v14, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:546*/v2.func_181662_b(v17, v18, v16).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:547*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:548*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
            /*SL:549*/v2.func_181662_b(v17, v18, v19).func_181666_a(v6, v7, v8, v9).func_181675_d();
        }
        /*SL:551*/v1.func_78381_a();
        /*SL:552*/GlStateManager.func_179132_a(true);
        /*SL:553*/GlStateManager.func_179084_k();
        /*SL:554*/GlStateManager.func_179141_d();
        /*SL:555*/GlStateManager.func_179098_w();
        /*SL:556*/GlStateManager.func_179126_j();
        /*SL:557*/GlStateManager.func_179121_F();
    }
    
    public static void drawGradientRect(final int a1, final int a2, final int a3, final int a4, final int a5, final int a6) {
        final float v1 = /*EL:561*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:562*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:563*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:564*/(a5 & 0xFF) / 255.0f;
        final float v5 = /*EL:565*/(a6 >> 24 & 0xFF) / 255.0f;
        final float v6 = /*EL:566*/(a6 >> 16 & 0xFF) / 255.0f;
        final float v7 = /*EL:567*/(a6 >> 8 & 0xFF) / 255.0f;
        final float v8 = /*EL:568*/(a6 & 0xFF) / 255.0f;
        /*SL:569*/GlStateManager.func_179090_x();
        /*SL:570*/GlStateManager.func_179147_l();
        /*SL:571*/GlStateManager.func_179118_c();
        /*SL:572*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        /*SL:573*/GlStateManager.func_179103_j(7425);
        final Tessellator v9 = /*EL:574*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:575*/v9.func_178180_c();
        /*SL:576*/v10.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:577*/v10.func_181662_b(a1 + a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:578*/v10.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:579*/v10.func_181662_b((double)a1, a2 + a4, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:580*/v10.func_181662_b(a1 + a3, a2 + a4, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:581*/v9.func_78381_a();
        /*SL:582*/GlStateManager.func_179103_j(7424);
        /*SL:583*/GlStateManager.func_179084_k();
        /*SL:584*/GlStateManager.func_179141_d();
        /*SL:585*/GlStateManager.func_179098_w();
    }
    
    public static void drawGradientBlockOutline(final BlockPos a1, final Color a2, final Color a3, final float a4, final double a5) {
        final IBlockState v1 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:589*/a1);
        final Vec3d v2 = /*EL:590*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        drawGradientBlockOutline(/*EL:591*/v1.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v2.field_72450_a, -v2.field_72448_b, -v2.field_72449_c).func_72321_a(0.0, a5, 0.0), a2, a3, a4);
    }
    
    public static void drawProperGradientBlockOutline(final BlockPos a1, final Color a2, final Color a3, final Color a4, final float a5) {
        final IBlockState v1 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:595*/a1);
        final Vec3d v2 = /*EL:596*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        drawProperGradientBlockOutline(/*EL:597*/v1.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v2.field_72450_a, -v2.field_72448_b, -v2.field_72449_c), a2, a3, a4, a5);
    }
    
    public static void drawProperGradientBlockOutline(final AxisAlignedBB a1, final Color a2, final Color a3, final Color a4, final float a5) {
        final float v1 = /*EL:601*/a4.getRed() / 255.0f;
        final float v2 = /*EL:602*/a4.getGreen() / 255.0f;
        final float v3 = /*EL:603*/a4.getBlue() / 255.0f;
        final float v4 = /*EL:604*/a4.getAlpha() / 255.0f;
        final float v5 = /*EL:605*/a3.getRed() / 255.0f;
        final float v6 = /*EL:606*/a3.getGreen() / 255.0f;
        final float v7 = /*EL:607*/a3.getBlue() / 255.0f;
        final float v8 = /*EL:608*/a3.getAlpha() / 255.0f;
        final float v9 = /*EL:609*/a2.getRed() / 255.0f;
        final float v10 = /*EL:610*/a2.getGreen() / 255.0f;
        final float v11 = /*EL:611*/a2.getBlue() / 255.0f;
        final float v12 = /*EL:612*/a2.getAlpha() / 255.0f;
        final double v13 = /*EL:613*/(a1.field_72337_e - a1.field_72338_b) / 2.0;
        /*SL:614*/GlStateManager.func_179094_E();
        /*SL:615*/GlStateManager.func_179147_l();
        /*SL:616*/GlStateManager.func_179097_i();
        /*SL:617*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:618*/GlStateManager.func_179090_x();
        /*SL:619*/GlStateManager.func_179132_a(false);
        /*SL:620*/GL11.glEnable(2848);
        /*SL:621*/GL11.glHint(3154, 4354);
        /*SL:622*/GL11.glLineWidth(a5);
        /*SL:623*/GL11.glBegin(1);
        /*SL:624*/GL11.glColor4d((double)v1, (double)v2, (double)v3, (double)v4);
        /*SL:625*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:626*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:627*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:628*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:629*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:630*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:631*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:632*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:633*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:634*/GL11.glColor4d((double)v5, (double)v6, (double)v7, (double)v8);
        /*SL:635*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b + v13, a1.field_72339_c);
        /*SL:636*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b + v13, a1.field_72339_c);
        /*SL:637*/GL11.glColor4f(v9, v10, v11, v12);
        /*SL:638*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:639*/GL11.glColor4d((double)v1, (double)v2, (double)v3, (double)v4);
        /*SL:640*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:641*/GL11.glColor4d((double)v5, (double)v6, (double)v7, (double)v8);
        /*SL:642*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b + v13, a1.field_72334_f);
        /*SL:643*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b + v13, a1.field_72334_f);
        /*SL:644*/GL11.glColor4d((double)v9, (double)v10, (double)v11, (double)v12);
        /*SL:645*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:646*/GL11.glColor4d((double)v1, (double)v2, (double)v3, (double)v4);
        /*SL:647*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:648*/GL11.glColor4d((double)v5, (double)v6, (double)v7, (double)v8);
        /*SL:649*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b + v13, a1.field_72334_f);
        /*SL:650*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b + v13, a1.field_72334_f);
        /*SL:651*/GL11.glColor4d((double)v9, (double)v10, (double)v11, (double)v12);
        /*SL:652*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:653*/GL11.glColor4d((double)v1, (double)v2, (double)v3, (double)v4);
        /*SL:654*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:655*/GL11.glColor4d((double)v5, (double)v6, (double)v7, (double)v8);
        /*SL:656*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b + v13, a1.field_72339_c);
        /*SL:657*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b + v13, a1.field_72339_c);
        /*SL:658*/GL11.glColor4d((double)v9, (double)v10, (double)v11, (double)v12);
        /*SL:659*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:660*/GL11.glColor4d((double)v9, (double)v10, (double)v11, (double)v12);
        /*SL:661*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:662*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:663*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:664*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:665*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:666*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:667*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:668*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:669*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:670*/GL11.glEnd();
        /*SL:671*/GL11.glDisable(2848);
        /*SL:672*/GlStateManager.func_179132_a(true);
        /*SL:673*/GlStateManager.func_179126_j();
        /*SL:674*/GlStateManager.func_179098_w();
        /*SL:675*/GlStateManager.func_179084_k();
        /*SL:676*/GlStateManager.func_179121_F();
    }
    
    public static void drawGradientBlockOutline(final AxisAlignedBB a1, final Color a2, final Color a3, final float a4) {
        final float v1 = /*EL:680*/a2.getRed() / 255.0f;
        final float v2 = /*EL:681*/a2.getGreen() / 255.0f;
        final float v3 = /*EL:682*/a2.getBlue() / 255.0f;
        final float v4 = /*EL:683*/a2.getAlpha() / 255.0f;
        final float v5 = /*EL:684*/a3.getRed() / 255.0f;
        final float v6 = /*EL:685*/a3.getGreen() / 255.0f;
        final float v7 = /*EL:686*/a3.getBlue() / 255.0f;
        final float v8 = /*EL:687*/a3.getAlpha() / 255.0f;
        /*SL:688*/GlStateManager.func_179094_E();
        /*SL:689*/GlStateManager.func_179147_l();
        /*SL:690*/GlStateManager.func_179097_i();
        /*SL:691*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:692*/GlStateManager.func_179090_x();
        /*SL:693*/GlStateManager.func_179132_a(false);
        /*SL:694*/GL11.glEnable(2848);
        /*SL:695*/GL11.glHint(3154, 4354);
        /*SL:696*/GL11.glLineWidth(a4);
        final Tessellator v9 = /*EL:697*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:698*/v9.func_178180_c();
        /*SL:699*/v10.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        /*SL:700*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:701*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:702*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:703*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:704*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:705*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:706*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:707*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:708*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:709*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:710*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:711*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:712*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:713*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:714*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:715*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:716*/v9.func_78381_a();
        /*SL:717*/GL11.glDisable(2848);
        /*SL:718*/GlStateManager.func_179132_a(true);
        /*SL:719*/GlStateManager.func_179126_j();
        /*SL:720*/GlStateManager.func_179098_w();
        /*SL:721*/GlStateManager.func_179084_k();
        /*SL:722*/GlStateManager.func_179121_F();
    }
    
    public static void drawGradientFilledBox(final BlockPos a1, final Color a2, final Color a3) {
        final IBlockState v1 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:726*/a1);
        final Vec3d v2 = /*EL:727*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        drawGradientFilledBox(/*EL:728*/v1.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v2.field_72450_a, -v2.field_72448_b, -v2.field_72449_c), a2, a3);
    }
    
    public static void drawGradientFilledBox(final AxisAlignedBB a1, final Color a2, final Color a3) {
        /*SL:732*/GlStateManager.func_179094_E();
        /*SL:733*/GlStateManager.func_179147_l();
        /*SL:734*/GlStateManager.func_179097_i();
        /*SL:735*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:736*/GlStateManager.func_179090_x();
        /*SL:737*/GlStateManager.func_179132_a(false);
        final float v1 = /*EL:738*/a3.getAlpha() / 255.0f;
        final float v2 = /*EL:739*/a3.getRed() / 255.0f;
        final float v3 = /*EL:740*/a3.getGreen() / 255.0f;
        final float v4 = /*EL:741*/a3.getBlue() / 255.0f;
        final float v5 = /*EL:742*/a2.getAlpha() / 255.0f;
        final float v6 = /*EL:743*/a2.getRed() / 255.0f;
        final float v7 = /*EL:744*/a2.getGreen() / 255.0f;
        final float v8 = /*EL:745*/a2.getBlue() / 255.0f;
        final Tessellator v9 = /*EL:746*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:747*/v9.func_178180_c();
        /*SL:748*/v10.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:749*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:750*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:751*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:752*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:753*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:754*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:755*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:756*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:757*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:758*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:759*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:760*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:761*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:762*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:763*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:764*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:765*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:766*/v10.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:767*/v10.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:768*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:769*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:770*/v10.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:771*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:772*/v10.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:773*/v9.func_78381_a();
        /*SL:774*/GlStateManager.func_179132_a(true);
        /*SL:775*/GlStateManager.func_179126_j();
        /*SL:776*/GlStateManager.func_179098_w();
        /*SL:777*/GlStateManager.func_179084_k();
        /*SL:778*/GlStateManager.func_179121_F();
    }
    
    public static void drawGradientRect(final float a1, final float a2, final float a3, final float a4, final int a5, final int a6) {
        final float v1 = /*EL:782*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:783*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:784*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:785*/(a5 & 0xFF) / 255.0f;
        final float v5 = /*EL:786*/(a6 >> 24 & 0xFF) / 255.0f;
        final float v6 = /*EL:787*/(a6 >> 16 & 0xFF) / 255.0f;
        final float v7 = /*EL:788*/(a6 >> 8 & 0xFF) / 255.0f;
        final float v8 = /*EL:789*/(a6 & 0xFF) / 255.0f;
        /*SL:790*/GlStateManager.func_179090_x();
        /*SL:791*/GlStateManager.func_179147_l();
        /*SL:792*/GlStateManager.func_179118_c();
        /*SL:793*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        /*SL:794*/GlStateManager.func_179103_j(7425);
        final Tessellator v9 = /*EL:795*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:796*/v9.func_178180_c();
        /*SL:797*/v10.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:798*/v10.func_181662_b(a1 + a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:799*/v10.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:800*/v10.func_181662_b((double)a1, a2 + a4, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:801*/v10.func_181662_b(a1 + a3, a2 + a4, 0.0).func_181666_a(v6, v7, v8, v5).func_181675_d();
        /*SL:802*/v9.func_78381_a();
        /*SL:803*/GlStateManager.func_179103_j(7424);
        /*SL:804*/GlStateManager.func_179084_k();
        /*SL:805*/GlStateManager.func_179141_d();
        /*SL:806*/GlStateManager.func_179098_w();
    }
    
    public static void drawFilledCircle(final double a1, final double a2, final double a3, final Color a4, final double a5) {
        final Tessellator v1 = /*EL:810*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:811*/v1.func_178180_c();
        /*SL:812*/v2.func_181668_a(5, DefaultVertexFormats.field_181706_f);
    }
    
    public static void drawGradientBoxTest(final BlockPos a1, final Color a2, final Color a3) {
    }
    
    public static void blockESP(final BlockPos a1, final Color a2, final double a3, final double a4) {
        blockEsp(/*EL:819*/a1, a2, a3, a4);
    }
    
    public static void drawBoxESP(final BlockPos a1, final Color a2, final boolean a3, final Color a4, final float a5, final boolean a6, final boolean a7, final int a8, final boolean a9) {
        /*SL:823*/if (a7) {
            drawBox(/*EL:824*/a1, new Color(a2.getRed(), a2.getGreen(), a2.getBlue(), a8));
        }
        /*SL:826*/if (a6) {
            drawBlockOutline(/*EL:827*/a1, a3 ? a4 : a2, a5, a9);
        }
    }
    
    public static void drawBoxESP(final BlockPos a1, final Color a2, final boolean a3, final Color a4, final float a5, final boolean a6, final boolean a7, final int a8, final boolean a9, final double a10, final boolean a11, final boolean a12, final boolean a13, final boolean a14, final int a15) {
        /*SL:832*/if (a7) {
            drawBox(/*EL:833*/a1, new Color(a2.getRed(), a2.getGreen(), a2.getBlue(), a8), a10, a11, a13, a15);
        }
        /*SL:835*/if (a6) {
            drawBlockOutline(/*EL:836*/a1, a3 ? a4 : a2, a5, a9, a10, a12, a14, a15);
        }
    }
    
    public static void glScissor(final float a1, final float a2, final float a3, final float a4, final ScaledResolution a5) {
        /*SL:841*/GL11.glScissor((int)(a1 * a5.func_78325_e()), (int)(RenderUtil.mc.field_71440_d - a4 * a5.func_78325_e()), (int)((a3 - a1) * a5.func_78325_e()), (int)((a4 - a2) * a5.func_78325_e()));
    }
    
    public static void drawLine(final float a1, final float a2, final float a3, final float a4, final float a5, final int a6) {
        final float v1 = /*EL:845*/(a6 >> 16 & 0xFF) / 255.0f;
        final float v2 = /*EL:846*/(a6 >> 8 & 0xFF) / 255.0f;
        final float v3 = /*EL:847*/(a6 & 0xFF) / 255.0f;
        final float v4 = /*EL:848*/(a6 >> 24 & 0xFF) / 255.0f;
        /*SL:849*/GlStateManager.func_179094_E();
        /*SL:850*/GlStateManager.func_179090_x();
        /*SL:851*/GlStateManager.func_179147_l();
        /*SL:852*/GlStateManager.func_179118_c();
        /*SL:853*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:854*/GlStateManager.func_179103_j(7425);
        /*SL:855*/GL11.glLineWidth(a5);
        /*SL:856*/GL11.glEnable(2848);
        /*SL:857*/GL11.glHint(3154, 4354);
        final Tessellator v5 = /*EL:858*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:859*/v5.func_178180_c();
        /*SL:860*/v6.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        /*SL:861*/v6.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:862*/v6.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:863*/v5.func_78381_a();
        /*SL:864*/GlStateManager.func_179103_j(7424);
        /*SL:865*/GL11.glDisable(2848);
        /*SL:866*/GlStateManager.func_179084_k();
        /*SL:867*/GlStateManager.func_179141_d();
        /*SL:868*/GlStateManager.func_179098_w();
        /*SL:869*/GlStateManager.func_179121_F();
    }
    
    public static void drawBox(final BlockPos a1, final Color a2) {
        final AxisAlignedBB v1 = /*EL:873*/new AxisAlignedBB(a1.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a1.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        RenderUtil.camera.func_78547_a(/*EL:874*/Objects.<Entity>requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        /*SL:875*/if (RenderUtil.camera.func_78546_a(new AxisAlignedBB(v1.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, v1.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, v1.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, v1.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, v1.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, v1.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            /*SL:876*/GlStateManager.func_179094_E();
            /*SL:877*/GlStateManager.func_179147_l();
            /*SL:878*/GlStateManager.func_179097_i();
            /*SL:879*/GlStateManager.func_179120_a(770, 771, 0, 1);
            /*SL:880*/GlStateManager.func_179090_x();
            /*SL:881*/GlStateManager.func_179132_a(false);
            /*SL:882*/GL11.glEnable(2848);
            /*SL:883*/GL11.glHint(3154, 4354);
            /*SL:884*/RenderGlobal.func_189696_b(v1, a2.getRed() / 255.0f, a2.getGreen() / 255.0f, a2.getBlue() / 255.0f, a2.getAlpha() / 255.0f);
            /*SL:885*/GL11.glDisable(2848);
            /*SL:886*/GlStateManager.func_179132_a(true);
            /*SL:887*/GlStateManager.func_179126_j();
            /*SL:888*/GlStateManager.func_179098_w();
            /*SL:889*/GlStateManager.func_179084_k();
            /*SL:890*/GlStateManager.func_179121_F();
        }
    }
    
    public static void drawBetterGradientBox(final BlockPos a1, final Color a2, final Color a3) {
        final float v1 = /*EL:895*/a2.getRed() / 255.0f;
        final float v2 = /*EL:896*/a2.getGreen() / 255.0f;
        final float v3 = /*EL:897*/a2.getBlue() / 255.0f;
        final float v4 = /*EL:898*/a2.getAlpha() / 255.0f;
        final float v5 = /*EL:899*/a3.getRed() / 255.0f;
        final float v6 = /*EL:900*/a3.getGreen() / 255.0f;
        final float v7 = /*EL:901*/a3.getBlue() / 255.0f;
        final float v8 = /*EL:902*/a3.getAlpha() / 255.0f;
        final AxisAlignedBB v9 = /*EL:903*/new AxisAlignedBB(a1.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a1.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        final double v10 = /*EL:904*/(v9.field_72337_e - v9.field_72338_b) / 2.0;
        final Tessellator v11 = /*EL:905*/Tessellator.func_178181_a();
        final BufferBuilder v12 = /*EL:906*/v11.func_178180_c();
        /*SL:907*/GlStateManager.func_179094_E();
        /*SL:908*/GlStateManager.func_179147_l();
        /*SL:909*/GlStateManager.func_179097_i();
        /*SL:910*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:911*/GlStateManager.func_179090_x();
        /*SL:912*/GlStateManager.func_179132_a(false);
        /*SL:913*/GL11.glEnable(2848);
        /*SL:914*/GL11.glHint(3154, 4354);
        /*SL:915*/v12.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        /*SL:916*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:917*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:918*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:919*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:920*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:921*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:922*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:923*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:924*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:925*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:926*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:927*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:928*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:929*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:930*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:931*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:932*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:933*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:934*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:935*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:936*/v12.func_181662_b(v9.field_72340_a, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:937*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:938*/v12.func_181662_b(v9.field_72336_d, v9.field_72338_b, v9.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:939*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:940*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:941*/v12.func_181662_b(v9.field_72340_a, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:942*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:943*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:944*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:945*/v12.func_181662_b(v9.field_72336_d, v9.field_72337_e, v9.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
    }
    
    public static void drawBetterGradientBox(final BlockPos a1, final Color a2, final Color a3, final Color a4) {
        final float v1 = /*EL:949*/a2.getRed() / 255.0f;
        final float v2 = /*EL:950*/a2.getGreen() / 255.0f;
        final float v3 = /*EL:951*/a2.getBlue() / 255.0f;
        final float v4 = /*EL:952*/a2.getAlpha() / 255.0f;
        final float v5 = /*EL:953*/a4.getRed() / 255.0f;
        final float v6 = /*EL:954*/a4.getGreen() / 255.0f;
        final float v7 = /*EL:955*/a4.getBlue() / 255.0f;
        final float v8 = /*EL:956*/a4.getAlpha() / 255.0f;
        final float v9 = /*EL:957*/a3.getRed() / 255.0f;
        final float v10 = /*EL:958*/a3.getGreen() / 255.0f;
        final float v11 = /*EL:959*/a3.getBlue() / 255.0f;
        final float v12 = /*EL:960*/a3.getAlpha() / 255.0f;
        final AxisAlignedBB v13 = /*EL:961*/new AxisAlignedBB(a1.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a1.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        final double v14 = /*EL:962*/(v13.field_72337_e - v13.field_72338_b) / 2.0;
        final Tessellator v15 = /*EL:963*/Tessellator.func_178181_a();
        final BufferBuilder v16 = /*EL:964*/v15.func_178180_c();
        /*SL:965*/GlStateManager.func_179094_E();
        /*SL:966*/GlStateManager.func_179147_l();
        /*SL:967*/GlStateManager.func_179097_i();
        /*SL:968*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:969*/GlStateManager.func_179090_x();
        /*SL:970*/GlStateManager.func_179132_a(false);
        /*SL:971*/GL11.glEnable(2848);
        /*SL:972*/GL11.glHint(3154, 4354);
        /*SL:973*/v16.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        /*SL:974*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:975*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:976*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:977*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:978*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72339_c).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:979*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:980*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:981*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:982*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:983*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:984*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72339_c).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:985*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72339_c).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:986*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72339_c).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:987*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:988*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:989*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:990*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:991*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:992*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:993*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b + v14, v13.field_72334_f).func_181666_a(v9, v10, v11, v12).func_181675_d();
        /*SL:994*/v15.func_78381_a();
        /*SL:995*/GL11.glDisable(2848);
        /*SL:996*/GlStateManager.func_179132_a(true);
        /*SL:997*/GlStateManager.func_179126_j();
        /*SL:998*/GlStateManager.func_179098_w();
        /*SL:999*/GlStateManager.func_179084_k();
        /*SL:1000*/GlStateManager.func_179121_F();
    }
    
    public static void drawEvenBetterGradientBox(final BlockPos a1, final Color a2, final Color a3, final Color a4) {
        final float v1 = /*EL:1004*/a2.getRed() / 255.0f;
        final float v2 = /*EL:1005*/a2.getGreen() / 255.0f;
        final float v3 = /*EL:1006*/a2.getBlue() / 255.0f;
        final float v4 = /*EL:1007*/a2.getAlpha() / 255.0f;
        final float v5 = /*EL:1008*/a4.getRed() / 255.0f;
        final float v6 = /*EL:1009*/a4.getGreen() / 255.0f;
        final float v7 = /*EL:1010*/a4.getBlue() / 255.0f;
        final float v8 = /*EL:1011*/a4.getAlpha() / 255.0f;
        final float v9 = /*EL:1012*/a3.getRed() / 255.0f;
        final float v10 = /*EL:1013*/a3.getGreen() / 255.0f;
        final float v11 = /*EL:1014*/a3.getBlue() / 255.0f;
        final float v12 = /*EL:1015*/a3.getAlpha() / 255.0f;
        final AxisAlignedBB v13 = /*EL:1016*/new AxisAlignedBB(a1.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a1.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        final double v14 = /*EL:1017*/(v13.field_72337_e - v13.field_72338_b) / 2.0;
        final Tessellator v15 = /*EL:1018*/Tessellator.func_178181_a();
        final BufferBuilder v16 = /*EL:1019*/v15.func_178180_c();
        /*SL:1020*/GlStateManager.func_179094_E();
        /*SL:1021*/GlStateManager.func_179147_l();
        /*SL:1022*/GlStateManager.func_179097_i();
        /*SL:1023*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:1024*/GlStateManager.func_179090_x();
        /*SL:1025*/GlStateManager.func_179132_a(false);
        /*SL:1026*/GL11.glEnable(2848);
        /*SL:1027*/GL11.glHint(3154, 4354);
        /*SL:1028*/v16.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        /*SL:1029*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1030*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1031*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1032*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1033*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1034*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1035*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1036*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1037*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1038*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1039*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1040*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1041*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1042*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1043*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1044*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1045*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1046*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1047*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1048*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72339_c).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1049*/v16.func_181662_b(v13.field_72340_a, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1050*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1051*/v16.func_181662_b(v13.field_72336_d, v13.field_72338_b, v13.field_72334_f).func_181666_a(v5, v6, v7, v8).func_181675_d();
        /*SL:1052*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1053*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1054*/v16.func_181662_b(v13.field_72340_a, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1055*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1056*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1057*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1058*/v16.func_181662_b(v13.field_72336_d, v13.field_72337_e, v13.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1059*/v15.func_78381_a();
        /*SL:1060*/GL11.glDisable(2848);
        /*SL:1061*/GlStateManager.func_179132_a(true);
        /*SL:1062*/GlStateManager.func_179126_j();
        /*SL:1063*/GlStateManager.func_179098_w();
        /*SL:1064*/GlStateManager.func_179084_k();
        /*SL:1065*/GlStateManager.func_179121_F();
    }
    
    public static void drawBox(final BlockPos a2, final Color a3, final double a4, final boolean a5, final boolean a6, final int v1) {
        /*SL:1069*/if (a5) {
            final Color a7 = /*EL:1070*/new Color(a3.getRed(), a3.getGreen(), a3.getBlue(), v1);
            drawOpenGradientBox(/*EL:1071*/a2, a6 ? a7 : a3, a6 ? a3 : a7, a4);
            /*SL:1072*/return;
        }
        final AxisAlignedBB v2 = /*EL:1074*/new AxisAlignedBB(a2.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a2.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a2.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a2.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a2.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m + a4, a2.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        RenderUtil.camera.func_78547_a(/*EL:1075*/Objects.<Entity>requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        /*SL:1076*/if (RenderUtil.camera.func_78546_a(new AxisAlignedBB(v2.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, v2.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, v2.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, v2.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, v2.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, v2.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            /*SL:1077*/GlStateManager.func_179094_E();
            /*SL:1078*/GlStateManager.func_179147_l();
            /*SL:1079*/GlStateManager.func_179097_i();
            /*SL:1080*/GlStateManager.func_179120_a(770, 771, 0, 1);
            /*SL:1081*/GlStateManager.func_179090_x();
            /*SL:1082*/GlStateManager.func_179132_a(false);
            /*SL:1083*/GL11.glEnable(2848);
            /*SL:1084*/GL11.glHint(3154, 4354);
            /*SL:1085*/RenderGlobal.func_189696_b(v2, a3.getRed() / 255.0f, a3.getGreen() / 255.0f, a3.getBlue() / 255.0f, a3.getAlpha() / 255.0f);
            /*SL:1086*/GL11.glDisable(2848);
            /*SL:1087*/GlStateManager.func_179132_a(true);
            /*SL:1088*/GlStateManager.func_179126_j();
            /*SL:1089*/GlStateManager.func_179098_w();
            /*SL:1090*/GlStateManager.func_179084_k();
            /*SL:1091*/GlStateManager.func_179121_F();
        }
    }
    
    public static void drawBlockOutline(final BlockPos a2, final Color a3, final float a4, final boolean v1) {
        final IBlockState v2 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:1096*/a2);
        /*SL:1097*/if ((v1 || v2.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(a2)) {
            final Vec3d a5 = /*EL:1098*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
            drawBlockOutline(/*EL:1099*/v2.func_185918_c((World)RenderUtil.mc.field_71441_e, a2).func_186662_g(0.0020000000949949026).func_72317_d(-a5.field_72450_a, -a5.field_72448_b, -a5.field_72449_c), a3, a4);
        }
    }
    
    public static void drawBlockOutline(final BlockPos a3, final Color a4, final float a5, final boolean a6, final double a7, final boolean a8, final boolean v1, final int v2) {
        /*SL:1104*/if (a8) {
            final Color a9 = /*EL:1105*/new Color(a4.getRed(), a4.getGreen(), a4.getBlue(), v2);
            drawGradientBlockOutline(/*EL:1106*/a3, v1 ? a9 : a4, v1 ? a4 : a9, a5, a7);
            /*SL:1107*/return;
        }
        final IBlockState v3 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:1109*/a3);
        /*SL:1110*/if ((a6 || v3.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(a3)) {
            final AxisAlignedBB a10 = /*EL:1111*/new AxisAlignedBB(a3.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a3.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a3.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a3.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a3.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m + a7, a3.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
            drawBlockOutline(/*EL:1112*/a10.func_186662_g(0.0020000000949949026), a4, a5);
        }
    }
    
    public static void drawBlockOutline(final AxisAlignedBB a1, final Color a2, final float a3) {
        final float v1 = /*EL:1117*/a2.getRed() / 255.0f;
        final float v2 = /*EL:1118*/a2.getGreen() / 255.0f;
        final float v3 = /*EL:1119*/a2.getBlue() / 255.0f;
        final float v4 = /*EL:1120*/a2.getAlpha() / 255.0f;
        /*SL:1121*/GlStateManager.func_179094_E();
        /*SL:1122*/GlStateManager.func_179147_l();
        /*SL:1123*/GlStateManager.func_179097_i();
        /*SL:1124*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:1125*/GlStateManager.func_179090_x();
        /*SL:1126*/GlStateManager.func_179132_a(false);
        /*SL:1127*/GL11.glEnable(2848);
        /*SL:1128*/GL11.glHint(3154, 4354);
        /*SL:1129*/GL11.glLineWidth(a3);
        final Tessellator v5 = /*EL:1130*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:1131*/v5.func_178180_c();
        /*SL:1132*/v6.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        /*SL:1133*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1134*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1135*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1136*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1137*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1138*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1139*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1140*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1141*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1142*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1143*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1144*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1145*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1146*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1147*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1148*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v1, v2, v3, v4).func_181675_d();
        /*SL:1149*/v5.func_78381_a();
        /*SL:1150*/GL11.glDisable(2848);
        /*SL:1151*/GlStateManager.func_179132_a(true);
        /*SL:1152*/GlStateManager.func_179126_j();
        /*SL:1153*/GlStateManager.func_179098_w();
        /*SL:1154*/GlStateManager.func_179084_k();
        /*SL:1155*/GlStateManager.func_179121_F();
    }
    
    public static void drawBoxESP(final BlockPos a2, final Color a3, final float a4, final boolean a5, final boolean a6, final int v1) {
        final AxisAlignedBB v2 = /*EL:1159*/new AxisAlignedBB(a2.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a2.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a2.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a2.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a2.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a2.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        RenderUtil.camera.func_78547_a(/*EL:1160*/Objects.<Entity>requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        /*SL:1161*/if (RenderUtil.camera.func_78546_a(new AxisAlignedBB(v2.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, v2.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, v2.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, v2.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, v2.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, v2.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            /*SL:1162*/GlStateManager.func_179094_E();
            /*SL:1163*/GlStateManager.func_179147_l();
            /*SL:1164*/GlStateManager.func_179097_i();
            /*SL:1165*/GlStateManager.func_179120_a(770, 771, 0, 1);
            /*SL:1166*/GlStateManager.func_179090_x();
            /*SL:1167*/GlStateManager.func_179132_a(false);
            /*SL:1168*/GL11.glEnable(2848);
            /*SL:1169*/GL11.glHint(3154, 4354);
            /*SL:1170*/GL11.glLineWidth(a4);
            final double a7 = RenderUtil.mc.field_71439_g.func_70011_f(/*EL:1171*/(double)(a2.func_177958_n() + 0.5f), (double)(a2.func_177956_o() + 0.5f), (double)(a2.func_177952_p() + 0.5f)) * 0.75;
            /*SL:1172*/if (a6) {
                /*SL:1173*/RenderGlobal.func_189696_b(v2, a3.getRed() / 255.0f, a3.getGreen() / 255.0f, a3.getBlue() / 255.0f, v1 / 255.0f);
            }
            /*SL:1175*/if (a5) {
                /*SL:1176*/RenderGlobal.func_189694_a(v2.field_72340_a, v2.field_72338_b, v2.field_72339_c, v2.field_72336_d, v2.field_72337_e, v2.field_72334_f, a3.getRed() / 255.0f, a3.getGreen() / 255.0f, a3.getBlue() / 255.0f, a3.getAlpha() / 255.0f);
            }
            /*SL:1178*/GL11.glDisable(2848);
            /*SL:1179*/GlStateManager.func_179132_a(true);
            /*SL:1180*/GlStateManager.func_179126_j();
            /*SL:1181*/GlStateManager.func_179098_w();
            /*SL:1182*/GlStateManager.func_179084_k();
            /*SL:1183*/GlStateManager.func_179121_F();
        }
    }
    
    public static void drawText(final BlockPos a1, final String a2) {
        /*SL:1188*/if (a1 == null || a2 == null) {
            /*SL:1189*/return;
        }
        /*SL:1191*/GlStateManager.func_179094_E();
        glBillboardDistanceScaled(/*EL:1192*/a1.func_177958_n() + 0.5f, a1.func_177956_o() + 0.5f, a1.func_177952_p() + 0.5f, (EntityPlayer)RenderUtil.mc.field_71439_g, 1.0f);
        /*SL:1193*/GlStateManager.func_179097_i();
        /*SL:1194*/GlStateManager.func_179137_b(-(Legacy.textManager.getStringWidth(a2) / 2.0), 0.0, 0.0);
        Legacy.textManager.drawStringWithShadow(/*EL:1195*/a2, 0.0f, 0.0f, -5592406);
        /*SL:1196*/GlStateManager.func_179121_F();
    }
    
    public static void drawOutlinedBlockESP(final BlockPos a1, final Color a2, final float a3) {
        final IBlockState v1 = RenderUtil.mc.field_71441_e.func_180495_p(/*EL:1200*/a1);
        final Vec3d v2 = /*EL:1201*/EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, RenderUtil.mc.func_184121_ak());
        drawBoundingBox(/*EL:1202*/v1.func_185918_c((World)RenderUtil.mc.field_71441_e, a1).func_186662_g(0.0020000000949949026).func_72317_d(-v2.field_72450_a, -v2.field_72448_b, -v2.field_72449_c), a3, ColorUtil.toRGBA(a2));
    }
    
    public static void blockEsp(final BlockPos a1, final Color a2, final double a3, final double a4) {
        final double v1 = /*EL:1206*/a1.func_177958_n() - RenderUtil.mc.field_175616_W.field_78725_b;
        final double v2 = /*EL:1207*/a1.func_177956_o() - RenderUtil.mc.field_175616_W.field_78726_c;
        final double v3 = /*EL:1208*/a1.func_177952_p() - RenderUtil.mc.field_175616_W.field_78723_d;
        /*SL:1209*/GL11.glPushMatrix();
        /*SL:1210*/GL11.glBlendFunc(770, 771);
        /*SL:1211*/GL11.glEnable(3042);
        /*SL:1212*/GL11.glLineWidth(2.0f);
        /*SL:1213*/GL11.glDisable(3553);
        /*SL:1214*/GL11.glDisable(2929);
        /*SL:1215*/GL11.glDepthMask(false);
        /*SL:1216*/GL11.glColor4d((double)(a2.getRed() / 255.0f), (double)(a2.getGreen() / 255.0f), (double)(a2.getBlue() / 255.0f), 0.25);
        drawColorBox(/*EL:1217*/new AxisAlignedBB(v1, v2, v3, v1 + a4, v2 + 1.0, v3 + a3), 0.0f, 0.0f, 0.0f, 0.0f);
        /*SL:1218*/GL11.glColor4d(0.0, 0.0, 0.0, 0.5);
        drawSelectionBoundingBox(/*EL:1219*/new AxisAlignedBB(v1, v2, v3, v1 + a4, v2 + 1.0, v3 + a3));
        /*SL:1220*/GL11.glLineWidth(2.0f);
        /*SL:1221*/GL11.glEnable(3553);
        /*SL:1222*/GL11.glEnable(2929);
        /*SL:1223*/GL11.glDepthMask(true);
        /*SL:1224*/GL11.glDisable(3042);
        /*SL:1225*/GL11.glPopMatrix();
        /*SL:1226*/GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public static void drawRect(final float a1, final float a2, final float a3, final float a4, final int a5) {
        final float v1 = /*EL:1230*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:1231*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:1232*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:1233*/(a5 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:1234*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:1235*/v5.func_178180_c();
        /*SL:1236*/GlStateManager.func_179147_l();
        /*SL:1237*/GlStateManager.func_179090_x();
        /*SL:1238*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:1239*/v6.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:1240*/v6.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1241*/v6.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1242*/v6.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1243*/v6.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1244*/v5.func_78381_a();
        /*SL:1245*/GlStateManager.func_179098_w();
        /*SL:1246*/GlStateManager.func_179084_k();
    }
    
    public static void drawRectMC(final int a1, final int a2, final int a3, final int a4, final int a5) {
        /*SL:1249*/Gui.func_73734_a(a1, a2, a3, a4, a5);
    }
    
    public static void drawBorderedRect(final int a1, final double a2, final int a3, final double a4, final int a5, int a6, int a7, final boolean a8) {
        /*SL:1252*/if (a8) {
            /*SL:1253*/a6 = ColorUtil.shadeColour(a6, -20);
            /*SL:1254*/a7 = ColorUtil.shadeColour(a7, -20);
        }
        drawRectBase(/*EL:1256*/a1 + a5, a2 + a5, a3 - a5, a4 - a5, a6);
        drawRectBase(/*EL:1257*/a1, a2 + a5, a1 + a5, a4 - a5, a7);
        drawRectBase(/*EL:1258*/a3 - a5, a2 + a5, a3, a4 - a5, a7);
        drawRectBase(/*EL:1259*/a1, a2, a3, a2 + a5, a7);
        drawRectBase(/*EL:1260*/a1, a4 - a5, a3, a4, a7);
    }
    
    public static void drawRectBase(int a3, double a4, double a5, double v1, final int v3) {
        /*SL:1265*/if (a3 < a5) {
            final double a6 = /*EL:1266*/a3;
            /*SL:1267*/a3 = (int)a5;
            /*SL:1268*/a5 = (int)a6;
        }
        /*SL:1271*/if (a4 < v1) {
            final double a7 = /*EL:1272*/a4;
            /*SL:1273*/a4 = v1;
            /*SL:1274*/v1 = a7;
        }
        /*SL:1277*/GlStateManager.func_179147_l();
        /*SL:1278*/GL11.glDisable(3042);
        /*SL:1279*/GL11.glDisable(3008);
        /*SL:1280*/GlStateManager.func_179090_x();
        /*SL:1281*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        /*SL:1282*/GlStateManager.func_179131_c((v3 >> 16 & 0xFF) / 255.0f, (v3 >> 8 & 0xFF) / 255.0f, (v3 & 0xFF) / 255.0f, (v3 >> 24 & 0xFF) / 255.0f);
        RenderUtil.bufferbuilder.func_181668_a(/*EL:1283*/7, DefaultVertexFormats.field_181705_e);
        RenderUtil.bufferbuilder.func_181662_b(/*EL:1284*/(double)a3, v1, 0.0).func_181675_d();
        RenderUtil.bufferbuilder.func_181662_b(/*EL:1285*/a5, v1, 0.0).func_181675_d();
        RenderUtil.bufferbuilder.func_181662_b(/*EL:1286*/a5, a4, 0.0).func_181675_d();
        RenderUtil.bufferbuilder.func_181662_b(/*EL:1287*/(double)a3, a4, 0.0).func_181675_d();
        RenderUtil.tessellator.func_78381_a();
        /*SL:1289*/GL11.glEnable(3042);
        /*SL:1290*/GL11.glEnable(3008);
        /*SL:1291*/GlStateManager.func_179098_w();
        /*SL:1292*/GlStateManager.func_179084_k();
    }
    
    public static void drawColorBox(final AxisAlignedBB a1, final float a2, final float a3, final float a4, final float a5) {
        final Tessellator v1 = /*EL:1316*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:1317*/v1.func_178180_c();
        /*SL:1318*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1319*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1320*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1321*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1322*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1323*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1324*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1325*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1326*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1327*/v1.func_78381_a();
        /*SL:1328*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1329*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1330*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1331*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1332*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1333*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1334*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1335*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1336*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1337*/v1.func_78381_a();
        /*SL:1338*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1339*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1340*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1341*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1342*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1343*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1344*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1345*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1346*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1347*/v1.func_78381_a();
        /*SL:1348*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1349*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1350*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1351*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1352*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1353*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1354*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1355*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1356*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1357*/v1.func_78381_a();
        /*SL:1358*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1359*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1360*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1361*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1362*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1363*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1364*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1365*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1366*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1367*/v1.func_78381_a();
        /*SL:1368*/v2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        /*SL:1369*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1370*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1371*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1372*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1373*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1374*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1375*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1376*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a2, a3, a4, a5).func_181675_d();
        /*SL:1377*/v1.func_78381_a();
    }
    
    public static void drawSelectionBoundingBox(final AxisAlignedBB a1) {
        final Tessellator v1 = /*EL:1381*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:1382*/v1.func_178180_c();
        /*SL:1383*/v2.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        /*SL:1384*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181675_d();
        /*SL:1385*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181675_d();
        /*SL:1386*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181675_d();
        /*SL:1387*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181675_d();
        /*SL:1388*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181675_d();
        /*SL:1389*/v1.func_78381_a();
        /*SL:1390*/v2.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        /*SL:1391*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181675_d();
        /*SL:1392*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181675_d();
        /*SL:1393*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181675_d();
        /*SL:1394*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181675_d();
        /*SL:1395*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181675_d();
        /*SL:1396*/v1.func_78381_a();
        /*SL:1397*/v2.func_181668_a(1, DefaultVertexFormats.field_181705_e);
        /*SL:1398*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181675_d();
        /*SL:1399*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181675_d();
        /*SL:1400*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181675_d();
        /*SL:1401*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181675_d();
        /*SL:1402*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181675_d();
        /*SL:1403*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181675_d();
        /*SL:1404*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181675_d();
        /*SL:1405*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181675_d();
        /*SL:1406*/v1.func_78381_a();
    }
    
    public static void glrendermethod() {
        /*SL:1410*/GL11.glEnable(3042);
        /*SL:1411*/GL11.glBlendFunc(770, 771);
        /*SL:1412*/GL11.glEnable(2848);
        /*SL:1413*/GL11.glLineWidth(2.0f);
        /*SL:1414*/GL11.glDisable(3553);
        /*SL:1415*/GL11.glEnable(2884);
        /*SL:1416*/GL11.glDisable(2929);
        final double v1 = RenderUtil.mc.func_175598_ae().field_78730_l;
        final double v2 = RenderUtil.mc.func_175598_ae().field_78731_m;
        final double v3 = RenderUtil.mc.func_175598_ae().field_78728_n;
        /*SL:1420*/GL11.glPushMatrix();
        /*SL:1421*/GL11.glTranslated(-v1, -v2, -v3);
    }
    
    public static void glStart(final float a1, final float a2, final float a3, final float a4) {
        glrendermethod();
        /*SL:1426*/GL11.glColor4f(a1, a2, a3, a4);
    }
    
    public static void glEnd() {
        /*SL:1430*/GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        /*SL:1431*/GL11.glPopMatrix();
        /*SL:1432*/GL11.glEnable(2929);
        /*SL:1433*/GL11.glEnable(3553);
        /*SL:1434*/GL11.glDisable(3042);
        /*SL:1435*/GL11.glDisable(2848);
    }
    
    public static AxisAlignedBB getBoundingBox(final BlockPos a1) {
        /*SL:1439*/return RenderUtil.mc.field_71441_e.func_180495_p(a1).func_185900_c((IBlockAccess)RenderUtil.mc.field_71441_e, a1).func_186670_a(a1);
    }
    
    public static void drawOutlinedBox(final AxisAlignedBB a1) {
        /*SL:1443*/GL11.glBegin(1);
        /*SL:1444*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:1445*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:1446*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:1447*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:1448*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:1449*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:1450*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:1451*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:1452*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c);
        /*SL:1453*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:1454*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c);
        /*SL:1455*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:1456*/GL11.glVertex3d(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f);
        /*SL:1457*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:1458*/GL11.glVertex3d(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f);
        /*SL:1459*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:1460*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:1461*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:1462*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c);
        /*SL:1463*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:1464*/GL11.glVertex3d(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f);
        /*SL:1465*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:1466*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f);
        /*SL:1467*/GL11.glVertex3d(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c);
        /*SL:1468*/GL11.glEnd();
    }
    
    public static void drawFilledBoxESPN(final BlockPos a1, final Color a2) {
        final AxisAlignedBB v1 = /*EL:1472*/new AxisAlignedBB(a1.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, a1.func_177958_n() + 1 - RenderUtil.mc.func_175598_ae().field_78730_l, a1.func_177956_o() + 1 - RenderUtil.mc.func_175598_ae().field_78731_m, a1.func_177952_p() + 1 - RenderUtil.mc.func_175598_ae().field_78728_n);
        final int v2 = /*EL:1473*/ColorUtil.toRGBA(a2);
        drawFilledBox(/*EL:1474*/v1, v2);
    }
    
    public static void drawFilledBox(final AxisAlignedBB a1, final int a2) {
        /*SL:1478*/GlStateManager.func_179094_E();
        /*SL:1479*/GlStateManager.func_179147_l();
        /*SL:1480*/GlStateManager.func_179097_i();
        /*SL:1481*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:1482*/GlStateManager.func_179090_x();
        /*SL:1483*/GlStateManager.func_179132_a(false);
        final float v1 = /*EL:1484*/(a2 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:1485*/(a2 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:1486*/(a2 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:1487*/(a2 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:1488*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:1489*/v5.func_178180_c();
        /*SL:1490*/v6.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:1491*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1492*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1493*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1494*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1495*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1496*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1497*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1498*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1499*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1500*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1501*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1502*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1503*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1504*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1505*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1506*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1507*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1508*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1509*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1510*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1511*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1512*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1513*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1514*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1515*/v5.func_78381_a();
        /*SL:1516*/GlStateManager.func_179132_a(true);
        /*SL:1517*/GlStateManager.func_179126_j();
        /*SL:1518*/GlStateManager.func_179098_w();
        /*SL:1519*/GlStateManager.func_179084_k();
        /*SL:1520*/GlStateManager.func_179121_F();
    }
    
    public static void drawBoundingBox(final AxisAlignedBB a1, final float a2, final int a3) {
        /*SL:1524*/GlStateManager.func_179094_E();
        /*SL:1525*/GlStateManager.func_179147_l();
        /*SL:1526*/GlStateManager.func_179097_i();
        /*SL:1527*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:1528*/GlStateManager.func_179090_x();
        /*SL:1529*/GlStateManager.func_179132_a(false);
        /*SL:1530*/GL11.glEnable(2848);
        /*SL:1531*/GL11.glHint(3154, 4354);
        /*SL:1532*/GL11.glLineWidth(a2);
        final float v1 = /*EL:1533*/(a3 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:1534*/(a3 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:1535*/(a3 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:1536*/(a3 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:1537*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:1538*/v5.func_178180_c();
        /*SL:1539*/v6.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        /*SL:1540*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1541*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1542*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1543*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1544*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1545*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1546*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1547*/v6.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1548*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1549*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1550*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1551*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1552*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1553*/v6.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1554*/v6.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1555*/v6.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1556*/v5.func_78381_a();
        /*SL:1557*/GL11.glDisable(2848);
        /*SL:1558*/GlStateManager.func_179132_a(true);
        /*SL:1559*/GlStateManager.func_179126_j();
        /*SL:1560*/GlStateManager.func_179098_w();
        /*SL:1561*/GlStateManager.func_179084_k();
        /*SL:1562*/GlStateManager.func_179121_F();
    }
    
    public static void glBillboard(final float a1, final float a2, final float a3) {
        final float v1 = /*EL:1566*/0.02666667f;
        /*SL:1567*/GlStateManager.func_179137_b(a1 - RenderUtil.mc.func_175598_ae().field_78725_b, a2 - RenderUtil.mc.func_175598_ae().field_78726_c, a3 - RenderUtil.mc.func_175598_ae().field_78723_d);
        /*SL:1568*/GlStateManager.func_187432_a(0.0f, 1.0f, 0.0f);
        /*SL:1569*/GlStateManager.func_179114_b(-RenderUtil.mc.field_71439_g.field_70177_z, 0.0f, 1.0f, 0.0f);
        /*SL:1570*/GlStateManager.func_179114_b(RenderUtil.mc.field_71439_g.field_70125_A, (RenderUtil.mc.field_71474_y.field_74320_O == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        /*SL:1571*/GlStateManager.func_179152_a(-0.02666667f, -0.02666667f, 0.02666667f);
    }
    
    public static void glBillboardDistanceScaled(final float a1, final float a2, final float a3, final EntityPlayer a4, final float a5) {
        glBillboard(/*EL:1575*/a1, a2, a3);
        final int v1 = /*EL:1576*/(int)a4.func_70011_f((double)a1, (double)a2, (double)a3);
        float v2 = /*EL:1577*/v1 / 2.0f / (2.0f + (2.0f - a5));
        /*SL:1578*/if (v2 < 1.0f) {
            /*SL:1579*/v2 = 1.0f;
        }
        /*SL:1581*/GlStateManager.func_179152_a(v2, v2, v2);
    }
    
    public static void drawColoredBoundingBox(final AxisAlignedBB a1, final float a2, final float a3, final float a4, final float a5, final float a6) {
        /*SL:1585*/GlStateManager.func_179094_E();
        /*SL:1586*/GlStateManager.func_179147_l();
        /*SL:1587*/GlStateManager.func_179097_i();
        /*SL:1588*/GlStateManager.func_179120_a(770, 771, 0, 1);
        /*SL:1589*/GlStateManager.func_179090_x();
        /*SL:1590*/GlStateManager.func_179132_a(false);
        /*SL:1591*/GL11.glEnable(2848);
        /*SL:1592*/GL11.glHint(3154, 4354);
        /*SL:1593*/GL11.glLineWidth(a2);
        final Tessellator v1 = /*EL:1594*/Tessellator.func_178181_a();
        final BufferBuilder v2 = /*EL:1595*/v1.func_178180_c();
        /*SL:1596*/v2.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        /*SL:1597*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, 0.0f).func_181675_d();
        /*SL:1598*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1599*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1600*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1601*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1602*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1603*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1604*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1605*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1606*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1607*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1608*/v2.func_181662_b(a1.field_72340_a, a1.field_72337_e, a1.field_72334_f).func_181666_a(a3, a4, a5, 0.0f).func_181675_d();
        /*SL:1609*/v2.func_181662_b(a1.field_72340_a, a1.field_72338_b, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1610*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72334_f).func_181666_a(a3, a4, a5, 0.0f).func_181675_d();
        /*SL:1611*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72334_f).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1612*/v2.func_181662_b(a1.field_72336_d, a1.field_72337_e, a1.field_72339_c).func_181666_a(a3, a4, a5, 0.0f).func_181675_d();
        /*SL:1613*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, a6).func_181675_d();
        /*SL:1614*/v2.func_181662_b(a1.field_72336_d, a1.field_72338_b, a1.field_72339_c).func_181666_a(a3, a4, a5, 0.0f).func_181675_d();
        /*SL:1615*/v1.func_78381_a();
        /*SL:1616*/GL11.glDisable(2848);
        /*SL:1617*/GlStateManager.func_179132_a(true);
        /*SL:1618*/GlStateManager.func_179126_j();
        /*SL:1619*/GlStateManager.func_179098_w();
        /*SL:1620*/GlStateManager.func_179084_k();
        /*SL:1621*/GlStateManager.func_179121_F();
    }
    
    public static void drawSphere(final double a1, final double a2, final double a3, final float a4, final int a5, final int a6) {
        final Sphere v1 = /*EL:1625*/new Sphere();
        /*SL:1626*/GL11.glPushMatrix();
        /*SL:1627*/GL11.glBlendFunc(770, 771);
        /*SL:1628*/GL11.glEnable(3042);
        /*SL:1629*/GL11.glLineWidth(1.2f);
        /*SL:1630*/GL11.glDisable(3553);
        /*SL:1631*/GL11.glDisable(2929);
        /*SL:1632*/GL11.glDepthMask(false);
        /*SL:1633*/v1.setDrawStyle(100013);
        /*SL:1634*/GL11.glTranslated(a1 - RenderUtil.mc.field_175616_W.field_78725_b, a2 - RenderUtil.mc.field_175616_W.field_78726_c, a3 - RenderUtil.mc.field_175616_W.field_78723_d);
        /*SL:1635*/v1.draw(a4, a5, a6);
        /*SL:1636*/GL11.glLineWidth(2.0f);
        /*SL:1637*/GL11.glEnable(3553);
        /*SL:1638*/GL11.glEnable(2929);
        /*SL:1639*/GL11.glDepthMask(true);
        /*SL:1640*/GL11.glDisable(3042);
        /*SL:1641*/GL11.glPopMatrix();
    }
    
    public static void drawCompleteImage(final float a1, final float a2, final float a3, final float a4) {
        /*SL:1646*/GL11.glPushMatrix();
        /*SL:1647*/GL11.glTranslatef(a1, a2, 0.0f);
        /*SL:1648*/GL11.glBegin(7);
        /*SL:1649*/GL11.glTexCoord2f(0.0f, 0.0f);
        /*SL:1650*/GL11.glVertex3f(0.0f, 0.0f, 0.0f);
        /*SL:1651*/GL11.glTexCoord2f(0.0f, 1.0f);
        /*SL:1652*/GL11.glVertex3f(0.0f, a4, 0.0f);
        /*SL:1653*/GL11.glTexCoord2f(1.0f, 1.0f);
        /*SL:1654*/GL11.glVertex3f(a3, a4, 0.0f);
        /*SL:1655*/GL11.glTexCoord2f(1.0f, 0.0f);
        /*SL:1656*/GL11.glVertex3f(a3, 0.0f, 0.0f);
        /*SL:1657*/GL11.glEnd();
        /*SL:1658*/GL11.glPopMatrix();
    }
    
    public static void drawOutlineRect(final float a1, final float a2, final float a3, final float a4, final int a5) {
        final float v1 = /*EL:1662*/(a5 >> 24 & 0xFF) / 255.0f;
        final float v2 = /*EL:1663*/(a5 >> 16 & 0xFF) / 255.0f;
        final float v3 = /*EL:1664*/(a5 >> 8 & 0xFF) / 255.0f;
        final float v4 = /*EL:1665*/(a5 & 0xFF) / 255.0f;
        final Tessellator v5 = /*EL:1666*/Tessellator.func_178181_a();
        final BufferBuilder v6 = /*EL:1667*/v5.func_178180_c();
        /*SL:1668*/GlStateManager.func_179147_l();
        /*SL:1669*/GlStateManager.func_179090_x();
        /*SL:1670*/GlStateManager.func_187441_d(1.0f);
        /*SL:1671*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:1672*/v6.func_181668_a(2, DefaultVertexFormats.field_181706_f);
        /*SL:1673*/v6.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1674*/v6.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1675*/v6.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1676*/v6.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1677*/v5.func_78381_a();
        /*SL:1678*/GlStateManager.func_179098_w();
        /*SL:1679*/GlStateManager.func_179084_k();
    }
    
    public static void draw3DRect(final float a1, final float a2, final float a3, final float a4, final Color a5, final Color a6, final float a7) {
        final float v1 = /*EL:1683*/a5.getAlpha() / 255.0f;
        final float v2 = /*EL:1684*/a5.getRed() / 255.0f;
        final float v3 = /*EL:1685*/a5.getGreen() / 255.0f;
        final float v4 = /*EL:1686*/a5.getBlue() / 255.0f;
        final float v5 = /*EL:1687*/a6.getAlpha() / 255.0f;
        final float v6 = /*EL:1688*/a6.getRed() / 255.0f;
        final float v7 = /*EL:1689*/a6.getGreen() / 255.0f;
        final float v8 = /*EL:1690*/a6.getBlue() / 255.0f;
        final Tessellator v9 = /*EL:1691*/Tessellator.func_178181_a();
        final BufferBuilder v10 = /*EL:1692*/v9.func_178180_c();
        /*SL:1693*/GlStateManager.func_179147_l();
        /*SL:1694*/GlStateManager.func_179090_x();
        /*SL:1695*/GlStateManager.func_187441_d(a7);
        /*SL:1696*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:1697*/v10.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        /*SL:1698*/v10.func_181662_b((double)a1, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1699*/v10.func_181662_b((double)a3, (double)a4, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1700*/v10.func_181662_b((double)a3, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1701*/v10.func_181662_b((double)a1, (double)a2, 0.0).func_181666_a(v2, v3, v4, v1).func_181675_d();
        /*SL:1702*/v9.func_78381_a();
        /*SL:1703*/GlStateManager.func_179098_w();
        /*SL:1704*/GlStateManager.func_179084_k();
    }
    
    public static void drawClock(final float a7, final float a8, final float v1, final int v2, final int v3, final float v4, final boolean v5, final Color v6) {
        final Disk v7 = /*EL:1708*/new Disk();
        final Date v8 = /*EL:1709*/new Date();
        final int v9 = /*EL:1710*/180 + -(Calendar.getInstance().get(10) * 30 + Calendar.getInstance().get(12) / 2);
        final int v10 = /*EL:1711*/180 + -(Calendar.getInstance().get(12) * 6 + Calendar.getInstance().get(13) / 10);
        final int v11 = /*EL:1712*/180 + -(Calendar.getInstance().get(13) * 6);
        final int v12 = /*EL:1713*/Calendar.getInstance().get(12);
        final int v13 = /*EL:1714*/Calendar.getInstance().get(10);
        /*SL:1715*/if (v5) {
            /*SL:1716*/GL11.glPushMatrix();
            /*SL:1717*/GL11.glColor4f(v6.getRed() / 255.0f, v6.getGreen() / 255.0f, v6.getBlue() / 255.0f, v6.getAlpha() / 255.0f);
            /*SL:1718*/GL11.glBlendFunc(770, 771);
            /*SL:1719*/GL11.glEnable(3042);
            /*SL:1720*/GL11.glLineWidth(v4);
            /*SL:1721*/GL11.glDisable(3553);
            /*SL:1722*/v7.setOrientation(100020);
            /*SL:1723*/v7.setDrawStyle(100012);
            /*SL:1724*/GL11.glTranslated((double)a7, (double)a8, 0.0);
            /*SL:1725*/v7.draw(0.0f, v1, v2, v3);
            /*SL:1726*/GL11.glEnable(3553);
            /*SL:1727*/GL11.glDisable(3042);
            /*SL:1728*/GL11.glPopMatrix();
        }
        else {
            /*SL:1731*/GL11.glPushMatrix();
            /*SL:1732*/GL11.glColor4f(v6.getRed() / 255.0f, v6.getGreen() / 255.0f, v6.getBlue() / 255.0f, v6.getAlpha() / 255.0f);
            /*SL:1733*/GL11.glEnable(3042);
            /*SL:1734*/GL11.glLineWidth(v4);
            /*SL:1735*/GL11.glDisable(3553);
            /*SL:1736*/GL11.glBegin(3);
            final ArrayList<Vec2f> a9 = /*EL:1737*/new ArrayList<Vec2f>();
            float a10 = /*EL:1738*/System.currentTimeMillis() % 7200L / 7200.0f;
            /*SL:1739*/for (int a11 = 0; a11 <= 360; ++a11) {
                final Vec2f a12 = /*EL:1740*/new Vec2f(a7 + (float)Math.sin(a11 * 3.141592653589793 / 180.0) * v1, a8 + (float)Math.cos(a11 * 3.141592653589793 / 180.0) * v1);
                /*SL:1741*/a9.add(a12);
            }
            Color a13 = /*EL:1743*/new Color(Color.HSBtoRGB(a10, 1.0f, 1.0f));
            /*SL:1744*/for (int a14 = 0; a14 < a9.size() - 1; ++a14) {
                /*SL:1745*/GL11.glColor4f(a13.getRed() / 255.0f, a13.getGreen() / 255.0f, a13.getBlue() / 255.0f, a13.getAlpha() / 255.0f);
                /*SL:1746*/GL11.glVertex3d((double)a9.get(a14).field_189982_i, (double)a9.get(a14).field_189983_j, 0.0);
                /*SL:1747*/GL11.glVertex3d((double)a9.get(a14 + 1).field_189982_i, (double)a9.get(a14 + 1).field_189983_j, 0.0);
                /*SL:1748*/a13 = new Color(Color.HSBtoRGB(a10 += 0.0027777778f, 1.0f, 1.0f));
            }
            /*SL:1750*/GL11.glEnd();
            /*SL:1751*/GL11.glEnable(3553);
            /*SL:1752*/GL11.glDisable(3042);
            /*SL:1753*/GL11.glPopMatrix();
        }
        drawLine(/*EL:1755*/a7, a8, a7 + (float)Math.sin(v9 * 3.141592653589793 / 180.0) * (v1 / 2.0f), a8 + (float)Math.cos(v9 * 3.141592653589793 / 180.0) * (v1 / 2.0f), 1.0f, Color.WHITE.getRGB());
        drawLine(/*EL:1756*/a7, a8, a7 + (float)Math.sin(v10 * 3.141592653589793 / 180.0) * (v1 - v1 / 10.0f), a8 + (float)Math.cos(v10 * 3.141592653589793 / 180.0) * (v1 - v1 / 10.0f), 1.0f, Color.WHITE.getRGB());
        drawLine(/*EL:1757*/a7, a8, a7 + (float)Math.sin(v11 * 3.141592653589793 / 180.0) * (v1 - v1 / 10.0f), a8 + (float)Math.cos(v11 * 3.141592653589793 / 180.0) * (v1 - v1 / 10.0f), 1.0f, Color.RED.getRGB());
    }
    
    public static void GLPre(final float a1) {
        RenderUtil.depth = /*EL:1761*/GL11.glIsEnabled(2896);
        RenderUtil.texture = /*EL:1762*/GL11.glIsEnabled(3042);
        RenderUtil.clean = /*EL:1763*/GL11.glIsEnabled(3553);
        RenderUtil.bind = /*EL:1764*/GL11.glIsEnabled(2929);
        RenderUtil.override = /*EL:1765*/GL11.glIsEnabled(2848);
        GLPre(RenderUtil.depth, RenderUtil.texture, RenderUtil.clean, RenderUtil.bind, RenderUtil.override, /*EL:1766*/a1);
    }
    
    public static void GlPost() {
        GLPost(RenderUtil.depth, RenderUtil.texture, RenderUtil.clean, RenderUtil.bind, RenderUtil.override);
    }
    
    private static void GLPre(final boolean a1, final boolean a2, final boolean a3, final boolean a4, final boolean a5, final float a6) {
        /*SL:1774*/if (a1) {
            /*SL:1775*/GL11.glDisable(2896);
        }
        /*SL:1777*/if (!a2) {
            /*SL:1778*/GL11.glEnable(3042);
        }
        /*SL:1780*/GL11.glLineWidth(a6);
        /*SL:1781*/if (a3) {
            /*SL:1782*/GL11.glDisable(3553);
        }
        /*SL:1784*/if (a4) {
            /*SL:1785*/GL11.glDisable(2929);
        }
        /*SL:1787*/if (!a5) {
            /*SL:1788*/GL11.glEnable(2848);
        }
        /*SL:1790*/GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        /*SL:1791*/GL11.glHint(3154, 4354);
        /*SL:1792*/GlStateManager.func_179132_a(false);
    }
    
    public static float[][] getBipedRotations(final ModelBiped a1) {
        final float[][] v1 = /*EL:1796*/new float[5][];
        final float[] v2 = /*EL:1797*/{ a1.field_78116_c.field_78795_f, a1.field_78116_c.field_78796_g, a1.field_78116_c.field_78808_h };
        /*SL:1798*/v1[0] = v2;
        final float[] v3 = /*EL:1799*/{ a1.field_178723_h.field_78795_f, a1.field_178723_h.field_78796_g, a1.field_178723_h.field_78808_h };
        /*SL:1800*/v1[1] = v3;
        final float[] v4 = /*EL:1801*/{ a1.field_178724_i.field_78795_f, a1.field_178724_i.field_78796_g, a1.field_178724_i.field_78808_h };
        /*SL:1802*/v1[2] = v4;
        final float[] v5 = /*EL:1803*/{ a1.field_178721_j.field_78795_f, a1.field_178721_j.field_78796_g, a1.field_178721_j.field_78808_h };
        /*SL:1804*/v1[3] = v5;
        final float[] v6 = /*EL:1805*/{ a1.field_178722_k.field_78795_f, a1.field_178722_k.field_78796_g, a1.field_178722_k.field_78808_h };
        /*SL:1806*/v1[4] = v6;
        /*SL:1807*/return v1;
    }
    
    private static void GLPost(final boolean a1, final boolean a2, final boolean a3, final boolean a4, final boolean a5) {
        /*SL:1811*/GlStateManager.func_179132_a(true);
        /*SL:1812*/if (!a5) {
            /*SL:1813*/GL11.glDisable(2848);
        }
        /*SL:1815*/if (a4) {
            /*SL:1816*/GL11.glEnable(2929);
        }
        /*SL:1818*/if (a3) {
            /*SL:1819*/GL11.glEnable(3553);
        }
        /*SL:1821*/if (!a2) {
            /*SL:1822*/GL11.glDisable(3042);
        }
        /*SL:1824*/if (a1) {
            /*SL:1825*/GL11.glEnable(2896);
        }
    }
    
    public static void drawArc(final float a4, final float a5, final float a6, final float v1, final float v2, final int v3) {
        /*SL:1830*/GL11.glBegin(4);
        /*SL:1831*/for (int a7 = (int)(v3 / (360.0f / v1)) + 1; a7 <= v3 / (360.0f / v2); ++a7) {
            final double a8 = /*EL:1832*/6.283185307179586 * (a7 - 1) / v3;
            final double a9 = /*EL:1833*/6.283185307179586 * a7 / v3;
            /*SL:1834*/GL11.glVertex2d((double)a4, (double)a5);
            /*SL:1835*/GL11.glVertex2d(a4 + Math.cos(a9) * a6, a5 + Math.sin(a9) * a6);
            /*SL:1836*/GL11.glVertex2d(a4 + Math.cos(a8) * a6, a5 + Math.sin(a8) * a6);
        }
        glEnd();
    }
    
    public static void drawArcOutline(final float a3, final float a4, final float a5, final float a6, final float v1, final int v2) {
        /*SL:1842*/GL11.glBegin(2);
        /*SL:1843*/for (int a7 = (int)(v2 / (360.0f / a6)) + 1; a7 <= v2 / (360.0f / v1); ++a7) {
            final double a8 = /*EL:1844*/6.283185307179586 * a7 / v2;
            /*SL:1845*/GL11.glVertex2d(a3 + Math.cos(a8) * a5, a4 + Math.sin(a8) * a5);
        }
        glEnd();
    }
    
    public static void drawCircleOutline(final float a1, final float a2, final float a3) {
        drawCircleOutline(/*EL:1851*/a1, a2, a3, 0, 360, 40);
    }
    
    public static void drawCircleOutline(final float a1, final float a2, final float a3, final int a4, final int a5, final int a6) {
        drawArcOutline(/*EL:1855*/a1, a2, a3, a4, a5, a6);
    }
    
    public static void drawCircle(final float a1, final float a2, final float a3) {
        drawCircle(/*EL:1859*/a1, a2, a3, 0, 360, 64);
    }
    
    public static void drawCircle(final float a1, final float a2, final float a3, final int a4, final int a5, final int a6) {
        drawArc(/*EL:1863*/a1, a2, a3, a4, a5, a6);
    }
    
    public static void drawOutlinedRoundedRectangle(final int a1, final int a2, final int a3, final int a4, final float a5, final float a6, final float a7, final float a8, final float a9, final float a10) {
        drawRoundedRectangle(/*EL:1867*/a1, a2, a3, a4, a5);
        /*SL:1868*/GL11.glColor4f(a6, a7, a8, a9);
        drawRoundedRectangle(/*EL:1869*/a1 + a10, a2 + a10, a3 - a10 * 2.0f, a4 - a10 * 2.0f, a5);
    }
    
    public static void drawRectangle(final float a1, final float a2, final float a3, final float a4) {
        /*SL:1873*/GL11.glEnable(3042);
        /*SL:1874*/GL11.glBlendFunc(770, 771);
        /*SL:1875*/GL11.glBegin(2);
        /*SL:1876*/GL11.glVertex2d((double)a3, 0.0);
        /*SL:1877*/GL11.glVertex2d(0.0, 0.0);
        /*SL:1878*/GL11.glVertex2d(0.0, (double)a4);
        /*SL:1879*/GL11.glVertex2d((double)a3, (double)a4);
        glEnd();
    }
    
    public static void drawRectangleXY(final float a1, final float a2, final float a3, final float a4) {
        /*SL:1884*/GL11.glEnable(3042);
        /*SL:1885*/GL11.glBlendFunc(770, 771);
        /*SL:1886*/GL11.glBegin(2);
        /*SL:1887*/GL11.glVertex2d((double)(a1 + a3), (double)a2);
        /*SL:1888*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:1889*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
        /*SL:1890*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a4));
        glEnd();
    }
    
    public static void drawFilledRectangle(final float a1, final float a2, final float a3, final float a4) {
        /*SL:1895*/GL11.glEnable(3042);
        /*SL:1896*/GL11.glBlendFunc(770, 771);
        /*SL:1897*/GL11.glBegin(7);
        /*SL:1898*/GL11.glVertex2d((double)(a1 + a3), (double)a2);
        /*SL:1899*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:1900*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
        /*SL:1901*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a4));
        glEnd();
    }
    
    public static Vec3d to2D(final double a1, final double a2, final double a3) {
        /*SL:1906*/GL11.glGetFloat(2982, RenderUtil.modelView);
        /*SL:1907*/GL11.glGetFloat(2983, RenderUtil.projection);
        /*SL:1908*/GL11.glGetInteger(2978, RenderUtil.viewport);
        final boolean v1 = /*EL:1909*/GLU.gluProject((float)a1, (float)a2, (float)a3, RenderUtil.modelView, RenderUtil.projection, RenderUtil.viewport, RenderUtil.screenCoords);
        /*SL:1910*/if (v1) {
            /*SL:1911*/return new Vec3d((double)RenderUtil.screenCoords.get(0), (double)(Display.getHeight() - RenderUtil.screenCoords.get(1)), (double)RenderUtil.screenCoords.get(2));
        }
        /*SL:1913*/return null;
    }
    
    public static void drawTracerPointer(final float a1, final float a2, final float a3, final float a4, final float a5, final boolean a6, final float a7, final int a8) {
        final boolean v1 = /*EL:1917*/GL11.glIsEnabled(3042);
        final float v2 = /*EL:1918*/(a8 >> 24 & 0xFF) / 255.0f;
        /*SL:1919*/GL11.glEnable(3042);
        /*SL:1920*/GL11.glDisable(3553);
        /*SL:1921*/GL11.glBlendFunc(770, 771);
        /*SL:1922*/GL11.glEnable(2848);
        /*SL:1923*/GL11.glPushMatrix();
        hexColor(/*EL:1924*/a8);
        /*SL:1925*/GL11.glBegin(7);
        /*SL:1926*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:1927*/GL11.glVertex2d((double)(a1 - a3 / a4), (double)(a2 + a3));
        /*SL:1928*/GL11.glVertex2d((double)a1, (double)(a2 + a3 / a5));
        /*SL:1929*/GL11.glVertex2d((double)(a1 + a3 / a4), (double)(a2 + a3));
        /*SL:1930*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:1931*/GL11.glEnd();
        /*SL:1932*/if (a6) {
            /*SL:1933*/GL11.glLineWidth(a7);
            /*SL:1934*/GL11.glColor4f(0.0f, 0.0f, 0.0f, v2);
            /*SL:1935*/GL11.glBegin(2);
            /*SL:1936*/GL11.glVertex2d((double)a1, (double)a2);
            /*SL:1937*/GL11.glVertex2d((double)(a1 - a3 / a4), (double)(a2 + a3));
            /*SL:1938*/GL11.glVertex2d((double)a1, (double)(a2 + a3 / a5));
            /*SL:1939*/GL11.glVertex2d((double)(a1 + a3 / a4), (double)(a2 + a3));
            /*SL:1940*/GL11.glVertex2d((double)a1, (double)a2);
            /*SL:1941*/GL11.glEnd();
        }
        /*SL:1943*/GL11.glPopMatrix();
        /*SL:1944*/GL11.glEnable(3553);
        /*SL:1945*/if (!v1) {
            /*SL:1946*/GL11.glDisable(3042);
        }
        /*SL:1948*/GL11.glDisable(2848);
    }
    
    public static int getRainbow(final int a1, final int a2, final float a3, final float a4) {
        float v1 = /*EL:1952*/(System.currentTimeMillis() + a2) % a1;
        /*SL:1953*/return Color.getHSBColor(v1 /= a1, a3, a4).getRGB();
    }
    
    public static void hexColor(final int a1) {
        final float v1 = /*EL:1957*/(a1 >> 16 & 0xFF) / 255.0f;
        final float v2 = /*EL:1958*/(a1 >> 8 & 0xFF) / 255.0f;
        final float v3 = /*EL:1959*/(a1 & 0xFF) / 255.0f;
        final float v4 = /*EL:1960*/(a1 >> 24 & 0xFF) / 255.0f;
        /*SL:1961*/GL11.glColor4f(v1, v2, v3, v4);
    }
    
    public static boolean isInViewFrustrum(final Entity a1) {
        /*SL:1965*/return isInViewFrustrum(a1.func_174813_aQ()) || a1.field_70158_ak;
    }
    
    public static boolean isInViewFrustrum(final AxisAlignedBB a1) {
        final Entity v1 = /*EL:1969*/Minecraft.func_71410_x().func_175606_aa();
        RenderUtil.frustrum.func_78547_a(/*EL:1970*/v1.field_70165_t, v1.field_70163_u, v1.field_70161_v);
        /*SL:1971*/return RenderUtil.frustrum.func_78546_a(a1);
    }
    
    public static void drawRoundedRectangle(final float a1, final float a2, final float a3, final float a4, final float a5) {
        /*SL:1975*/GL11.glEnable(3042);
        drawArc(/*EL:1976*/a1 + a3 - a5, a2 + a4 - a5, a5, 0.0f, 90.0f, 16);
        drawArc(/*EL:1977*/a1 + a5, a2 + a4 - a5, a5, 90.0f, 180.0f, 16);
        drawArc(/*EL:1978*/a1 + a5, a2 + a5, a5, 180.0f, 270.0f, 16);
        drawArc(/*EL:1979*/a1 + a3 - a5, a2 + a5, a5, 270.0f, 360.0f, 16);
        /*SL:1980*/GL11.glBegin(4);
        /*SL:1981*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)a2);
        /*SL:1982*/GL11.glVertex2d((double)(a1 + a5), (double)a2);
        /*SL:1983*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)(a2 + a5));
        /*SL:1984*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)(a2 + a5));
        /*SL:1985*/GL11.glVertex2d((double)(a1 + a5), (double)a2);
        /*SL:1986*/GL11.glVertex2d((double)(a1 + a5), (double)(a2 + a5));
        /*SL:1987*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a5));
        /*SL:1988*/GL11.glVertex2d((double)a1, (double)(a2 + a5));
        /*SL:1989*/GL11.glVertex2d((double)a1, (double)(a2 + a4 - a5));
        /*SL:1990*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a5));
        /*SL:1991*/GL11.glVertex2d((double)a1, (double)(a2 + a4 - a5));
        /*SL:1992*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a4 - a5));
        /*SL:1993*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)(a2 + a4 - a5));
        /*SL:1994*/GL11.glVertex2d((double)(a1 + a5), (double)(a2 + a4 - a5));
        /*SL:1995*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)(a2 + a4));
        /*SL:1996*/GL11.glVertex2d((double)(a1 + a3 - a5), (double)(a2 + a4));
        /*SL:1997*/GL11.glVertex2d((double)(a1 + a5), (double)(a2 + a4 - a5));
        /*SL:1998*/GL11.glVertex2d((double)(a1 + a5), (double)(a2 + a4));
        glEnd();
    }
    
    public static void renderOne(final float a1) {
        checkSetupFBO();
        /*SL:2004*/GL11.glPushAttrib(1048575);
        /*SL:2005*/GL11.glDisable(3008);
        /*SL:2006*/GL11.glDisable(3553);
        /*SL:2007*/GL11.glDisable(2896);
        /*SL:2008*/GL11.glEnable(3042);
        /*SL:2009*/GL11.glBlendFunc(770, 771);
        /*SL:2010*/GL11.glLineWidth(a1);
        /*SL:2011*/GL11.glEnable(2848);
        /*SL:2012*/GL11.glEnable(2960);
        /*SL:2013*/GL11.glClear(1024);
        /*SL:2014*/GL11.glClearStencil(15);
        /*SL:2015*/GL11.glStencilFunc(512, 1, 15);
        /*SL:2016*/GL11.glStencilOp(7681, 7681, 7681);
        /*SL:2017*/GL11.glPolygonMode(1032, 6913);
    }
    
    public static void renderTwo() {
        /*SL:2021*/GL11.glStencilFunc(512, 0, 15);
        /*SL:2022*/GL11.glStencilOp(7681, 7681, 7681);
        /*SL:2023*/GL11.glPolygonMode(1032, 6914);
    }
    
    public static void renderThree() {
        /*SL:2027*/GL11.glStencilFunc(514, 1, 15);
        /*SL:2028*/GL11.glStencilOp(7680, 7680, 7680);
        /*SL:2029*/GL11.glPolygonMode(1032, 6913);
    }
    
    public static void renderFour(final Color a1) {
        setColor(/*EL:2033*/a1);
        /*SL:2034*/GL11.glDepthMask(false);
        /*SL:2035*/GL11.glDisable(2929);
        /*SL:2036*/GL11.glEnable(10754);
        /*SL:2037*/GL11.glPolygonOffset(1.0f, -2000000.0f);
        /*SL:2038*/OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
    }
    
    public static void renderFive() {
        /*SL:2042*/GL11.glPolygonOffset(1.0f, 2000000.0f);
        /*SL:2043*/GL11.glDisable(10754);
        /*SL:2044*/GL11.glEnable(2929);
        /*SL:2045*/GL11.glDepthMask(true);
        /*SL:2046*/GL11.glDisable(2960);
        /*SL:2047*/GL11.glDisable(2848);
        /*SL:2048*/GL11.glHint(3154, 4352);
        /*SL:2049*/GL11.glEnable(3042);
        /*SL:2050*/GL11.glEnable(2896);
        /*SL:2051*/GL11.glEnable(3553);
        /*SL:2052*/GL11.glEnable(3008);
        /*SL:2053*/GL11.glPopAttrib();
    }
    
    public static void setColor(final Color a1) {
        /*SL:2057*/GL11.glColor4d(a1.getRed() / 255.0, a1.getGreen() / 255.0, a1.getBlue() / 255.0, a1.getAlpha() / 255.0);
    }
    
    public static void checkSetupFBO() {
        final Framebuffer v1 = RenderUtil.mc.field_147124_at;
        /*SL:2062*/if (v1 != null && v1.field_147624_h > -1) {
            setupFBO(/*EL:2063*/v1);
            /*SL:2064*/v1.field_147624_h = -1;
        }
    }
    
    private static void setupFBO(final Framebuffer a1) {
        /*SL:2069*/EXTFramebufferObject.glDeleteRenderbuffersEXT(a1.field_147624_h);
        final int v1 = /*EL:2070*/EXTFramebufferObject.glGenRenderbuffersEXT();
        /*SL:2071*/EXTFramebufferObject.glBindRenderbufferEXT(36161, v1);
        /*SL:2072*/EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, RenderUtil.mc.field_71443_c, RenderUtil.mc.field_71440_d);
        /*SL:2073*/EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, v1);
        /*SL:2074*/EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, v1);
    }
    
    static {
        bufferbuilder = Tessellator.func_178181_a().func_178180_c();
        tessellator = Tessellator.func_178181_a();
        RenderUtil.itemRender = RenderUtil.mc.func_175599_af();
        RenderUtil.camera = (ICamera)new Frustum();
        frustrum = new Frustum();
        RenderUtil.depth = GL11.glIsEnabled(2896);
        RenderUtil.texture = GL11.glIsEnabled(3042);
        RenderUtil.clean = GL11.glIsEnabled(3553);
        RenderUtil.bind = GL11.glIsEnabled(2929);
        RenderUtil.override = GL11.glIsEnabled(2848);
        screenCoords = BufferUtils.createFloatBuffer(3);
        viewport = BufferUtils.createIntBuffer(16);
        modelView = BufferUtils.createFloatBuffer(16);
        projection = BufferUtils.createFloatBuffer(16);
    }
}
