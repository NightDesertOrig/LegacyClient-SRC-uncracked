package me.dev.legacy.api.util;

import java.util.Arrays;
import net.minecraft.init.Blocks;
import java.util.Iterator;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Block;
import java.util.List;
import net.minecraft.client.Minecraft;

public class TestUtil
{
    private static final Minecraft mc;
    public static List<Block> emptyBlocks;
    public static List<Block> rightclickableBlocks;
    
    public static boolean canSeeBlock(final BlockPos a1) {
        /*SL:27*/return TestUtil.mc.field_71439_g != null && TestUtil.mc.field_71441_e.func_147447_a(new Vec3d(TestUtil.mc.field_71439_g.field_70165_t, TestUtil.mc.field_71439_g.field_70163_u + TestUtil.mc.field_71439_g.func_70047_e(), TestUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)a1.func_177958_n(), (double)a1.func_177956_o(), (double)a1.func_177952_p()), false, true, false) == null;
    }
    
    public static void placeCrystalOnBlock(final BlockPos a1, final EnumHand a2) {
        final RayTraceResult v1 = TestUtil.mc.field_71441_e.func_72933_a(/*EL:31*/new Vec3d(TestUtil.mc.field_71439_g.field_70165_t, TestUtil.mc.field_71439_g.field_70163_u + TestUtil.mc.field_71439_g.func_70047_e(), TestUtil.mc.field_71439_g.field_70161_v), new Vec3d(a1.func_177958_n() + 0.5, a1.func_177956_o() - 0.5, a1.func_177952_p() + 0.5));
        final EnumFacing v2 = /*EL:32*/(v1 == null || v1.field_178784_b == null) ? EnumFacing.UP : v1.field_178784_b;
        TestUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:33*/(Packet)new CPacketPlayerTryUseItemOnBlock(a1, v2, a2, 0.0f, 0.0f, 0.0f));
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos a1, final boolean a2, final float a3) {
        /*SL:37*/return !a2 || TestUtil.mc.field_71441_e.func_147447_a(new Vec3d(TestUtil.mc.field_71439_g.field_70165_t, TestUtil.mc.field_71439_g.field_70163_u + TestUtil.mc.field_71439_g.func_70047_e(), TestUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)a1.func_177958_n(), (double)(a1.func_177956_o() + a3), (double)a1.func_177952_p()), false, true, false) == null;
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos a1, final boolean a2) {
        /*SL:41*/return rayTracePlaceCheck(a1, a2, 1.0f);
    }
    
    public static void openBlock(final BlockPos v-4) {
        final EnumFacing[] values;
        final EnumFacing[] array = /*EL:46*/values = EnumFacing.values();
        for (final EnumFacing v1 : values) {
            final Block a1 = TestUtil.mc.field_71441_e.func_180495_p(/*EL:47*/v-4.func_177972_a(v1)).func_177230_c();
            /*SL:48*/if (TestUtil.emptyBlocks.contains(a1)) {
                TestUtil.mc.field_71442_b.func_187099_a(TestUtil.mc.field_71439_g, TestUtil.mc.field_71441_e, /*EL:49*/v-4, v1.func_176734_d(), new Vec3d((Vec3i)v-4), EnumHand.MAIN_HAND);
                /*SL:50*/return;
            }
        }
    }
    
    public static boolean placeBlock(final BlockPos v-6) {
        /*SL:55*/if (isBlockEmpty(v-6)) {
            final EnumFacing[] values;
            final EnumFacing[] array = /*EL:57*/values = EnumFacing.values();
            for (final EnumFacing enumFacing : values) {
                final Block a1 = TestUtil.mc.field_71441_e.func_180495_p(/*EL:58*/v-6.func_177972_a(enumFacing)).func_177230_c();
                final Vec3d v1 = /*EL:59*/new Vec3d(v-6.func_177958_n() + 0.5 + enumFacing.func_82601_c() * 0.5, v-6.func_177956_o() + 0.5 + enumFacing.func_96559_d() * 0.5, v-6.func_177952_p() + 0.5 + enumFacing.func_82599_e() * 0.5);
                if (!TestUtil.emptyBlocks.contains(/*EL:60*/a1) && TestUtil.mc.field_71439_g.func_174824_e(TestUtil.mc.func_184121_ak()).func_72438_d(v1) <= 4.25) {
                    final float[] v2 = /*EL:62*/{ TestUtil.mc.field_71439_g.field_70177_z, TestUtil.mc.field_71439_g.field_70125_A };
                    /*SL:63*/if (TestUtil.rightclickableBlocks.contains(a1)) {
                        TestUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:64*/(Packet)new CPacketEntityAction((Entity)TestUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                    }
                    TestUtil.mc.field_71442_b.func_187099_a(TestUtil.mc.field_71439_g, TestUtil.mc.field_71441_e, /*EL:66*/v-6.func_177972_a(enumFacing), enumFacing.func_176734_d(), new Vec3d((Vec3i)v-6), EnumHand.MAIN_HAND);
                    /*SL:67*/if (TestUtil.rightclickableBlocks.contains(a1)) {
                        TestUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:68*/(Packet)new CPacketEntityAction((Entity)TestUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                    }
                    TestUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    /*SL:71*/return true;
                }
            }
        }
        /*SL:74*/return false;
    }
    
    public static boolean isBlockEmpty(final BlockPos v-1) {
        try {
            /*SL:79*/if (TestUtil.emptyBlocks.contains(TestUtil.mc.field_71441_e.func_180495_p(v-1).func_177230_c())) {
                final AxisAlignedBB v1 = /*EL:81*/new AxisAlignedBB(v-1);
                final Iterator v2 = TestUtil.mc.field_71441_e.field_72996_f.iterator();
                /*SL:84*/while (v2.hasNext()) {
                    final Entity a1;
                    /*SL:86*/if ((a1 = v2.next()) instanceof EntityLivingBase && v1.func_72326_a(a1.func_174813_aQ())) {
                        return /*EL:91*/false;
                    }
                }
                return true;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static boolean canPlaceBlock(final BlockPos v-4) {
        /*SL:95*/if (isBlockEmpty(v-4)) {
            final EnumFacing[] values;
            final EnumFacing[] array = /*EL:97*/values = EnumFacing.values();
            for (final EnumFacing v1 : values) {
                /*SL:98*/if (!TestUtil.emptyBlocks.contains(TestUtil.mc.field_71441_e.func_180495_p(v-4.func_177972_a(v1)).func_177230_c())) {
                    final Vec3d a1 = /*EL:99*/new Vec3d(v-4.func_177958_n() + 0.5 + v1.func_82601_c() * 0.5, v-4.func_177956_o() + 0.5 + v1.func_96559_d() * 0.5, v-4.func_177952_p() + 0.5 + v1.func_82599_e() * 0.5);
                    /*SL:100*/if (TestUtil.mc.field_71439_g.func_174824_e(TestUtil.mc.func_184121_ak()).func_72438_d(a1) <= 4.25) {
                        /*SL:102*/return true;
                    }
                }
            }
        }
        /*SL:105*/return false;
    }
    
    static {
        mc = Minecraft.func_71410_x();
        TestUtil.emptyBlocks = Arrays.<Block>asList(Blocks.field_150350_a, Blocks.field_150356_k, Blocks.field_150353_l, Blocks.field_150358_i, Blocks.field_150355_j, Blocks.field_150395_bd, Blocks.field_150431_aC, Blocks.field_150329_H, Blocks.field_150480_ab);
        TestUtil.rightclickableBlocks = Arrays.<Block>asList(Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150477_bB, Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA, Blocks.field_150467_bQ, Blocks.field_150471_bO, Blocks.field_150430_aB, Blocks.field_150441_bU, Blocks.field_150413_aR, Blocks.field_150416_aS, Blocks.field_150455_bV, Blocks.field_180390_bo, Blocks.field_180391_bp, Blocks.field_180392_bq, Blocks.field_180386_br, Blocks.field_180385_bs, Blocks.field_180387_bt, Blocks.field_150382_bo, Blocks.field_150367_z, Blocks.field_150409_cd, Blocks.field_150442_at, Blocks.field_150323_B, Blocks.field_150421_aI, Blocks.field_150461_bJ, Blocks.field_150324_C, Blocks.field_150460_al, Blocks.field_180413_ao, Blocks.field_180414_ap, Blocks.field_180412_aq, Blocks.field_180411_ar, Blocks.field_180410_as, Blocks.field_180409_at, Blocks.field_150414_aQ, Blocks.field_150381_bn, Blocks.field_150380_bt, Blocks.field_150438_bZ, Blocks.field_185776_dc, Blocks.field_150483_bI, Blocks.field_185777_dd, Blocks.field_150462_ai);
    }
}
