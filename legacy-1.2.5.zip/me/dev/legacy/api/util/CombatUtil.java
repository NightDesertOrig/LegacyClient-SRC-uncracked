package me.dev.legacy.api.util;

import java.util.Arrays;
import net.minecraft.init.MobEffects;
import net.minecraft.util.math.MathHelper;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.util.CombatRules;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.Explosion;
import net.minecraft.entity.EntityLivingBase;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.util.math.RayTraceResult;
import java.util.ArrayList;
import me.dev.legacy.Legacy;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.init.Blocks;
import java.util.Iterator;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockAir;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.item.Item;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Block;
import java.util.List;

public class CombatUtil
{
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    private static Minecraft mc;
    public static final Vec3d[] cityOffsets;
    private static final List<Integer> invalidSlots;
    
    public static int findCrapple() {
        /*SL:59*/if (CombatUtil.mc.field_71439_g == null) {
            /*SL:60*/return -1;
        }
        /*SL:62*/for (int v0 = 0; v0 < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++v0) {
            /*SL:63*/if (!CombatUtil.invalidSlots.contains(v0)) {
                final ItemStack v = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(/*EL:66*/v0);
                /*SL:67*/if (!v.func_190926_b()) {
                    /*SL:70*/if (v.func_77973_b().equals(Items.field_151153_ao) && v.func_77952_i() != 1) {
                        /*SL:71*/return v0;
                    }
                }
            }
        }
        /*SL:74*/return -1;
    }
    
    public static int findItemSlotDamage1(final Item v0) {
        /*SL:78*/if (CombatUtil.mc.field_71439_g == null) {
            /*SL:79*/return -1;
        }
        /*SL:81*/for (int v = 0; v < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++v) {
            /*SL:82*/if (!CombatUtil.invalidSlots.contains(v)) {
                final ItemStack a1 = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(/*EL:85*/v);
                /*SL:86*/if (!a1.func_190926_b()) {
                    /*SL:89*/if (a1.func_77973_b().equals(v0) && a1.func_77952_i() == 1) {
                        /*SL:90*/return v;
                    }
                }
            }
        }
        /*SL:93*/return -1;
    }
    
    public static int findItemSlot(final Item v0) {
        /*SL:97*/if (CombatUtil.mc.field_71439_g == null) {
            /*SL:98*/return -1;
        }
        /*SL:100*/for (int v = 0; v < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++v) {
            /*SL:101*/if (!CombatUtil.invalidSlots.contains(v)) {
                final ItemStack a1 = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(/*EL:104*/v);
                /*SL:105*/if (!a1.func_190926_b()) {
                    /*SL:108*/if (a1.func_77973_b().equals(v0)) {
                        /*SL:109*/return v;
                    }
                }
            }
        }
        /*SL:112*/return -1;
    }
    
    public static boolean isHoldingCrystal(final boolean a1) {
        /*SL:116*/if (a1) {
            /*SL:117*/return CombatUtil.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP;
        }
        /*SL:119*/return CombatUtil.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP || CombatUtil.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
    }
    
    public static boolean requiredDangerSwitch(final double a1) {
        final int v1 = (int)CombatUtil.mc.field_71441_e.field_72996_f.stream().filter(/*EL:124*/a1 -> a1 instanceof EntityEnderCrystal).filter(/*EL:125*/a2 -> CombatUtil.mc.field_71439_g.func_70032_d(a2) <= a1).filter(/*EL:126*/a1 -> calculateDamage(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v, (Entity)CombatUtil.mc.field_71439_g) >= CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj()).count();
        /*SL:129*/return v1 > 0;
    }
    
    public static boolean passesOffhandCheck(final double a1, final Item a2, final boolean a3) {
        final double v1 = CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        /*SL:134*/if (!a3) {
            /*SL:135*/if (findItemSlot(a2) == -1) {
                /*SL:136*/return false;
            }
        }
        else/*SL:139*/ if (findCrapple() == -1) {
            /*SL:140*/return false;
        }
        /*SL:143*/return v1 >= a1;
    }
    
    public static void switchOffhandStrict(final int a1, final int a2) {
        /*SL:150*/switch (a2) {
            case 0: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:152*/a1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                /*SL:153*/break;
            }
            case 1: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:155*/45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                /*SL:156*/break;
            }
            case 2: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:158*/a1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                CombatUtil.mc.field_71442_b.func_78765_e();
                break;
            }
        }
    }
    
    public static void switchOffhandTotemNotStrict() {
        final int v1 = findItemSlot(Items.field_190929_cY);
        /*SL:166*/if (v1 != -1) {
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:167*/v1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:168*/45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:169*/v1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_78765_e();
        }
    }
    
    public static void switchOffhandNonStrict(final int a1) {
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:175*/a1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:176*/45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, /*EL:177*/a1, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_78765_e();
    }
    
    public static boolean canSeeBlock(final BlockPos a1) {
        /*SL:182*/return CombatUtil.mc.field_71441_e.func_147447_a(new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)a1.func_177958_n(), (double)(a1.func_177956_o() + 1.0f), (double)a1.func_177952_p()), false, true, false) == null;
    }
    
    public static boolean placeBlock(final BlockPos a2, final boolean a3, final boolean a4, final boolean a5, final boolean a6, final boolean a7, final int v1) {
        /*SL:187*/if (!checkCanPlace(a2)) {
            /*SL:188*/return false;
        }
        final EnumFacing v2 = getPlaceSide(/*EL:191*/a2);
        final BlockPos v3 = /*EL:192*/a2.func_177972_a(v2);
        final EnumFacing v4 = /*EL:193*/v2.func_176734_d();
        /*SL:194*/if (!CombatUtil.mc.field_71441_e.func_180495_p(v3).func_177230_c().func_176209_a(CombatUtil.mc.field_71441_e.func_180495_p(v3), false)) {
            /*SL:195*/return false;
        }
        /*SL:197*/if (a6) {
            /*SL:198*/if (a7) {
                CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:199*/(Packet)new CPacketHeldItemChange(v1));
            }
            else/*SL:201*/ if (CombatUtil.mc.field_71439_g.field_71071_by.field_70461_c != v1) {
                CombatUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:202*/v1;
            }
        }
        boolean v5 = /*EL:206*/false;
        /*SL:207*/if (CombatUtil.blackList.contains(CombatUtil.mc.field_71441_e.func_180495_p(v3).func_177230_c()) || CombatUtil.shulkerList.contains(CombatUtil.mc.field_71441_e.func_180495_p(v3).func_177230_c())) {
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:208*/(Packet)new CPacketEntityAction((Entity)CombatUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            /*SL:209*/v5 = true;
        }
        final Vec3d v6 = getHitVector(/*EL:211*/v3, v4);
        /*SL:212*/if (a4) {
            final float[] a8 = getLegitRotations(/*EL:213*/v6);
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:214*/(Packet)new CPacketPlayer.Rotation(a8[0], a8[1], CombatUtil.mc.field_71439_g.field_70122_E));
        }
        final EnumHand v7 = /*EL:217*/a3 ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
        CombatUtil.mc.field_71442_b.func_187099_a(CombatUtil.mc.field_71439_g, CombatUtil.mc.field_71441_e, /*EL:218*/v3, v4, v6, v7);
        CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:219*/(Packet)new CPacketAnimation(v7));
        /*SL:220*/if (v5) {
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:221*/(Packet)new CPacketEntityAction((Entity)CombatUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
        /*SL:223*/return true;
    }
    
    private static Vec3d getHitVector(final BlockPos a1, final EnumFacing a2) {
        /*SL:227*/return new Vec3d((Vec3i)a1).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(a2.func_176730_m()).func_186678_a(0.5));
    }
    
    public static Vec3d getHitAddition(final double a1, final double a2, final double a3, final BlockPos a4, final EnumFacing a5) {
        /*SL:231*/return new Vec3d((Vec3i)a4).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(a5.func_176730_m()).func_186678_a(0.5));
    }
    
    public static void betterRotate(final BlockPos a1, final EnumFacing a2, final boolean a3) {
        float v3;
        float v2 = /*EL:237*/v2 = (v3 = 0.0f);
        /*SL:238*/switch (getPlaceSide(a1)) {
            case UP: {
                /*SL:240*/v3 = (v2 = 0.5f);
                /*SL:241*/v2 = 0.0f;
                /*SL:242*/break;
            }
            case DOWN: {
                /*SL:244*/v3 = (v2 = 0.5f);
                /*SL:245*/v2 = -0.5f;
                /*SL:246*/break;
            }
            case NORTH: {
                /*SL:248*/v2 = 0.5f;
                /*SL:249*/v2 = -0.5f;
                /*SL:250*/v3 = -0.5f;
                /*SL:251*/break;
            }
            case EAST: {
                /*SL:253*/v2 = 0.5f;
                /*SL:254*/v2 = -0.5f;
                /*SL:255*/v3 = 0.5f;
                /*SL:256*/break;
            }
            case SOUTH: {
                /*SL:258*/v2 = 0.5f;
                /*SL:259*/v2 = -0.5f;
                /*SL:260*/v3 = 0.5f;
                /*SL:261*/break;
            }
            case WEST: {
                /*SL:263*/v2 = -0.5f;
                /*SL:264*/v2 = -0.5f;
                /*SL:265*/v3 = 0.5f;
                break;
            }
        }
        final float[] v4 = getLegitRotations(getHitAddition(/*EL:268*/v2, v2, v3, a1, a2));
        CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:269*/(Packet)new CPacketPlayer.Rotation(v4[0], v4[1], CombatUtil.mc.field_71439_g.field_70122_E));
    }
    
    private static EnumFacing getPlaceSide(final BlockPos v-4) {
        EnumFacing enumFacing = /*EL:279*/null;
        /*SL:280*/for (final EnumFacing v1 : EnumFacing.values()) {
            final BlockPos a1 = /*EL:281*/v-4.func_177972_a(v1);
            /*SL:282*/if (CombatUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c().func_176209_a(CombatUtil.mc.field_71441_e.func_180495_p(a1), false) && !CombatUtil.mc.field_71441_e.func_180495_p(a1).func_185904_a().func_76222_j()) {
                /*SL:283*/enumFacing = v1;
            }
        }
        /*SL:286*/return enumFacing;
    }
    
    public static boolean checkCanPlace(final BlockPos v1) {
        /*SL:290*/if (!(CombatUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() instanceof BlockAir) && !(CombatUtil.mc.field_71441_e.func_180495_p(v1).func_177230_c() instanceof BlockLiquid)) {
            /*SL:291*/return false;
        }
        /*SL:293*/for (final Entity a1 : CombatUtil.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(v1))) {
            /*SL:294*/if (!(a1 instanceof EntityItem) && !(a1 instanceof EntityXPOrb) && !(a1 instanceof EntityArrow)) {
                /*SL:295*/return false;
            }
        }
        /*SL:298*/return getPlaceSide(v1) != null;
    }
    
    public static boolean isInCity(final EntityPlayer a4, final double a5, final double a6, final boolean a7, final boolean v1, final boolean v2, final boolean v3) {
        final BlockPos v4 = /*EL:302*/new BlockPos(a4.func_174791_d());
        /*SL:303*/for (final EnumFacing a8 : EnumFacing.values()) {
            /*SL:307*/if (a8 != EnumFacing.UP) {
                if (a8 != EnumFacing.DOWN) {
                    final BlockPos a9 = /*EL:308*/v4.func_177972_a(a8);
                    final BlockPos a10 = /*EL:309*/a9.func_177972_a(a8);
                    /*SL:313*/if ((CombatUtil.mc.field_71441_e.func_180495_p(a9).func_177230_c() == Blocks.field_150350_a && ((CombatUtil.mc.field_71441_e.func_180495_p(a10).func_177230_c() == Blocks.field_150350_a && isHard(CombatUtil.mc.field_71441_e.func_180495_p(a10.func_177984_a()).func_177230_c())) || !a7) && !v3) || (CombatUtil.mc.field_71439_g.func_174818_b(a10) <= a6 * a6 && CombatUtil.mc.field_71439_g.func_70068_e((Entity)a4) <= a5 * a5 && isHard(CombatUtil.mc.field_71441_e.func_180495_p(v4.func_177981_b(3)).func_177230_c())) || /*EL:314*/!v1) {
                        /*SL:315*/return true;
                    }
                }
            }
        }
        /*SL:318*/return false;
    }
    
    public static boolean isHard(final Block a1) {
        /*SL:322*/return a1 == Blocks.field_150343_Z || a1 == Blocks.field_150357_h;
    }
    
    public static boolean canLegPlace(final EntityPlayer v1, final double v2) {
        int v3 = /*EL:326*/0;
        int v4 = /*EL:327*/0;
        /*SL:328*/for (BlockPos a2 : HoleUtil.cityOffsets) {
            /*SL:329*/a2 = getFlooredPosition((Entity)v1).func_177963_a(a2.field_72450_a, a2.field_72448_b, a2.field_72449_c);
            /*SL:330*/if (CombatUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c() == Blocks.field_150343_Z || CombatUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c() == Blocks.field_150357_h) {
                /*SL:332*/++v3;
            }
            /*SL:334*/if (CombatUtil.mc.field_71439_g.func_174818_b(a2) >= v2 * v2) {
                /*SL:335*/++v4;
            }
        }
        /*SL:338*/return v3 == 4 && v4 >= 1;
    }
    
    public static int getSafetyFactor(final BlockPos a1) {
        /*SL:342*/return 0;
    }
    
    public static boolean canPlaceCrystal(final BlockPos a1, final double a2, final double a3, final boolean a4) {
        final BlockPos v1 = /*EL:346*/a1.func_177984_a();
        final BlockPos v2 = /*EL:347*/v1.func_177984_a();
        final AxisAlignedBB v3 = /*EL:348*/new AxisAlignedBB(v1).func_72321_a(0.0, 1.0, 0.0);
        /*SL:349*/return ((CombatUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() == Blocks.field_150343_Z || CombatUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c() == Blocks.field_150357_h) && CombatUtil.mc.field_71441_e.func_180495_p(/*EL:350*/v1).func_177230_c() == Blocks.field_150350_a && CombatUtil.mc.field_71441_e.func_180495_p(/*EL:351*/v2).func_177230_c() == Blocks.field_150350_a && CombatUtil.mc.field_71441_e.func_72872_a(/*EL:352*/(Class)Entity.class, v3).isEmpty() && CombatUtil.mc.field_71439_g.func_174818_b(/*EL:353*/a1) <= /*EL:354*/a2 * a2 && !a4) || rayTraceRangeCheck(a1, a3, 0.0);
    }
    
    public static int getVulnerability(final EntityPlayer a1, final double a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8, final double a9, final int a10, final boolean a11, final boolean a12, final boolean a13, final boolean a14, final boolean a15) {
        /*SL:359*/if (isInCity(a1, a2, a3, true, true, true, false) && a11) {
            return 5;
        }
        /*SL:360*/if (getClosestValidPos(a1, a5, a6, a7, a3, a4, a8, a12, a14, a15, true) != null) {
            return 4;
        }
        /*SL:361*/if (a1.func_110143_aJ() + a1.func_110139_bj() <= a9) {
            return 3;
        }
        /*SL:362*/if (isArmorLow(a1, a10, true) && a13) {
            return 2;
        }
        /*SL:363*/return 0;
    }
    
    public static Map<BlockPos, Double> mapBlockDamage(final EntityPlayer a3, final double a4, final double a5, final double a6, final double a7, final double a8, final double a9, final boolean a10, final boolean v1, final boolean v2) {
        final Map<BlockPos, Double> v3 = /*EL:367*/new HashMap<BlockPos, Double>();
        /*SL:368*/for (final BlockPos a11 : getSphere(new BlockPos((Vec3i)getFlooredPosition((Entity)CombatUtil.mc.field_71439_g)), (float)a7, (int)a7, false, true, 0)) {
            /*SL:369*/if (!canPlaceCrystal(a11, a7, a8, a10)) {
                continue;
            }
            /*SL:370*/if (!checkFriends(a11, a5, a9, v2)) {
                continue;
            }
            /*SL:371*/if (!checkSelf(a11, a4, v1)) {
                continue;
            }
            /*SL:372*/if (a10 && !rayTraceRangeCheck(a11, a8, 0.0)) {
                continue;
            }
            final double a12 = calculateDamage(/*EL:373*/a11, (Entity)a3);
            /*SL:374*/if (a12 < a6) {
                continue;
            }
            /*SL:375*/v3.put(a11, a12);
        }
        /*SL:377*/return v3;
    }
    
    public static boolean checkFriends(final BlockPos a2, final double a3, final double a4, final boolean v1) {
        /*SL:381*/for (final EntityPlayer a5 : CombatUtil.mc.field_71441_e.field_73010_i) {
            /*SL:382*/if (CombatUtil.mc.field_71439_g.func_70068_e((Entity)a5) > a4 * a4) {
                continue;
            }
            /*SL:383*/if (calculateDamage(a2, (Entity)a5) > a3) {
                /*SL:384*/return false;
            }
            /*SL:386*/if (calculateDamage(a2, (Entity)a5) > a5.func_110143_aJ() + a5.func_110139_bj() && v1) {
                /*SL:387*/return false;
            }
        }
        /*SL:390*/return true;
    }
    
    public static boolean checkFriends(final EntityEnderCrystal a2, final double a3, final double a4, final boolean v1) {
        /*SL:394*/for (final EntityPlayer a5 : CombatUtil.mc.field_71441_e.field_73010_i) {
            /*SL:395*/if (CombatUtil.mc.field_71439_g.func_70068_e((Entity)a5) > a4 * a4) {
                continue;
            }
            /*SL:396*/if (calculateDamage((Entity)a2, (Entity)a5) > a3) {
                /*SL:397*/return false;
            }
            /*SL:399*/if (calculateDamage((Entity)a2, (Entity)a5) > a5.func_110143_aJ() + a5.func_110139_bj() && v1) {
                /*SL:400*/return false;
            }
        }
        /*SL:403*/return true;
    }
    
    public static boolean checkSelf(final BlockPos a1, final double a2, final boolean a3) {
        final boolean v1 = calculateDamage(/*EL:407*/a1, (Entity)CombatUtil.mc.field_71439_g) > CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        final boolean v2 = calculateDamage(/*EL:408*/a1, (Entity)CombatUtil.mc.field_71439_g) > a2;
        /*SL:409*/return (!a3 || !v1) && !v2;
    }
    
    public static boolean checkSelf(final EntityEnderCrystal a1, final double a2, final boolean a3) {
        final boolean v1 = calculateDamage(/*EL:413*/(Entity)a1, (Entity)CombatUtil.mc.field_71439_g) > CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        final boolean v2 = calculateDamage(/*EL:414*/(Entity)a1, (Entity)CombatUtil.mc.field_71439_g) > a2;
        /*SL:415*/return (!a3 || !v1) && !v2;
    }
    
    public static boolean isPosValid(final EntityPlayer a1, final BlockPos a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8, final boolean a9, final boolean a10, final boolean a11) {
        /*SL:419*/if (a2 == null) {
            return false;
        }
        /*SL:420*/if (!isHard(CombatUtil.mc.field_71441_e.func_180495_p(a2).func_177230_c())) {
            return false;
        }
        /*SL:421*/if (!canPlaceCrystal(a2, a6, a7, a9)) {
            return false;
        }
        /*SL:422*/if (!checkFriends(a2, a4, a8, a11)) {
            return false;
        }
        /*SL:423*/if (!checkSelf(a2, a3, a10)) {
            return false;
        }
        final double v1 = calculateDamage(/*EL:424*/a2, (Entity)a1);
        /*SL:425*/return v1 >= a5 && /*EL:426*/(!a9 || rayTraceRangeCheck(a2, a7, 0.0));
    }
    
    public static BlockPos getClosestValidPos(final EntityPlayer a3, final double a4, final double a5, final double a6, final double a7, final double a8, final double a9, final boolean a10, final boolean a11, final boolean v1, final boolean v2) {
        double v3 = /*EL:431*/-1.0;
        BlockPos v4 = /*EL:432*/null;
        /*SL:433*/if (a3 == null) {
            return null;
        }
        final List<BlockPos> v5 = getSphere(/*EL:434*/new BlockPos((Vec3i)getFlooredPosition((Entity)CombatUtil.mc.field_71439_g)), (float)a7, (int)a7, false, true, 0);
        /*SL:435*/v5.sort(Comparator.<? super BlockPos, Comparable>comparing(a1 -> CombatUtil.mc.field_71439_g.func_174818_b(a1)));
        /*SL:436*/for (final BlockPos a12 : v5) {
            /*SL:437*/if (!canPlaceCrystal(a12, a7, a8, a10)) {
                continue;
            }
            /*SL:438*/if (a10 && !rayTraceRangeCheck(a12, a8, 0.0)) {
                continue;
            }
            final double a13 = calculateDamage(/*EL:439*/a12, (Entity)a3);
            /*SL:440*/if (a13 < a6) {
                continue;
            }
            /*SL:441*/if (!checkFriends(a12, a5, a9, v1)) {
                continue;
            }
            /*SL:442*/if (!checkSelf(a12, a4, a11)) {
                continue;
            }
            /*SL:443*/if (a13 > 15.0) {
                return a12;
            }
            /*SL:444*/if (a13 <= v3) {
                continue;
            }
            /*SL:445*/v3 = a13;
            /*SL:446*/v4 = a12;
        }
        /*SL:449*/return v4;
    }
    
    public static BlockPos getClosestValidPosMultiThread(final EntityPlayer a4, final double a5, final double a6, final double a7, final double a8, final double a9, final double a10, final boolean v1, final boolean v2, final boolean v3) {
        final List<ValidPosThread> v4 = /*EL:454*/new CopyOnWriteArrayList<ValidPosThread>();
        BlockPos v5 = /*EL:455*/null;
        /*SL:457*/for (final BlockPos a11 : getSphere(new BlockPos(a4.func_174791_d()), 13.0f, 13, false, true, 0)) {
            final ValidPosThread a12 = /*EL:458*/new ValidPosThread(a4, a11, a5, a6, a7, a8, a9, a10, v1, v2, v3);
            /*SL:459*/v4.add(a12);
            /*SL:460*/a12.start();
        }
        boolean v6 = /*EL:463*/false;
        /*SL:474*/do {
            for (final ValidPosThread a13 : v4) {
                if (a13.isInterrupted() && a13.isValid) {
                    v5 = a13.pos;
                }
            }
            v6 = v4.stream().noneMatch(a1 -> a1.isValid && a1.isInterrupted());
        } while (v5 == null && !v6);
        Legacy.LOGGER.info(/*EL:476*/(v5 == null) ? "pos was null" : v5.toString());
        /*SL:477*/return v5;
    }
    
    public static List<BlockPos> getSphere(final BlockPos a6, final float v1, final int v2, final boolean v3, final boolean v4, final int v5) {
        final List<BlockPos> v6 = /*EL:553*/new ArrayList<BlockPos>();
        final int v7 = /*EL:554*/a6.func_177958_n();
        final int v8 = /*EL:555*/a6.func_177956_o();
        final int v9 = /*EL:556*/a6.func_177952_p();
        /*SL:557*/for (int a7 = v7 - (int)v1; a7 <= v7 + v1; ++a7) {
            /*SL:558*/for (int a8 = v9 - (int)v1; a8 <= v9 + v1; ++a8) {
                /*SL:559*/for (int a9 = v4 ? (v8 - (int)v1) : v8; a9 < (v4 ? (v8 + v1) : (v8 + v2)); ++a9) {
                    final double a10 = /*EL:560*/(v7 - a7) * (v7 - a7) + (v9 - a8) * (v9 - a8) + (v4 ? ((v8 - a9) * (v8 - a9)) : 0);
                    /*SL:561*/if (a10 < v1 * v1 && (!v3 || a10 >= (v1 - 1.0f) * (v1 - 1.0f))) {
                        final BlockPos a11 = /*EL:562*/new BlockPos(a7, a9 + v5, a8);
                        /*SL:563*/v6.add(a11);
                    }
                }
            }
        }
        /*SL:568*/return v6;
    }
    
    public static boolean isArmorLow(final EntityPlayer a2, final int a3, final boolean v1) {
        /*SL:572*/for (final ItemStack a4 : a2.field_71071_by.field_70460_b) {
            /*SL:573*/if (a4 == null) {
                /*SL:574*/return true;
            }
            /*SL:575*/if (v1 && getItemDamage(/*EL:576*/a4) < a3) {
                /*SL:577*/return true;
            }
        }
        /*SL:581*/return false;
    }
    
    public static int getItemDamage(final ItemStack a1) {
        /*SL:585*/return a1.func_77958_k() - a1.func_77952_i();
    }
    
    public static boolean rayTraceRangeCheck(final Entity a1, final double a2) {
        final boolean v1 = CombatUtil.mc.field_71439_g.func_70685_l(/*EL:590*/a1);
        /*SL:591*/return !v1 || CombatUtil.mc.field_71439_g.func_70068_e(a1) <= a2 * a2;
    }
    
    public static boolean rayTraceRangeCheck(final BlockPos a1, final double a2, final double a3) {
        final RayTraceResult v1 = CombatUtil.mc.field_71441_e.func_147447_a(/*EL:595*/new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)a1.func_177958_n(), a1.func_177956_o() + a3, (double)a1.func_177952_p()), false, true, false);
        /*SL:596*/return v1 == null || CombatUtil.mc.field_71439_g.func_174818_b(a1) <= a2 * a2;
    }
    
    public static EntityEnderCrystal getClosestValidCrystal(final EntityPlayer a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8, final boolean a9, final boolean a10, final boolean v1) {
        /*SL:601*/if (a2 == null) {
            return null;
        }
        final List<EntityEnderCrystal> v2 = (List<EntityEnderCrystal>)CombatUtil.mc.field_71441_e.field_72996_f.stream().filter(/*EL:603*/a1 -> a1 instanceof EntityEnderCrystal).filter(/*EL:604*/a2 -> CombatUtil.mc.field_71439_g.func_70068_e(a2) <= a6 * a6).sorted(/*EL:606*/Comparator.<? super T>comparingDouble(a1 -> CombatUtil.mc.field_71439_g.func_70068_e(a1))).map(a1 -> a1).collect(/*EL:608*/Collectors.<Object>toList());
        /*SL:609*/for (final EntityEnderCrystal a11 : v2) {
            /*SL:611*/if (a9 && !rayTraceRangeCheck((Entity)a11, a7)) {
                continue;
            }
            /*SL:612*/if (calculateDamage((Entity)a11, (Entity)a2) < a5) {
                continue;
            }
            /*SL:613*/if (!checkSelf(a11, a3, a10)) {
                continue;
            }
            /*SL:614*/if (!checkFriends(a11, a4, a8, v1)) {
                continue;
            }
            /*SL:615*/return a11;
        }
        /*SL:617*/return null;
    }
    
    public static List<BlockPos> getDisc(final BlockPos v-6, final float v-5) {
        final List<BlockPos> list = /*EL:621*/new ArrayList<BlockPos>();
        final int func_177958_n = /*EL:622*/v-6.func_177958_n();
        final int func_177956_o = /*EL:623*/v-6.func_177956_o();
        final int func_177952_p = /*EL:624*/v-6.func_177952_p();
        /*SL:626*/for (int v0 = func_177958_n - (int)v-5; v0 <= func_177958_n + v-5; ++v0) {
            /*SL:627*/for (int v = func_177952_p - (int)v-5; v <= func_177952_p + v-5; ++v) {
                double a2 = /*EL:628*/(func_177958_n - v0) * (func_177958_n - v0) + (func_177952_p - v) * (func_177952_p - v);
                /*SL:629*/if (a2 < v-5 * v-5) {
                    /*SL:630*/a2 = new BlockPos(v0, func_177956_o, v);
                    /*SL:631*/list.add(a2);
                }
            }
        }
        /*SL:636*/return list;
    }
    
    public static BlockPos getFlooredPosition(final Entity a1) {
        /*SL:640*/return new BlockPos(Math.floor(a1.field_70165_t), Math.floor(a1.field_70163_u), Math.floor(a1.field_70161_v));
    }
    
    public static float calculateDamage(final double a1, final double a2, final double a3, final Entity a4) {
        final float v1 = /*EL:644*/12.0f;
        final double v2 = /*EL:645*/a4.func_70011_f(a1, a2, a3) / v1;
        final Vec3d v3 = /*EL:646*/new Vec3d(a1, a2, a3);
        double v4 = /*EL:647*/0.0;
        try {
            /*SL:649*/v4 = a4.field_70170_p.func_72842_a(v3, a4.func_174813_aQ());
        }
        catch (Exception ex) {}
        final double v5 = /*EL:651*/(1.0 - v2) * v4;
        final float v6 = /*EL:652*/(int)((v5 * v5 + v5) / 2.0 * 7.0 * v1 + 1.0);
        double v7 = /*EL:653*/1.0;
        /*SL:654*/if (a4 instanceof EntityLivingBase) {
            /*SL:655*/v7 = getBlastReduction((EntityLivingBase)a4, getDamageMultiplied(v6), new Explosion((World)Minecraft.func_71410_x().field_71441_e, (Entity)null, a1, a2, a3, 6.0f, false, true));
        }
        /*SL:657*/return (float)v7;
    }
    
    public static float getBlastReduction(final EntityLivingBase v-6, final float v-5, final Explosion v-4) {
        /*SL:662*/if (v-6 instanceof EntityPlayer) {
            final EntityPlayer a1 = /*EL:663*/(EntityPlayer)v-6;
            final DamageSource a2 = /*EL:664*/DamageSource.func_94539_a(v-4);
            float n = /*EL:665*/CombatRules.func_189427_a(v-5, (float)a1.func_70658_aO(), (float)a1.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
            int a3 = /*EL:667*/0;
            try {
                /*SL:669*/a3 = EnchantmentHelper.func_77508_a(a1.func_184193_aE(), a2);
            }
            catch (Exception ex) {}
            final float v1 = /*EL:671*/MathHelper.func_76131_a((float)a3, 0.0f, 20.0f);
            /*SL:672*/n *= 1.0f - v1 / 25.0f;
            /*SL:674*/if (v-6.func_70644_a(MobEffects.field_76429_m)) {
                /*SL:675*/n -= n / 4.0f;
            }
            /*SL:678*/n = Math.max(n, 0.0f);
            /*SL:679*/return n;
        }
        float n = /*EL:681*/CombatRules.func_189427_a(v-5, (float)v-6.func_70658_aO(), (float)v-6.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
        /*SL:682*/return n;
    }
    
    public static float getDamageMultiplied(final float a1) {
        final int v1 = /*EL:686*/Minecraft.func_71410_x().field_71441_e.func_175659_aa().func_151525_a();
        /*SL:687*/return a1 * ((v1 == 0) ? 0.0f : ((v1 == 2) ? 1.0f : ((v1 == 1) ? 0.5f : 1.5f)));
    }
    
    public static float calculateDamage(final Entity a1, final Entity a2) {
        /*SL:691*/return calculateDamage(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v, a2);
    }
    
    public static float calculateDamage(final BlockPos a1, final Entity a2) {
        /*SL:695*/return calculateDamage(a1.func_177958_n() + 0.5, a1.func_177956_o() + 1, a1.func_177952_p() + 0.5, a2);
    }
    
    public static Vec3d interpolateEntity(final Entity a1) {
        /*SL:699*/return new Vec3d(a1.field_70142_S + (a1.field_70165_t - a1.field_70142_S) * CombatUtil.mc.func_184121_ak(), a1.field_70137_T + (a1.field_70163_u - a1.field_70137_T) * CombatUtil.mc.func_184121_ak(), a1.field_70136_U + (a1.field_70161_v - a1.field_70136_U) * CombatUtil.mc.func_184121_ak());
    }
    
    public static float[] calcAngle(final Vec3d a1, final Vec3d a2) {
        final double v1 = /*EL:703*/a2.field_72450_a - a1.field_72450_a;
        final double v2 = /*EL:704*/(a2.field_72448_b - a1.field_72448_b) * -1.0;
        final double v3 = /*EL:705*/a2.field_72449_c - a1.field_72449_c;
        final double v4 = /*EL:706*/MathHelper.func_76133_a(v1 * v1 + v3 * v3);
        /*SL:707*/return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(v3, v1)) - 90.0), (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(v2, v4))) };
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = /*EL:711*/new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v);
        final double v2 = /*EL:712*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:713*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:714*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:715*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:717*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:718*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:720*/return new float[] { CombatUtil.mc.field_71439_g.field_70177_z + /*EL:721*/MathHelper.func_76142_g(v6 - CombatUtil.mc.field_71439_g.field_70177_z), CombatUtil.mc.field_71439_g.field_70125_A + /*EL:722*/MathHelper.func_76142_g(v7 - CombatUtil.mc.field_71439_g.field_70125_A) };
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150329_H, Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        CombatUtil.mc = Minecraft.func_71410_x();
        cityOffsets = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 2.0), new Vec3d(-2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -2.0) };
        invalidSlots = Arrays.<Integer>asList(0, 5, 6, 7, 8);
    }
    
    public static class ValidPosThread extends Thread
    {
        BlockPos pos;
        EntityPlayer player;
        double maxSelfDamage;
        double maxFriendDamage;
        double minDamage;
        double placeRange;
        double wallsRange;
        double friendRange;
        boolean rayTrace;
        boolean antiSuicide;
        boolean antiFriendPop;
        public float damage;
        public boolean isValid;
        public CombatPosInfo info;
        
        public ValidPosThread(final EntityPlayer a1, final BlockPos a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8, final boolean a9, final boolean a10, final boolean a11) {
            super("Break");
            this.pos = a2;
            this.maxSelfDamage = a3;
            this.maxFriendDamage = a4;
            this.minDamage = a5;
            this.placeRange = a6;
            this.wallsRange = a7;
            this.friendRange = a8;
            this.rayTrace = a9;
            this.antiSuicide = a10;
            this.antiFriendPop = a11;
            this.player = a1;
        }
        
        @Override
        public void run() {
            /*SL:516*/if (CombatUtil.mc.field_71439_g.func_174818_b(this.pos) <= this.placeRange * this.placeRange && CombatUtil.canPlaceCrystal(this.pos, this.placeRange, this.wallsRange, this.rayTrace) && CombatUtil.checkFriends(this.pos, this.maxFriendDamage, this.friendRange, this.antiFriendPop) && /*EL:517*/CombatUtil.checkSelf(this.pos, this.maxSelfDamage, this.antiSuicide)) {
                /*SL:518*/this.damage = CombatUtil.calculateDamage(this.pos, (Entity)this.player);
                /*SL:519*/if (this.damage >= this.minDamage && /*EL:520*/(!this.rayTrace || CombatUtil.rayTraceRangeCheck(this.pos, this.wallsRange, 0.0))) {
                    /*SL:521*/this.isValid = true;
                    /*SL:522*/this.info = new CombatPosInfo(this.player, this.pos, this.damage);
                    Legacy.LOGGER.info(/*EL:523*/"Pos was valid.");
                    /*SL:524*/return;
                }
            }
            /*SL:531*/this.isValid = false;
            /*SL:532*/this.info = new CombatPosInfo(this.player, this.pos, -1.0f);
            Legacy.LOGGER.info(/*EL:533*/"Pos was invalid.");
        }
    }
    
    public static class CombatPosInfo
    {
        public EntityPlayer player;
        public BlockPos pos;
        public float damage;
        
        public CombatPosInfo(final EntityPlayer a1, final BlockPos a2, final float a3) {
            this.pos = a2;
            this.damage = a3;
            this.player = a1;
        }
    }
}
