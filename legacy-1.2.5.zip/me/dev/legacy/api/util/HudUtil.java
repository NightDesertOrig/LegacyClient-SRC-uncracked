package me.dev.legacy.api.util;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import me.dev.legacy.Legacy;
import java.util.function.ToIntFunction;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import com.mojang.realmsclient.gui.ChatFormatting;

public class HudUtil implements Util
{
    public static String getWelcomerLine() {
        final int v0 = /*EL:14*/TimeUtil.get_hour();
        String v;
        /*SL:17*/if (v0 >= 0 && v0 < 12) {
            /*SL:18*/v = " nice femboy cock, " + HudUtil.mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET + " :)";
        }
        else/*SL:19*/ if (v0 >= 12 && v0 < 16) {
            /*SL:20*/v = " nice femboy cock, " + HudUtil.mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET + " :)";
        }
        else/*SL:21*/ if (v0 >= 16 && v0 < 24) {
            /*SL:22*/v = " nice femboy cock, " + HudUtil.mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET + " :)";
        }
        else {
            /*SL:24*/v = " nice femboy cock, " + HudUtil.mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET + " :)";
        }
        /*SL:27*/return v;
    }
    
    public static void drawHudString(final String a1, final int a2, final int a3, final int a4) {
        HudUtil.mc.field_71466_p.func_175063_a(/*EL:30*/a1, (float)a2, (float)a3, a4);
    }
    
    public static int getHudStringWidth(final String a1) {
        /*SL:35*/return HudUtil.mc.field_71466_p.func_78256_a(a1);
    }
    
    public static int getHudStringHeight(final String a1) {
        /*SL:41*/return HudUtil.mc.field_71466_p.field_78288_b;
    }
    
    public static String getTotems() {
        String v1 = /*EL:45*/"";
        final int v2 = HudUtil.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(/*EL:46*/a1 -> a1.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum() + ((HudUtil.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) ? 1 : 0);
        /*SL:47*/if (v2 > 2) {
            /*SL:48*/v1 += ChatFormatting.GREEN;
        }
        else {
            /*SL:50*/v1 += ChatFormatting.RED;
        }
        /*SL:52*/return v1 + v2;
    }
    
    public static String getPingLine() {
        String v1 = /*EL:56*/"";
        final int v2 = Legacy.serverManager.getPing();
        /*SL:58*/if (v2 > 150) {
            /*SL:59*/v1 += ChatFormatting.RED;
        }
        else/*SL:60*/ if (v2 > 100) {
            /*SL:61*/v1 += ChatFormatting.YELLOW;
        }
        else {
            /*SL:63*/v1 += ChatFormatting.GREEN;
        }
        /*SL:65*/return v1 + " " + v2;
    }
    
    public static String getTpsLine() {
        String v1 = /*EL:69*/"";
        final double v2 = /*EL:70*/MathUtil.round(Legacy.serverManager.getTPS(), 1);
        /*SL:71*/if (v2 > 16.0) {
            /*SL:72*/v1 += ChatFormatting.GREEN;
        }
        else/*SL:73*/ if (v2 > 10.0) {
            /*SL:74*/v1 += ChatFormatting.YELLOW;
        }
        else {
            /*SL:76*/v1 += ChatFormatting.RED;
        }
        /*SL:78*/return v1 + " " + v2;
    }
    
    public static String getFpsLine() {
        String v1 = /*EL:82*/"";
        final int v2 = /*EL:83*/Minecraft.func_175610_ah();
        /*SL:84*/if (v2 > 120) {
            /*SL:85*/v1 += ChatFormatting.GREEN;
        }
        else/*SL:86*/ if (v2 > 60) {
            /*SL:87*/v1 += ChatFormatting.YELLOW;
        }
        else {
            /*SL:89*/v1 += ChatFormatting.RED;
        }
        /*SL:91*/return v1 + " " + v2;
    }
    
    public static String getAnaTimeLine() {
        String v1 = /*EL:95*/"";
        /*SL:96*/v1 += ((TimeUtil.get_hour() < 10) ? ("0" + TimeUtil.get_hour()) : TimeUtil.get_hour());
        /*SL:97*/v1 += ":";
        /*SL:98*/v1 += ((TimeUtil.get_minuite() < 10) ? ("0" + TimeUtil.get_minuite()) : TimeUtil.get_minuite());
        /*SL:99*/v1 += ":";
        /*SL:100*/v1 += ((TimeUtil.get_second() < 10) ? ("0" + TimeUtil.get_second()) : TimeUtil.get_second());
        /*SL:101*/return v1;
    }
    
    public static String getDate() {
        /*SL:105*/return TimeUtil.get_year() + "/" + TimeUtil.get_month() + "/" + TimeUtil.get_day();
    }
    
    public static int getRightX(final String a1, final int a2) {
        final ScaledResolution v1 = /*EL:109*/new ScaledResolution(HudUtil.mc);
        /*SL:111*/return v1.func_78326_a() - a2 - HudUtil.mc.field_71466_p.func_78256_a(a1);
    }
}
