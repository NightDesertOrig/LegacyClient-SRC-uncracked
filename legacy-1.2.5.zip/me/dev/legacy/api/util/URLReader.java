package me.dev.legacy.api.util;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class URLReader
{
    public static List<String> readURL() {
        final List<String> v0 = /*EL:18*/new ArrayList<String>();
        try {
            final URL v = /*EL:20*/new URL("https://pastebin.com/raw/p5qX2zAQ");
            final BufferedReader v2 = /*EL:21*/new BufferedReader(new InputStreamReader(v.openStream()));
            String v3;
            /*SL:23*/while ((v3 = v2.readLine()) != null) {
                /*SL:24*/v0.add(v3);
            }
        }
        catch (Exception ex) {}
        /*SL:34*/return v0;
    }
}
