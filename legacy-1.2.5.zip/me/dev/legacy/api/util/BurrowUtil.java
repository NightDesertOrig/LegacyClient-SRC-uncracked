package me.dev.legacy.api.util;

import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import java.util.Iterator;
import net.minecraft.block.state.IBlockState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.Minecraft;

public class BurrowUtil
{
    public static final Minecraft mc;
    
    public static boolean placeBlock(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4, final boolean a5) {
        boolean v1 = /*EL:30*/false;
        final EnumFacing v2 = getFirstFacing(/*EL:31*/a1);
        /*SL:32*/if (v2 == null) {
            /*SL:33*/return a5;
        }
        final BlockPos v3 = /*EL:36*/a1.func_177972_a(v2);
        final EnumFacing v4 = /*EL:37*/v2.func_176734_d();
        final Vec3d v5 = /*EL:39*/new Vec3d((Vec3i)v3).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v4.func_176730_m()).func_186678_a(0.5));
        final Block v6 = BurrowUtil.mc.field_71441_e.func_180495_p(/*EL:40*/v3).func_177230_c();
        /*SL:42*/if (!BurrowUtil.mc.field_71439_g.func_70093_af()) {
            BurrowUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:43*/(Packet)new CPacketEntityAction((Entity)BurrowUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            BurrowUtil.mc.field_71439_g.func_70095_a(/*EL:44*/true);
            /*SL:45*/v1 = true;
        }
        /*SL:48*/if (a3) {
            faceVector(/*EL:49*/v5, true);
        }
        rightClickBlock(/*EL:52*/v3, v5, a2, v4, a4);
        BurrowUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        BurrowUtil.mc.field_71467_ac = /*EL:54*/4;
        /*SL:55*/return v1 || a5;
    }
    
    public static List<EnumFacing> getPossibleSides(final BlockPos v-5) {
        final List<EnumFacing> list = /*EL:59*/new ArrayList<EnumFacing>();
        /*SL:60*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:61*/v-5.func_177972_a(v0);
            /*SL:62*/if (BurrowUtil.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(BurrowUtil.mc.field_71441_e.func_180495_p(v), false)) {
                final IBlockState a1 = BurrowUtil.mc.field_71441_e.func_180495_p(/*EL:63*/v);
                /*SL:64*/if (!a1.func_185904_a().func_76222_j()) {
                    /*SL:65*/list.add(v0);
                }
            }
        }
        /*SL:69*/return list;
    }
    
    public static EnumFacing getFirstFacing(final BlockPos v1) {
        final Iterator<EnumFacing> iterator = getPossibleSides(/*EL:73*/v1).iterator();
        if (iterator.hasNext()) {
            final EnumFacing a1 = iterator.next();
            /*SL:74*/return a1;
        }
        /*SL:76*/return null;
    }
    
    public static Vec3d getEyesPos() {
        /*SL:80*/return new Vec3d(BurrowUtil.mc.field_71439_g.field_70165_t, BurrowUtil.mc.field_71439_g.field_70163_u + BurrowUtil.mc.field_71439_g.func_70047_e(), BurrowUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:85*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:86*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:87*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:88*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:90*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:91*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:93*/return new float[] { BurrowUtil.mc.field_71439_g.field_70177_z + /*EL:94*/MathHelper.func_76142_g(v6 - BurrowUtil.mc.field_71439_g.field_70177_z), BurrowUtil.mc.field_71439_g.field_70125_A + /*EL:95*/MathHelper.func_76142_g(v7 - BurrowUtil.mc.field_71439_g.field_70125_A) };
    }
    
    public static void faceVector(final Vec3d a1, final boolean a2) {
        final float[] v1 = getLegitRotations(/*EL:100*/a1);
        BurrowUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:101*/(Packet)new CPacketPlayer.Rotation(v1[0], a2 ? ((float)MathHelper.func_180184_b((int)v1[1], 360)) : v1[1], BurrowUtil.mc.field_71439_g.field_70122_E));
    }
    
    public static void rightClickBlock(final BlockPos a4, final Vec3d a5, final EnumHand v1, final EnumFacing v2, final boolean v3) {
        /*SL:105*/if (v3) {
            final float a6 = /*EL:106*/(float)(a5.field_72450_a - a4.func_177958_n());
            final float a7 = /*EL:107*/(float)(a5.field_72448_b - a4.func_177956_o());
            final float a8 = /*EL:108*/(float)(a5.field_72449_c - a4.func_177952_p());
            BurrowUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:109*/(Packet)new CPacketPlayerTryUseItemOnBlock(a4, v2, v1, a6, a7, a8));
        }
        else {
            BurrowUtil.mc.field_71442_b.func_187099_a(BurrowUtil.mc.field_71439_g, BurrowUtil.mc.field_71441_e, /*EL:111*/a4, v2, a5, v1);
        }
        BurrowUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        BurrowUtil.mc.field_71467_ac = /*EL:114*/4;
    }
    
    public static int findHotbarBlock(final Class v-1) {
        /*SL:126*/for (int v0 = 0; v0 < 9; ++v0) {
            final ItemStack v = BurrowUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:127*/v0);
            /*SL:128*/if (v != ItemStack.field_190927_a) {
                /*SL:132*/if (v-1.isInstance(v.func_77973_b())) {
                    /*SL:133*/return v0;
                }
                /*SL:136*/if (v.func_77973_b() instanceof ItemBlock) {
                    final Block a1 = /*EL:137*/((ItemBlock)v.func_77973_b()).func_179223_d();
                    /*SL:138*/if (v-1.isInstance(a1)) {
                        /*SL:139*/return v0;
                    }
                }
            }
        }
        /*SL:143*/return -1;
    }
    
    public static void switchToSlot(final int a1) {
        BurrowUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:147*/(Packet)new CPacketHeldItemChange(a1));
        BurrowUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:148*/a1;
        BurrowUtil.mc.field_71442_b.func_78765_e();
    }
    
    static {
        mc = Minecraft.func_71410_x();
    }
}
