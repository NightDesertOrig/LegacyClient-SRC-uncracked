package me.dev.legacy.api.util;

import javax.swing.JFrame;

public class Gui extends JFrame
{
    public RefreshLog thread;
    
    public void setThead(final RefreshLog a1) {
        /*SL:19*/this.thread = a1;
    }
    
    static class RefreshLog extends Thread
    {
        public Gui INSTANCE;
        public boolean running;
        
        public RefreshLog(final Gui a1) {
            this.INSTANCE = /*EL:20*/a1;
            this.running = true;
        }
    }
}
