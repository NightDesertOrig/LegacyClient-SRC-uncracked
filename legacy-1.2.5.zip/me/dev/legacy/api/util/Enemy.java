package me.dev.legacy.api.util;

public class Enemy
{
    public String username;
    
    public Enemy(final String a1) {
        this.username = a1;
    }
    
    public String getUsername() {
        /*SL:11*/return this.username;
    }
}
