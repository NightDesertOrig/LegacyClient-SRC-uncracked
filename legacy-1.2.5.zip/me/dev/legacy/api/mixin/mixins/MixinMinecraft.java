package me.dev.legacy.api.mixin.mixins;

import me.dev.legacy.modules.render.NoRender;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import me.dev.legacy.modules.player.MultiTask;
import net.minecraft.client.entity.EntityPlayerSP;
import me.dev.legacy.Legacy;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.events.other.KeyEvent;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.crash.CrashReport;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ Minecraft.class })
public abstract class MixinMinecraft
{
    @Inject(method = { "shutdownMinecraftApplet" }, at = { @At("HEAD") })
    private void stopClient(final CallbackInfo a1) {
        /*SL:24*/this.unload();
    }
    
    @Redirect(method = { "run" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
    public void displayCrashReport(final Minecraft a1, final CrashReport a2) {
        /*SL:29*/this.unload();
    }
    
    @Inject(method = { "runTickKeyboard" }, at = { @At(value = "INVOKE", remap = false, target = "Lorg/lwjgl/input/Keyboard;getEventKey()I", ordinal = 0, shift = At.Shift.BEFORE) })
    private void onKeyboard(final CallbackInfo v2) {
        final int v4;
        final int v3 = /*EL:35*/v4 = ((Keyboard.getEventKey() == 0) ? (Keyboard.getEventCharacter() + '\u0100') : Keyboard.getEventKey());
        /*SL:36*/if (Keyboard.getEventKeyState()) {
            final KeyEvent a1 = /*EL:37*/new KeyEvent(v3);
            MinecraftForge.EVENT_BUS.post(/*EL:38*/(Event)a1);
        }
    }
    
    private void unload() {
        Legacy.LOGGER.info(/*EL:43*/"Initiated client shutdown.");
        /*SL:44*/Legacy.onUnload();
        Legacy.LOGGER.info(/*EL:45*/"Finished client shutdown.");
    }
    
    @Redirect(method = { "sendClickBlockToController" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z"))
    private boolean isHandActiveWrapper(final EntityPlayerSP a1) {
        /*SL:50*/return !MultiTask.getInstance().isOn() && a1.func_184587_cr();
    }
    
    @Redirect(method = { "rightClickMouse" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;getIsHittingBlock()Z", ordinal = 0))
    private boolean isHittingBlockHook(final PlayerControllerMP a1) {
        /*SL:55*/return !MultiTask.getInstance().isOn() && a1.func_181040_m();
    }
    
    @Redirect(method = { "runTick" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/WorldClient;doVoidFogParticles(III)V"))
    public void doVoidFogParticlesHook(final WorldClient a1, final int a2, final int a3, final int a4) {
        /*SL:60*/NoRender.getInstance().doVoidFogParticles(a2, a3, a4);
    }
}
