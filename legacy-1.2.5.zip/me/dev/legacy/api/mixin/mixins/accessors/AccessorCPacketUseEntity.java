package me.dev.legacy.api.mixin.mixins.accessors;

import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.network.play.client.CPacketUseEntity;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ CPacketUseEntity.class })
public interface AccessorCPacketUseEntity
{
    @Accessor("entityId")
    void setEntityId(int p0);
    
    @Accessor("action")
    void setAction(CPacketUseEntity.Action p0);
}
