package me.dev.legacy.api.mixin.mixins.accessors;

import org.spongepowered.asm.mixin.gen.Invoker;
import net.minecraft.client.multiplayer.ServerAddress;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ ServerAddress.class })
public interface IServerAddress
{
    @Invoker("getServerAddress")
    default String[] getServerAddress(String a1) {
        /*SL:11*/throw new IllegalStateException("Mixin didnt transform this");
    }
}
