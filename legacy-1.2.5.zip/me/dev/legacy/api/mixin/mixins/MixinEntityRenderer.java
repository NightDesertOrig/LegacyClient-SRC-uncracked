package me.dev.legacy.api.mixin.mixins;

import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.render.NoRender;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.util.glu.Project;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.events.render.PerspectiveEvent;
import me.dev.legacy.MinecraftInstance;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import java.util.ArrayList;
import net.minecraft.init.Items;
import net.minecraft.item.ItemPickaxe;
import me.dev.legacy.modules.misc.NoHitBox;
import java.util.List;
import com.google.common.base.Predicate;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.Entity;
import net.minecraft.client.multiplayer.WorldClient;
import org.spongepowered.asm.mixin.Final;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ EntityRenderer.class })
public abstract class MixinEntityRenderer
{
    private boolean injection;
    @Shadow
    public ItemStack field_190566_ab;
    @Shadow
    @Final
    public Minecraft field_78531_r;
    
    public MixinEntityRenderer() {
        this.injection = true;
    }
    
    @Shadow
    public abstract void func_78473_a(final float p0);
    
    @Redirect(method = { "getMouseOver" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/WorldClient;getEntitiesInAABBexcluding(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;Lcom/google/common/base/Predicate;)Ljava/util/List;"))
    public List<Entity> getEntitiesInAABBexcluding(final WorldClient a1, final Entity a2, final AxisAlignedBB a3, final Predicate a4) {
        /*SL:54*/if (NoHitBox.getINSTANCE().isOn() && ((Minecraft.func_71410_x().field_71439_g.func_184614_ca().func_77973_b() instanceof ItemPickaxe && NoHitBox.getINSTANCE().pickaxe.getValue()) || (Minecraft.func_71410_x().field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && NoHitBox.getINSTANCE().crystal.getValue()) || (Minecraft.func_71410_x().field_71439_g.func_184614_ca().func_77973_b() == Items.field_151153_ao && NoHitBox.getINSTANCE().gapple.getValue()) || Minecraft.func_71410_x().field_71439_g.func_184614_ca().func_77973_b() == Items.field_151033_d || Minecraft.func_71410_x().field_71439_g.func_184614_ca().func_77973_b() == Items.field_151142_bV)) {
            /*SL:55*/return new ArrayList<Entity>();
        }
        /*SL:57*/return (List<Entity>)a1.func_175674_a(a2, a3, a4);
    }
    
    @Redirect(method = { "setupCameraTransform" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onSetupCameraTransform(final float a1, final float a2, final float a3, final float a4) {
        final PerspectiveEvent v1 = /*EL:62*/new PerspectiveEvent(MinecraftInstance.mc.field_71443_c / MinecraftInstance.mc.field_71440_d);
        MinecraftForge.EVENT_BUS.post(/*EL:63*/(Event)v1);
        /*SL:64*/Project.gluPerspective(a1, v1.getAspect(), a3, a4);
    }
    
    @Redirect(method = { "renderWorldPass" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onRenderWorldPass(final float a1, final float a2, final float a3, final float a4) {
        final PerspectiveEvent v1 = /*EL:69*/new PerspectiveEvent(MinecraftInstance.mc.field_71443_c / MinecraftInstance.mc.field_71440_d);
        MinecraftForge.EVENT_BUS.post(/*EL:70*/(Event)v1);
        /*SL:71*/Project.gluPerspective(a1, v1.getAspect(), a3, a4);
    }
    
    @Redirect(method = { "renderCloudsCheck" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onRenderCloudsCheck(final float a1, final float a2, final float a3, final float a4) {
        final PerspectiveEvent v1 = /*EL:76*/new PerspectiveEvent(MinecraftInstance.mc.field_71443_c / MinecraftInstance.mc.field_71440_d);
        MinecraftForge.EVENT_BUS.post(/*EL:77*/(Event)v1);
        /*SL:78*/Project.gluPerspective(a1, v1.getAspect(), a3, a4);
    }
    
    @Inject(method = { "renderItemActivation" }, at = { @At("HEAD") }, cancellable = true)
    public void renderItemActivationHook(final CallbackInfo a1) {
        /*SL:83*/if (this.field_190566_ab != null && NoRender.getInstance().isOn() && NoRender.getInstance().totemPops.getValue() && this.field_190566_ab.func_77973_b() == Items.field_190929_cY) {
            /*SL:84*/a1.cancel();
        }
    }
    
    @Inject(method = { "updateLightmap" }, at = { @At("HEAD") }, cancellable = true)
    private void updateLightmap(final float a1, final CallbackInfo a2) {
        /*SL:90*/if (NoRender.getInstance().isOn() && (NoRender.getInstance().skylight.getValue() == NoRender.Skylight.ENTITY || NoRender.getInstance().skylight.getValue() == NoRender.Skylight.ALL)) {
            /*SL:91*/a2.cancel();
        }
    }
    
    @Redirect(method = { "setupCameraTransform" }, at = @At(value = "FIELD", target = "Lnet/minecraft/client/entity/EntityPlayerSP;prevTimeInPortal:F"))
    public float prevTimeInPortalHook(final EntityPlayerSP a1) {
        /*SL:97*/if (NoRender.getInstance().isOn() && NoRender.getInstance().nausea.getValue()) {
            /*SL:98*/return -3.4028235E38f;
        }
        /*SL:100*/return a1.field_71080_cy;
    }
    
    @Inject(method = { "setupFog" }, at = { @At("HEAD") }, cancellable = true)
    public void setupFogHook(final int a1, final float a2, final CallbackInfo a3) {
        /*SL:105*/if (NoRender.getInstance().isOn() && NoRender.getInstance().fog.getValue() == NoRender.Fog.NOFOG) {
            /*SL:106*/a3.cancel();
        }
    }
    
    @Redirect(method = { "setupFog" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ActiveRenderInfo;getBlockStateAtEntityViewpoint(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;F)Lnet/minecraft/block/state/IBlockState;"))
    public IBlockState getBlockStateAtEntityViewpointHook(final World a1, final Entity a2, final float a3) {
        /*SL:112*/if (NoRender.getInstance().isOn() && NoRender.getInstance().fog.getValue() == NoRender.Fog.AIR) {
            /*SL:113*/return Blocks.field_150350_a.field_176228_M;
        }
        /*SL:115*/return ActiveRenderInfo.func_186703_a(a1, a2, a3);
    }
    
    @Inject(method = { "hurtCameraEffect" }, at = { @At("HEAD") }, cancellable = true)
    public void hurtCameraEffectHook(final float a1, final CallbackInfo a2) {
        /*SL:120*/if (NoRender.getInstance().isOn() && NoRender.getInstance().hurtcam.getValue()) {
            /*SL:121*/a2.cancel();
        }
    }
}
