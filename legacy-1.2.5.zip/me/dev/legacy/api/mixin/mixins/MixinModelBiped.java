package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.render.NoRender;
import net.minecraft.entity.monster.EntityPigZombie;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBiped;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ ModelBiped.class })
public class MixinModelBiped
{
    @Inject(method = { "render" }, at = { @At("HEAD") }, cancellable = true)
    public void render(final Entity a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final CallbackInfo a8) {
        /*SL:17*/if (a1 instanceof EntityPigZombie && NoRender.getInstance().pigmen.getValue()) {
            /*SL:18*/a8.cancel();
        }
    }
}
