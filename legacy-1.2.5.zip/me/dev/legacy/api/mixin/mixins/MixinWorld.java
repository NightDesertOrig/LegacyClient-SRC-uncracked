package me.dev.legacy.api.mixin.mixins;

import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.events.move.PushEvent;
import me.dev.legacy.modules.render.NoRender;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.misc.Tracker;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.entity.Entity;
import com.google.common.base.Predicate;
import java.util.List;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ World.class })
public class MixinWorld
{
    @Redirect(method = { "getEntitiesWithinAABB(Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;Lcom/google/common/base/Predicate;)Ljava/util/List;" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/chunk/Chunk;getEntitiesOfTypeWithinAABB(Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;Ljava/util/List;Lcom/google/common/base/Predicate;)V"))
    public <T extends Entity> void getEntitiesOfTypeWithinAABBHook(final Chunk a1, final Class<? extends T> a2, final AxisAlignedBB a3, final List<T> a4, final Predicate<? super T> a5) {
        try {
            /*SL:29*/a1.func_177430_a((Class)a2, a3, (List)a4, (Predicate)a5);
        }
        catch (Exception ex) {}
    }
    
    @Inject(method = { "onEntityAdded" }, at = { @At("HEAD") })
    private void onEntityAdded(final Entity a1, final CallbackInfo a2) {
        /*SL:36*/if (Tracker.getInstance().isOn()) {
            /*SL:37*/Tracker.getInstance().onSpawnEntity(a1);
        }
    }
    
    @Inject(method = { "checkLightFor" }, at = { @At("HEAD") }, cancellable = true)
    private void updateLightmapHook(final EnumSkyBlock a1, final BlockPos a2, final CallbackInfoReturnable<Boolean> a3) {
        /*SL:43*/if (a1 == EnumSkyBlock.SKY && NoRender.getInstance().isOn() && (NoRender.getInstance().skylight.getValue() == NoRender.Skylight.WORLD || NoRender.getInstance().skylight.getValue() == NoRender.Skylight.ALL)) {
            /*SL:44*/a3.setReturnValue(true);
            /*SL:45*/a3.cancel();
        }
    }
    
    @Redirect(method = { "handleMaterialAcceleration" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isPushedByWater()Z"))
    public boolean isPushedbyWaterHook(final Entity a1) {
        final PushEvent v1 = /*EL:51*/new PushEvent(2, a1);
        MinecraftForge.EVENT_BUS.post(/*EL:52*/(Event)v1);
        /*SL:53*/return a1.func_96092_aw() && !v1.isCanceled();
    }
}
