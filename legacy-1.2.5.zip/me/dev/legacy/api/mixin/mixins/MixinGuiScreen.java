package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraft.item.ItemShulkerBox;
import me.dev.legacy.modules.misc.ShulkerViewer;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.item.ItemStack;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.Gui;

@Mixin({ GuiScreen.class })
public class MixinGuiScreen extends Gui
{
    @Inject(method = { "renderToolTip" }, at = { @At("HEAD") }, cancellable = true)
    public void renderToolTipHook(final ItemStack a1, final int a2, final int a3, final CallbackInfo a4) {
        /*SL:18*/if (ShulkerViewer.getInstance().isOn() && a1.func_77973_b() instanceof ItemShulkerBox) {
            /*SL:19*/ShulkerViewer.getInstance().renderShulkerToolTip(a1, a2, a3, null);
            /*SL:20*/a4.cancel();
        }
    }
}
