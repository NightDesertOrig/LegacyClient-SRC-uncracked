package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraft.client.renderer.GlStateManager;
import me.dev.legacy.modules.render.ItemViewModel;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.ItemRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ ItemRenderer.class })
public class MixinItemRenderer
{
    @Inject(method = { "renderItemSide" }, at = { @At("HEAD") })
    public void renderItemSide(final EntityLivingBase a1, final ItemStack a2, final ItemCameraTransforms.TransformType a3, final boolean a4, final CallbackInfo a5) {
        /*SL:19*/if (ItemViewModel.INSTANCE.isEnabled()) {
            /*SL:20*/GlStateManager.func_179152_a(ItemViewModel.INSTANCE.scaleX.getValue() / 100.0f, ItemViewModel.INSTANCE.scaleY.getValue() / 100.0f, ItemViewModel.INSTANCE.scaleZ.getValue() / 100.0f);
            /*SL:21*/if (a3 == ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND) {
                /*SL:22*/GlStateManager.func_179109_b(ItemViewModel.INSTANCE.translateX.getValue() / 100.0f, ItemViewModel.INSTANCE.translateY.getValue() / 100.0f, ItemViewModel.INSTANCE.translateZ.getValue() / 100.0f);
                /*SL:23*/GlStateManager.func_179114_b((float)ItemViewModel.INSTANCE.rotateX.getValue(), 1.0f, 0.0f, 0.0f);
                /*SL:24*/GlStateManager.func_179114_b((float)ItemViewModel.INSTANCE.rotateY.getValue(), 0.0f, 1.0f, 0.0f);
                /*SL:25*/GlStateManager.func_179114_b((float)ItemViewModel.INSTANCE.rotateZ.getValue(), 0.0f, 0.0f, 1.0f);
            }
            else/*SL:26*/ if (a3 == ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND) {
                /*SL:27*/GlStateManager.func_179109_b(-ItemViewModel.INSTANCE.translateX.getValue() / 100.0f, ItemViewModel.INSTANCE.translateY.getValue() / 100.0f, ItemViewModel.INSTANCE.translateZ.getValue() / 100.0f);
                /*SL:28*/GlStateManager.func_179114_b((float)(-ItemViewModel.INSTANCE.rotateX.getValue()), 1.0f, 0.0f, 0.0f);
                /*SL:29*/GlStateManager.func_179114_b((float)ItemViewModel.INSTANCE.rotateY.getValue(), 0.0f, 1.0f, 0.0f);
                /*SL:30*/GlStateManager.func_179114_b((float)ItemViewModel.INSTANCE.rotateZ.getValue(), 0.0f, 0.0f, 1.0f);
            }
        }
    }
}
