package me.dev.legacy.api.mixin.mixins;

import javax.annotation.Nullable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.entity.RenderManager;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.opengl.GL11;
import me.dev.legacy.modules.render.PlayerChams;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import me.dev.legacy.MinecraftInstance;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.EntityLivingBase;

@Mixin({ RenderLivingBase.class })
public class MixinRenderLivingBase<T extends EntityLivingBase> extends Render implements MinecraftInstance
{
    @Shadow
    protected ModelBase field_77045_g;
    
    @Inject(method = { "renderModel" }, at = { @At("HEAD") }, cancellable = true)
    public void renderModel(final T a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final CallbackInfo a8) {
        /*SL:31*/if (a1 instanceof EntityPlayer && a1 != MixinRenderLivingBase.mc.field_71439_g && PlayerChams.INSTANCE.isEnabled() && PlayerChams.INSTANCE.chams.getValue()) {
            /*SL:32*/GL11.glPushAttrib(1048575);
            /*SL:33*/GL11.glDisable(3008);
            /*SL:34*/GL11.glDisable(3553);
            /*SL:35*/GL11.glDisable(2896);
            /*SL:36*/GL11.glEnable(3042);
            /*SL:37*/GL11.glBlendFunc(770, 771);
            /*SL:38*/GL11.glDepthMask(false);
            /*SL:39*/GL11.glLineWidth(1.5f);
            /*SL:40*/GL11.glEnable(2960);
            /*SL:41*/GL11.glClear(1024);
            /*SL:42*/GL11.glClearStencil(15);
            /*SL:43*/GL11.glStencilFunc(512, 1, 15);
            /*SL:44*/GL11.glStencilOp(7681, 7681, 7681);
            /*SL:45*/GL11.glPolygonMode(1028, 6913);
            /*SL:46*/GL11.glStencilFunc(512, 0, 15);
            /*SL:47*/GL11.glStencilOp(7681, 7681, 7681);
            /*SL:48*/GL11.glPolygonMode(1028, 6914);
            /*SL:49*/GL11.glStencilFunc(514, 1, 15);
            /*SL:50*/GL11.glStencilOp(7680, 7680, 7680);
            /*SL:51*/GL11.glPolygonMode(1028, 6913);
            /*SL:52*/GL11.glDisable(2929);
            /*SL:53*/GL11.glDepthMask(false);
            /*SL:54*/GL11.glEnable(10754);
            /*SL:55*/OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
            /*SL:56*/GL11.glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
            /*SL:57*/GL11.glColor4d((double)(PlayerChams.INSTANCE.invisibleRed.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.invisibleGreen.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.invisibleBlue.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.alpha.getValue() / 255.0f));
            /*SL:58*/this.field_77045_g.func_78088_a((Entity)a1, a2, a3, a4, a5, a6, a7);
            /*SL:59*/GL11.glEnable(2929);
            /*SL:60*/GL11.glDepthMask(true);
            /*SL:61*/GL11.glColor4d((double)(PlayerChams.INSTANCE.visibleRed.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.visibleGreen.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.visibleBlue.getValue() / 255.0f), (double)(PlayerChams.INSTANCE.alpha.getValue() / 255.0f));
            /*SL:62*/this.field_77045_g.func_78088_a((Entity)a1, a2, a3, a4, a5, a6, a7);
            /*SL:63*/GL11.glEnable(3042);
            /*SL:64*/GL11.glEnable(2896);
            /*SL:65*/GL11.glEnable(3553);
            /*SL:66*/GL11.glEnable(3008);
            /*SL:67*/GL11.glPopAttrib();
            /*SL:68*/a8.cancel();
        }
    }
    
    @Inject(method = { "renderLayers" }, at = { @At("RETURN") })
    public void renderLayers(final T a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8, final CallbackInfo a9) {
        /*SL:75*/if (a1 instanceof EntityPlayer && PlayerChams.INSTANCE.isEnabled() && PlayerChams.INSTANCE.wireframe.getValue()) {
            PlayerChams.INSTANCE.onRenderModel(/*EL:76*/this.field_77045_g, (Entity)a1, a2, a3, a5, a6, a7, a8);
        }
    }
    
    protected MixinRenderLivingBase(final RenderManager a1) {
        super(a1);
    }
    
    @Nullable
    protected ResourceLocation func_110775_a(final Entity a1) {
        /*SL:87*/return null;
    }
}
