package me.dev.legacy.api.mixin.mixins;

import me.dev.legacy.Legacy;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.render.NoRender;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.ScaledResolution;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiIngame;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.Gui;

@Mixin({ GuiIngame.class })
public class MixinGuiIngame extends Gui
{
    @Shadow
    @Final
    public GuiNewChat field_73840_e;
    
    @Inject(method = { "renderPortal" }, at = { @At("HEAD") }, cancellable = true)
    protected void renderPortalHook(final float a1, final ScaledResolution a2, final CallbackInfo a3) {
        /*SL:25*/if (NoRender.getInstance().isOn() && NoRender.getInstance().portal.getValue()) {
            /*SL:26*/a3.cancel();
        }
    }
    
    @Inject(method = { "renderPumpkinOverlay" }, at = { @At("HEAD") }, cancellable = true)
    protected void renderPumpkinOverlayHook(final ScaledResolution a1, final CallbackInfo a2) {
        /*SL:32*/if (NoRender.getInstance().isOn() && NoRender.getInstance().pumpkin.getValue()) {
            /*SL:33*/a2.cancel();
        }
    }
    
    @Inject(method = { "renderPotionEffects" }, at = { @At("HEAD") }, cancellable = true)
    protected void renderPotionEffectsHook(final ScaledResolution a1, final CallbackInfo a2) {
        /*SL:39*/if (Legacy.moduleManager != null) {
            /*SL:40*/a2.cancel();
        }
    }
}
