package me.dev.legacy.api.mixin;

import java.util.Map;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.launch.MixinBootstrap;
import me.dev.legacy.Legacy;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

public class MixinLoader implements IFMLLoadingPlugin
{
    private static boolean isObfuscatedEnvironment;
    
    public MixinLoader() {
        Legacy.LOGGER.info("\n\nLoading mixins by BlackBro4");
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.legacy.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
        Legacy.LOGGER.info(MixinEnvironment.getDefaultEnvironment().getObfuscationContext());
    }
    
    public String[] getASMTransformerClass() {
        /*SL:24*/return new String[0];
    }
    
    public String getModContainerClass() {
        /*SL:28*/return null;
    }
    
    public String getSetupClass() {
        /*SL:32*/return null;
    }
    
    public void injectData(final Map<String, Object> a1) {
        MixinLoader.isObfuscatedEnvironment = /*EL:36*/a1.get("runtimeDeobfuscationEnabled");
    }
    
    public String getAccessTransformerClass() {
        /*SL:40*/return null;
    }
    
    static {
        MixinLoader.isObfuscatedEnvironment = false;
    }
}
