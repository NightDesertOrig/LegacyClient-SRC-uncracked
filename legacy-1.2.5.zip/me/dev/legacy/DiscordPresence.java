package me.dev.legacy;

import me.dev.legacy.modules.client.RPC;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;

public class DiscordPresence
{
    public static DiscordRichPresence presence;
    private static final DiscordRPC rpc;
    private static Thread thread;
    private static int index;
    
    public static void start() {
        final DiscordEventHandlers v1 = /*EL:17*/new DiscordEventHandlers();
        DiscordPresence.rpc.Discord_Initialize(/*EL:18*/"847105722956513312", v1, true, "");
        DiscordPresence.presence.startTimestamp = /*EL:19*/System.currentTimeMillis() / 1000L;
        DiscordPresence.presence.details = /*EL:20*/((Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu) ? "Main menu" : ("Playing " + ((Minecraft.func_71410_x().field_71422_O != null) ? (RPC.INSTANCE.showIP.getValue() ? ("on " + Minecraft.func_71410_x().field_71422_O.field_78845_b + ".") : " multiplayer") : " singleplayer")));
        DiscordPresence.presence.state = /*EL:21*/"Donbass activity";
        DiscordPresence.presence.largeImageKey = /*EL:22*/"legacy-1";
        DiscordPresence.presence.largeImageText = /*EL:23*/"v1.2.5";
        DiscordPresence.presence.smallImageKey = /*EL:24*/"";
        DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
        DiscordRichPresence presence;
        String string;
        String string2;
        final StringBuilder sb;
        (DiscordPresence.thread = /*EL:26*/new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                DiscordPresence.rpc.Discord_RunCallbacks();
                presence = DiscordPresence.presence;
                if (Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu) {
                    string = "Main menu";
                }
                else {
                    new StringBuilder().append("Playing ");
                    if (Minecraft.func_71410_x().field_71422_O != null) {
                        if (RPC.INSTANCE.showIP.getValue()) {
                            string2 = "on " + Minecraft.func_71410_x().field_71422_O.field_78845_b + ".";
                        }
                        else {
                            string2 = " multiplayer";
                        }
                    }
                    else {
                        string2 = " singleplayer";
                    }
                    string = sb.append(string2).toString();
                }
                presence.details = string;
                DiscordPresence.presence.state = "Eating kids";
                if (RPC.INSTANCE.users.getValue()) {
                    if (DiscordPresence.index == 6) {
                        DiscordPresence.index = 1;
                    }
                    DiscordPresence.presence.smallImageKey = "user" + DiscordPresence.index;
                    ++DiscordPresence.index;
                    if (DiscordPresence.index == 2) {
                        DiscordPresence.presence.smallImageText = /*EL:60*/"BlackBro4";
                    }
                    /*SL:61*/if (DiscordPresence.index == 3) {
                        DiscordPresence.presence.smallImageText = "rianix";
                    }
                    if (DiscordPresence.index == 4) {
                        DiscordPresence.presence.smallImageText = "Sudmarin";
                    }
                    if (DiscordPresence.index == 5) {
                        DiscordPresence.presence.smallImageText = "Ziasan";
                    }
                    if (DiscordPresence.index == 6) {
                        DiscordPresence.presence.smallImageText = "end41r";
                    }
                }
                DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException ex) {}
            }
        }, "RPC-Callback-Handler")).start();
    }
    
    public static void stop() {
        /*SL:64*/if (DiscordPresence.thread != null && !DiscordPresence.thread.isInterrupted()) {
            DiscordPresence.thread.interrupt();
        }
        DiscordPresence.rpc.Discord_Shutdown();
    }
    
    static {
        DiscordPresence.index = 1;
        rpc = DiscordRPC.INSTANCE;
        DiscordPresence.presence = new DiscordRichPresence();
    }
}
