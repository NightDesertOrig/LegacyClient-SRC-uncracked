package me.dev.legacy;

import net.minecraft.client.Minecraft;

public interface MinecraftInstance
{
    public static final Minecraft mc = Minecraft.func_71410_x();
}
