package me.dev.legacy.impl.gui.components.items.buttons;

import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.gui.LegacyGui;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.impl.setting.Setting;

public class StringButton extends Button
{
    private final Setting setting;
    public boolean isListening;
    private CurrentString currentString;
    
    public StringButton(final Setting a1) {
        super(a1.getName());
        this.currentString = new CurrentString("");
        this.setting = a1;
        this.width = 15;
    }
    
    public static String removeLastChar(final String a1) {
        String v1 = /*EL:27*/"";
        /*SL:28*/if (a1 != null && a1.length() > 0) {
            /*SL:29*/v1 = a1.substring(0, a1.length() - 1);
        }
        /*SL:31*/return v1;
    }
    
    @Override
    public void drawScreen(final int a1, final int a2, final float a3) {
        final int v1 = /*EL:36*/ColorUtil.toARGB(ClickGui.getInstance().fontcolorr.getValue(), ClickGui.getInstance().fontcolorb.getValue(), ClickGui.getInstance().fontcolorb.getValue(), 255);
        /*SL:38*/RenderUtil.drawRect(this.x, this.y, this.x + this.width + 7.4f + 20.0f, this.y + this.height - 0.5f, this.getState() ? (this.isHovering(a1, a2) ? Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).alpha.getValue()) : Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).hoverAlpha.getValue())) : (this.isHovering(a1, a2) ? -2007673515 : 290805077));
        /*SL:39*/if (this.isListening) {
            Legacy.textManager.drawStringWithShadow(/*EL:40*/this.currentString.getString() + Legacy.textManager.getIdleSign(), this.x + 2.3f, this.y - 1.7f - LegacyGui.getClickGui().getTextOffset(), this.getState() ? -2 : v1);
        }
        else {
            Legacy.textManager.drawStringWithShadow(/*EL:42*/(this.setting.getName().equals("Buttons") ? "Buttons " : (this.setting.getName().equals("Prefix") ? ("Prefix  " + ChatFormatting.GRAY) : "")) + this.setting.getValue(), this.x + 2.3f, this.y - 1.7f - LegacyGui.getClickGui().getTextOffset(), this.getState() ? -2 : v1);
        }
    }
    
    @Override
    public void mouseClicked(final int a1, final int a2, final int a3) {
        /*SL:48*/super.mouseClicked(a1, a2, a3);
        /*SL:49*/if (this.isHovering(a1, a2)) {
            StringButton.mc.func_147118_V().func_147682_a(/*EL:50*/(ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0f));
        }
    }
    
    @Override
    public void onKeyTyped(final char a1, final int a2) {
        /*SL:56*/if (this.isListening) {
            /*SL:57*/switch (a2) {
                case 1: {
                    /*SL:59*/return;
                }
                case 28: {
                    /*SL:62*/this.enterString();
                }
                case 14: {
                    /*SL:65*/this.setString(removeLastChar(this.currentString.getString()));
                    break;
                }
            }
            /*SL:68*/if (ChatAllowedCharacters.func_71566_a(a1)) {
                /*SL:69*/this.setString(this.currentString.getString() + a1);
            }
        }
    }
    
    @Override
    public void update() {
        /*SL:76*/this.setHidden(!this.setting.isVisible());
    }
    
    private void enterString() {
        /*SL:80*/if (this.currentString.getString().isEmpty()) {
            /*SL:81*/this.setting.setValue(this.setting.getDefaultValue());
        }
        else {
            /*SL:83*/this.setting.setValue(this.currentString.getString());
        }
        /*SL:85*/this.setString("");
        /*SL:86*/this.onMouseClick();
    }
    
    @Override
    public int getHeight() {
        /*SL:91*/return 14;
    }
    
    @Override
    public void toggle() {
        /*SL:96*/this.isListening = !this.isListening;
    }
    
    @Override
    public boolean getState() {
        /*SL:101*/return !this.isListening;
    }
    
    public void setString(final String a1) {
        /*SL:105*/this.currentString = new CurrentString(a1);
    }
    
    public static class CurrentString
    {
        private final String string;
        
        public CurrentString(final String a1) {
            this.string = a1;
        }
        
        public String getString() {
            /*SL:116*/return this.string;
        }
    }
}
