package me.dev.legacy.impl.gui.components;

import me.dev.legacy.impl.gui.components.items.buttons.Button;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import java.util.Iterator;
import me.dev.legacy.impl.gui.LegacyGui;
import java.awt.Color;
import me.dev.legacy.Legacy;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import me.dev.legacy.api.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.impl.gui.components.items.Item;
import java.util.ArrayList;
import me.dev.legacy.api.AbstractModule;

public class Component extends AbstractModule
{
    public static int[] counter1;
    private final ArrayList<Item> items;
    public boolean drag;
    private int x;
    private int y;
    private int x2;
    private int y2;
    private int width;
    private int height;
    private final int barHeight;
    private boolean open;
    private boolean hidden;
    
    public Component(final String a1, final int a2, final int a3, final boolean a4) {
        super(a1);
        this.items = new ArrayList<Item>();
        this.hidden = false;
        this.x = a2;
        this.y = a3;
        this.width = 88;
        this.barHeight = 15;
        this.height = 18;
        this.open = a4;
        this.setupItems();
    }
    
    public void setupItems() {
    }
    
    private void drag(final int a1, final int a2) {
        /*SL:50*/if (!this.drag) {
            /*SL:51*/return;
        }
        /*SL:53*/this.x = this.x2 + a1;
        /*SL:54*/this.y = this.y2 + a2;
    }
    
    public void drawScreen(final int v2, final int v3, final float v4) {
        /*SL:58*/this.drag(v2, v3);
        Component.counter1 = /*EL:59*/new int[] { 1 };
        final float v5 = /*EL:60*/this.open ? (this.getTotalItemHeight() - 2.0f) : 0.0f;
        final int v6 = /*EL:61*/ColorUtil.toARGB(ClickGui.getInstance().endcolorred.getValue(), ClickGui.getInstance().endcolorgreen.getValue(), ClickGui.getInstance().endcolorblue.getValue(), 255);
        final int v7 = /*EL:62*/ColorUtil.toARGB(ClickGui.getInstance().startcolorred.getValue(), ClickGui.getInstance().startcolorgreen.getValue(), ClickGui.getInstance().startcolorblue.getValue(), 255);
        /*SL:64*/Gui.func_73734_a(this.x, this.y - 1, this.x + this.width, this.y + this.height - 6, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB() : v6);
        /*SL:67*/if (this.open) {
            /*SL:68*/RenderUtil.drawRect(this.x, this.y + 12.5f, this.x + this.width, this.y + this.height + v5, 1996488704);
        }
        /*SL:72*/RenderUtil.drawSidewaysGradientRect(this.x, this.y - 5, this.x + this.width + 20, this.y + this.height - 6, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB() : v6, v7);
        final int v8 = /*EL:73*/ColorUtil.toARGB(ClickGui.getInstance().testcolorr.getValue(), ClickGui.getInstance().testcolorgreen.getValue(), ClickGui.getInstance().testcolorblue.getValue(), 255);
        final int v9 = /*EL:74*/ColorUtil.toARGB(ClickGui.getInstance().fontcolorr.getValue(), ClickGui.getInstance().fontcolorg.getValue(), ClickGui.getInstance().fontcolorb.getValue(), 255);
        /*SL:76*/if (this.open) {
            /*SL:77*/RenderUtil.drawRect(this.x, this.y + 12.5f, this.x + this.width + 20, this.y + this.height + v5, v8);
            /*SL:79*/if (ClickGui.getInstance().outline.getValue()) {
                /*SL:81*/GlStateManager.func_179090_x();
                /*SL:82*/GlStateManager.func_179147_l();
                /*SL:83*/GlStateManager.func_179118_c();
                /*SL:84*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
                /*SL:85*/GlStateManager.func_179103_j(7425);
                /*SL:86*/GL11.glBegin(2);
                final Color a1 = /*EL:87*/ClickGui.getInstance().rainbow.getValue() ? Legacy.colorManager.getColor() : new Color(ColorUtil.toARGB(165, 23, 55, 255));
                /*SL:88*/GL11.glColor4f((float)a1.getRed(), (float)a1.getGreen(), (float)a1.getBlue(), (float)a1.getAlpha());
                /*SL:89*/GL11.glVertex3f((float)this.x, this.y - 1.5f - 4.0f, 0.0f);
                /*SL:90*/GL11.glVertex3f((float)(this.x + this.width + 20), this.y - 1.5f - 4.0f, 0.0f);
                /*SL:91*/GL11.glVertex3f((float)(this.x + this.width + 20), this.y + this.height + v5, 5.0f);
                /*SL:92*/GL11.glVertex3f((float)this.x, this.y + this.height + v5, 5.0f);
                /*SL:94*/GL11.glEnd();
                /*SL:95*/GlStateManager.func_179103_j(7424);
                /*SL:96*/GlStateManager.func_179084_k();
                /*SL:97*/GlStateManager.func_179141_d();
                /*SL:98*/GlStateManager.func_179098_w();
            }
        }
        Legacy.textManager.drawStringWithShadow(/*EL:106*/this.getName(), this.x + 3.0f + 30.0f, this.y - 4.0f - LegacyGui.getClickGui().getTextOffset() - 2.0f, v9);
        /*SL:107*/if (this.open) {
            float a2 = /*EL:108*/this.getY() + this.getHeight() - 3.0f;
            /*SL:109*/for (final Item a3 : this.getItems()) {
                /*SL:110*/++Component.counter1[0];
                /*SL:111*/if (a3.isHidden()) {
                    continue;
                }
                /*SL:112*/a3.setLocation(this.x + 2.0f, a2);
                /*SL:113*/a3.setWidth(this.getWidth() - 4);
                /*SL:114*/a3.drawScreen(v2, v3, v4);
                /*SL:115*/a2 += a3.getHeight() + 1.5f;
            }
        }
    }
    
    public void mouseClicked(final int a1, final int a2, final int a3) {
        /*SL:121*/if (a3 == 0 && this.isHovering(a1, a2)) {
            /*SL:122*/this.x2 = this.x - a1;
            /*SL:123*/this.y2 = this.y - a2;
            /*SL:124*/LegacyGui.getClickGui().getComponents().forEach(a1 -> {
                if (a1.drag) {
                    a1.drag = false;
                }
                return;
            });
            /*SL:129*/this.drag = true;
            /*SL:130*/return;
        }
        /*SL:132*/if (a3 == 1 && this.isHovering(a1, a2)) {
            /*SL:133*/this.open = !this.open;
            Component.mc.func_147118_V().func_147682_a(/*EL:134*/(ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0f));
            /*SL:135*/return;
        }
        /*SL:137*/if (!this.open) {
            /*SL:138*/return;
        }
        /*SL:140*/this.getItems().forEach(a4 -> a4.mouseClicked(a1, a2, a3));
    }
    
    public void mouseReleased(final int a1, final int a2, final int a3) {
        /*SL:144*/if (a3 == 0) {
            /*SL:145*/this.drag = false;
        }
        /*SL:147*/if (!this.open) {
            /*SL:148*/return;
        }
        /*SL:150*/this.getItems().forEach(a4 -> a4.mouseReleased(a1, a2, a3));
    }
    
    public void onKeyTyped(final char a1, final int a2) {
        /*SL:154*/if (!this.open) {
            /*SL:155*/return;
        }
        /*SL:157*/this.getItems().forEach(a3 -> a3.onKeyTyped(a1, a2));
    }
    
    public void addButton(final Button a1) {
        /*SL:161*/this.items.add(a1);
    }
    
    public int getX() {
        /*SL:165*/return this.x;
    }
    
    public void setX(final int a1) {
        /*SL:169*/this.x = a1;
    }
    
    public int getY() {
        /*SL:173*/return this.y;
    }
    
    public void setY(final int a1) {
        /*SL:177*/this.y = a1;
    }
    
    public int getWidth() {
        /*SL:181*/return this.width;
    }
    
    public void setWidth(final int a1) {
        /*SL:185*/this.width = a1;
    }
    
    public int getHeight() {
        /*SL:189*/return this.height;
    }
    
    public void setHeight(final int a1) {
        /*SL:193*/this.height = a1;
    }
    
    public boolean isHidden() {
        /*SL:197*/return this.hidden;
    }
    
    public void setHidden(final boolean a1) {
        /*SL:201*/this.hidden = a1;
    }
    
    public boolean isOpen() {
        /*SL:205*/return this.open;
    }
    
    public final ArrayList<Item> getItems() {
        /*SL:209*/return this.items;
    }
    
    private boolean isHovering(final int a1, final int a2) {
        /*SL:213*/return a1 >= this.getX() && a1 <= this.getX() + this.getWidth() && a2 >= this.getY() && a2 <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
    }
    
    private float getTotalItemHeight() {
        float n = /*EL:217*/0.0f;
        /*SL:218*/for (final Item v1 : this.getItems()) {
            /*SL:219*/n += v1.getHeight() + 1.5f;
        }
        /*SL:221*/return n;
    }
    
    static {
        Component.counter1 = new int[] { 1 };
    }
}
