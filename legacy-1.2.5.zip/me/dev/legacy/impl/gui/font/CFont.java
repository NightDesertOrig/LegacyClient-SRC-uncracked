package me.dev.legacy.impl.gui.font;

import org.lwjgl.opengl.GL11;
import java.awt.geom.Rectangle2D;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import net.minecraft.client.renderer.texture.DynamicTexture;
import java.awt.Font;

public class CFont
{
    private final float imgSize = 512.0f;
    protected CharData[] charData;
    protected Font font;
    protected boolean antiAlias;
    protected boolean fractionalMetrics;
    protected int fontHeight;
    protected int charOffset;
    protected DynamicTexture tex;
    
    public CFont(final Font a1, final boolean a2, final boolean a3) {
        this.charData = new CharData[256];
        this.fontHeight = -1;
        this.charOffset = 0;
        this.font = a1;
        this.antiAlias = a2;
        this.fractionalMetrics = a3;
        this.tex = this.setupTexture(a1, a2, a3, this.charData);
    }
    
    protected DynamicTexture setupTexture(final Font a3, final boolean a4, final boolean v1, final CharData[] v2) {
        final BufferedImage v3 = /*EL:28*/this.generateFontImage(a3, a4, v1, v2);
        try {
            /*SL:30*/return new DynamicTexture(v3);
        }
        catch (Exception a5) {
            /*SL:32*/a5.printStackTrace();
            /*SL:33*/return null;
        }
    }
    
    protected BufferedImage generateFontImage(final Font v2, final boolean v3, final boolean v4, final CharData[] v5) {
        /*SL:38*/this.getClass();
        final int v6 = 512;
        final BufferedImage v7 = /*EL:39*/new BufferedImage(v6, v6, 2);
        final Graphics2D v8 = /*EL:40*/(Graphics2D)v7.getGraphics();
        /*SL:41*/v8.setFont(v2);
        /*SL:42*/v8.setColor(new Color(255, 255, 255, 0));
        /*SL:43*/v8.fillRect(0, 0, v6, v6);
        /*SL:44*/v8.setColor(Color.WHITE);
        /*SL:45*/v8.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, v4 ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        /*SL:46*/v8.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, v3 ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        /*SL:47*/v8.setRenderingHint(RenderingHints.KEY_ANTIALIASING, v3 ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
        final FontMetrics v9 = /*EL:48*/v8.getFontMetrics();
        int v10 = /*EL:49*/0;
        int v11 = /*EL:50*/0;
        int v12 = /*EL:51*/1;
        /*SL:52*/for (Rectangle2D a4 = (Rectangle2D)0; a4 < v5.length; ++a4) {
            final char a2 = /*EL:53*/(char)a4;
            final CharData a3 = /*EL:54*/new CharData();
            /*SL:55*/a4 = v9.getStringBounds(String.valueOf(a2), v8);
            /*SL:56*/a3.width = a4.getBounds().width + 8;
            /*SL:57*/a3.height = a4.getBounds().height;
            /*SL:58*/if (v11 + a3.width >= v6) {
                /*SL:59*/v11 = 0;
                /*SL:60*/v12 += v10;
                /*SL:61*/v10 = 0;
            }
            /*SL:63*/if (a3.height > v10) {
                /*SL:64*/v10 = a3.height;
            }
            /*SL:66*/a3.storedX = v11;
            /*SL:67*/a3.storedY = v12;
            /*SL:68*/if (a3.height > this.fontHeight) {
                /*SL:69*/this.fontHeight = a3.height;
            }
            /*SL:71*/v5[a4] = a3;
            /*SL:72*/v8.drawString(String.valueOf(a2), v11 + 2, v12 + v9.getAscent());
            /*SL:73*/v11 += a3.width;
        }
        /*SL:75*/return v7;
    }
    
    public void drawChar(final CharData[] a3, final char a4, final float v1, final float v2) throws ArrayIndexOutOfBoundsException {
        try {
            /*SL:80*/this.drawQuad(v1, v2, a3[a4].width, a3[a4].height, a3[a4].storedX, a3[a4].storedY, a3[a4].width, a3[a4].height);
        }
        catch (Exception a5) {
            /*SL:82*/a5.printStackTrace();
        }
    }
    
    protected void drawQuad(final float a1, final float a2, final float a3, final float a4, final float a5, final float a6, final float a7, final float a8) {
        /*SL:87*/this.getClass();
        final float v1 = a5 / 512.0f;
        /*SL:88*/this.getClass();
        final float v2 = a6 / 512.0f;
        /*SL:89*/this.getClass();
        final float v3 = a7 / 512.0f;
        /*SL:90*/this.getClass();
        final float v4 = a8 / 512.0f;
        /*SL:91*/GL11.glTexCoord2f(v1 + v3, v2);
        /*SL:92*/GL11.glVertex2d((double)(a1 + a3), (double)a2);
        /*SL:93*/GL11.glTexCoord2f(v1, v2);
        /*SL:94*/GL11.glVertex2d((double)a1, (double)a2);
        /*SL:95*/GL11.glTexCoord2f(v1, v2 + v4);
        /*SL:96*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
        /*SL:97*/GL11.glTexCoord2f(v1, v2 + v4);
        /*SL:98*/GL11.glVertex2d((double)a1, (double)(a2 + a4));
        /*SL:99*/GL11.glTexCoord2f(v1 + v3, v2 + v4);
        /*SL:100*/GL11.glVertex2d((double)(a1 + a3), (double)(a2 + a4));
        /*SL:101*/GL11.glTexCoord2f(v1 + v3, v2);
        /*SL:102*/GL11.glVertex2d((double)(a1 + a3), (double)a2);
    }
    
    public int getStringHeight(final String a1) {
        /*SL:106*/return this.getHeight();
    }
    
    public int getHeight() {
        /*SL:110*/return (this.fontHeight - 8) / 2;
    }
    
    public int getStringWidth(final String v2) {
        int v3 = /*EL:114*/0;
        /*SL:115*/for (final char a1 : v2.toCharArray()) {
            /*SL:116*/if (a1 < this.charData.length) {
                if (a1 >= '\0') {
                    /*SL:117*/v3 += this.charData[a1].width - 8 + this.charOffset;
                }
            }
        }
        /*SL:119*/return v3 / 2;
    }
    
    public boolean isAntiAlias() {
        /*SL:123*/return this.antiAlias;
    }
    
    public void setAntiAlias(final boolean a1) {
        /*SL:127*/if (this.antiAlias != a1) {
            /*SL:128*/this.antiAlias = a1;
            /*SL:129*/this.tex = this.setupTexture(this.font, a1, this.fractionalMetrics, this.charData);
        }
    }
    
    public boolean isFractionalMetrics() {
        /*SL:134*/return this.fractionalMetrics;
    }
    
    public void setFractionalMetrics(final boolean a1) {
        /*SL:138*/if (this.fractionalMetrics != a1) {
            /*SL:139*/this.fractionalMetrics = a1;
            /*SL:140*/this.tex = this.setupTexture(this.font, this.antiAlias, a1, this.charData);
        }
    }
    
    public Font getFont() {
        /*SL:145*/return this.font;
    }
    
    public void setFont(final Font a1) {
        /*SL:149*/this.font = a1;
        /*SL:150*/this.tex = this.setupTexture(a1, this.antiAlias, this.fractionalMetrics, this.charData);
    }
    
    protected static class CharData
    {
        public int width;
        public int height;
        public int storedX;
        public int storedY;
    }
}
