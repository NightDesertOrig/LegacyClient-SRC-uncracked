package me.dev.legacy.impl.command.commands;

import me.dev.legacy.impl.command.Command;

public class HistoryCommand extends Command
{
    public HistoryCommand() {
        super("history", new String[] { "<player>" });
    }
    
    @Override
    public void execute(final String[] v-2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_1         /* v-2 */
        //     1: arraylength    
        //     2: iconst_1       
        //     3: if_icmpeq       11
        //     6: aload_1         /* v-2 */
        //     7: arraylength    
        //     8: ifne            35
        //    11: new             Ljava/lang/StringBuilder;
        //    14: dup            
        //    15: invokespecial   java/lang/StringBuilder.<init>:()V
        //    18: getstatic       com/mojang/realmsclient/gui/ChatFormatting.RED:Lcom/mojang/realmsclient/gui/ChatFormatting;
        //    21: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    24: ldc             "Please specify a player."
        //    26: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    29: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    32: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //    35: aload_1         /* v-2 */
        //    36: iconst_0       
        //    37: aaload         
        //    38: invokestatic    me/dev/legacy/api/util/PlayerUtil.getUUIDFromName:(Ljava/lang/String;)Ljava/util/UUID;
        //    41: astore_3        /* a1 */
        //    42: goto            53
        //    45: astore          v1
        //    47: ldc             "An error occured."
        //    49: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //    52: return         
        //    53: aload_3         /* v0 */
        //    54: invokestatic    me/dev/legacy/api/util/PlayerUtil.getHistoryOfNames:(Ljava/util/UUID;)Ljava/util/List;
        //    57: astore_2        /* v-1 */
        //    58: goto            69
        //    61: astore          v1
        //    63: ldc             "An error occured."
        //    65: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //    68: return         
        //    69: aload_2         /* v-1 */
        //    70: ifnull          138
        //    73: new             Ljava/lang/StringBuilder;
        //    76: dup            
        //    77: invokespecial   java/lang/StringBuilder.<init>:()V
        //    80: aload_1         /* v-2 */
        //    81: iconst_0       
        //    82: aaload         
        //    83: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    86: ldc             "\u00c2?s name history:"
        //    88: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    91: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    94: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //    97: aload_2         /* v-1 */
        //    98: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   103: astore          4
        //   105: aload           4
        //   107: invokeinterface java/util/Iterator.hasNext:()Z
        //   112: ifeq            135
        //   115: aload           4
        //   117: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   122: checkcast       Ljava/lang/String;
        //   125: astore          v2
        //   127: aload           v2
        //   129: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //   132: goto            105
        //   135: goto            143
        //   138: ldc             "No names found."
        //   140: invokestatic    me/dev/legacy/impl/command/commands/HistoryCommand.sendMessage:(Ljava/lang/String;)V
        //   143: return         
        //    LocalVariableTable:
        //  Start  Length  Slot  Name  Signature
        //  -----  ------  ----  ----  ----------------------------------------------------
        //  42     3       3     a1    Ljava/util/UUID;
        //  47     6       4     v1    Ljava/lang/Exception;
        //  58     3       2     v-1   Ljava/util/List;
        //  63     6       4     v1    Ljava/lang/Exception;
        //  127    5       5     v2    Ljava/lang/String;
        //  0      144     0     v-3   Lme/dev/legacy/impl/command/commands/HistoryCommand;
        //  0      144     1     v-2   [Ljava/lang/String;
        //  69     75      2     v-1   Ljava/util/List;
        //  53     91      3     v0    Ljava/util/UUID;
        //    LocalVariableTypeTable:
        //  Start  Length  Slot  Name  Signature
        //  -----  ------  ----  ----  ------------------------------------
        //  58     3       2     v-1   Ljava/util/List<Ljava/lang/String;>;
        //  69     75      2     v-1   Ljava/util/List<Ljava/lang/String;>;
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  35     42     45     53     Ljava/lang/Exception;
        //  53     58     61     69     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.ast.AstBuilder.convertLocalVariables(AstBuilder.java:2987)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2446)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:109)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:210)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at cuchaz.enigma.Deobfuscator.getSourceTree(Deobfuscator.java:224)
        //     at cuchaz.enigma.Deobfuscator.writeSources(Deobfuscator.java:306)
        //     at cuchaz.enigma.gui.GuiController$1.run(GuiController.java:110)
        //     at cuchaz.enigma.gui.ProgressDialog$1.run(ProgressDialog.java:98)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
