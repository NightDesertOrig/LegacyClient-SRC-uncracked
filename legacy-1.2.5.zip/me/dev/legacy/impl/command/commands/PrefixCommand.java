package me.dev.legacy.impl.command.commands;

import me.dev.legacy.Legacy;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.command.Command;

public class PrefixCommand extends Command
{
    public PrefixCommand() {
        super("prefix", new String[] { "<char>" });
    }
    
    @Override
    public void execute(final String[] a1) {
        /*SL:15*/if (a1.length == 1) {
            /*SL:16*/Command.sendMessage(ChatFormatting.GREEN + "Current prefix is " + Legacy.commandManager.getPrefix());
            /*SL:17*/return;
        }
        Legacy.commandManager.setPrefix(/*EL:19*/a1[0]);
        /*SL:20*/Command.sendMessage("Prefix changed to " + ChatFormatting.GRAY + a1[0]);
    }
}
