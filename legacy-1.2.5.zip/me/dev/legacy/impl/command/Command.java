package me.dev.legacy.impl.command;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.text.TextComponentBase;
import net.minecraft.util.text.ITextComponent;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.AbstractModule;

public abstract class Command extends AbstractModule
{
    protected String name;
    protected String[] commands;
    
    public Command(final String a1) {
        super(a1);
        this.name = a1;
        this.commands = new String[] { "" };
    }
    
    public Command(final String a1, final String[] a2) {
        super(a1);
        this.name = a1;
        this.commands = a2;
    }
    
    public static void sendMessage(final String a1) {
        sendSilentMessage(Legacy.commandManager.getClientMessage() + /*EL:30*/" " + ChatFormatting.GRAY + a1);
    }
    
    public static void sendSilentMessage(final String a1) {
        /*SL:34*/if (AbstractModule.nullCheck()) {
            /*SL:35*/return;
        }
        Command.mc.field_71439_g.func_145747_a(/*EL:37*/(ITextComponent)new ChatMessage(a1));
    }
    
    public static String getCommandPrefix() {
        /*SL:41*/return Legacy.commandManager.getPrefix();
    }
    
    public abstract void execute(final String[] p0);
    
    @Override
    public String getName() {
        /*SL:48*/return this.name;
    }
    
    public String[] getCommands() {
        /*SL:52*/return this.commands;
    }
    
    public static char coolLineThing() {
        /*SL:85*/return '�';
    }
    
    public static class ChatMessage extends TextComponentBase
    {
        private final String text;
        
        public ChatMessage(final String v2) {
            final Pattern v3 = Pattern.compile("&[0123456789abcdefrlosmk]");
            final Matcher v4 = v3.matcher(v2);
            final StringBuffer v5 = new StringBuffer();
            while (v4.find()) {
                final String a1 = v4.group().substring(1);
                v4.appendReplacement(v5, a1);
            }
            v4.appendTail(v5);
            this.text = v5.toString();
        }
        
        public String func_150261_e() {
            /*SL:72*/return this.text;
        }
        
        public ITextComponent func_150259_f() {
            /*SL:76*/return null;
        }
        
        public ITextComponent shallowCopy() {
            /*SL:80*/return (ITextComponent)new ChatMessage(this.text);
        }
    }
}
