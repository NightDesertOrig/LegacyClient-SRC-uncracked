package me.dev.legacy;

import me.dev.legacy.api.manager.HWIDManager;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "hwidauthmod", name = "HWID-Authentication-System", version = "1.0.0")
public class HWIDAuthMod
{
    public static final String MODID = "hwidauthmod";
    public static final String NAME = "HWID-Authentication-System";
    public static final String VERSION = "1.0.0";
    
    public static String getVersion() {
        /*SL:16*/return "1.0.0";
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent a1) {
        /*SL:21*/HWIDManager.hwidCheck();
    }
}
