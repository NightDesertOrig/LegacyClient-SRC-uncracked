package me.zero.alpine;

public interface EventBus
{
    void subscribe(Object p0);
    
    void subscribe(Object... p0);
    
    void subscribe(Iterable<Object> p0);
    
    void unsubscribe(Object p0);
    
    void unsubscribe(Object... p0);
    
    void unsubscribe(Iterable<Object> p0);
    
    void post(Object p0);
    
    void attach(EventBus p0);
    
    void detach(EventBus p0);
}
