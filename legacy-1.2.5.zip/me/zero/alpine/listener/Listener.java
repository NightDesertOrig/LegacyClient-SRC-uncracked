package me.zero.alpine.listener;

import net.jodah.typetools.TypeResolver;
import java.util.function.Predicate;

public final class Listener<T> implements EventHook<T>
{
    private final Class<T> target;
    private final EventHook<T> hook;
    private final Predicate<T>[] filters;
    private final byte priority;
    
    public Listener(final EventHook<T> a1, final Predicate<T>... a2) {
        this(a1, (byte)3, (Predicate[])a2);
    }
    
    public Listener(final EventHook<T> a1, final byte a2, final Predicate<T>... a3) {
        this.hook = a1;
        this.priority = a2;
        this.target = (Class<T>)TypeResolver.<EventHook, ? extends EventHook>resolveRawArgument(EventHook.class, a1.getClass());
        this.filters = a3;
    }
    
    public final Class<T> getTarget() {
        /*SL:61*/return this.target;
    }
    
    public final byte getPriority() {
        /*SL:75*/return this.priority;
    }
    
    @Override
    public final void invoke(final T v2) {
        /*SL:88*/if (this.filters.length > 0) {
            /*SL:89*/for (final Predicate<T> a1 : this.filters) {
                /*SL:90*/if (!a1.test(v2)) {
                    /*SL:91*/return;
                }
            }
        }
        /*SL:93*/this.hook.invoke(v2);
    }
}
