package me.zero.alpine.fork.listener;

import net.jodah.typetools.TypeResolver;
import java.util.function.Predicate;

public class Listener<T> implements EventHook<T>
{
    private final Class<T> target;
    private final EventHook<T> hook;
    private final Predicate<T>[] filters;
    private final int priority;
    
    public Listener(final EventHook<T> a1, final Predicate<T>... a2) {
        this(a1, 0, (Predicate[])a2);
    }
    
    public Listener(final EventHook<T> a1, final int a2, final Predicate<T>... a3) {
        this.hook = a1;
        this.priority = a2;
        this.target = (Class<T>)TypeResolver.<EventHook, ? extends EventHook>resolveRawArgument(EventHook.class, a1.getClass());
        this.filters = a3;
    }
    
    public Class<T> getTarget() {
        /*SL:64*/return this.target;
    }
    
    public int getPriority() {
        /*SL:77*/return this.priority;
    }
    
    @Override
    public void invoke(final T v2) {
        /*SL:91*/if (this.filters.length > 0) {
            /*SL:92*/for (final Predicate<T> a1 : this.filters) {
                /*SL:93*/if (!a1.test(v2)) {
                    /*SL:94*/return;
                }
            }
        }
        /*SL:98*/this.hook.invoke(v2);
    }
}
