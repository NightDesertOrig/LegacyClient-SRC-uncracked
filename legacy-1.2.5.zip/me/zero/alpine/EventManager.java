package me.zero.alpine;

import java.lang.annotation.Annotation;
import me.zero.alpine.listener.EventHandler;
import java.util.function.Consumer;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Objects;
import java.util.function.Predicate;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import me.zero.alpine.listener.Listener;
import java.util.List;
import java.util.Map;

public class EventManager implements EventBus
{
    private final Map<Object, List<Listener>> SUBSCRIPTION_CACHE;
    private final Map<Class<?>, List<Listener>> SUBSCRIPTION_MAP;
    private final List<EventBus> ATTACHED_BUSES;
    
    public EventManager() {
        this.SUBSCRIPTION_CACHE = new HashMap<Object, List<Listener>>();
        this.SUBSCRIPTION_MAP = new HashMap<Class<?>, List<Listener>>();
        this.ATTACHED_BUSES = new ArrayList<EventBus>();
    }
    
    @Override
    public void subscribe(final Object a1) {
        final List<Listener> v1 = /*EL:37*/this.SUBSCRIPTION_CACHE.computeIfAbsent(a1, a1 -> Arrays.<Field>stream(a1.getClass().getDeclaredFields()).filter(EventManager::isValidField).<Object>map(/*EL:44*/a2 -> asListener(a1, a2)).filter(/*EL:47*/Objects::nonNull).<List<? super Object>, ?>collect((Collector<? super Object, ?, List<? super Object>>)Collectors.<Object>toList()));
        v1.forEach(this::subscribe);
        if (!this.ATTACHED_BUSES.isEmpty()) {
            /*SL:48*/this.ATTACHED_BUSES.forEach(a2 -> a2.subscribe(a1));
        }
    }
    
    @Override
    public void subscribe(final Object... a1) {
        /*SL:53*/Arrays.<Object>stream(a1).forEach(this::subscribe);
    }
    
    @Override
    public void subscribe(final Iterable<Object> a1) {
        /*SL:58*/a1.forEach(this::subscribe);
    }
    
    @Override
    public void unsubscribe(final Object a1) {
        final List<Listener> v1 = /*EL:63*/this.SUBSCRIPTION_CACHE.get(a1);
        /*SL:64*/if (v1 == null) {
            /*SL:65*/return;
        }
        /*SL:67*/this.SUBSCRIPTION_MAP.values().forEach(a2 -> a2.removeIf(v1::contains));
        /*SL:70*/if (!this.ATTACHED_BUSES.isEmpty()) {
            /*SL:71*/this.ATTACHED_BUSES.forEach(a2 -> a2.unsubscribe(a1));
        }
    }
    
    @Override
    public void unsubscribe(final Object... a1) {
        /*SL:76*/Arrays.<Object>stream(a1).forEach(this::unsubscribe);
    }
    
    @Override
    public void unsubscribe(final Iterable<Object> a1) {
        /*SL:81*/a1.forEach(this::unsubscribe);
    }
    
    @Override
    public void post(final Object a1) {
        final List<Listener> v1 = /*EL:87*/this.SUBSCRIPTION_MAP.get(a1.getClass());
        /*SL:88*/if (v1 != null) {
            /*SL:89*/v1.forEach(a2 -> a2.invoke(a1));
        }
        /*SL:92*/if (!this.ATTACHED_BUSES.isEmpty()) {
            /*SL:93*/this.ATTACHED_BUSES.forEach(a2 -> a2.post(a1));
        }
    }
    
    @Override
    public void attach(final EventBus a1) {
        /*SL:98*/if (!this.ATTACHED_BUSES.contains(a1)) {
            /*SL:99*/this.ATTACHED_BUSES.add(a1);
        }
    }
    
    @Override
    public void detach(final EventBus a1) {
        /*SL:104*/if (this.ATTACHED_BUSES.contains(a1)) {
            /*SL:105*/this.ATTACHED_BUSES.remove(a1);
        }
    }
    
    private static boolean isValidField(final Field a1) {
        /*SL:119*/return a1.isAnnotationPresent(EventHandler.class) && Listener.class.isAssignableFrom(a1.getType());
    }
    
    private static Listener asListener(final Object v-1, final Field v0) {
        try {
            final boolean a1 = /*EL:134*/v0.isAccessible();
            /*SL:135*/v0.setAccessible(true);
            final Listener a2 = /*EL:136*/(Listener)v0.get(v-1);
            /*SL:137*/v0.setAccessible(a1);
            /*SL:139*/if (a2 == null) {
                /*SL:140*/return null;
            }
            /*SL:142*/if (a2.getPriority() > 5 || a2.getPriority() < 1) {
                /*SL:143*/throw new RuntimeException("Event Priority out of bounds! %s");
            }
            /*SL:145*/return a2;
        }
        catch (IllegalAccessException v) {
            /*SL:147*/return null;
        }
    }
    
    private void subscribe(final Listener a1) {
        List<Listener> v1;
        int v2;
        for (/*SL:157*/v1 = this.SUBSCRIPTION_MAP.computeIfAbsent(a1.getTarget(), a1 -> new ArrayList()), /*SL:159*/v2 = 0; /*EL:160*/v2 < v1.size() && /*EL:161*/a1.getPriority() >= v1.get(v2).getPriority(); ++v2) {}
        /*SL:166*/v1.add(v2, a1);
    }
}
